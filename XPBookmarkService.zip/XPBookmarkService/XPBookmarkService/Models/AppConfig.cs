// ----------------------------------------------------------------------------
// <copyright file="AppConfig.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System.Xml.Serialization;

namespace XPBookmarkService.Models
{
    /// <summary>
    /// 設定XMLクラス
    /// </summary>
    [XmlRoot("AppConfig")]
    public class AppConfig
    {
        /// <summary>
        /// XProtectサーバー関連情報
        /// </summary>
        [XmlElement("XProtectServer")]
        public XProtectServer XProtectServer { get; set; } = new XProtectServer();

        /// <summary>
        /// フォルダー関連情報
        /// </summary>
        [XmlElement("Folder")]
        public Folder Folder { get; set; } = new Folder();

        /// <summary>
        /// ブックマーク関連情報
        /// </summary>
        [XmlElement("Bookmark")]
        public Bookmark Bookmark { get; set; } = new Bookmark();

        /// <summary>
        /// ログ関連情報
        /// </summary>
        [XmlElement("Log")]
        public Log Log { get; set; } = new Log();
    }

    /// <summary>
    /// XProtectServer
    /// </summary>
    public class XProtectServer
    {
        /// <summary>
        /// XProtect Management Server URI
        /// </summary>
        [XmlElement("Uri")]
        public string Uri { get; set; }

        /// <summary>
        /// ドメイン
        /// </summary>
        [XmlElement("Domain")]
        public string Domain { get; set; }

        /// <summary>
        /// XProtectユーザー
        /// </summary>
        [XmlElement("User")]
        public string User { get; set; }

        /// <summary>
        /// XProtectユーザーパスワード
        /// </summary>
        [XmlElement("Password")]
        public string Password { get; set; }

        /// <summary>
        /// 暗号化パスワード
        /// </summary>
        [XmlElement("EncryptedPassword")]
        public string EncryptedPassword { get; set; }

        /// <summary>
        /// ログインリトライ間隔（ミリ秒）
        /// </summary>
        [XmlElement("LoginRetryInterval")]
        public uint LoginRetryInterval { get; set; }

        /// <summary>
        /// ログインリトライ回数
        /// </summary>
        [XmlElement("LoginRetryCount")]
        public uint LoginRetryCount { get; set; }
    }

    /// <summary>
    /// Folder
    /// </summary>
    public class Folder
    {
        /// <summary>
        /// ホットフォルダーパス
        /// </summary>
        [XmlElement("HotFolderPath")]
        public string HotFolderPath { get; set; }

        /// <summary>
        /// ホットフォルダ監視間隔(ミリ秒)
        /// </summary>
        [XmlElement("HotFolderPollingInterval")]
        public uint HotFolderPollingInterval { get; set; } = 10 * 1000;

        /// <summary>
        /// ブックマーク付与ファイル拡張子
        /// </summary>
        [XmlElement("BookmarkFileExtension")]
        public string BookmarkFileExtension { get; set; }

        /// <summary>
        /// ホットフォルダー内ファイルのコピーリトライ回数
        /// </summary>
        [XmlElement("CopyRetryCount")]
        public int CopyRetryCount { get; set; }

        /// <summary>
        /// コピーリトライ待機時間（ミリ秒）
        /// </summary>
        [XmlElement("CopyRetryInterval")]
        public int CopyRetryInterval { get; set; }

        /// <summary>
        /// ワークフォルダーパス
        /// </summary>
        [XmlElement("WorkFolderPath")]
        public string WorkFolderPath { get; set; }
    }

    /// <summary>
    /// Bookmark
    /// </summary>
    public class Bookmark
    {
        /// <summary>
        /// ブックマーク時刻より前の実際に開始するプレ時間（単位：秒）
        /// </summary>
        [XmlElement("PreTime")]
        public uint PreTime { get; set; } = 10;

        /// <summary>
        /// ブックマーク時刻より後の実際に終了するポスト時間（単位：秒）
        /// </summary>
        [XmlElement("PostTime")]
        public uint PostTime { get; set; } = 100;

        /// <summary>
        /// ブックマーク付与CSVの1行目をヘッダ行とする
        /// </summary>
        [XmlElement("UseCsvHeader")]
        public bool UseCsvHeader { get; set; }

        /// <summary>
        /// CSV配置設定
        /// </summary>
        [XmlElement("CsvColumns")]
        public CsvColumns CsvColumns { get; set; } = new CsvColumns();

        /// <summary>
        /// ヘッドライン関連情報
        /// </summary>
        [XmlElement("Headline")]
        public Affix Headline { get; set; } = new Affix();

        /// <summary>
        /// ディスクリプション関連情報
        /// </summary>
        [XmlElement("Description")]
        public Affix Description { get; set; } = new Affix();
    }

    /// <summary>
    /// 接辞（接頭辞、接尾辞）
    /// </summary>
    public class Affix
    {
        /// <summary>
        /// プレフィックス
        /// </summary>
        [XmlElement("Prefix")]
        public string Prefix { get; set; }

        /// <summary>
        /// サフィックス
        /// </summary>
        [XmlElement("Suffix")]
        public string Suffix { get; set; }
    }

    /// <summary>
    /// CSV配置設定
    /// </summary>
    public class CsvColumns
    {
        /// <summary>
        /// 日時
        /// </summary>
        [XmlAttribute("DateTime")]
        public int DateTime { get; set; }

        /// <summary>
        /// カメラ名
        /// </summary>
        [XmlAttribute("CameraName")]
        public int CameraName { get; set; }

        /// <summary>
        /// ヘッドライン
        /// </summary>
        [XmlAttribute("Headline")]
        public int Headline { get; set; }

        /// <summary>
        /// 説明
        /// </summary>
        [XmlAttribute("Description")]
        public int Description { get; set; } = int.MinValue;
    }

    /// <summary>
    /// Log
    /// </summary>
    public class Log
    {
        /// <summary>
        /// ブックマークが録画映像範囲外に付与された時のログ出力
        /// </summary>
        [XmlElement("OutsideRecordedVideoBookmark")]
        public bool OutsideRecordedVideoBookmark { get; set; }

    }
}
