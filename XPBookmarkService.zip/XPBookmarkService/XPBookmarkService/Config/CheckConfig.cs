// ----------------------------------------------------------------------------
// <copyright file="CheckConfig.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.IO;
using XPBookmarkService.Common;
using XPBookmarkService.Models;
using XPBookmarkService.Services;

namespace XPBookmarkService.Config
{
    /// <summary>
    /// 設定XMLの内容のバリデーションチェッククラス
    /// </summary>
    public static class CheckConfig
    {
        /// <summary>
        /// ログインリトライ間隔のデフォルト値（ミリ秒）
        /// </summary>
        private const int DefaultLoginRetryInterval = 20 * 1000;

        /// <summary>
        /// ホットフォルダ監視間隔のデフォルト値（ミリ秒）
        /// </summary>
        private const int DefaultHotFolderPollingInterval = 10 * 1000;

        /// <summary>
        /// ブックマーク付与ファイルのデフォルト拡張子
        /// </summary>
        private const string DefaultBookmarkFileExtension = ".csv";

        /// <summary>
        /// ファイルコピーリトライ時の待ち時間（ミリ秒）
        /// </summary>
        private const int DefaultCopyRetryInterval = 200;

        /// <summary>
        /// 設定内容の妥当性（フォルダの存在チェック等）確認
        /// </summary>
        /// <returns>チェック結果</returns>
        public static bool Check()
        {
            AppConfig appConfig = Program.GetAppConfigInstace();
            var result = true;

            // ログインリトライ間隔が設定されていなかったらデフォルト値をセットする
            if (appConfig.XProtectServer.LoginRetryInterval == 0)
            {
                appConfig.XProtectServer.LoginRetryInterval = DefaultLoginRetryInterval;
                Logger.Instace.Info($"CheckConfig: set a default value for the login retry interval. interval:{DefaultLoginRetryInterval}");
            }

            // ホットフォルダ監視間隔未設定ならデフォルト値をセット
            if (appConfig.Folder.HotFolderPollingInterval == 0)
            {
                appConfig.XProtectServer.LoginRetryInterval = DefaultLoginRetryInterval;
                Logger.Instace.Info($"CheckConfig: set a default value for the hot folder polling interval. interval:{DefaultHotFolderPollingInterval}");
            }

            // ブックマーク付与ファイル拡張子が指定されていなかったらデフォルトをセットする
            if (string.IsNullOrWhiteSpace(appConfig.Folder.BookmarkFileExtension) == true)
            {
                appConfig.Folder.BookmarkFileExtension = DefaultBookmarkFileExtension;
                Logger.Instace.Info($"CheckConfig: set a default value for the bookmark file pattern. pattern:{DefaultBookmarkFileExtension}");
            }

            // ホットフォルダパス 確認
            if (string.IsNullOrWhiteSpace(appConfig.Folder.HotFolderPath) == true)
            {
                Logger.Instace.Error("CheckConfig: hot folder name is not specified.");
                result = false;
            }
            // ホットフォルダパス URI作成
            else if (!Uri.TryCreate(appConfig.Folder.HotFolderPath, UriKind.Absolute, out var uri))
            {
                Logger.Instace.Error($"CheckConfig: invalid hot folder path. path:\"{appConfig.Folder.HotFolderPath}\"");
                result = false;
            }
            // ネットワークフォルダが指定されている？
            else if (uri.IsUnc)
            {
                Logger.Instace.Error($"CheckConfig: hot folder settings are invalid. path:\"{appConfig.Folder.HotFolderPath}\"");
                result = false;
            }
            else
            {
                // ローカルPC上のホットフォルダの存在確認
                if (Directory.Exists(appConfig.Folder.HotFolderPath) == false)
                {
                    Logger.Instace.Error($"CheckConfig: hot folder was not found. path:\"{appConfig.Folder.HotFolderPath}\"");
                    result = false;
                }
                else
                {
                    Logger.Instace.Info($"CheckConfig: hot folder is on local disk. path:\"{appConfig.Folder.HotFolderPath}\"");
                }
            }

            // ファイルコピーリトライ時の待ち時間が設定されていなかったらデフォルト値をセットする
            if (appConfig.Folder.CopyRetryInterval == 0)
            {
                appConfig.Folder.CopyRetryInterval = DefaultCopyRetryInterval;
                Logger.Instace.Info($"CheckConfig: set a default value for the copy retry wait time. wait time:{DefaultCopyRetryInterval}");
            }

            // 作業用フォルダの存在確認
            if (Directory.Exists(appConfig.Folder.WorkFolderPath) == false)
            {
                Logger.Instace.Error($"CheckConfig: work folder was not found. path:\"{appConfig.Folder.WorkFolderPath}\"");
                result = false;
            }

            // CSV配置設定（重複チェックしない）
            var dateTime = appConfig.Bookmark.CsvColumns.DateTime;
            var cameraName = appConfig.Bookmark.CsvColumns.CameraName;
            var headline = appConfig.Bookmark.CsvColumns.Headline;
            var description = appConfig.Bookmark.CsvColumns.Description;
            var indexMin = (int)BookmarkManager.CsvColumnIndex.Min;
            // 日時 未設定
            if (dateTime == 0)
            {
                Logger.Instace.Error($"CheckConfig: CsvColumns.DateTime not specified.");
                result = false;
            }
            else
            {
                // 範囲外
                if (dateTime < indexMin)
                {
                    Logger.Instace.Error($"CheckConfig: CsvColumns.DateTime is out of range. value:{dateTime}");
                    result = false;
                }
            }
            // カメラ名 未設定
            if (cameraName == 0)
            {
                Logger.Instace.Error($"CheckConfig: CsvColumns.CameraName not specified.");
                result = false;
            }
            else
            {
                // 範囲外
                if (cameraName < indexMin)
                {
                    Logger.Instace.Error($"CheckConfig: CsvColumns.CameraNane is out of range. value:{cameraName}");
                    result = false;
                }
            }
            // ヘッドライン 未設定
            if (headline == 0)
            {
                Logger.Instace.Error($"CheckConfig: CsvColumns.Headline not specified.");
                result = false;
            }
            else
            {
                // 範囲外
                if (headline < indexMin)
                {
                    Logger.Instace.Error($"CheckConfig: CsvColumns.Headline is out of range. value:{headline}");
                    result = false;
                }
            }
            // 説明 未設定
            if (description == int.MinValue)
            {
                // 省略設定
                appConfig.Bookmark.CsvColumns.Description = (int)BookmarkManager.CsvColumnIndex.Optional;
            }
            else
            {
                // 範囲外
                if (description < indexMin && description != (int)BookmarkManager.CsvColumnIndex.Optional)
                {
                    Logger.Instace.Error($"CheckConfig: CsvColumns.Description is out of range. value:{description}");
                    result = false;
                }
            }

            return result;
        }
    }
}
