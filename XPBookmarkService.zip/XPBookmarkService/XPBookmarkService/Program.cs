// ----------------------------------------------------------------------------
// <copyright file="Program.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.IO;
using System.ServiceProcess;
using XPBookmarkService.Common;
using XPBookmarkService.Config;
using XPBookmarkService.Models;

namespace XPBookmarkService
{
    /// <summary>
    /// Programクラス
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// アプリケーションコンフィグインスタンス
        /// </summary>
        private static AppConfig _appConfig = null;

        /// <summary>
        /// アプリケーションコンフィグXMLファイル
        /// </summary>
        private const string AppConfigXmlFile = "XPTraceabilityService.xml";

        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        public static void Main(string[] args)
        {
            Logger.Instace.Info("========== Start service ==========");

            // サービス起動のための初期処理
            if (InitializeServiceBeforeRunning() == false)
            {
                Logger.Instace.Info("Failed the initial processing required to start windows service.");
                Logger.Instace.Info("********** Stop service ***********");
                return;
            }

            if (Environment.UserInteractive)
            {
                // Windowsサービス用をデバッグするためのコードです
                // 出力の種類 : コンソールアプリケーション
                XPBookmarkService service1 = new XPBookmarkService(args);
                service1.TestStartupAndStop(args);
            }
            else
            {
                // Windowsサービス用の正式なコードです
                // 出力の種類 : Windowsアプリケーション
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[]
                {
                    new XPBookmarkService(args)
                };
                ServiceBase.Run(ServicesToRun);
            }

            // 後処理
            EndService();
        }

        /// <summary>
        /// サービスの初期処理
        /// 失敗したらサービスとして起動しない
        /// </summary>
        /// <returns>処理結果</returns>
        private static bool InitializeServiceBeforeRunning()
        {
            // MIPSDK VideoOSの初期化
            VideoOS.Platform.SDK.Environment.Initialize();          // General initialize.  Always required
            VideoOS.Platform.SDK.Export.Environment.Initialize();   // Initialize export references

            // 設定XMLファイルの読み込み
            string location = System.Reflection.Assembly.GetExecutingAssembly().Location;
            FileInfo fi = new FileInfo(location);
            string configFile = Path.Combine(fi.Directory.FullName, AppConfigXmlFile);

            Logger.Instace.Info($"Load config file: \"{configFile}\"");
            XmlConfigSerializer<AppConfig> configSerializer = new XmlConfigSerializer<AppConfig>(configFile);
            try
            {
                _appConfig = configSerializer.Deserialize();
            }
            catch (FileNotFoundException ex)
            {
                Logger.Instace.Error("Configuration file was not found.");
                Logger.Instace.ErrorException(ex);
                return false;
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instace.Error("Configuration file is invalid.");
                Logger.Instace.ErrorException(ex);
                return false;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error("Exception occurred while reading the configuration file.");
                Logger.Instace.ErrorException(ex);
                return false;
            }

            // 設定XMLのバリデーションチェック
            if (CheckConfig.Check() == false)
            {
                Logger.Instace.Error("Invalid configuration data.");
                return false;
            }

            try
            {
                // パスワード暗号化・保存
                SaveEncryptedPasswords(configSerializer);
                // 暗号化パスワード復号化
                DecryptPasswords();
            }
            catch (Exception ex)
            {
                Logger.Instace.Error("Exception occurred in password encryption processing.");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Error(ex.ToString());
                return false;
            }

            return true;
        }

        /// <summary>
        /// サービスの後処理
        /// </summary>
        /// <returns></returns>
        private static bool EndService()
        {
            Logger.Instace.Info("********** Stop service ***********");
            return true;
        }

        /// <summary>
        /// 設定XMLの平文パスワードの暗号化と保存を行う
        /// </summary>
        /// <param name="configSerializer"></param>
        /// <returns></returns>
        private static void SaveEncryptedPasswords(XmlConfigSerializer<AppConfig> configSerializer)
        {
            var enc = new Encrypter();
            var saveCconfig = false;

            if (!string.IsNullOrEmpty(_appConfig.XProtectServer.Password))
            {
                _appConfig.XProtectServer.EncryptedPassword = enc.Encrypt(_appConfig.XProtectServer.Password);
                _appConfig.XProtectServer.Password = null;
                saveCconfig = true;
            }

            if (saveCconfig == true)
            {
                configSerializer.Serialize(_appConfig);
            }

            return;
        }

        private static void DecryptPasswords()
        {
            var enc = new Encrypter();

            if (!string.IsNullOrEmpty(_appConfig.XProtectServer.EncryptedPassword))
            {
                _appConfig.XProtectServer.Password = enc.Decrypt(_appConfig.XProtectServer.EncryptedPassword);
            }
        }

        /// <summary>
        /// アプリケーションコンフィグインスタンスを取得する
        /// </summary>
        /// <returns></returns>
        public static AppConfig GetAppConfigInstace() => _appConfig;
    }
}
