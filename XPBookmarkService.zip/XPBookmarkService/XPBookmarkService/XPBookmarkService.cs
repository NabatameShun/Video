// ----------------------------------------------------------------------------
// <copyright file="XPBookmarkService.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using VideoOS.Platform;
using XPBookmarkService.Common;
using XPBookmarkService.Models;
using XPBookmarkService.Services;

namespace XPBookmarkService
{
    using Timer = System.Timers.Timer;

    /// <summary>
    /// サービスクラス
    /// </summary>
    public partial class XPBookmarkService : ServiceBase
    {
        /// <summary>
        /// XProtect Management Serverクラスインスタンス
        /// </summary>
        private XPManagementServer _xpManagementServer = null;

        /// <summary>
        /// XProtectログイン用タイマー
        /// </summary>
        private static Timer _xprotectLoginIntervalTimer = null;

        /// <summary>
        /// XProtectログインリトライカウント
        /// </summary>
        private int _xprotectLoginRetryCount = 0;

        /// <summary>
        /// ホットフォルダ監視用タイマー
        /// </summary>
        private static Timer _hotfolderWatchIntervalTimer = null;

        /// <summary>
        /// ブックマーク管理インスタンス
        /// </summary>
        private static BookmarkManager _bookmarkManager = null;

        /// <summary>
        /// 接続処理実行中フラグ
        /// </summary>
        private static bool IsExecConnectProc = false;

        /// <summary>
        /// ブックマーク処理実行中フラグ
        /// </summary>
        private static bool IsExecBookmarkProc = false;

        /// <summary>
        /// 設定情報
        /// </summary>
        private readonly AppConfig appConfig = Program.GetAppConfigInstace();

        /// <summary>
        /// カメラ一覧
        /// </summary>
        public static Dictionary<FQID, string> CameraFqidList { get; private set; } = new Dictionary<FQID, string>();

        /// <summary>
        /// XProtectログイン処理が起動時かどうかのフラグ
        /// true:起動時, false:実行中
        /// </summary>
        private bool XpLoginStartup { get; set; } = true;

        /// <summary>
        /// XProtect接続処理結果
        /// </summary>
        private LoginResult XprotectLoginResult { get; set; } = LoginResult.None;

        /// <summary>
        /// サービス停止要求トークンソース
        /// </summary>
        private static CancellationTokenSource StopServiceRequestTokenSource;

        /// <summary>
        /// サービス停止要求トークン
        /// </summary>
        private static CancellationToken StopServiceRequestToken;

        /// <summary>
        /// サービスステータス
        /// </summary>
        public enum ServiceState
        {
            SERVICE_STOPPED = 0x00000001,
            SERVICE_START_PENDING = 0x00000002,
            SERVICE_STOP_PENDING = 0x00000003,
            SERVICE_RUNNING = 0x00000004,
            SERVICE_CONTINUE_PENDING = 0x00000005,
            SERVICE_PAUSE_PENDING = 0x00000006,
            SERVICE_PAUSED = 0x00000007,
        }

        /// <summary>
        /// ログイン結果
        /// </summary>
        private enum LoginResult
        {
            /// <summary>未実施</summary>
            None,
            /// <summary>成功</summary>
            Success,
            /// <summary>失敗</summary>
            Failure,
            /// <summary>リトライ回数超過</summary>
            RetryOver,
        }

        /// <summary>
        /// サービスステータス構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct ServiceStatus
        {
            public int dwServiceType;
            public ServiceState dwCurrentState;
            public int dwControlsAccepted;
            public int dwWin32ExitCode;
            public int dwServiceSpecificExitCode;
            public int dwCheckPoint;
            public int dwWaitHint;
        };

        /// <summary>
        /// 呼び出し側サービスに関するサービス制御マネージャのステータス情報を更新する
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="serviceStatus"></param>
        /// <returns></returns>
        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool SetServiceStatus(IntPtr handle, ref ServiceStatus serviceStatus);

        /// <summary>
        /// デバッグ用コンソール表示
        /// </summary>
        /// <returns></returns>
        [DllImport("kernel32.dll")]
        private static extern bool AllocConsole();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="args"></param>
        public XPBookmarkService(string[] _)
        {
            this.InitializeComponent();

            this.CreateHotFolderWatchTimer();
            this.CreateXProtectLoginTimer();

            StopServiceRequestTokenSource = new CancellationTokenSource();
            StopServiceRequestToken = StopServiceRequestTokenSource.Token;
        }

        /// <summary>
        /// デバッグ用アプリ実行
        /// </summary>
        /// <param name="args">引数リスト</param>
        internal void TestStartupAndStop(string[] args)
        {
            AllocConsole(); // デバッグ用コンソール表示

            this.OnStart(args);
            Console.WriteLine("Exit for press \"Enter\" key.");
            Task.Run(async delegate
            {
                while (Console.ReadLine() == null)
                {
                    await Task.Delay(1000);
                }
            }).Wait();
            if (_xprotectLoginIntervalTimer != null && _hotfolderWatchIntervalTimer != null)
            {
                this.Stop();
            }
        }

        /// <summary>
        /// サービスの開始
        /// </summary>
        /// <param name="args"></param>
        protected override void OnStart(string[] args)
        {
            Logger.Instace.Info("Service initialize start.");

            // サービス状態を「開始保留」に更新する
            var serviceStatus = new ServiceStatus() { dwCurrentState = ServiceState.SERVICE_START_PENDING, dwWaitHint = 100000 };
            SetServiceStatus(this.ServiceHandle, ref serviceStatus);

            _bookmarkManager = new BookmarkManager();
            this._xpManagementServer = new XPManagementServer(this.appConfig.XProtectServer.Uri,
                                                              this.appConfig.XProtectServer.Domain,
                                                              this.appConfig.XProtectServer.User,
                                                              this.appConfig.XProtectServer.Password);

            Logger.Instace.Info("Service initialize completed.");

            Task.Run(() => this.OnXProtectLoginTimer(null, null));
        }

        /// <summary>
        /// サービスの停止
        /// </summary>
        protected override void OnStop()
        {
            // 処理停止要求
            StopServiceRequestTokenSource.Cancel();
            Logger.Instace.Info("Received a service stop request.");

            // タイマー終了
            this.DeleteHotFolderWatchTimer();
            this.DeleteXProtectLoginTimer();

            // 処理終了待ち
            Task.Run(async () =>
            {
                while (IsExecConnectProc || IsExecBookmarkProc)
                {
                    await Task.Delay(100);
                }
            }).Wait();

            // XProtect Management Serverからログアウト
            this._xpManagementServer?.Logout();
            this._xpManagementServer = null;

            Logger.Instace.Info("Service was stopped.");
        }

        /// <summary>
        /// XProtectログイン用タイマーハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnXProtectLoginTimer(object sender, ElapsedEventArgs args)
        {
            Logger.Instace.Debug("OnXProtectLoginTimer: start");
            this.StopXProtectLoginTimer();

            this.XprotectLoginResult = LoginResult.None;
            if (!StopServiceRequestToken.IsCancellationRequested)
            {
                if (this._xprotectLoginRetryCount > 0)
                {
                    Logger.Instace.Info($"Retry to login to XProtect. [Retry={this._xprotectLoginRetryCount}]");
                }

                IsExecConnectProc = true;
                this.XprotectLoginResult = this.LoginToXProtect();
                IsExecConnectProc = false;
            }
            if (!StopServiceRequestToken.IsCancellationRequested)
            {
                switch (this.XprotectLoginResult)
                {
                case LoginResult.Success:
                    var msg = this.XpLoginStartup ? "Bookmark program start." : "Reconnected to XProtect.";
                    this._xprotectLoginRetryCount = 0;
                    Logger.Instace.Info(msg);
                    // サービスステータス：実行中
                    var serviceStatus = new ServiceStatus() { dwCurrentState = ServiceState.SERVICE_RUNNING, dwWaitHint = 100000 };
                    SetServiceStatus(this.ServiceHandle, ref serviceStatus);
                    // カメラ一覧取得
                    CameraFqidList = XPManagementServer.GetCameraFqidList();
                    if (this.XpLoginStartup)
                    {
                        // 監視スタート
                        Task.Run(() => this.OnHotFolderWatchTimer(null, null));
                    }
                    break;
                case LoginResult.Failure:
                    this._xprotectLoginRetryCount++;
                    this.StartXProtectLoginTimer();
                    break;
                case LoginResult.RetryOver:
                    if (this.XpLoginStartup)
                    {
                        // サービス停止
                        this.Stop();
                    }
                    else
                    {
                        // XProtectに再接続できませんでした。XProtectの状態を確認して、本アプリケーションを再起動してください。
                        Logger.Instace.Error("Could not reconnect to XProtect. Check the status of XProtect and restart this application.");
                    }
                    break;
                default:
                    break;
                }
            }
            Logger.Instace.Debug("OnXProtectLoginTimer: end");
        }

        /// <summary>
        /// XProtectにログインする
        /// </summary>
        /// <returns></returns>
        private LoginResult LoginToXProtect()
        {
            if (this._xpManagementServer.Login())
            {
                Logger.Instace.Info("Successed to Login to XProtect.");
                return LoginResult.Success;
            }
            else
            {
                Logger.Instace.Error("Failed to login to XProtect.");

                // リトライ回数上限チェック
                if (this.IsLoginMaxRetryCountExceeded())
                {
                    Logger.Instace.Error("Maximum number of retries has been exceeded, so the process ends.");
                    return LoginResult.RetryOver;
                }

                return LoginResult.Failure;
            }
        }

        /// <summary>
        /// XProtectログインのリトライ回数が上限値を超えたかどうかを返す
        /// </summary>
        /// <returns></returns>
        private bool IsLoginMaxRetryCountExceeded()
            => this._xprotectLoginRetryCount >= this.appConfig.XProtectServer.LoginRetryCount;

        /// <summary>
        /// XProtect再ログイン
        /// </summary>
        /// <returns>再接続結果 true:成功/false:失敗</returns>
        public bool ReconnectToXprotect()
        {
            var result = false;
            this.OnXProtectLoginTimer(null, null);
            while (!StopServiceRequestToken.IsCancellationRequested)
            {
                if(this.XprotectLoginResult == LoginResult.Success)
                {
                    result = true;
                    break;
                }
                else if(this.XprotectLoginResult == LoginResult.RetryOver)
                {
                    break;
                }
                Task.Run(async () => await Task.Delay(500)).Wait();
            }
            return result;
        }

        /// <summary>
        /// ホットフォルダー監視用タイマーハンドラ
        /// </summary>
        /// <param name="sender">送信元</param>
        /// <param name="args">イベント引数</param>
        public void OnHotFolderWatchTimer(object sender, ElapsedEventArgs args)
        {
            Logger.Instace.Debug("OnHotFolderWatchTimer: start");
            this.StopHotFolderWatchTimer();

            if (!StopServiceRequestToken.IsCancellationRequested)
            {
                this.WatchHotFolder();
            }

            if (!StopServiceRequestToken.IsCancellationRequested)
            {
                this.StartHotFolderWatchTimer();
            }
            Logger.Instace.Debug("OnHotFolderWatchTimer: end");
        }

        /// <summary>
        /// ホットフォルダのチェック
        /// </summary>
        /// <returns>チェック結果</returns>
        private bool WatchHotFolder()
        {
            // ホットフォルダ内のブックマーク付与CSVファイルパスを取得する
            string[] bookmarkFiles = BookmarkFileManager.GetBookmarkFileListInHotFolder();
            if (bookmarkFiles.Length == 0)
            {
                return false;
            }

            foreach (string bookmarkFile in bookmarkFiles)
            {
                if (StopServiceRequestToken.IsCancellationRequested)
                {
                    break;
                }

                IsExecBookmarkProc = true;
                try
                {
                    this.CreateBookmark(bookmarkFile);
                }
                catch(Exception ex)
                {
                    Logger.Instace.ErrorException(ex);
                    Logger.Instace.Error(ex.StackTrace);
                }
                IsExecBookmarkProc = false;
            }

            return true;
        }

        /// <summary>
        /// ブックマーク付与CSVファイルの内容を元にブックマークを作成する
        /// </summary>
        /// <param name="bookmarkCsvFilePath">ブックマークCSVファイルパス</param>
        /// <remarks>処理結果</remarks>
        private bool CreateBookmark(string bookmarkCsvFilePath)
        {
            var sw = new System.Diagnostics.Stopwatch();
            sw.Restart();
            Logger.Instace.Info("Start create bookmark.");

            BookmarkFileManager bookmarkFileManager = new BookmarkFileManager();

            // ホットフォルダに投入されたブックマーク付与CSVファイルをワークフォルダに移動する
            if (bookmarkFileManager.MoveBookmarkFileToWorkFolder(bookmarkCsvFilePath) == false)
            {
                Logger.Instace.Error("Failed to copy the bookmark file from hot folder to work folder.");
                bookmarkFileManager.SendErrorFileToHotFolder();
                return false;
            }
            // エラーファイル削除（前回コピー失敗の救済を想定）
            bookmarkFileManager.RemoveErrorFile(bookmarkCsvFilePath);

            // ワークフォルダ内のカレントなブックマーク付与ファイルパスの取得
            string currentBookmarkFilePath = bookmarkFileManager.GetCurrentWorkBookmarkFilePath();

            // ブックマーク付与CSVファイルをロードしてブックマーク情報リストとして展開する
            var res = _bookmarkManager.CreateBookmarkInfoList(currentBookmarkFilePath);
            var bookmarkInfoList = _bookmarkManager.GetBookmarkInfoList();
            if (!res || bookmarkInfoList.Count == 0)
            {
                if (!res)
                {
                    Logger.Instace.Error("Failed to create bookmark list.");
                }
                if (bookmarkInfoList.Count == 0)
                {
                    Logger.Instace.Error($"Valid bookmark list is empty. file:\"{bookmarkFileManager.GetCurrentWorkBookmarkFilePath()}\"");
                }
                bookmarkFileManager.SendErrorFileToHotFolder();
                if (bookmarkInfoList.Count == 0)
                {
                    bookmarkFileManager.RemoveCurrentWorkBookmarkFile();
                    return false;
                }
            }

            // ブックマーク付与CSVファイルで指定されているブックマークを作成する
            var line_index = this.appConfig.Bookmark.UseCsvHeader ? 1 : 0;
            var waitTiming = line_index;
            var errorCount = 0;
            foreach (var bookmarkInfo in bookmarkInfoList)
            {
                line_index++;
                if (_bookmarkManager.CreateBookmark(bookmarkInfo) == false)
                {
                    // ブックマーク作成に失敗したら次のブックマークを登録する
                    Logger.Instace.Error($"Failed to create bookmark. line:{(line_index)}, file:\"{bookmarkFileManager.GetCurrentWorkBookmarkFilePath()}\"");
                    errorCount++;
                }
                if (line_index % 10 == waitTiming && line_index < bookmarkInfoList.Count)
                {
                    Task.Run(async () => await Task.Delay(10)).Wait();
                    Logger.Instace.Debug($"***** ブックマーク生成 wait! line:{line_index}");
                }
            }
            if (errorCount > 0)
            {
                bookmarkFileManager.SendErrorFileToHotFolder();
            }

            // ワークフォルダ内のブックマーク付与ファイルを削除
            bookmarkFileManager.RemoveCurrentWorkBookmarkFile();

            sw.Stop();
            Logger.Instace.Info($"Bookmark creation is complete. Processing time: {sw.Elapsed.TotalSeconds:f4} sec.");
            return errorCount == 0;
        }

        /// <summary>
        /// XProtectログイン用タイマー 生成
        /// </summary>
        private void CreateXProtectLoginTimer()
        {
            // タイマーの設定と起動
            _xprotectLoginIntervalTimer = new Timer
            {
                Interval = this.appConfig.XProtectServer.LoginRetryInterval,
            };
            _xprotectLoginIntervalTimer.Elapsed += this.OnXProtectLoginTimer;
        }

        /// <summary>
        /// XProtectログイン用タイマー 開始
        /// </summary>
        private void StartXProtectLoginTimer()
        {
            _xprotectLoginIntervalTimer?.Start();
        }

        /// <summary>
        /// XProtectログイン用タイマー 停止
        /// </summary>
        private void StopXProtectLoginTimer()
        {
            _xprotectLoginIntervalTimer?.Stop();
        }

        /// <summary>
        /// XProtectログイン用タイマー 削除
        /// </summary>
        private void DeleteXProtectLoginTimer()
        {
            _xprotectLoginIntervalTimer?.Stop();
            _xprotectLoginIntervalTimer?.Close();
            _xprotectLoginIntervalTimer = null;
        }

        /// <summary>
        /// ホットフォルダ監視用タイマー 生成
        /// </summary>
        private void CreateHotFolderWatchTimer()
        {
            _hotfolderWatchIntervalTimer = new Timer()
            {
                Interval = this.appConfig.Folder.HotFolderPollingInterval,
            };
            _hotfolderWatchIntervalTimer.Elapsed += this.OnHotFolderWatchTimer;
        }

        /// <summary>
        /// ホットフォルダ監視用タイマー 開始
        /// </summary>
        private void StartHotFolderWatchTimer()
        {
            _hotfolderWatchIntervalTimer?.Start();
        }

        /// <summary>
        /// ホットフォルダ監視用タイマー 停止
        /// </summary>
        private void StopHotFolderWatchTimer()
        {
            _hotfolderWatchIntervalTimer?.Stop();
        }

        /// <summary>
        /// ホットフォルダ監視用タイマー 削除
        /// </summary>
        private void DeleteHotFolderWatchTimer()
        {
            _hotfolderWatchIntervalTimer?.Stop();
            _hotfolderWatchIntervalTimer?.Close();
            _hotfolderWatchIntervalTimer = null;
        }
    }
}
