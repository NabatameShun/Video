// ----------------------------------------------------------------------------
// <copyright file="XPBookmarkService.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using XPBookmarkService.Common;
using XPBookmarkService.Models;

namespace XPBookmarkService.Services
{
    /// <summary>
    /// ブックマークファイルファイル管理クラス
    /// </summary>
    public class BookmarkFileManager
    {
        /// <summary>
        /// エラーファイル拡張子
        /// </summary>
        private const string ErrExt = ".err";

        /// <summary>
        /// 年月日テンプレート
        /// </summary>
        private const string Template_yyyyMMdd = "yyyyMMdd";

        /// <summary>
        /// ホットフォルダに投入されたブックマーク付与CSVファイルパス
        /// </summary>
        private string _sourceBookmarkFilePath = string.Empty;

        /// <summary>
        /// ワークフォルダ内のカレントブックマーク付与CSVファイルパス
        /// </summary>
        private string _currentWorkBookmarkFilePath = string.Empty;

        /// <summary>
        /// 設定情報
        /// </summary>
        private readonly AppConfig appConfig = Program.GetAppConfigInstace();

        /// <summary>
        /// CSVファイル読み込みで無視するCSVファイル一覧
        /// コピー/削除失敗等で残ってしまったファイル
        /// </summary>
        private static readonly HashSet<string> ignoredCsvFileList = new HashSet<string>();

        /// <summary>
        /// ホットフォルダに投入されたブックマークファイルをワークフォルダに移動する
        /// Note:
        /// ワークフォルダに移動したブックマークファイルにはファイル名にタイムスタンプを付与する
        /// </summary>
        /// <returns>処理結果</returns>
        public bool MoveBookmarkFileToWorkFolder(string bookmarkFilePath)
        {
            // ホットフォルダに投入されたブックマークファイルパスを保存しておく
            this._sourceBookmarkFilePath = bookmarkFilePath;

            // ホットフォルダ内のブックマークCSVファイルをワークフォルダにコピーする
            // （この後、ホットフォルダのブックマークファイルは削除するので外見上は移動となる）
            if (!this.CopyFileToFolder(bookmarkFilePath, this.appConfig.Folder.WorkFolderPath))
            {
                Logger.Instace.Error($"Error occurred when copying to the work folder. bookmarkFilePath:\"{bookmarkFilePath}\"");
                return false;
            }

            try
            {
                // ホットフォルダ内のコピー元のファイルを削除
                File.Delete(bookmarkFilePath);
            }
            catch (Exception ex)
            {
                // ファイル削除で例外となってもそのまま処理は進める
                AddIgnoredCsvFileList(bookmarkFilePath);
                Logger.Instace.Warn($"Delete file error. bookmarkFilePath:\"{bookmarkFilePath}\"");
                Logger.Instace.WarnException(ex);
            }

            Logger.Instace.Info($"Current bookmark file is \"{this._currentWorkBookmarkFilePath}\".");
            return true;
        }

        /// <summary>
        /// コピー元ファイルをコピー先フォルダにコピーする
        /// </summary>
        /// <param name="srcFilePath">コピー元ファイルパス</param>
        /// <param name="dstFolder">コピー先フォルダパス</param>
        /// <param name="dstFileName">コピー先ファイルパス</param>
        /// <returns>処理結果</returns>
        private bool CopyFileToFolder(string srcFilePath, string dstFolder, string dstFileName = null)
        {
            if (!File.Exists(srcFilePath))
            {
                Logger.Instace.Info($"Source file is not exist. file:\"{srcFilePath}\"");
                return false;
            }

            var destFilePath = Path.Combine(dstFolder, dstFileName ?? Path.GetFileName(srcFilePath));

            if (WaitForFileUnlocked(srcFilePath, this.appConfig.Folder.CopyRetryCount, this.appConfig.Folder.CopyRetryInterval) == false)
            {
                Logger.Instace.Info($"File is locked. sourceFile:\"{srcFilePath}\"");
                return false;
            }

            try
            {
                File.Copy(srcFilePath, destFilePath, true);
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"Copy file error. file:\"{srcFilePath}\", folder:\"{dstFolder}\"");
                Logger.Instace.ErrorException(ex);
                return false;
            }

            // ワークフォルダに保存したカレントなブックマークファイル名を保存しておく
            this._currentWorkBookmarkFilePath = destFilePath;

            Logger.Instace.Info($"Copy to dest folder. file:\"{srcFilePath}\", folder:\"{dstFolder}\"");
            return true;
        }

        /// <summary>
        /// コピー先フォルダ内に日付フォルダを作成してからコピー元ファイルをコピー先フォルダにコピーする
        /// </summary>
        /// <param name="sourceFile">コピー元ファイルパス</param>
        /// <param name="dstFolder">日付フォルダを作成しコピーするフォルダパス</param>
        /// <param name="dstFilePath">コピー先ファイルパス</param>
        /// <returns>処理結果</returns>
        private bool CopyFileToDateFolder(string sourceFile, string dstFolder, string dstFilePath = null)
        {
            if (!File.Exists(sourceFile))
            {
                Logger.Instace.Info($"Source file not exist. file:\"{sourceFile}\"");
                return false;
            }

            DateTime now = DateTime.Now;
            string dstDateFolder = Path.Combine(dstFolder, now.ToString(Template_yyyyMMdd, CultureInfo.InvariantCulture));

            if (Directory.Exists(dstDateFolder) == false)
            {
                Logger.Instace.Info($"Create dest folder. file:\"{sourceFile}\", folder:\"{dstDateFolder}\"");
                Directory.CreateDirectory(dstDateFolder);
            }

            var destFilePath = Path.Combine(dstDateFolder, dstFilePath ?? Path.GetFileName(sourceFile));

            if (WaitForFileUnlocked(sourceFile, this.appConfig.Folder.CopyRetryCount, this.appConfig.Folder.CopyRetryInterval) == false)
            {
                Logger.Instace.Info($"File was not unlocked within the specified time. sourceFile:\"{sourceFile}\"");
                return false;
            }

            try
            {
                File.Copy(sourceFile, destFilePath, true);
            }
            catch (IOException ex)
            {
                Logger.Instace.Error($"Copy file error. file:\"{sourceFile}\", folder:\"{dstDateFolder}\"");
                Logger.Instace.ErrorException(ex);
                return false;
            }

            // ワークフォルダに保存したカレントなブックマークファイル名を保存しておく
            this._currentWorkBookmarkFilePath = destFilePath;

            Logger.Instace.Info($"Copy to destination folder. file:\"{sourceFile}\", folder:\"{dstDateFolder}\"");
            return true;
        }

        /// <summary>
        /// カレントなブクマーク付与CSVファイルを削除する
        /// </summary>
        public void RemoveCurrentWorkBookmarkFile()
        {
            if (string.IsNullOrEmpty(this._currentWorkBookmarkFilePath) == true)
            {
                return;
            }

            try
            {
                // ワークフォルダのブックマークCSVファイルを削除
                File.Delete(this._currentWorkBookmarkFilePath);
            }
            catch
            {
            }
            finally
            {
                this._currentWorkBookmarkFilePath = string.Empty;
            }
        }

        /// <summary>
        /// ワークフォルダ内のカレントなブックマーク付与ファイルパスを取得する
        /// </summary>
        /// <returns></returns>
        public string GetCurrentWorkBookmarkFilePath()
        {
            return this._currentWorkBookmarkFilePath;
        }

        /// <summary>
        /// このインスタンスで管理しているブックマーク付与CSVファイルで
        /// エラーが発生した時、ブックマーク付与CSVファイルをエラーファイルに
        /// コピーしてホットフォルダに返却する
        /// </summary>
        public void SendErrorFileToHotFolder()
        {
            var dstFilePath = this._sourceBookmarkFilePath + ErrExt;
            var srcFilePath = string.IsNullOrEmpty(this._currentWorkBookmarkFilePath) ? this._sourceBookmarkFilePath : this._currentWorkBookmarkFilePath;

            if (File.Exists(dstFilePath))
            {
                return;
            }

            Logger.Instace.Info($"Create error file. \"{dstFilePath}\"");
            try
            {
                File.Copy(srcFilePath, dstFilePath);
            }
            catch (Exception)
            {
                try
                {
                    using (File.Create(dstFilePath)) { }
                }
                catch(Exception ex)
                {
                    Logger.Instace.ErrorException(ex);
                }
                return;
            }
        }

        /// <summary>
        /// ホットフォルダのエラーファイルを削除する
        /// </summary>
        /// <param name="bookmarkCsvFilePath">CSVファイルパス</param>
        public void RemoveErrorFile(string bookmarkCsvFilePath)
        {
            var removeFilePath = bookmarkCsvFilePath + ErrExt;
            if (!File.Exists(removeFilePath))
            {
                return;
            }

            Logger.Instace.Info($"Remove error file. \"{removeFilePath}\"");
            try
            {
                File.Delete(removeFilePath);
            }
            catch (Exception ex)
            {
                Logger.Instace.ErrorException(ex);
                return;
            }
        }

        /// <summary>
        /// ホットフォルダのブックマーク付与CSVファイルのリストを取得する
        /// </summary>
        /// <returns>CSVファイルリスト</returns>
        public static string[] GetBookmarkFileListInHotFolder()
        {
            var appConfig = Program.GetAppConfigInstace();
            var extension = appConfig.Folder.BookmarkFileExtension;
            var fileList = new List<string>();
            try
            {
                // ホットフォルダ内のブックマーク付与CSVファイルパスを取得する
                fileList = Directory.GetFiles(appConfig.Folder.HotFolderPath, $"*{extension}")
                                    .Where(file => file.EndsWith(extension))
                                    .ToList();
                // 無視ファイルを除外
                fileList.RemoveAll(file => ignoredCsvFileList.Contains(file));
            }
            catch(Exception ex)
            {
                // ホットフォルダのCSVファイル一覧取得でエラーが発生しました。
                Logger.Instace.Error("An error occurred while getting the CSV file list of the hot folder.");
                Logger.Instace.ErrorException(ex);
            }
            return fileList.ToArray();
        }

        /// <summary>
        /// ファイルのロックが解除されるのを待つ
        /// ネットワーク共有フォルダにファイルが置かれた時など、ウィルスチェックプログラムが
        /// ファイルをロックしてしまうことがある。そのロックが解除されて、本プログラムが
        /// ファイルにアクセスできるようになるまで待機する。
        /// </summary>
        /// <param name="filePath">対象ファイルパス</param>
        /// <param name="maxRetry">最大リトライ回数</param>
        /// <param name="interval">待機時間(ミリ秒)</param>
        /// <returns>処理結果</returns>
        private static bool WaitForFileUnlocked(string filePath, int maxRetry, int interval)
        {
            int retryCount = 0;

            while (IsFileLocked(filePath) == true)
            {
                if (retryCount >= maxRetry)
                {
                    return false;
                }
                Task.Run(async () => await Task.Delay(interval)).Wait();
                retryCount++;
            }
            return true;
        }

        /// <summary>
        /// ファイルが他プロセスにロック（オープン）されているかどうかを返す
        /// </summary>
        /// <param name="filePath">チェックするファイルパス</param>
        /// <returns>ロック状態</returns>
        private static bool IsFileLocked(string filePath)
        {
            try
            {
                using (new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
                return false;
            }
            catch
            {
                return true;
            }

        }

        /// <summary>
        /// 無視リストにファイルを追加する
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        public static void AddIgnoredCsvFileList(string filePath) => ignoredCsvFileList.Add(filePath);
    }
}
