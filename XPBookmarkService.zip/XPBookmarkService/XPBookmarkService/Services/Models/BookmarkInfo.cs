// ----------------------------------------------------------------------------
// <copyright file="BookmarkInfo.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using VideoOS.Platform;

namespace XPBookmarkService.Services.Models
{
    /// <summary>
    /// ブックマーク情報クラス
    /// </summary>
    public class BookmarkInfo
    {
        /// <summary>
        /// ブックマーク開始時刻
        /// </summary>
        public DateTime BookmarkTimeBegin { get; set; }

        /// <summary>
        /// ブックマークトリガー時刻
        /// </summary>
        public DateTime BookmarkTimeTrigged { get; set; }

        /// <summary>
        /// ブックマーク終了時刻
        /// </summary>
        public DateTime BookmarkTimeEnd { get; set; }

        /// <summary>
        /// カメラ名
        /// </summary>
        public string CameraName { get; set; }

        /// <summary>
        /// カメラFQID
        /// </summary>
        public FQID CameraFQID { get; set; }

        /// <summary>
        /// ブックマークヘッドライン
        /// </summary>
        public string BookmarkHeadline { get; set; }

        /// <summary>
        /// ブックマーク説明
        /// </summary>
        public string BookmarkDescription { get; set; }
    }
}
