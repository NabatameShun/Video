// ----------------------------------------------------------------------------
// <copyright file="XPManagementServer.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using VideoOS.Platform;
using VideoOS.Platform.ConfigurationItems;
using VideoOS.Platform.Login;
using VideoOS.Platform.SDK.Platform;
using XPBookmarkService.Common;

namespace XPBookmarkService.Services
{
    using Environment = VideoOS.Platform.SDK.Environment;

    /// <summary>
    /// XProtect Management Serverクラス
    /// </summary>
    public class XPManagementServer
    {
        /// <summary>
        /// サーバーアドレス（URI文字列）
        /// </summary>
        private readonly string _serverAddress = string.Empty;

        /// <summary>
        /// ドメイン
        /// </summary>
        private readonly string _domain = string.Empty;

        /// <summary>
        /// ユーザー
        /// </summary>
        private readonly string _user = string.Empty;

        /// <summary>
        /// パスワード
        /// </summary>
        private readonly string _password = string.Empty;

        /// <summary>
        /// サーバーURI
        /// </summary>
        private readonly Uri _serverUri = null;

        /// <summary>
        /// XProtect認証タイプ
        /// </summary>
        private const string AuthenticationType = "Basic";

        /// <summary>
        /// XProtect認証タイプ：Windows
        /// </summary>
        private const string AuthenticationTypeWindows = "Negotiate";

        /// <summary>
        /// サーバーID
        /// </summary>
        public List<ServerId> ServerId { get; private set; } = new List<ServerId>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="serverAddress">XProtectサーバURI</param>
        /// <param name="domain">接続ドメイン名</param>
        /// <param name="user">接続ユーザ名</param>
        /// <param name="password">接続パスワード</param>
        public XPManagementServer(string serverAddress, string domain, string user, string password)
        {
            this._serverAddress = serverAddress;
            this._domain = domain;
            this._user = user;
            this._password = password;
            this._serverUri = new Uri(serverAddress);

            // 接続アカウント/パスワードが未設定の場合はデフォルト認証
            if (string.IsNullOrEmpty(this._user) || string.IsNullOrEmpty(this._password))
            {
                // デフォルト認証
                NetworkCredential networkCredential = CredentialCache.DefaultNetworkCredentials;
                // サーバー追加
                Environment.AddServer(false, this._serverUri, networkCredential);
            }
            else if (!string.IsNullOrWhiteSpace(this._domain))
            {
                // Windows認証
                CredentialCache networkCredential = Util.BuildCredentialCache(this._serverUri,
                                                                              $@"{this._domain}\{this._user}",
                                                                              this._password,
                                                                              AuthenticationTypeWindows);
                // サーバー追加
                Environment.AddServer(false, this._serverUri, networkCredential);
            }
            else
            {
                // 基本認証
                CredentialCache networkCredential = Util.BuildCredentialCache(this._serverUri,
                                                                              this._user,
                                                                              this._password,
                                                                              AuthenticationType);
                // サーバー追加
                Environment.AddServer(false, this._serverUri, networkCredential);
            }
        }

        /// <summary>
        /// Management Serverへのログイン
        /// </summary>
        public bool Login()
        {
            Logger.Instace.Info($"Login to XProtect({this._serverAddress}).");
            try
            {
                var assembly = Assembly.GetExecutingAssembly();
                Guid integrationId = new Guid(assembly.GetCustomAttribute<GuidAttribute>().Value);
                var assemblyName = assembly.GetName();
                string integrationName = assembly.GetCustomAttribute<AssemblyProductAttribute>().Product;
                string version = assemblyName.Version.ToString();
                string manufacturerName = assembly.GetCustomAttribute<AssemblyCompanyAttribute>().Company;
                VideoOS.Platform.SDK.Environment.Login(this._serverUri, integrationId, integrationName, version, manufacturerName, false);
            }
            catch (InvalidCredentialsMIPException)
            {
                Logger.Instace.Error("The credentials supplied are not valid with the server.");
                return false;
            }
            catch (ServerNotFoundMIPException)
            {
                Logger.Instace.Error("The server did not answer.");
                return false;
            }
            catch (LoginFailedInternalMIPException ex)
            {
                // 実行時発生してはいけません
                Logger.Instace.Error("An internal error happened.");
                Logger.Instace.Error(ex.StackTrace);
                return false;
            }
            catch (Exception ex)
            {
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Error(ex.StackTrace);
                return false;
            }

            // 構成アイテムのロード
            Environment.LoadConfiguration(this._serverUri);

            // サーバーID取得（基本的には1個のはず）
            var list = Configuration.Instance.GetItemsByKind(Kind.Server);
            foreach (Item item in list)
            {
                this.ServerId.Add(item.FQID.ServerId);
            }

            return true;
        }

        /// <summary>
        /// ログアウト
        /// </summary>
        public void Logout()
        {
            if (this._serverUri == null)
            {
                return;
            }

            if (Environment.IsLoggedIn(this._serverUri) == true)
            {
                Environment.RemoveAllServers();
                Environment.Logout(this._serverUri);
                Logger.Instace.Info("Logout to XProtect completed.");
            }
        }

        /// <summary>
        /// カメラFQIDの取得
        /// </summary>
        /// <param name="cameraName">カメラ名</param>
        /// <returns>カメラFQID</returns>
        public static FQID GetCameraFQID(string cameraName)
        {
            // カメラItemの取得
            Item cameraItem = FindCamera(cameraName);
            if (cameraItem == null)
            {
                Logger.Instace.Error($"Camera not found. camera name:{cameraName}");
                return null;
            }
            return cameraItem.FQID;
        }

        /// <summary>
        /// カメラ名で指定されたカメラアイテムの検索
        /// </summary>
        /// <param name="cameraName">カメラ名</param>
        /// <returns>カメラアイテム</returns>
        private static Item FindCamera(string cameraName)
        {
            // Get the root level Items, which are the servers added. Configuration is not loaded implicitly yet.
            List<Item> list = Configuration.Instance.GetItemsByKind(Kind.Camera);

            Item cameraItem;

            // For each root level Item, check the children. We are certain, none of the root level Items is a camera
            foreach (Item item in list)
            {
                cameraItem = CheckChildren(item, cameraName);
                if (cameraItem != null)
                {
                    return cameraItem;
                }
            }
            return null;
        }

        /// <summary>
        /// XProtectサーバー情報の下位下層を検索する
        /// </summary>
        /// <param name="parent">親アイテム</param>
        /// <param name="cameraName">カメラ名</param>
        /// <returns>カメラアイテム</returns>
        private static Item CheckChildren(Item parent, string cameraName)
        {
            Item cameraItem;

            List<Item> itemsOnNextLevel = parent.GetChildren(); // This causes the configuration Items to be loaded.
            if (itemsOnNextLevel != null)
            {
                foreach (Item item in itemsOnNextLevel)
                {
                    // If we find the camera we want, remember it and return with no further checks
                    // It must have Kind == Camera and it must not be a folder (It seems that camera folders have Kind == Camera)
                    if (item.FQID.Kind == Kind.Camera && item.FQID.FolderType == FolderType.No)
                    {
                        // Does the name match the camera name we are looking for?
                        if (item.Name == cameraName)
                        {
                            // Remember this camera and stop checking.
                            return item;
                        }
                    }
                    else
                    {
                        // We have not found our camera, so check the next level of Items in case this Item has children.
                        if (item.HasChildren != HasChildren.No)
                        {
                            cameraItem = CheckChildren(item, cameraName);
                            if (cameraItem != null)
                            {
                                return cameraItem;
                            }
                        }
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// カメラItem一覧取得
        /// </summary>
        /// <returns></returns>
        public static Dictionary<FQID, string> GetCameraFqidList()
        {
            var list = Configuration.Instance.GetItemsByKind(Kind.Camera);
            var cameraItems = new ConcurrentDictionary<FQID, Item>();

            foreach (Item item in list)
            {
                MakeCameraFqidList(item, ref cameraItems);
            }
            return cameraItems.ToDictionary(dic => dic.Key, dic => dic.Value.Name);
        }

        /// <summary>
        /// カメラItem一覧作成
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="cameraItems"></param>
        private static void MakeCameraFqidList(Item parent, ref ConcurrentDictionary<FQID, Item> cameraItems)
        {
            var itemsOnNextLevel = parent.GetChildren();
            if (itemsOnNextLevel != null)
            {
                foreach (var item in itemsOnNextLevel)
                {
                    if (item.FQID.Kind == Kind.Camera && item.FQID.FolderType == FolderType.No)
                    {
                        cameraItems.TryAdd(item.FQID, item);
                    }
                    else
                    {
                        if (item.HasChildren != HasChildren.No)
                        {
                            MakeCameraFqidList(item, ref cameraItems);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 登録済みカメラ一覧の取得
        /// </summary>
        /// <returns>カメラ一覧</returns>
        public static Dictionary<Guid, string> GetCameraGuidList()
        {
            // カメラグループフォルダからカメラ一覧を取得
            var managementServer = new ManagementServer(EnvironmentManager.Instance.MasterSite);
            var cameraList = new ConcurrentDictionary<Guid, Camera>();
            var groups = managementServer.CameraGroupFolder.CameraGroups;
            foreach (var grp in groups)
            {
                MakeCameraGudiList(grp, ref cameraList);
            }
            return cameraList.ToDictionary(dic => dic.Key, dic => dic.Value.Name);
        }

        /// <summary>
        /// カメラフォルダ内のカメラのオブジェクトIDとカメラオブジェクトの一覧を作成
        /// </summary>
        /// <param name="curGroup"></param>
        /// <param name="cameraList"></param>
        private static void MakeCameraGudiList(CameraGroup curGroup, ref ConcurrentDictionary<Guid, Camera> cameraList)
        {
            // カレントグループのカメラフォルダのカメラを一覧に追加
            var cameras = curGroup.CameraFolder.Cameras;
            foreach (var c in cameras)
            {
                // 異なるグループに同じカメラが登録されている場合は一覧に含めない
                // カメラIDが無いものは無視する
                if (!string.IsNullOrWhiteSpace(c.Id))
                {
                    cameraList.TryAdd(new Guid(c.Id), c);
                }
            }
            // 子グループを検索
            var groups = curGroup.CameraGroupFolder.CameraGroups;
            foreach (var grp in groups)
            {
                MakeCameraGudiList(grp, ref cameraList);
            }
        }
    }
}
