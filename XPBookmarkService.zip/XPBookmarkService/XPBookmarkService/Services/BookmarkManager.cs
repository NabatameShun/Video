// ----------------------------------------------------------------------------
// <copyright file="BookmarkManager.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using VideoOS.Platform;
using VideoOS.Platform.Data;
using XPBookmarkService.Common;
using XPBookmarkService.Models;
using XPBookmarkService.Services.Models;

namespace XPBookmarkService.Services
{
    /// <summary>
    /// ブックマーク情報クラス
    /// </summary>
    public class BookmarkManager
    {
        /// <summary>
        /// ブックマークCSVファイルのカラムインデックス
        /// </summary>
        public enum CsvColumnIndex
        {
            /// <summary>省略可能</summary>
            Optional = -1,
            /// <summary>インデックス最小値</summary>
            Min = 1,
        }

        /// <summary>
        /// BookmarkInfoインスタンスリスト
        /// </summary>
        private List<BookmarkInfo> _bookmarkList = new List<BookmarkInfo>();

        /// <summary>
        /// ブックマーク付与ファイルのデフォルトエンコード名称
        /// </summary>
        private const string DefaultBookmarkCsvEncode = "SJIS";

        /// <summary>
        /// ブックマーク付与CSVの既定カラム数
        /// </summary>
        private readonly int BookmarkCsvFileColumns;

        /// <summary>
        /// 小数点
        /// </summary>
        private const string Dot = ".";

        /// <summary>
        /// 設定情報
        /// </summary>
        private readonly AppConfig appConfig = Program.GetAppConfigInstace();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public BookmarkManager()
        {
            var csvSetting = this.appConfig.Bookmark.CsvColumns;
            this.BookmarkCsvFileColumns = (new List<int> { csvSetting.DateTime, csvSetting.CameraName, csvSetting.Headline, csvSetting.Description }).Max();
        }

        /// <summary>
        /// ブックマーク付与CSVファイルからブックマーク情報リスト
        /// （BookmarkInfoクラスインスタンスのリスト）を作成する
        /// </summary>
        /// <param name="bookmarkFilePath">ブックマークファイルパス</param>
        /// <returns>処理結果</returns>
        public bool CreateBookmarkInfoList(string bookmarkFilePath)
        {
            // ブックマークリストのクリア
            this._bookmarkList.Clear();

            List<List<string>> rows;
            try
            {
                // ブックマーク付与CSVのロード
                rows = CSVParser.LoadFromPath(bookmarkFilePath, CSVParser.Delimiter.Comma, Encoding.GetEncoding(DefaultBookmarkCsvEncode));

                if (this.appConfig.Bookmark.UseCsvHeader && rows.Count <= 1
                    || !this.appConfig.Bookmark.UseCsvHeader && rows.Count == 0)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                Logger.Instace.Warn($"Exception occurred while loading the bookmark file. bookmarkFilePath:\"{bookmarkFilePath}\"");
                Logger.Instace.WarnException(ex);
                return false;
            }

            var result = true;
            var line_index = 0;
            if (this.appConfig.Bookmark.UseCsvHeader)
            {
                line_index = 1;     // ヘッダ行分
                rows.RemoveAt(0);   // ヘッダ行削除
            }
            foreach (var columns in rows)
            {
                line_index++;
                if (columns.Count < this.BookmarkCsvFileColumns)
                {
                    Logger.Instace.Error($"Invalid bookmark csv file format. line:{line_index}");
                    result = false;
                    continue;
                }

                // ブックマーク情報（説明は省略可）
                var csvColSetting = this.appConfig.Bookmark.CsvColumns;
                var bookmarkDateTime = columns[csvColSetting.DateTime - 1];
                var bookmarkCameraName = columns[csvColSetting.CameraName - 1];
                var bookmarkHeadlineBody = columns[csvColSetting.Headline - 1];
                var bookmarkDescriptionBody = csvColSetting.Description == (int)CsvColumnIndex.Optional ? "" : columns[csvColSetting.Description - 1];

                // ヘッドライン、説明にプレフィックス、サフィックスを付与する
                var bookmarkHeadline = this.appConfig.Bookmark.Headline.Prefix + bookmarkHeadlineBody + this.appConfig.Bookmark.Headline.Suffix;
                var bookmarkDescription = this.appConfig.Bookmark.Description.Prefix + bookmarkDescriptionBody + this.appConfig.Bookmark.Description.Suffix;

                // 日時チェック＆変換
                var pattern = @"^\d{1,4}/\d{1,2}/\d{1,2}\s\d{1,2}:\d{1,2}(:\d{1,2})?";
                var match = Regex.Match(bookmarkDateTime, pattern);
                if (!match.Success)
                {
                    Logger.Instace.Error($"Invalid triggered data/time. line:{line_index}, Value:\"{bookmarkDateTime}\"");
                    result = false;
                    continue;
                }
                if (!DateTime.TryParse(match.Value, out var bookmarkTimeTriggered))
                {
                    Logger.Instace.Error($"Invalid triggered data/time. line:{line_index}, Value:\"{bookmarkDateTime}\"");
                    result = false;
                    continue;
                }

                bookmarkTimeTriggered = bookmarkTimeTriggered.ToUniversalTime();

                var bookmarkTimeBegin = bookmarkTimeTriggered.AddSeconds(-this.appConfig.Bookmark.PreTime);
                var bookmarkTimeEnd = bookmarkTimeTriggered.AddSeconds(this.appConfig.Bookmark.PostTime);

                // カメラ名称からFQID取得
                var cameraDic = XPBookmarkService.CameraFqidList.FirstOrDefault(camera => camera.Value == bookmarkCameraName);
                if (cameraDic.Equals(default(KeyValuePair<FQID, string>)))
                {
                    Logger.Instace.Error($"Camera not found. line:{line_index}, camera name:\"{bookmarkCameraName}\"");
                    result = false;
                    continue;
                }
                var camraFQID = cameraDic.Key;

                // ブックマーク情報作成
                var bookmarkInfo = new BookmarkInfo()
                {
                    BookmarkTimeBegin = bookmarkTimeBegin,
                    BookmarkTimeTrigged = bookmarkTimeTriggered,
                    BookmarkTimeEnd = bookmarkTimeEnd,
                    CameraName = bookmarkCameraName,
                    CameraFQID = camraFQID,
                    BookmarkHeadline = bookmarkHeadline,
                    BookmarkDescription = bookmarkDescription
                };
                this._bookmarkList.Add(bookmarkInfo);
            }
            return result;
        }

        /// <summary>
        /// ブックマーク情報リストの取得
        /// </summary>
        /// <returns></returns>
        public List<BookmarkInfo> GetBookmarkInfoList()
        {
            return this._bookmarkList;
        }

        /// <summary>
        /// ブックマークの作成
        /// </summary>
        /// <param name="bookmarkInfo">ブックマーク情報</param>
        /// <returns>処理結果</returns>
        public bool CreateBookmark(BookmarkInfo bookmarkInfo)
        {
            StringBuilder bookmarkHeader = new StringBuilder();
            StringBuilder bookmarkDesc = new StringBuilder();

            // 新規作成ブックマーク用のブックマークID取得
            BookmarkReference bookmarkRef;
			try
			{
                // 再接続後の再ログイン不要
                bookmarkRef = BookmarkService.Instance.BookmarkGetNewReference(bookmarkInfo.CameraFQID, false);
                if (bookmarkRef == null)
                {
                    Logger.Instace.Error($"Failed to get new bookmark reference.");
                    return false;
                }
			}
			catch (Exception ex)
			{
                Logger.Instace.Error($"Exception occured while get new bookmark reference.");
                Logger.Instace.ErrorException(ex);
                return false;
            }

            bookmarkHeader.Append(bookmarkInfo.BookmarkHeadline);
            bookmarkDesc.Append(bookmarkInfo.BookmarkDescription);

            Logger.Instace.Info($"Creating a bookmark. " +
                                $"camera:\"{bookmarkInfo.CameraName}\", " +
                                $"begin:\"{bookmarkInfo.BookmarkTimeBegin.ToLocalTime():yyyy/MM/dd HH:mm:ss}\", " +
                                $"triggered:\"{bookmarkInfo.BookmarkTimeTrigged.ToLocalTime():yyyy/MM/dd HH:mm:ss}\", " +
                                $"end:\"{bookmarkInfo.BookmarkTimeEnd.ToLocalTime():yyyy/MM/dd HH:mm:ss}\", " +
                                $"headline:\"{bookmarkInfo.BookmarkHeadline}\"");

            // ブックマーク付与対象のカメラアイテムの取得
            // 切断されていても使用可
            Item cameraItem = Configuration.Instance.GetItem(bookmarkInfo.CameraFQID.ObjectId, Kind.Camera);
            if (cameraItem == null)
            {
                Logger.Instace.Error($"Camera was not found. camera:\"{bookmarkInfo.CameraFQID.ObjectId}\"");
                return false;
            }

            if (this.appConfig.Log.OutsideRecordedVideoBookmark == true)
            {
                Logger.Instace.Debug($"[{DateTime.Now:HH:mm:ss.ffff}] Start CheckRecordedVideo");
                // ブックマークが録画映像範囲外ならその旨のログを出力する
                if (IsBookmarkInRecordedVideo(cameraItem, bookmarkInfo.BookmarkTimeBegin) == false)
                {
                    Logger.Instace.Warn($"Bookmark is outside the range of the recorded video. " +
                                        $"bookmark begin date/time:\"{bookmarkInfo.BookmarkTimeBegin.ToLocalTime():yyyy/MM/dd HH:mm:ss}\"");
                }
                Logger.Instace.Debug($"[{DateTime.Now:HH:mm:ss.ffff}] End CheckRecordedVideo");
            }

            Logger.Instace.Debug($"[{DateTime.Now:HH:mm:ss.ffff}] Start BookmarkCreate");
            bool result;
			try
			{
                // 再接続後の再ログイン不要
                var bookmark = BookmarkService.Instance.BookmarkCreate(
                    bookmarkInfo.CameraFQID,
                    bookmarkInfo.BookmarkTimeBegin,
				    bookmarkInfo.BookmarkTimeTrigged,
				    bookmarkInfo.BookmarkTimeEnd,
				    bookmarkRef.Reference,
				    bookmarkHeader.ToString(),
				    bookmarkDesc.ToString());
                if (bookmark == null)
                {
                    Logger.Instace.Error($"Failed to create bookmark.");
                }
                result = bookmark != null;
			}
			catch (Exception ex)
			{
                Logger.Instace.Error($"Exception occured while creating the bookmark.");
                Logger.Instace.ErrorException(ex);
                result = false;
            }
            Logger.Instace.Debug($"[{DateTime.Now:HH:mm:ss.ffff}] End BookmarkCreate");
            return result;
        }

        /// <summary>
        /// ブックマークの時刻が録画映像範囲内かどうかを返す
        /// </summary>
        /// <param name="cameraItem">カメラアイテム</param>
        /// <param name="bookmarkDateTime">ブックマーク日時</param>
        /// <returns>録画映像範囲内かどうか</returns>
        static private bool IsBookmarkInRecordedVideo(Item cameraItem, DateTime bookmarkDateTime)
        {
            var bookmarkWithinVideo = false;
            SequenceDataSource dataSource = null;
            try
            {
                dataSource = new SequenceDataSource(cameraItem);
                dataSource.Init();

                TimeSpan maxTimeBefore = new TimeSpan();
                TimeSpan maxTimeAfter = new TimeSpan();

                // 再接続後の再ログイン不要
                List<object> cacheRecordings = dataSource.GetData(bookmarkDateTime, maxTimeBefore, 1, maxTimeAfter, 1);

                foreach (SequenceData recording in cacheRecordings)
                {
                    if (recording.EventSequence.StartDateTime <= bookmarkDateTime
                        && bookmarkDateTime <= recording.EventSequence.EndDateTime)
                    {
                        bookmarkWithinVideo = true;
                        break;
                    }
                }
            }
            finally
            {
                dataSource?.Close();
            }
            return bookmarkWithinVideo;
        }
    }
}
