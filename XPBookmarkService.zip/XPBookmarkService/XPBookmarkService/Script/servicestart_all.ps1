﻿$services = @('Milestone XProtect Recording Server', 'Milestone XProtect Management Server', 'Milestone XProtect Log Server', 'MilestoneEventServerService', 'Milestone XProtect Data Collector Server', 'Milestone XProtect Mobile Server', 'MSSQLSERVER')
Set-ExecutionPolicy Bypass
foreach($service In Get-Service $services | Where-Object {$_.status -eq "stopped"}){
    Start-Service $service
}

echo "`r`n<<<  Service Status  >>>"
Get-Service $services | Format-Table -Property DisplayName, Status > C:\temp\servicestart_all_ps.log
