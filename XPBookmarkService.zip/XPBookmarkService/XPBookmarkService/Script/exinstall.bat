@echo off
set SERVICENAME="XPBookmarkService"
set SERVICEEXEPATH="D:\Project\05_�g���^�c���H��\02_Source\XPBookmarkService\XPBookmarkService\XPBookmarkService\bin\x64\Release\XPBookmarkService.exe"

SC create %SERVICENAME% binpath=%SERVICEEXEPATH%
SC description %SERVICENAME% "T�l���� XProtect Bookmark Service"
