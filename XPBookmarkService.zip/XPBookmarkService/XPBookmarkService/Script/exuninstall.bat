@echo off
set SERVICENAME="XPBookmarkService"

SC delete %SERVICENAME%
