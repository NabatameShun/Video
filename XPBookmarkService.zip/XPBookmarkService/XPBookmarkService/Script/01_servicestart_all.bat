powershell -ExecutionPolicy Bypass -File C:\temp\servicestart_all.ps1
