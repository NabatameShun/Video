// ----------------------------------------------------------------------------
// <copyright file="BookmarkConfig.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System.Xml.Serialization;

namespace XPDelBookmark
{
    /// <summary>
    /// 設定XMLクラス
    /// </summary>
    [XmlRoot("AppConfig")]
    public class BookmarkConfig
    {
        /// <summary>
        /// XProtectサーバー関連情報
        /// </summary>
        [XmlElement("XProtectServer")]
        public XProtectServer XProtectServer { get; set; } = new XProtectServer();

        /// <summary>
        /// ブックマーク関連情報
        /// </summary>
        [XmlElement("Bookmark")]
        public Bookmark Bookmark { get; set; } = new Bookmark();
    }

    /// <summary>
    /// XProtectServer
    /// </summary>
    public class XProtectServer
    {
        /// <summary>
        /// XProtect Management Server URI
        /// </summary>
        [XmlElement("Uri")]
        public string Uri { get; set; }

        /// <summary>
        /// ドメイン
        /// </summary>
        [XmlElement("Domain")]
        public string Domain { get; set; }

        /// <summary>
        /// XProtectユーザー
        /// </summary>
        [XmlElement("User")]
        public string User { get; set; }

        /// <summary>
        /// XProtectユーザーパスワード
        /// </summary>
        [XmlElement("Password")]
        public string Password { get; set; }

        /// <summary>
        /// 暗号化パスワード
        /// </summary>
        [XmlElement("EncryptedPassword")]
        public string EncryptedPassword { get; set; }
    }

    /// <summary>
    /// Bookmark
    /// </summary>
    public class Bookmark
    {
        /// <summary>
        /// ブックマーク保存日数
        /// </summary>
        [XmlElement("RetentionDays")]
        public uint RetentionDays { get; set; }

        /// <summary>
        /// ブックマーク検索開始日付
        /// </summary>
        [XmlElement("SearchStartDate")]
        public string SearchStartDate { get; set; } = "2000/1/1";
    }
}
