// ----------------------------------------------------------------------------
// <copyright file="CheckConfig.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Globalization;
using XPDelBookmark.Common;

namespace XPDelBookmark
{
    /// <summary>
    /// 設定XMLの内容のバリデーションチェッククラス
    /// </summary>
    public static class CheckConfig
    {
        /// <summary>
        /// 設定内容の妥当性（フォルダの存在チェック等）を行う
        /// </summary>
        /// <returns>チェック結果</returns>
        public static bool Check()
        {
            var result = true;
            var appConfig = Program.AppConfig;

            if(!DateTime.TryParseExact(appConfig.Bookmark.SearchStartDate, "yyyy/M/d", CultureInfo.InvariantCulture, DateTimeStyles.None, out _))
            {
                Logger.Instace.Error("Check config: The search start date is incorrect.");
                result = false;
            }
            
            return result;
        }
    }
}
