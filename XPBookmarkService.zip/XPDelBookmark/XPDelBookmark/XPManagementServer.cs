// ----------------------------------------------------------------------------
// <copyright file="XPManagementServer.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using VideoOS.Platform;
using VideoOS.Platform.Login;
using VideoOS.Platform.SDK.Platform;
using XPDelBookmark.Common;

namespace XPDelBookmark
{
    using Environment = VideoOS.Platform.SDK.Environment;

    /// <summary>
    /// XProtect Management Serverクラス
    /// </summary>
    public class XPManagementServer
	{
        /// <summary>
        /// サーバーアドレス（URI文字列）
        /// </summary>
        private readonly string _serverAddress = string.Empty;

        /// <summary>
        /// ドメイン
        /// </summary>
        private readonly string _domain = string.Empty;

        /// <summary>
        /// ユーザー
        /// </summary>
        private readonly string _user = string.Empty;

        /// <summary>
        /// パスワード
        /// </summary>
        private readonly string _password = string.Empty;

        /// <summary>
        /// サーバーURI
        /// </summary>
        private readonly Uri _serverUri = null;

        /// <summary>
        /// XProtect認証タイプ
        /// </summary>
        private const string AuthenticationType = "Basic";

        /// <summary>
        /// XProtect認証タイプ：Windows
        /// </summary>
        private const string AuthenticationTypeWindows = "Negotiate";

        /// <summary>
        /// サーバーID
        /// </summary>
        public List<ServerId> ServerId { get; private set; } = new List<ServerId>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="serverAddress">XProtectサーバURI</param>
        /// <param name="domain">ドメイン名</param>
        /// <param name="user">ユーザ名</param>
        /// <param name="password">パスワード</param>
        public XPManagementServer(string serverAddress, string domain, string user, string password)
		{
            this._serverAddress = serverAddress;
            this._domain = domain;
            this._user = user;
            this._password = password;
            this._serverUri = new Uri(serverAddress);

            // 接続アカウント/パスワードが未設定の場合はデフォルト認証
            if (string.IsNullOrEmpty(this._user) || string.IsNullOrEmpty(this._password))
            {
                // デフォルト認証
                NetworkCredential networkCredential = CredentialCache.DefaultNetworkCredentials;
                // サーバー追加
                Environment.AddServer(false, this._serverUri, networkCredential);
            }
            else if (!string.IsNullOrWhiteSpace(this._domain))
            {
                // Windows認証
                CredentialCache networkCredential = Util.BuildCredentialCache(this._serverUri,
                                                                              $@"{this._domain}\{this._user}",
                                                                              this._password,
                                                                              AuthenticationTypeWindows);
                // サーバー追加
                Environment.AddServer(false, this._serverUri, networkCredential);
            }
            else
            {
                // 基本認証
                CredentialCache networkCredential = Util.BuildCredentialCache(this._serverUri,
                                                                              this._user,
                                                                              this._password,
                                                                              AuthenticationType);
                // サーバー追加
                Environment.AddServer(false, this._serverUri, networkCredential);
            }
        }

        /// <summary>
        /// Management Serverへのログイン
        /// </summary>
        /// <returns>処理結果</returns>
        public bool Login()
        {
            Logger.Instace.Info($"Login to XProtect({this._serverAddress}).");
            try
            {
                var assembly = Assembly.GetExecutingAssembly();
                Guid integrationId = new Guid(assembly.GetCustomAttribute<GuidAttribute>().Value);
                var assemblyName = assembly.GetName();
                string integrationName = assembly.GetCustomAttribute<AssemblyProductAttribute>().Product;
                string version = assemblyName.Version.ToString();
                string manufacturerName = assembly.GetCustomAttribute<AssemblyCompanyAttribute>().Company;
                VideoOS.Platform.SDK.Environment.Login(this._serverUri, integrationId, integrationName, version, manufacturerName, false);
            }
            catch (InvalidCredentialsMIPException)
            {
                Logger.Instace.Error("The credentials supplied are not valid with the server.");
                return false;
            }
            catch (ServerNotFoundMIPException)
            {
                Logger.Instace.Error("The server did not answer.");
                return false;
            }
            catch (LoginFailedInternalMIPException ex)
            {
                // 実行時発生してはいけません
                Logger.Instace.Error("An internal error happened.");
                Logger.Instace.Error(ex.StackTrace);
                return false;
            }
            catch (Exception ex)
            {
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Error(ex.StackTrace);
                return false;
            }

            // 構成アイテムのロード
            Environment.LoadConfiguration(this._serverUri);

            // サーバーID取得（基本的には1個のはず）
            var list = Configuration.Instance.GetItemsByKind(Kind.Server);
            foreach (Item item in list)
            {
                this.ServerId.Add(item.FQID.ServerId);
            }

            Logger.Instace.Info("Login completed.");
            return true;
        }

        /// <summary>
        /// ログアウト
        /// </summary>
        public void Logout()
        {
            if (this._serverUri == null)
            {
                return;
            }

            if (Environment.IsLoggedIn(this._serverUri) == true)
            {
                Environment.RemoveAllServers();
                Environment.Logout(this._serverUri);
                Logger.Instace.Info($"Logout to XProtect completed ({this._serverUri}).");
            }
        }
    }
}
