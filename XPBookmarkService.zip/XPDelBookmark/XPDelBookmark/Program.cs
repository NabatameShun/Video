// ----------------------------------------------------------------------------
// <copyright file="Program.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.IO;
using VideoOS.Platform;
using VideoOS.Platform.Data;
using XPDelBookmark.Common;

namespace XPDelBookmark
{
    public static class Program
    {
        /// <summary>
        /// アプリケーションコンフィグインスタンス
        /// </summary>
        public static BookmarkConfig AppConfig { get; private set; } = null;

        /// <summary>
        /// アプリケーションコンフィグXMLファイル
        /// </summary>
        private const string _appConfigXmlFile = "XPDelBookmark.xml";

        /// <summary>
        /// ブックマーク検索１回当たりの取得結果数
        /// </summary>
        private const int _maxSearchRequestCount = 128;

        /// <summary>
        /// エントリポイント
        /// </summary>
        public static void Main(string[] _)
        {
            Logger.Instace.Info("========== Start Application ==========");

            try
            {
                string logMsg;
                if (InitializeApplication() == false)
                {
                    logMsg = "Failed to initialize the application.";
                    Logger.Instace.Info(logMsg);
                    Console.WriteLine(logMsg);
                    return;
                }

                XPManagementServer xpServer = null;
                try
                {
                    xpServer = new XPManagementServer(AppConfig.XProtectServer.Uri,
                                                      AppConfig.XProtectServer.Domain,
                                                      AppConfig.XProtectServer.User,
                                                      AppConfig.XProtectServer.Password);
                    if (xpServer.Login() == false)
                    {
                        logMsg = $"Failed to login to XProtect server ({AppConfig.XProtectServer.Uri}).";
                        Logger.Instace.Error(logMsg);
                        Console.WriteLine(logMsg);
                        return;
                    }
                    Console.WriteLine($"Login to XProtect server ({AppConfig.XProtectServer.Uri}).");

                    DeleteBookmarks(xpServer);
                }
                catch (Exception ex)
                {
                    Logger.Instace.ErrorException(ex);
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    xpServer?.Logout();
                }
            }
            finally
            {
                Logger.Instace.Info("******** Finished Application *********");
            }
        }

        /// <summary>
        /// アプリケーション初期処理
        /// </summary>
        /// <returns>処理結果</returns>
        private static bool InitializeApplication()
        {
            VideoOS.Platform.SDK.Environment.Initialize();

            // 設定ファイル読み込み
            var fi = new FileInfo(System.Reflection.Assembly.GetExecutingAssembly().Location);
            var configFile = Path.Combine(fi.Directory.FullName, _appConfigXmlFile);

            Logger.Instace.Info($"Load config file: \"{configFile}\"");
            var configSerializer = new XmlConfigSerializer<BookmarkConfig>(configFile);
            try
            {
                AppConfig = configSerializer.Deserialize();
            }
            catch (FileNotFoundException ex)
            {
                Logger.Instace.Error($"Configuration file was not found. ({configFile})");
                Logger.Instace.ErrorException(ex);
                return false;
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instace.Error("Configuration file are invalid.");
                Logger.Instace.ErrorException(ex);
                return false;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error("Configuration file load error.");
                Logger.Instace.ErrorException(ex);
                return false;
            }

            // 設定内容チェック
            if (!CheckConfig.Check())
            {
                Logger.Instace.Error("Invalid configuration data.");
                return false;
            }

            try
            {
                // パスワード暗号化
                SaveEncryptedPasswords(configSerializer);
            }
            catch(Exception ex)
            {
                Logger.Instace.Error("Password encryption processing failed.");
                Logger.Instace.ErrorException(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// パスワード暗号化
        /// </summary>
        /// <param name="configSerializer"></param>
        private static void SaveEncryptedPasswords(XmlConfigSerializer<BookmarkConfig> configSerializer)
        {
            var enc = new Encrypter();

            // カメラパスワードが暗号化されていなければ暗号化して保存する
            if (!string.IsNullOrEmpty(AppConfig.XProtectServer.Password))
            {
                AppConfig.XProtectServer.EncryptedPassword = enc.Encrypt(AppConfig.XProtectServer.Password);
                AppConfig.XProtectServer.Password = null;

                // 暗号化したパスワードの保存（および平文パスワードのクリア）
                configSerializer.Serialize(AppConfig);
            }

            // カメラパスワードを復号化する
            if (!string.IsNullOrEmpty(AppConfig.XProtectServer.EncryptedPassword))
            {
                AppConfig.XProtectServer.Password = enc.Decrypt(AppConfig.XProtectServer.EncryptedPassword);
            }
            return;
        }

        /// <summary>
        /// 設定XMLで指定された日数より古いブックマークを削除する
        /// 例：DeleteDaysAgoエレメントに5を設定
        /// 5日前より古いブックマークを削除する（4日前までのブックマークが残る）
        /// アプリの実行時間に関わらず5日前までに作成されたすべてのブックマークを削除する
        /// </summary>
        /// <param name="xpServer"></param>
        /// <returns>処理結果</returns>
        private static bool DeleteBookmarks(XPManagementServer xpServer)
        {
            Logger.Instace.Info($"DeleteBookmarks: start");

            string logMsg;
            var mediaDeviceTypes = new Guid[] { Kind.Camera };

            // 検索開始日時
            //DateTime.TryParse(_searchStartDt, out var searchStart);
            DateTime.TryParse(AppConfig.Bookmark.SearchStartDate, out var searchStart);

            // 検索終了日時
            //  例）保存日数＝１日 の場合
            //      アプリ実行日を０日目として...
            //      １日前の0:00:00以降のブックマークを保存
            //      それ以前（２日前の23:59:59以前）のブックマークを削除
            var searchEnd = DateTime.Today.AddDays(-AppConfig.Bookmark.RetentionDays).AddSeconds(-1);
            Logger.Instace.Info($"Search period. Start:{searchStart:yyyy/MM/dd HH:mm:ss}, End:{searchEnd:yyyy/MM/dd HH:mm:ss}.");
            if (searchStart > searchEnd)
            {
                // 検索期間が異常です。検索開始日付、保存日数を確認してください。
                logMsg = $"The search period is abnormal. Check the search start date and retention days. "
                         + $"SearchStartDate:{AppConfig.Bookmark.SearchStartDate}, RetentionDays:{AppConfig.Bookmark.RetentionDays}.";
                Console.WriteLine(logMsg);
                Logger.Instace.Error(logMsg);
                return false;
            }

            var timeLimitUSec = (long)(searchEnd - searchStart).TotalMilliseconds * 1000;  // 単位：マイクロ秒
            searchStart = searchStart.ToUniversalTime();

            int deletedBookmarkCount = 0;
            while (true)
            {
                // 検索1回当たりの結果取得数は128個までとし、削除も128個ずつ行う。
                var serverId = xpServer.ServerId.Count > 0 ? xpServer.ServerId[0] : null;
                var bookmarkList = BookmarkService.Instance.BookmarkSearchTime(serverId,
                                                                               searchStart,
                                                                               timeLimitUSec, // Period of time to search within (in microseconds). 
                                                                               _maxSearchRequestCount,
                                                                               mediaDeviceTypes,
                                                                               null,
                                                                               null,
                                                                               null);
                if (bookmarkList == null)
                {
                    logMsg = "Error occurred while searching for bookmarks.";
                    Console.WriteLine(logMsg);
                    Logger.Instace.Error(logMsg);
                    break;
                }
                if (bookmarkList.Length == 0)
                {
                    break;
                }

                Logger.Instace.Info($"-> Found {bookmarkList.Length} bookmark(s)");

                foreach (var bookmark in bookmarkList)
                {
                    var item = bookmark.GetDeviceItem();
                    Logger.Instace.Info($"Delete bookmark:");
                    Logger.Instace.Info($"  Camera: Name={item.Name}, Id={item.FQID.ObjectId}");
                    Logger.Instace.Info($"  Start={bookmark.TimeBegin.ToLocalTime():yyyy/MM/dd HH:mm:ss}, "
                                        + $"Triggered={bookmark.TimeTrigged.ToLocalTime():yyyy/MM/dd HH:mm:ss}, "
                                        + $"End={bookmark.TimeEnd.ToLocalTime():yyyy/MM/dd HH:mm:ss}");
                    Logger.Instace.Info($"  Bookmark id={bookmark.Reference}");
                    Logger.Instace.Info($"  Header={bookmark.Header}, Description={bookmark.Description}");
                    Logger.Instace.Info($"  User={bookmark.User}");

                    // ブックマークの削除
                    BookmarkService.Instance.BookmarkDelete(bookmark);
                    deletedBookmarkCount++;
                }
            }
            logMsg = $"{deletedBookmarkCount} bookmark(s) have been deleted.";
            Console.WriteLine(logMsg);
            Logger.Instace.Info($"DeleteBookmarks: end, {logMsg}");
            return true;
        }
    }
}
