// ----------------------------------------------------------------------------
// <copyright file="CsvListManager.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System.Linq;
using System.Collections.Generic;

namespace XPAutoExport
{
    /// <summary>
    /// CSV情報クラス
    /// </summary>
    public class CsvListManager
    {
        /// <summary>
        /// CSVファイル毎のエクスポート情報
        /// </summary>
        private List<CsvInfo> _csvInfoList;


        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <remarks></remarks>
        public CsvListManager()
        {
            this._csvInfoList = new List<CsvInfo>();
        }// CsvListManager()

        /// <summary>
        /// CSVファイル毎のエクスポート情報クリア
        /// </summary>
        /// <remarks></remarks>
        public void ClearCsvInfoList()
        {
            this._csvInfoList.Clear();
            return;
        }// ClearCsvInfoList()

        /// <summary>
        /// CSVファイル毎のエクスポート情報追加(配列の先頭に追加する。)
        /// </summary>
        /// <param name="csvInfo">csvInfoクラス</param>
        /// <remarks></remarks>
        public void InsertTopCsvInfoList(CsvInfo csvInfo)
        {
            this._csvInfoList.Insert(0, csvInfo);
            return;
        }// InsertTopCsvInfoList()


        /// <summary>
        /// CSVファイル毎のエクスポート情報から１件取得
        /// </summary>
        /// <param name="i">取得するリストN番目(0オリジン)</param>
        /// <remarks>CsvInfoクラス</remarks>
        public CsvInfo GetCsvInfoList(int listNo)
        {
            if (this._csvInfoList.Count() <= listNo)
            {
                return null;
            }// if
            return this._csvInfoList[listNo];
        }// GetCsvInfoList()

        /// <summary>
        /// CSVファイル毎のエクスポート情報から１件削除
        /// </summary>
        /// <param name="i">削除するリストN番目(0オリジン)</param>
        /// <remarks>処理結果</remarks>
        public bool RemoveAtCsvInfoList(int listNo)
        {
            if (this._csvInfoList.Count <= listNo)
            {
                return false;
            }// if
            this._csvInfoList.RemoveAt(listNo);
            return true;
        }// RemoveAtCsvInfoList()

        /// <summary>
        /// CSVファイル毎のエクスポート情報件数
        /// </summary>
        /// <remarks>件数</remarks>
        public int CountCsvInfoList()
        {
            return this._csvInfoList.Count;
        }// CountCsvInfoList()

    }// class CsvListManager
}// namespace XPAutoExport
