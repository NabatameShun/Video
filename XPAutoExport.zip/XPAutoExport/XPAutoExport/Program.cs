﻿// ----------------------------------------------------------------------------
// <copyright file="Program.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.IO;
using System.ServiceProcess;
using XPAutoExport.Common;
using XPAutoExport.Config;

namespace XPAutoExport
{
    static class Program
    {
        /// <summary>
        /// 設定ファイル
        /// </summary>
        private const string AppConfigXmlFile = "XPAutoExportSetting.xml";

        /// <summary>
        /// アプリケーションコンフィグインスタンス
        /// </summary>
        private static AppConfig _appConfig = null;

        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        static void Main(string[] args)
        {
            Logger.Instace.Info("Program :: Main : ========== XPAutoExport Main Start ==========");

            // サービス起動のための初期処理
            if (InitializeServiceBeforeRunning() == false)
            {
                Logger.Instace.Error("Program :: Main : failed the initial processing required to start windows service.");
                Logger.Instace.Info("Program :: Main : ========== XPAutoExport Main End  Error ==========");
                return;
            }// if

            if (Environment.UserInteractive)
            {
                // デバッグするためのコードです
                // 出力の種類 : コンソールアプリケーション
                XPAutoExport service1 = new XPAutoExport(args);
                Logger.Instace.Debug("Program :: Main : ========== TestStartupAndStop ==========");
                service1.TestStartupAndStop(args);
            }// if
            else
            {
                // サービス開始
                ServiceBase[] ServicesToRun;
                ServicesToRun = new ServiceBase[]
                {
                    new XPAutoExport(args)
                };
                Logger.Instace.Debug("Program :: Main : ========== ServiceBase.Run ==========");
                ServiceBase.Run(ServicesToRun);
            }// else

            Logger.Instace.Info("Program :: Main : ========== XPAutoExport Main End ==========");
        }// Main()


        /// <summary>
        /// サービスの初期処理
        /// 失敗したらサービスとして起動しない
        /// </summary>
        /// <returns>処理結果</returns>
        private static bool InitializeServiceBeforeRunning()
        {
            // MIPSDK VideoOSの初期化
            try
            {
                Logger.Instace.Debug("Program :: InitializeServiceBeforeRunning : MIPSDK VideoOS initialize start.");
                VideoOS.Platform.SDK.Environment.Initialize();          // General initialize.  Always required
                VideoOS.Platform.SDK.Export.Environment.Initialize();   // Initialize export references
                Logger.Instace.Debug("Program :: InitializeServiceBeforeRunning : MIPSDK VideoOS initialize end.");
            }
            catch (Exception ex)
            {
                Logger.Instace.Error("Program :: InitializeServiceBeforeRunning : MIPSDK VideoOS initialize error.");
                Logger.Instace.ErrorException(ex);
                return false;
            }

            // 設定XMLファイルの読み込み
            string location = System.Reflection.Assembly.GetExecutingAssembly().Location;
            FileInfo fi = new FileInfo(location);
            string configFile = Path.Combine(fi.Directory.FullName, AppConfigXmlFile);

            Logger.Instace.Debug($"Program :: InitializeServiceBeforeRunning : load config file.  config file:{configFile}");
            XmlConfigSerializer<AppConfig> configSerializer = new XmlConfigSerializer<AppConfig>(configFile);
            try
            {
                // XMLファイルから設定項目を読み込む
                _appConfig = configSerializer.Deserialize();
            }
            catch (FileNotFoundException ex)
            {
                Logger.Instace.Error($"Program :: InitializeServiceBeforeRunning : config file was not found.  config file:{configFile}");
                Logger.Instace.ErrorException(ex);
                return false;
            }
            catch (InvalidOperationException ex)
            {
                Logger.Instace.Error($"Program :: InitializeServiceBeforeRunning : configuration file is invalid.  config file:{configFile}");
                Logger.Instace.ErrorException(ex);
                return false;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"Program :: InitializeServiceBeforeRunning : exception occurred while reading the config file.  config file:{configFile}");
                Logger.Instace.ErrorException(ex);
                return false;
            }

            // 設定XMLのバリデーションチェック
            if (CheckConfig.Check() == false)
            {
                Logger.Instace.Error($"Program :: InitializeServiceBeforeRunning : invalid config data.  config file:{configFile}");
                return false;
            }// if

            try
            {
                // パスワード暗号化・保存
                SaveEncryptedPasswords(configSerializer);
                // 暗号化パスワード復号化
                DecryptPasswords();
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"Program :: InitializeServiceBeforeRunning : exception occurred in password encryption processing.  config file:{configFile}");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Error(ex.ToString());
                return false;
            }

            return true;
        }// InitializeServiceBeforeRunning()


        /// <summary>
        /// 設定XMLの平文パスワードの暗号化と保存を行う
        /// </summary>
        /// <param name="configSerializer"></param>
        /// <returns></returns>
        private static void SaveEncryptedPasswords(XmlConfigSerializer<AppConfig> configSerializer)
        {
            var enc = new Encrypter();
            var saveCconfig = false;

            // XProtectサーバー情報 「XProtectパスワード」が設定されている。
            if (!string.IsNullOrEmpty(_appConfig.XProtectServer.Password))
            {
                Logger.Instace.Debug($"Program :: SaveEncryptedPasswords : XProtectServer information \"Password\" is set .");
                _appConfig.XProtectServer.EncryptedPassword = enc.Encrypt(_appConfig.XProtectServer.Password);
                Logger.Instace.Debug($"Program :: SaveEncryptedPasswords : XProtectServer information \"EncryptedPassword)\" :{_appConfig.XProtectServer.EncryptedPassword}");
                _appConfig.XProtectServer.Password = null;
                saveCconfig = true;
            }// if
            else
            {
                if (_appConfig.XProtectServer.Password == "")
                {
                    Logger.Instace.Debug($"Program :: SaveEncryptedPasswords : ReceiverInfo information \"Password\" is empty string set .");
                    _appConfig.XProtectServer.EncryptedPassword = "";
                    Logger.Instace.Debug($"Program :: SaveEncryptedPasswords : ReceiverInfo information \"EncryptedPassword\" :{_appConfig.XProtectServer.EncryptedPassword}");
                    _appConfig.XProtectServer.Password = null;
                    saveCconfig = true;
                }// is
                else
                {
                    Logger.Instace.Debug($"Program :: SaveEncryptedPasswords : XProtectServer information \"Password\" is not set .");
                }// else
            }// else

            if (saveCconfig == true)
            {
                // 設定ファイルを更新する。
                Logger.Instace.Debug($"Program :: SaveEncryptedPasswords : update the configuration file.");
                configSerializer.Serialize(_appConfig);
            }// if

            return;
        }// SaveEncryptedPasswords()


        /// <summary>
        /// 暗号化パスワードの複合化
        /// </summary>
        /// <returns></returns>
        private static void DecryptPasswords()
        {
            var enc = new Encrypter();

            // XProtectサーバー情報 「XProtectパスワード（暗号化）」が設定されている。
            if (!string.IsNullOrEmpty(_appConfig.XProtectServer.EncryptedPassword))
            {
                Logger.Instace.Debug($"Program :: DecryptPasswords : XProtectServer information \"EncryptedPassword\" is set :{_appConfig.XProtectServer.EncryptedPassword}");
                _appConfig.XProtectServer.Password = enc.Decrypt(_appConfig.XProtectServer.EncryptedPassword);
            }// if
            else
            {
                _appConfig.XProtectServer.Password = "";
                Logger.Instace.Info($"Program :: DecryptPasswords : XProtectServer information \"EncryptedPassword\" is not set.　Password size :{_appConfig.XProtectServer.Password.Length}");
            }// else
        }// DecryptPasswords()


        /// <summary>
        /// アプリケーションコンフィグインスタンスを取得する
        /// </summary>
        /// <returns></returns>
        public static AppConfig GetAppConfigInstace() => _appConfig;

    }// class Program

}// namespace XPAutoExport
