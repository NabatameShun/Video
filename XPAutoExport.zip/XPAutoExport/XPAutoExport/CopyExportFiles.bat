@echo off
set MIPSDKBIN="C:\Program Files\Milestone\MIPSDK\Bin"

XCopy %MIPSDKBIN%\VideoOS.Utilities.dll %1 /Y /q
XCopy %MIPSDKBIN%\VideoOS.Platform.SDK.dll %1 /Y /q
XCopy %MIPSDKBIN%\VideoOS.Platform.SDK.Export.dll %1 /Y /q
XCopy %MIPSDKBIN%\VideoOS.Platform.Common.dll %1 /Y /q
XCopy %MIPSDKBIN%\DBExporterClientMW.dll %1 /Y /q
XCopy %MIPSDKBIN%\AVIExporterClientMW.dll %1 /Y /q
XCopy %MIPSDKBIN%\boost_*.dll %1 /Y /q
XCopy %MIPSDKBIN%\imv*.dll %1 /Y /q
XCopy %MIPSDKBIN%\Mm025.dll %1 /Y /q
XCopy %MIPSDKBIN%\mfc1*.dll %1 /Y /q
XCopy %MIPSDKBIN%\mfcm1*.dll %1 /Y /q
XCopy %MIPSDKBIN%\msvcp1*.dll %1 /Y /q
XCopy %MIPSDKBIN%\msvcr1*.dll %1 /Y /q
XCopy %MIPSDKBIN%\xerces-c*.dll %1 /Y /q
XCopy %MIPSDKBIN%\xqilla*.dll %1 /Y /q
XCopy %MIPSDKBIN%\VideoOS.Platform.Primitives.dll %1 /Y /q
XCopy %MIPSDKBIN%\VideoOS.Database*.dll %1 /Y /q
XCopy %MIPSDKBIN%\VideoOS.Toolkit*.dll %1 /Y /q
XCopy %MIPSDKBIN%\Toolkit*.dll %1 /Y /q
XCopy %MIPSDKBIN%\CoreToolkits.dll %1 /Y /q
XCopy %MIPSDKBIN%\15dd936825ad475ea34e35f3f54217a6\*.* %1\15dd936825ad475ea34e35f3f54217a6\ /y /s /q
XCopy %MIPSDKBIN%\libmfx*.dll %1 /Y /q
XCopy %MIPSDKBIN%\cudart64_*.dll %1 /Y /q
XCopy %MIPSDKBIN%\nppc64_*.dll %1 /Y /q
XCopy %MIPSDKBIN%\nppicom64_*.dll %1 /Y /q
XCopy %MIPSDKBIN%\Autofac.dll %1 /Y /q
XCopy %MIPSDKBIN%\VideoOS.IdentityServer.Common.dll %1 /Y /q
XCopy %MIPSDKBIN%\Microsoft.IdentityModel*.dll %1 /Y /q
XCopy %MIPSDKBIN%\Microsoft.AspNetCore.JsonPatch.dll %1 /Y /q
XCopy %MIPSDKBIN%\Newtonsoft.Json.dll %1 /Y /q
XCopy %MIPSDKBIN%\System.IdentityModel.Tokens.Jwt.dll %1 /Y /q
XCopy %MIPSDKBIN%\System.Net.Http.Formatting.dll %1 /Y /q
