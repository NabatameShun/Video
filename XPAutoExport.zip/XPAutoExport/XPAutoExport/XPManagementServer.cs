// ----------------------------------------------------------------------------
// <copyright file="XPManagementServer.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using VideoOS.Platform;
using VideoOS.Platform.ConfigurationItems;
using VideoOS.Platform.Login;
using VideoOS.Platform.SDK.Platform;
using XPAutoExport.Common;

namespace XPAutoExport
{
    using Environment = VideoOS.Platform.SDK.Environment;

    /// <summary>
    /// XProtect Management Serverクラス
    /// </summary>
    public class XPManagementServer
    {
        /// <summary>
        /// サーバーアドレス（URI文字列）
        /// </summary>
        private string _serverAddress = string.Empty;

        /// <summary>
        /// ドメイン
        /// </summary>
        private string _domain = string.Empty;

        /// <summary>
        /// ユーザー
        /// </summary>
        private string _user = string.Empty;

        /// <summary>
        /// パスワード
        /// </summary>
        private string _password = string.Empty;

        /// <summary>
        /// 認証方式
        /// </summary>
        private string _authenticationType = string.Empty;

        /// <summary>
        /// サーバーURI
        /// </summary>
        private Uri _serverUri = null;

        /// <summary>
        /// サーバーID
        /// </summary>
        public List<ServerId> ServerId { get; private set; } = new List<ServerId>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="serverAddress">XProtectサーバURI</param>
        /// <param name="user">接続ユーザ名</param>
        /// <param name="password">接続パスワード</param>
        /// <param name="authenticationType">認証方式</param>
        public XPManagementServer(string serverAddress, string user, string password, string authenticationType)
        {
            Logger.Instace.Debug($"XPManagementServer :: XPManagementServer : start. serverAddress:{serverAddress}  user:{user}  auth:{authenticationType}");
            this._serverAddress = serverAddress;
            this._user = user;
            this._password = password;
            this._authenticationType = authenticationType;
            this._serverUri = new Uri(serverAddress);
            try
            {
                CredentialCache networkCredential = Util.BuildCredentialCache(this._serverUri,
                                                                              this._user,
                                                                              this._password,
                                                                              this._authenticationType);
                // サーバー追加
                Environment.AddServer(false, this._serverUri, networkCredential);
            }
            catch (Exception ex)
            {
                Logger.Instace.Warn($"XPManagementServer :: XPManagementServer : exception error.");
                Logger.Instace.Warn(ex.StackTrace);
            }
        }// XPManagementServer()


        /// <summary>
        /// Management Serverへのログイン
        /// </summary>
        public bool Login()
        {
            Logger.Instace.Info($"XPManagementServer :: Login : XProtect:{this._serverAddress}");
            try
            {
                Logger.Instace.Debug($"XPManagementServer :: Login : serverUri:{this._serverUri}");
                Assembly assembly = Assembly.GetExecutingAssembly();
                object[] attributes = assembly.GetCustomAttributes(typeof(GuidAttribute), true);
                GuidAttribute guidAttr = (GuidAttribute)attributes[0];
                var companyAttribute = assembly
                     .GetCustomAttributes(typeof(AssemblyCompanyAttribute), false)
                     .OfType<AssemblyCompanyAttribute>()
                     .FirstOrDefault();

                Environment.Login(_serverUri, new Guid(guidAttr.Value), assembly.GetName().FullName, assembly.GetName().Version.ToString(), companyAttribute?.Company);
            }
            catch (InvalidCredentialsMIPException)
            {
                Logger.Instace.Warn("XPManagementServer :: Login : the credentials supplied are not valid with the server.");
                return false;
            }
            catch (ServerNotFoundMIPException)
            {
                Logger.Instace.Warn("XPManagementServer :: Login : the server did not answer.");
                return false;
            }
            catch (LoginFailedInternalMIPException ex)
            {
                // 実行時発生してはいけません
                Logger.Instace.Warn("XPManagementServer :: Login : an internal error happened.");
                Logger.Instace.Warn(ex.StackTrace);
                return false;
            }
            catch (Exception ex)
            {
                Logger.Instace.Warn("XPManagementServer :: Login : exception error.");
                Logger.Instace.Warn(ex.StackTrace);
                return false;
            }

            // 構成アイテムのロード
            Environment.LoadConfiguration(this._serverUri);

            // サーバーID取得（基本的には1個のはず）
            var list = Configuration.Instance.GetItemsByKind(Kind.Server);
            foreach (Item item in list)
            {
                this.ServerId.Add(item.FQID.ServerId);
            }// foreach

            return true;
        }// Login()


        /// <summary>
        /// ログアウト
        /// </summary>
        public void Logout()
        {
            if (this._serverUri == null)
            {
                Logger.Instace.Info($"XPManagementServer :: Logout : serverUri:null");
                return;
            }// if

            if (Environment.IsLoggedIn(this._serverUri) == true)
            {
                try
                {
                    Environment.RemoveAllServers();
                    Environment.Logout(this._serverUri);
                    Logger.Instace.Info("XPManagementServer :: Logout : logout to XProtct completed.");
                }
                catch (Exception ex)
                {
                    Logger.Instace.Warn($"XPManagementServer :: Logout : exception error");
                    Logger.Instace.Warn(ex.StackTrace);
                }
            }// if
        }// Logout()


        /// <summary>
        /// リトライ時のログアウト
        /// </summary>
        public void RetryLogout()
        {
            if (this._serverUri == null)
            {
                Logger.Instace.Info($"XPManagementServer :: RetryLogout : serverUri:null");
                return;
            }// if

            if (Environment.IsLoggedIn(this._serverUri) == true)
            {
                try
                {
                    Environment.RemoveAllServers();
                    Environment.Logout(this._serverUri);

                    CredentialCache networkCredential = Util.BuildCredentialCache(this._serverUri,
                                                              this._user,
                                                              this._password,
                                                              this._authenticationType);
                    // サーバー追加
                    Environment.AddServer(false, this._serverUri, networkCredential);

                    Logger.Instace.Info("XPManagementServer :: RetryLogout : logout to XProtct completed.");
                }
                catch (Exception ex)
                {
                    Logger.Instace.Warn($"XPManagementServer :: RetryLogout : exception error");
                    Logger.Instace.Warn(ex.StackTrace);
                }
            }// if
        }// Logout()

        /// <summary>
        /// カメラFQIDの取得
        /// </summary>
        /// <param name="cameraName">カメラ名</param>
        /// <returns>カメラFQID</returns>
        public static FQID GetCameraFQID(string cameraName)
        {
            try
            {
                // カメラItemの取得
                Item cameraItem = FindCamera(cameraName);
                if (cameraItem == null)
                {
                    Logger.Instace.Error($"XPManagementServer :: GetCameraFQID() : camera not found.  camera name:{cameraName}");
                    return null;
                }
                return cameraItem.FQID;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPManagementServer :: GetCameraFQID() : exception error.");
                Logger.Instace.ErrorException(ex);
                return null;
            }
        }// GetCameraFQID()


        /// <summary>
        /// カメラ名で指定されたカメラアイテムの検索
        /// </summary>
        /// <param name="cameraName">カメラ名</param>
        /// <returns>カメラアイテム</returns>
        private static Item FindCamera(string cameraName)
        {
            try
            {
                // Get the root level Items, which are the servers added. Configuration is not loaded implicitly yet.
                List<Item> list = Configuration.Instance.GetItemsByKind(Kind.Camera);

                Item cameraItem;

                // For each root level Item, check the children. We are certain, none of the root level Items is a camera
                foreach (Item item in list)
                {
                    cameraItem = CheckChildren(item, cameraName);
                    if (cameraItem != null)
                    {
                        return cameraItem;
                    }// if
                }// foreach
                return null;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPManagementServer :: FindCamera : exception error.");
                Logger.Instace.ErrorException(ex);
                return null;
            }
        }// FindCamera()


        /// <summary>
        /// XProtectサーバー情報の下位下層を検索する
        /// </summary>
        /// <param name="parent">親アイテム</param>
        /// <param name="cameraName">カメラ名</param>
        /// <returns>カメラアイテム</returns>
        private static Item CheckChildren(Item parent, string cameraName)
        {
            Item cameraItem;

            List<Item> itemsOnNextLevel = parent.GetChildren(); // This causes the configuration Items to be loaded.
            if (itemsOnNextLevel != null)
            {
                foreach (Item item in itemsOnNextLevel)
                {
                    // If we find the camera we want, remember it and return with no further checks
                    // It must have Kind == Camera and it must not be a folder (It seems that camera folders have Kind == Camera)
                    if (item.FQID.Kind == Kind.Camera && item.FQID.FolderType == FolderType.No)
                    {
                        // Does the name match the camera name we are looking for?
                        if (item.Name == cameraName)
                        {
                            // Remember this camera and stop checking.
                            return item;
                        }
                    }// if
                    else
                    {
                        // We have not found our camera, so check the next level of Items in case this Item has children.
                        if (item.HasChildren != HasChildren.No)
                        {
                            cameraItem = CheckChildren(item, cameraName);
                            if (cameraItem != null)
                            {
                                return cameraItem;
                            }
                        }
                    }// else
                }// foreach
            }// if
            return null;
        }// CheckChildren()


        /// <summary>
        /// カメラItem一覧取得
        /// </summary>
        /// <returns></returns>
        public static Dictionary<FQID, string> GetCameraFqidList()
        {
            var list = Configuration.Instance.GetItemsByKind(Kind.Camera);
            var cameraItems = new ConcurrentDictionary<FQID, Item>();

            foreach (Item item in list)
            {
                MakeCameraFqidList(item, ref cameraItems);
            }
            return cameraItems.ToDictionary(dic => dic.Key, dic => dic.Value.Name);
        }// GetCameraFqidList()


        /// <summary>
        /// カメラItem一覧作成
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="cameraItems"></param>
        private static void MakeCameraFqidList(Item parent, ref ConcurrentDictionary<FQID, Item> cameraItems)
        {
            var itemsOnNextLevel = parent.GetChildren();
            if (itemsOnNextLevel != null)
            {
                foreach (var item in itemsOnNextLevel)
                {
                    if (item.FQID.Kind == Kind.Camera && item.FQID.FolderType == FolderType.No)
                    {
                        cameraItems.TryAdd(item.FQID, item);
                    }// if
                    else
                    {
                        if (item.HasChildren != HasChildren.No)
                        {
                            MakeCameraFqidList(item, ref cameraItems);
                        }// if
                    }// else
                }// foreach
            }// if
        }// MakeCameraFqidList()


        /// <summary>
        /// 登録済みカメラ一覧の取得
        /// </summary>
        /// <returns>カメラ一覧</returns>
        public static Dictionary<Guid, string> GetCameraGuidList()
        {
            // カメラグループフォルダからカメラ一覧を取得
            var managementServer = new ManagementServer(EnvironmentManager.Instance.MasterSite);
            var cameraList = new ConcurrentDictionary<Guid, Camera>();
            var groups = managementServer.CameraGroupFolder.CameraGroups;
            foreach (var grp in groups)
            {
                MakeCameraGudiList(grp, ref cameraList);
            }// foreach
            return cameraList.ToDictionary(dic => dic.Key, dic => dic.Value.Name);
        }// GetCameraGuidList()


        /// <summary>
        /// カメラフォルダ内のカメラのオブジェクトIDとカメラオブジェクトの一覧を作成
        /// </summary>
        /// <param name="curGroup"></param>
        /// <param name="cameraList"></param>
        private static void MakeCameraGudiList(CameraGroup curGroup, ref ConcurrentDictionary<Guid, Camera> cameraList)
        {
            // カレントグループのカメラフォルダのカメラを一覧に追加
            var cameras = curGroup.CameraFolder.Cameras;
            foreach (var c in cameras)
            {
                // 異なるグループに同じカメラが登録されている場合は一覧に含めない
                // カメラIDが無いものは無視する
                if (!string.IsNullOrWhiteSpace(c.Id))
                {
                    cameraList.TryAdd(new Guid(c.Id), c);
                }// if
            }// foreach
            // 子グループを検索
            var groups = curGroup.CameraGroupFolder.CameraGroups;
            foreach (var grp in groups)
            {
                MakeCameraGudiList(grp, ref cameraList);
            }// foreach
        }// MakeCameraGudiList()

    }// class XPManagementServer
}// namespace XPAutoExport
