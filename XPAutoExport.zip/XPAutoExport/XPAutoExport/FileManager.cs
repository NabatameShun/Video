// ----------------------------------------------------------------------------
// <copyright file="FileManager.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using XPAutoExport.Common;
using XPAutoExport.Config;

namespace XPAutoExport
{
    /// <summary>
    /// CSVファイル管理クラス
    /// </summary>
    public class FileManager
    {
        /// <summary>
        /// エラーファイル拡張子
        /// </summary>
        private const string ErrExt = ".err";

        /// <summary>
        /// CSVファイル拡張子
        /// </summary>
        private const string CsvExt = ".csv";

        /// <summary>
        /// CSVファイル検索
        /// </summary>
        private const string CsvSearch  = "*.csv";

        /// <summary>
        /// 年月日テンプレート
        /// </summary>
        private const string Template_yyyyMMdd = "yyyyMMdd";

        /// <summary>
        /// ホットフォルダに投入されたCSVファイルパス
        /// </summary>
        private string _sourceCsvFilePath = string.Empty;

        /// <summary>
        /// ワークフォルダ内のカレントCSVファイルパス
        /// </summary>
        private string _currentWorkCsvkFilePath = string.Empty;

        /// <summary>
        /// 設定情報
        /// </summary>
        private readonly AppConfig appConfig = Program.GetAppConfigInstace();

        /// <summary>
        /// ホットフォルダに投入されたCSVファイルをワークフォルダに移動する
        /// </summary>
        /// <returns>処理結果</returns>
        public bool MoveCsvFileToWorkFolder(string csvFilePath)
        {
            // ホットフォルダに投入されたCSVファイルパスを保存しておく
            this._sourceCsvFilePath = csvFilePath;

            // ホットフォルダ内のCSVファイルをワークフォルダにコピーする
            // （この後、ホットフォルダのCSVファイルは削除するので外見上は移動となる）
            if (!this.CopyFileToFolder(csvFilePath, this.appConfig.Folder.WorkFolderPath))
            {
                Logger.Instace.Error($"FileManager :: MoveCsvFileToWorkFolder : error occurred when copying to the work folder.  csvFilePath:{csvFilePath}");
                return false;
            }// if

            try
            {
                // ホットフォルダ内のコピー元のファイルを削除
                File.Delete(csvFilePath);
            }
            catch (Exception ex)
            {
                // ファイル削除で例外となってもそのまま処理は進める
                Logger.Instace.Warn($"FileManager :: MoveCsvFileToWorkFolder : delete file error.  csv file:{csvFilePath}");
                Logger.Instace.WarnException(ex);
            }

            Logger.Instace.Info($"FileManager :: MoveCsvFileToWorkFolder : current csv file:{this._currentWorkCsvkFilePath}");
            return true;
        }// MoveCsvFileToWorkFolder()

        /// <summary>
        /// コピー元ファイルをコピー先フォルダにコピーする
        /// </summary>
        /// <param name="srcFilePath">コピー元ファイルパス</param>
        /// <param name="dstFolder">コピー先フォルダパス</param>
        /// <param name="dstFileName">コピー先ファイルパス</param>
        /// <returns>処理結果</returns>
        private bool CopyFileToFolder(string srcFilePath, string dstFolder, string dstFileName = null)
        {
            if (!File.Exists(srcFilePath))
            {
                Logger.Instace.Error($"FileManager :: CopyFileToFolder : source file is not exist.  file:{srcFilePath}");
                return false;
            }

            var destFilePath = Path.Combine(dstFolder, dstFileName ?? Path.GetFileName(srcFilePath));

            if (WaitForFileUnlocked(srcFilePath, 0, 0) == false)
            {
                Logger.Instace.Error($"FileManager :: CopyFileToFolder : file is locked.  sourceFile:{srcFilePath}");
                return false;
            }

            try
            {
                File.Copy(srcFilePath, destFilePath, true);
            }
            catch (IOException ex)
            {
                Logger.Instace.Error($"FileManager :: CopyFileToFolder : copy file error.  file:{srcFilePath}  folder:{dstFolder}");
                Logger.Instace.ErrorException(ex);
                return false;
            }

            // ワークフォルダに保存したカレントなCSVファイル名を保存しておく
            this._currentWorkCsvkFilePath = destFilePath;

            Logger.Instace.Debug($"FileManager :: CopyFileToFolder : copy to dest folder.  file:{srcFilePath}  folder:{dstFolder}");
            return true;
        }// CopyFileToFolder()


        /// <summary>
        /// カレントなCSVファイルを削除する
        /// </summary>
        public void RemoveCurrentWorkCsvFile()
        {
            if (string.IsNullOrEmpty(this._currentWorkCsvkFilePath) == true)
            {
                return;
            }

            try
            {
                // ワークフォルダのブックマークCSVファイルを削除
                File.Delete(this._currentWorkCsvkFilePath);
            }
            catch
            {
            }
            finally
            {
                this._currentWorkCsvkFilePath = string.Empty;
            }
        }// RemoveCurrentWorkCsvFile()

        /// <summary>
        /// ワークフォルダ内のカレントなCSVファイルパスを取得する
        /// </summary>
        /// <returns></returns>
        public string GetCurrentWorkCsvFilePath()
        {
            return this._currentWorkCsvkFilePath;
        }// GetCurrentWorkCsvFilePath()

        /// <summary>
        /// このインスタンスで管理しているCSVファイルで
        /// エラーが発生した時、CSVファイルをエラーファイルに
        /// リネームしてホットフォルダに返却する
        /// </summary>
        public void SendErrorFileToHotFolder()
        {
            var filename = Path.GetFileNameWithoutExtension(this._sourceCsvFilePath);
            var dstFilePath = appConfig.Folder.HotFolderPath + "\\" + filename + CsvExt + ErrExt;
            var srcFilePath = string.IsNullOrEmpty(this._currentWorkCsvkFilePath) ? this._sourceCsvFilePath : this._currentWorkCsvkFilePath;
            try
            {
                Logger.Instace.Debug($"FileManager :: SendErrorFileToHotFolder : move err file.  {srcFilePath} => {dstFilePath}");
                File.Move(srcFilePath, dstFilePath);
            }
            catch (IOException ex)
            {
                Logger.Instace.Warn($"FileManager :: SendErrorFileToHotFolder : move err file error.  {srcFilePath} => {dstFilePath}");
                Logger.Instace.Warn(ex.ToString());
                return;
            }
        }// SendErrorFileToHotFolder()


        /// <summary>
        /// 指定フォルダ下CSVファイルのリストを取得する
        /// </summary>
        /// <param name="path">ファイルパス</param>
        /// <returns>CSVファイルリスト</returns>
        public static string[] GetCsvFileListInFolder(string path)
        {
            AppConfig appConfig = Program.GetAppConfigInstace();

            // ホットフォルダ内のCSVファイルパスを取得する
            var fileList = Directory.GetFiles(path, CsvSearch)
                                    .Where(file => file.EndsWith(CsvExt))
                                    .ToList();
            return fileList.ToArray();
        }// GetCsvFileListInHotFolder()


        /// <summary>
        /// ファイルのロックが解除されるのを待つ
        /// ネットワーク共有フォルダにファイルが置かれた時など、ウィルスチェックプログラムが
        /// ファイルをロックしてしまうことがある。そのロックが解除されて、本プログラムが
        /// ファイルにアクセスできるようになるまで待機する。
        /// </summary>
        /// <param name="filePath">対象ファイルパス</param>
        /// <param name="maxRetry">最大リトライ回数</param>
        /// <param name="interval">待機時間(ミリ秒)</param>
        /// <returns>処理結果</returns>
        private static bool WaitForFileUnlocked(string filePath, int maxRetry, int interval)
        {
            int retryCount = 0;

            while (IsFileLocked(filePath) == true)
            {
                if (retryCount >= maxRetry)
                {
                    return false;
                }// if
                Task.Run(async () => await Task.Delay(interval)).Wait();
                retryCount++;
            }// while
            return true;
        }// WaitForFileUnlocked()

        /// <summary>
        /// ファイルが他プロセスにロック（オープン）されているかどうかを返す
        /// </summary>
        /// <param name="filePath">チェックするファイルパス</param>
        /// <returns>ロック状態</returns>
        private static bool IsFileLocked(string filePath)
        {
            try
            {
                using (new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
                return false;
            }
            catch
            {
                return true;
            }
        }// IsFileLocked()

    }// class FileManager
}// namespace XPAutoExport
