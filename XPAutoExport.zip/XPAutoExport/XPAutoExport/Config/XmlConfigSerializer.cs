// ----------------------------------------------------------------------------
// <copyright file="XmlConfigSerializer.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace XPAutoExport.Config
{
    /// <summary>
    /// XML設定シリアライズクラス
    ///   指定された型の設定項目をUTF-8のXMLファイルに読み書きするクラス
    /// </summary>
    /// <typeparam name="T">設定クラスの型</typeparam>
    public class XmlConfigSerializer<T>
    {
        //----------------------------------------------------------------------
        // フィールド
        //----------------------------------------------------------------------
        /// <summary>
        /// 設定ファイルパス
        /// </summary>
        protected string filePath = string.Empty;

        /// <summary>
        /// XMLシリアライザー
        /// </summary>
        private XmlSerializer serializer;


        //----------------------------------------------------------------------
        // メソッド
        //----------------------------------------------------------------------
        /// <summary>
        /// デフォルトコンストラクタ
        /// </summary>
        public XmlConfigSerializer()
        {
            // XMLシリアライザー作成
            this.serializer = new XmlSerializer(typeof(T));
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="filePath">設定ファイルパス</param>
        public XmlConfigSerializer(string filePath) : this()
        {
            // 設定ファイルパス
            this.filePath = filePath;
        }

        /// <summary>
        /// 指定された設定項目をファイルに書き込む
        /// </summary>
        /// <param name="config">設定内容</param>
        public void Serialize(T config)
            => this.Serialize(config, this.filePath);

        /// <summary>
        /// 指定された設定項目を指定されたファイルに書き込む
        /// </summary>
        /// <param name="config">設定内容</param>
        /// <param name="filePath">設定ファイル</param>
        public void Serialize(T config, string filePath)
        {
            using (var writer = new StreamWriter(filePath, false, Encoding.UTF8))
            {
                this.Serialize(config, writer);
            }
        }

        /// <summary>
        /// 指定された設定項目を指定されたストリームに書き込む
        /// </summary>
        /// <param name="config">設定内容</param>
        /// <param name="writer">ストリーム</param>
        public void Serialize(T config, StreamWriter writer)
        {
            // プレフィクス・名前空間を出力しない
            var ns = new XmlSerializerNamespaces();
            ns.Add(string.Empty, string.Empty);

            this.serializer.Serialize(writer, config, ns);
        }

        /// <summary>
        /// ファイルから設定項目を読み込む
        /// </summary>
        /// <returns>設定内容</returns>
        public T Deserialize() => this.Deserialize(this.filePath);

        /// <summary>
        /// 指定されたファイルから設定項目を読み込む
        /// </summary>
        /// <param name="filePath">設定ファイルパス</param>
        /// <returns>設定内容</returns>
        public T Deserialize(string filePath)
        {
            T config = default;

            if (string.IsNullOrWhiteSpace(filePath))
            {
                throw new FileNotFoundException($"{filePath} not specified.");
            }
            else if (!File.Exists(filePath))
            {
                throw new FileNotFoundException($"File not found. Path[{filePath}]");
            }

            using (var reader = new StreamReader(filePath, Encoding.UTF8))
            {
                config = this.Deserialize(reader);
            }

            return config;
        }

        /// <summary>
        /// 指定されたストリームから設定項目を読み込む
        /// </summary>
        /// <param name="reader">設定項目ストリーム</param>
        /// <returns>設定内容</returns>
        public T Deserialize(StreamReader reader)
            => (T)this.serializer.Deserialize(reader);
    }
}
