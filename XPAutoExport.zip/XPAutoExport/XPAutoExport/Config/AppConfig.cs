// ----------------------------------------------------------------------------
// <copyright file="AppConfig.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System.Xml.Serialization;

namespace XPAutoExport.Config
{
    /// <summary>
    /// エクスポート形式定数
    /// </summary>
    static class ExportFormat
    {
        public const int Mkv = 0;  //エクスポート形式：映像（MKV）
        public const int Jpeg = 1; //エクスポート形式：静止画（JPEG）
    }// class ExportFormat

    /// <summary>
    /// ファイル名の先頭の形式定数
    /// </summary>
    static class FileNameType
    {
        public const int CameraNm_Timestamp = 0; //「カメラ名_タイムスタンプ_...」
        public const int Timestamp_CameraNm = 1; //「タイムスタンプ_カメラ名_...」
    }// class FileNameType

    /// <summary>
    /// 設定ファイルXMLクラス
    /// </summary>
    [XmlRoot("AppConfig")]
    public class AppConfig
    {
        /// <summary>
        /// XProtectサーバー情報
        /// </summary>
        [XmlElement("XProtectServer")]
        public XProtectServer XProtectServer { get; set; } = new XProtectServer();

        /// <summary>
        /// フォルダ情報
        /// </summary>
        [XmlElement("Folder")]
        public Folder Folder { get; set; } = new Folder();

        /// <summary>
        /// エクスポート情報
        /// </summary>
        [XmlElement("Export")]
        public Export Export { get; set; } = new Export();

        /// <summary>
        /// ファイル名情報
        /// </summary>
        [XmlElement("FileName")]
        public FileName FileName { get; set; } = new FileName();

        /// <summary>
        /// CSVカラム情報
        /// </summary>
        [XmlElement("CsvColumn")]
        public CsvColumn CsvColumn { get; set; } = new CsvColumn();

        /// <summary>
        /// CSV行情報
        /// </summary>
        [XmlElement("CsvRow")]
        public CsvRow CsvRow{ get; set; } = new CsvRow();
    }// class AppConfig

    /// <summary>
    /// XProtectサーバー情報
    /// </summary>
    public class XProtectServer
    {
        /// <summary>
        /// XProtectサーバーUri
        /// </summary>
        [XmlElement("Uri")]
        public string Uri { get; set; }

        /// <summary>
        /// XProtectユーザー
        /// </summary>
        [XmlElement("User")]
        public string User { get; set; }

        /// <summary>
        /// XProtectパスワード（暗号化）
        /// </summary>
        [XmlElement("EncryptedPassword")]
        public string EncryptedPassword { get; set; } = null;

        /// <summary>
        /// XProtectパスワード
        /// </summary>
        [XmlElement("Password")]
        public string Password { get; set; } = null;

        /// <summary>
        /// 認証方式
        /// </summary>
        [XmlElement("AuthenticationType")]
        public string AuthenticationType { get; set; }

        /// <summary>
        /// ログインリトライ回数
        ///   -1:無制限
        /// </summary>
        [XmlElement("LoginRetryCount")]
        public int LoginRetryCount { get; set; } = -9999;

        /// <summary>
        /// ログインリトライ間隔（秒）
        /// </summary>
        [XmlElement("LoginRetryInterval")]
        public int LoginRetryInterval { get; set; } = -9999;

        /// <summary>
        /// カメラ一覧取得間隔（分）
        /// </summary>
        [XmlElement("GetCameraListInterval")]
        public int GetCameraListInterval { get; set; } = -9999;

    }// class XProtectServer

    /// <summary>
    /// フォルダ情報
    /// </summary>
    public class Folder
    {
        /// <summary>
        /// ホットフォルダパス
        /// </summary>
        [XmlElement("HotFolderPath")]
        public string HotFolderPath { get; set; }

        /// <summary>
        /// 監視間隔(秒)
        /// </summary>
        [XmlElement("HotFolderPollingInterval")]
        public int HotFolderPollingInterval { get; set; } = -9999;

        /// <summary>
        /// ワークフォルダパス
        /// </summary>
        [XmlElement("WorkFolderPath")]
        public string WorkFolderPath { get; set; }

        /// <summary>
        /// エクスポートフォルダパス
        /// </summary>
        [XmlElement("ExportFolderPath")]
        public string ExportFolderPath { get; set; }
    }// class Folder

    /// <summary>
    /// エクスポート情報
    /// </summary>
    public class Export
    {
        /// <summary>
        /// エクスポート形式
        /// </summary>
        [XmlElement("Format")]
        public int Format { get; set; } = -9999;

        /// <summary>
        /// プレ時間（秒）
        /// </summary>
        [XmlElement("PreTime")]
        public int PreTime { get; set; } = -9999;

        /// <summary>
        /// エクスポート時間（秒）
        /// </summary>
        [XmlElement("ExportTime")]
        public int ExportTime { get; set; } = -9999;
    }// class Export

    /// <summary>
    /// ファイル名情報
    /// </summary>
    public class FileName
    {
        /// <summary>
        /// ファイル名の先頭の形式
        /// </summary>
        [XmlElement("Type")]
        public int Type { get; set; } = -9999;

    }// class ExportFormat

    /// <summary>
    /// CSV行情報
    /// </summary>
    public class CsvRow
    {
        /// <summary>
        /// CSVの1行目をヘッダ行とする
        /// </summary>
        [XmlElement("UseCsvHeader")]
        public bool UseCsvHeader { get; set; } = false;
    }

    /// <summary>
    /// CSVカラム情報
    /// </summary>
    public class CsvColumn
    {
        /// <summary>
        /// CSV上「エクスポート時刻」カラム位置
        /// </summary>
        [XmlElement("ExportDateTimeIndex")]
        public int ExportDateTimeIndex { get; set; } = -9999;

        /// <summary>
        /// CSV上「カメラ名」カラム位置
        /// </summary>
        [XmlElement("ExportCameraNameIndex")]
        public int ExportCameraNameIndex { get; set; } = -9999;

        /// <summary>
        /// CSV上「プレ時間」カラム位置
        /// </summary>
        [XmlElement("PreTimeIndex")]
        public int PreTimeIndex { get; set; } = -9999;

        /// <summary>
        /// CSV上「エクスポート時間」カラム位置
        /// </summary>
        [XmlElement("ExportTimeIndex")]
        public int ExportTimeIndex { get; set; } = -9999;

        /// <summary>
        /// CSV上「エクスポートファイル出力フォルダ名」カラム位置
        /// </summary>
        [XmlElement("ExportFileOutputFolderIndex")]
        public int ExportFileOutputFolderIndex { get; set; } = -9999;

        /// <summary>
        /// CSV上「ファイル名パーツ①」カラム位置
        /// </summary>
        [XmlElement("ExportFileNamePart1Index")]
        public int ExportFileNamePart1Index { get; set; } = -9999;

        /// <summary>
        /// CSV上「ファイル名パーツ②」カラム位置
        /// </summary>
        [XmlElement("ExportFileNamePart2Index")]
        public int ExportFileNamePart2Index { get; set; } = -9999;

        /// <summary>
        /// CSV上「ファイル名パーツ③」カラム位置
        /// </summary>
        [XmlElement("ExportFileNamePart3Index")]
        public int ExportFileNamePart3Index { get; set; } = -9999;

        /// <summary>
        /// CSV上「ファイル名パーツ④」カラム位置
        /// </summary>
        [XmlElement("ExportFileNamePart4Index")]
        public int ExportFileNamePart4Index { get; set; } = -9999;

        /// <summary>
        /// CSV上「ファイル名パーツ⑤」カラム位置
        /// </summary>
        [XmlElement("ExportFileNamePart5Index")]
        public int ExportFileNamePart5Index { get; set; } = -9999;

    }// class CsvColumn

}// namespace XPAutoExport.Config
