// ----------------------------------------------------------------------------
// <copyright file="CheckConfig.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System.IO;
using XPAutoExport.Common;

namespace XPAutoExport.Config
{
    /// <summary>
    /// 設定ファイルXMLの内容のバリデーションチェッククラス
    /// </summary>
    public static class CheckConfig
    {
        /// <summary>
        /// ログインリトライ回数のデフォルト値（秒）
        /// </summary>
        private const int DefaultLoginRetryCount = 5;

        /// <summary>
        /// ログインリトライ間隔のデフォルト値（秒）
        /// </summary>
        private const int DefaultLoginRetryInterval = 20;

        /// <summary>
        /// カメラ一覧取得間隔（分）
        /// </summary>
        private const int DefaultGetCameraListInterval = 0;

        /// <summary>
        /// 監視間隔のデフォルト値（秒）
        /// </summary>
        private const int DefaultHotFolderPollingInterval = 30;

        /// <summary>
        /// エクスポート形式
        /// </summary>
        private const int DefaultFormat = ExportFormat.Mkv;

        /// <summary>
        /// プレ時間（秒）
        /// </summary>
        private const int DefaultPreTime = 10;

        /// <summary>
        /// エクスポート時間（秒）
        /// </summary>
        private const int DefaultExportTime = 60;

        /// <summary>
        /// ファイル名の先頭の形式
        /// </summary>
        private const int DefaultType = FileNameType.CameraNm_Timestamp;

        /// <summary>
        /// CSV上「エクスポート時刻」カラム位置
        /// </summary>
        private const int DefaultExportDateTimeIndex = 0;

        /// <summary>
        /// CSV上「カメラ名」カラム位置
        /// </summary>
        private const int DefaultExportCameraNameIndex = 1;

        /// <summary>
        /// CSV上「プレ時間」カラム位置
        /// </summary>
        private const int DefaultPreTimeIndex = 2;

        /// <summary>
        /// CSV上「エクスポート時間」カラム位置
        /// </summary>
        private const int DefaultExportTimeIndex = 3;

        /// <summary>
        /// CSV上「エクスポートファイル出力フォルダ名」カラム位置
        /// </summary>
        private const int DefaultExportFileOutputFolderIndex = 4;

        /// <summary>
        /// CSV上「ファイル名パーツ①」カラム位置
        /// </summary>
        private const int DefaultExportFileNamePart1Index = 5;

        /// <summary>
        /// CSV上「ファイル名パーツ②」カラム位置
        /// </summary>
        private const int DefaultExportFileNamePart2Index = 6;

        /// <summary>
        /// CSV上「ファイル名パーツ③」カラム位置
        /// </summary>
        private const int DefaultExportFileNamePart3Index = 7;

        /// <summary>
        /// CSV上「ファイル名パーツ④」カラム位置
        /// </summary>
        private const int DefaultExportFileNamePart4Index = 8;

        /// <summary>
        /// CSV上「ファイル名パーツ⑤」カラム位置
        /// </summary>
        private const int DefaultExportFileNamePart5Index = 9;



        /// <summary>
        /// 設定内容の妥当性（フォルダの存在チェック等）確認
        /// </summary>
        /// <returns>チェック結果</returns>
        public static bool Check()
        {
            AppConfig appConfig = Program.GetAppConfigInstace();
            var result = true;

            // XProtectサーバー情報 「XProtectサーバーUri」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set XProtectServer information \"Uri\" :{appConfig.XProtectServer.Uri}");
            if (string.IsNullOrWhiteSpace(appConfig.XProtectServer.Uri) == true)
            {
                Logger.Instace.Error($"CheckConfig :: Check : XProtectServer information \"Uri\" not set.");
                result = false;
            }// if
            else
            {
                Logger.Instace.Info($"CheckConfig :: Check : XProtectServer information \"Uri\" :{appConfig.XProtectServer.Uri}.");
            }// else

            // XProtectサーバー情報 「XProtectユーザー」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set XProtectServer Information \"User\" :{appConfig.XProtectServer.User}");
            if (string.IsNullOrWhiteSpace(appConfig.XProtectServer.User) == true)
            {
                Logger.Instace.Error($"CheckConfig :: Check : XProtectServer Information \"User\" not set.");
                result = false;
            }// if
            else
            {
                Logger.Instace.Info($"CheckConfig :: Check : XProtectServer Information \"User\" :{appConfig.XProtectServer.User}");
            }// else

            // 「XProtectパスワード」「XProtectパスワード（暗号化）」の両方のタグが存在しない場合はエラーとする。
            if ((appConfig.XProtectServer.EncryptedPassword == null) &&
                (appConfig.XProtectServer.Password == null))
            {
                Logger.Instace.Error($"CheckConfig :: Check : XProtectServer Information \"EncryptedPassword\" and \"Password\" not set.");
                result = false;
            }

            // XProtectサーバー情報 「認証方式」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set XProtectServer information \"AuthenticationType\" :{appConfig.XProtectServer.AuthenticationType}");
            if (string.IsNullOrWhiteSpace(appConfig.XProtectServer.AuthenticationType) == true)
            {
                Logger.Instace.Error($"CheckConfig :: Check : XProtectServer information \"AuthenticationType\" not set.");
                result = false;
            }// if
            else
            {
                Logger.Instace.Info($"CheckConfig :: Check : XProtectServer information \"AuthenticationType\" :{appConfig.XProtectServer.AuthenticationType}");
            }// else

            // XProtectサーバー情報 「ログインリトライ回数」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set XProtectServer information Set the default value for \"LoginRetryCount\" :{appConfig.XProtectServer.LoginRetryCount}");
            if (appConfig.XProtectServer.LoginRetryCount < -1)
            {
                appConfig.XProtectServer.LoginRetryCount = DefaultLoginRetryCount;
                Logger.Instace.Warn($"CheckConfig :: Check : XProtectServer information Set the default value for \"LoginRetryCount\" :{appConfig.XProtectServer.LoginRetryCount}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : XProtectServer information \"LoginRetryCount\" :{appConfig.XProtectServer.LoginRetryCount}");

            // XProtectサーバー情報 「ログインリトライ間隔（秒）」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set XProtectServer information set the default value for \"LoginRetryInterval\" :{appConfig.XProtectServer.LoginRetryInterval}");
            if (appConfig.XProtectServer.LoginRetryInterval < 0)
            {
                appConfig.XProtectServer.LoginRetryInterval = DefaultLoginRetryInterval;
                Logger.Instace.Warn($"CheckConfig :: Check : XProtectServer information set the default value for \"LoginRetryInterval\" :{appConfig.XProtectServer.LoginRetryInterval}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : XProtectServer information \"LoginRetryInterval\" :{appConfig.XProtectServer.LoginRetryInterval}");

            // XProtectサーバー情報 「カメラ一覧取得間隔（分）」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set XProtectServer information Set the default value for \"GetCameraListInterval\" :{appConfig.XProtectServer.GetCameraListInterval}");
            if (appConfig.XProtectServer.GetCameraListInterval < 0)
            {
                appConfig.XProtectServer.GetCameraListInterval = DefaultGetCameraListInterval;
                Logger.Instace.Warn($"CheckConfig :: Check : XProtectServer information set the default value for \"GetCameraListInterval\" :{appConfig.XProtectServer.GetCameraListInterval}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : XProtectServer information \"GetCameraListInterval\" :{appConfig.XProtectServer.GetCameraListInterval}");

            // フォルダ情報 「ホットフォルダパス」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set Folder information \"HotFolderPath\" :{appConfig.Folder.HotFolderPath}");
            if (string.IsNullOrWhiteSpace(appConfig.Folder.HotFolderPath) == true)
            {
                Logger.Instace.Error($"CheckConfig :: Check : Folder information \"HotFolderPath\" is not set.");
                result = false;
            }// if
            else if (Directory.Exists(appConfig.Folder.HotFolderPath) == false)
            {
                Logger.Instace.Warn($"CheckConfig :: Check : Folder information \"HotFolderPath\" does not exist. :{appConfig.Folder.HotFolderPath}");
            }// else if
            else
            {
                Logger.Instace.Info($"CheckConfig :: Check : Folder information \"HotFolderPath\" :{appConfig.Folder.HotFolderPath}");
            }// else

            // フォルダ情報 「監視間隔(秒)」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set Folder information set the default value for \"HotFolderPollingInterval\" :{appConfig.Folder.HotFolderPollingInterval}");
            if (appConfig.Folder.HotFolderPollingInterval < 0)
            {
                appConfig.Folder.HotFolderPollingInterval = DefaultHotFolderPollingInterval;
                Logger.Instace.Warn($"CheckConfig :: Check : Folder information set the default value for \"HotFolderPollingInterval\" :{appConfig.Folder.HotFolderPollingInterval}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : Folder information \"HotFolderPollingInterval\" :{appConfig.Folder.HotFolderPollingInterval}");

            // フォルダ情報 「ワークフォルダパス」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set Folder information \"WorkFolderPath\" :{appConfig.Folder.WorkFolderPath}");
            if (string.IsNullOrWhiteSpace(appConfig.Folder.WorkFolderPath) == true)
            {
                Logger.Instace.Error($"CheckConfig :: Check : Folder information \"WorkFolderPath\" is not set.");
                result = false;
            }// if
            else if (Directory.Exists(appConfig.Folder.WorkFolderPath) == false)
            {
                Logger.Instace.Warn($"CheckConfig :: Check : \"WorkFolderPath\" does not exist :{appConfig.Folder.WorkFolderPath}");
            }// else if
            else
            {
                Logger.Instace.Info($"CheckConfig :: Check : Folder information \"WorkFolderPath\" :{appConfig.Folder.WorkFolderPath}");
            }// else

            // フォルダ情報 「エクスポートフォルダパス」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set Folder information \"ExportFolderPath\" :{ appConfig.Folder.ExportFolderPath}");
            if (string.IsNullOrWhiteSpace(appConfig.Folder.ExportFolderPath) == true)
            {
                Logger.Instace.Error($"CheckConfig :: Check : Folder information \"ExportFolderPath\" is not set.");
                result = false;
            }// if
            else if (Directory.Exists(appConfig.Folder.ExportFolderPath) == false)
            {
                Logger.Instace.Error($"CheckConfig :: Check : \"ExportFolderPath\" does not exist :{appConfig.Folder.ExportFolderPath}");
                result = false;
            }// else if
            else
            {
                Logger.Instace.Info($"CheckConfig :: Check : Folder information \"ExportFolderPath\" :{appConfig.Folder.ExportFolderPath}");
            }// else

            // エクスポート情報 「エクスポート形式」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set Export information Set the default value for \"Format\" :{appConfig.Export.Format}");
            if ((appConfig.Export.Format != ExportFormat.Mkv) &&
                (appConfig.Export.Format != ExportFormat.Jpeg))
            {
                appConfig.Export.Format = DefaultFormat;
                Logger.Instace.Warn($"CheckConfig :: Check : Export information set the default value for \"Format\" :{appConfig.Export.Format}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : Export information \"Format\" :{appConfig.Export.Format}");

            // 「エクスポート形式」が、映像（NKV）の場合のみ設定する。
            if (appConfig.Export.Format == ExportFormat.Mkv)
            {
                // エクスポート情報 「プレ時間（秒）」 設定値確認
                Logger.Instace.Debug($"CheckConfig :: Check : set Export information set default value for \"PreTime\" :{appConfig.Export.PreTime}");
                if (appConfig.Export.PreTime < 0)
                {
                    appConfig.Export.PreTime = DefaultPreTime;
                    Logger.Instace.Warn($"CheckConfig :: Check : Export information set default value for \"PreTime\" :{appConfig.Export.PreTime}");
                }// if
                Logger.Instace.Info($"CheckConfig :: Check : Export information \"PreTime\" :{appConfig.Export.PreTime}");

                // エクスポート情報 「エクスポート時間（秒）」 設定値確認
                Logger.Instace.Debug($"CheckConfig :: Check : set Export information set default value for \"ExportTime\" :{appConfig.Export.ExportTime}");
                if (appConfig.Export.ExportTime < 0)
                {
                    appConfig.Export.ExportTime = DefaultExportTime;
                    Logger.Instace.Warn($"CheckConfig :: Check : Export information set default value for \"ExportTime\" :{appConfig.Export.ExportTime}");
                }// if
                Logger.Instace.Info($"CheckConfig :: Check : Export information \"ExportTime\" :{appConfig.Export.ExportTime}");
            }// if
            else
            {
                Logger.Instace.Info($"CheckConfig :: Check : Export information \"PreTime\" Do not get.");
                Logger.Instace.Info($"CheckConfig :: Check : Export information \"ExportTime\" Do not get.");
            }

            // ファイル名情報 「ファイル名の先頭の形式」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set FileName information Set the default value in \"Type\" :{appConfig.FileName.Type}");
            if ((appConfig.FileName.Type != FileNameType.CameraNm_Timestamp) &&
                (appConfig.FileName.Type != FileNameType.Timestamp_CameraNm))
            {
                appConfig.FileName.Type = DefaultType;
                Logger.Instace.Warn($"CheckConfig :: Check : FileName information set the default value in \"Type\" :{appConfig.FileName.Type}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : FileName information \"Type\" :{appConfig.FileName.Type}");

            // CSVカラム情報 「CSV上「エクスポート時刻」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information Set default value for \"ExportDateTimeIndex\" :{appConfig.CsvColumn.ExportDateTimeIndex}");
            if (appConfig.CsvColumn.ExportDateTimeIndex < 0)
            {
                appConfig.CsvColumn.ExportDateTimeIndex = DefaultExportDateTimeIndex;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"ExportDateTimeIndex\" :{appConfig.CsvColumn.ExportDateTimeIndex}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"ExportDateTimeIndex\" :{appConfig.CsvColumn.ExportDateTimeIndex}");

            // CSVカラム情報 「CSV上「カメラ名」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information Set default value for \"ExportCameraNameIndex\" :{appConfig.CsvColumn.ExportCameraNameIndex}");
            if (appConfig.CsvColumn.ExportCameraNameIndex < 0)
            {
                appConfig.CsvColumn.ExportCameraNameIndex = DefaultExportCameraNameIndex;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"ExportCameraNameIndex\" :{appConfig.CsvColumn.ExportCameraNameIndex}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"ExportCameraNameIndex\" :{appConfig.CsvColumn.ExportCameraNameIndex}");

            // CSVカラム情報 「CSV上「プレ時間」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information set default value for \"PreTimeIndex\" :{appConfig.CsvColumn.PreTimeIndex}");
            if (appConfig.CsvColumn.PreTimeIndex < 0)
            {
                appConfig.CsvColumn.PreTimeIndex = DefaultPreTimeIndex;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"PreTimeIndex\" :{appConfig.CsvColumn.PreTimeIndex}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"PreTimeIndex\" :{appConfig.CsvColumn.PreTimeIndex}");

            // CSVカラム情報 「CSV上「エクスポート時間」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information Set default value for \"ExportTimeIndex\" :{appConfig.CsvColumn.ExportTimeIndex}");
            if (appConfig.CsvColumn.ExportTimeIndex < 0)
            {
                appConfig.CsvColumn.ExportTimeIndex = DefaultExportTimeIndex;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"ExportTimeIndex\" :{appConfig.CsvColumn.ExportTimeIndex}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"ExportTimeIndex\" :{appConfig.CsvColumn.ExportTimeIndex}");

            // CSVカラム情報 「CSV上「エクスポートファイル出力フォルダ名」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information set default value for \"ExportFileOutputFolderIndex\" :{appConfig.CsvColumn.ExportFileOutputFolderIndex}");
            if (appConfig.CsvColumn.ExportFileOutputFolderIndex < 0)
            {
                appConfig.CsvColumn.ExportFileOutputFolderIndex = DefaultExportFileOutputFolderIndex;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"ExportFileOutputFolderIndex\" :{appConfig.CsvColumn.ExportFileOutputFolderIndex}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"ExportFileOutputFolderIndex\" :{appConfig.CsvColumn.ExportFileOutputFolderIndex}");

            // CSVカラム情報 「CSV上「ファイル名パーツ①」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information set default value for \"ExportFileNamePart1Index\" :{appConfig.CsvColumn.ExportFileNamePart1Index}");
            if (appConfig.CsvColumn.ExportFileNamePart1Index < 0)
            {
                appConfig.CsvColumn.ExportFileNamePart1Index = DefaultExportFileNamePart1Index;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"ExportFileNamePart1Index\" :{appConfig.CsvColumn.ExportFileNamePart1Index}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"ExportFileNamePart1Index\" :{appConfig.CsvColumn.ExportFileNamePart1Index}");

            // CSVカラム情報 「CSV上「ファイル名パーツ②」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information set default value for \"ExportFileNamePart2Index\" :{appConfig.CsvColumn.ExportFileNamePart2Index}");
            if (appConfig.CsvColumn.ExportFileNamePart2Index < 0)
            {
                appConfig.CsvColumn.ExportFileNamePart2Index = DefaultExportFileNamePart2Index;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"ExportFileNamePart2Index\" :{appConfig.CsvColumn.ExportFileNamePart2Index}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"ExportFileNamePart2Index\" :{appConfig.CsvColumn.ExportFileNamePart2Index}");

            // CSVカラム情報 「CSV上「ファイル名パーツ③」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information set default value for \"ExportFileNamePart3Index\" :{appConfig.CsvColumn.ExportFileNamePart3Index}");
            if (appConfig.CsvColumn.ExportFileNamePart3Index < 0)
            {
                appConfig.CsvColumn.ExportFileNamePart3Index = DefaultExportFileNamePart3Index;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"ExportFileNamePart3Index\" :{appConfig.CsvColumn.ExportFileNamePart3Index}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"ExportFileNamePart3Index\" :{appConfig.CsvColumn.ExportFileNamePart3Index}");

            // CSVカラム情報 「CSV上「ファイル名パーツ④」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information set default value for \"ExportFileNamePart4Index\" :{appConfig.CsvColumn.ExportFileNamePart4Index}");
            if (appConfig.CsvColumn.ExportFileNamePart4Index < 0)
            {
                appConfig.CsvColumn.ExportFileNamePart4Index = DefaultExportFileNamePart4Index;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"ExportFileNamePart4Index\" :{appConfig.CsvColumn.ExportFileNamePart4Index}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"ExportFileNamePart4Index\" :{appConfig.CsvColumn.ExportFileNamePart4Index}");

            // CSVカラム情報 「CSV上「ファイル名パーツ⑤」カラム位置」 設定値確認
            Logger.Instace.Debug($"CheckConfig :: Check : set CsvColumn information set default value for \"ExportFileNamePart5Index\" :{appConfig.CsvColumn.ExportFileNamePart5Index}");
            if (appConfig.CsvColumn.ExportFileNamePart5Index < 0)
            {
                appConfig.CsvColumn.ExportFileNamePart5Index = DefaultExportFileNamePart5Index;
                Logger.Instace.Warn($"CheckConfig :: Check : CsvColumn information set default value for \"ExportFileNamePart5Index\" :{appConfig.CsvColumn.ExportFileNamePart5Index}");
            }// if
            Logger.Instace.Info($"CheckConfig :: Check : CsvColumn information \"ExportFileNamePart5Index\" :{appConfig.CsvColumn.ExportFileNamePart5Index}");

            // CSV行情報 「CSVの1行目をヘッダ行とする」 設定値確認
            Logger.Instace.Info($"CheckConfig :: Check : CsvRow information \"UseCsvHeader\" :{appConfig.CsvRow.UseCsvHeader}");

            return result;
        }// Check()


        /// <summary>
        /// 範囲チェック
        /// </summary>
        /// <param name="src">チェック元</param>
        /// <param name="min">最小値</param>
        /// <param name="max">最大値</param>
        /// <returns>範囲内かどうか</returns>
        private static bool IsRange(int src, int min, int max) => min <= src && src <= max;

    }// class CheckConfig

}// namespace XPAutoExport.Config
