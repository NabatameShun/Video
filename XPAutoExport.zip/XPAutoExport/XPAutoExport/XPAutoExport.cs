﻿// ----------------------------------------------------------------------------
// <copyright file="XPAutoExport.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.ServiceProcess;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using VideoOS.Platform;
using XPAutoExport.Common;
using XPAutoExport.Config;
using XpMkvExportDll;
using System.Threading;

namespace XPAutoExport
{
    public partial class XPAutoExport : ServiceBase
    {
        /// <summary>
        /// 設定情報
        /// </summary>
        private readonly AppConfig appConfig = Program.GetAppConfigInstace();

        /// <summary>
        /// 自動エクスポート開始タスク
        /// </summary>
        private Task autoExportStartTask = null;

        /// <summary>
        /// 自動エクスポート開始タスク用キャンセルトークン
        /// </summary>
        private CancellationTokenSource autoExportStartCancellationTokenSource = null;

        /// <summary>
        /// XProtect Management Serverクラスインスタンス
        /// </summary>
        private XPManagementServer _xpManagementServer = null;

        /// <summary>
        /// カメラ一覧
        /// </summary>
        public static Dictionary<FQID, string> CameraFqidList { get; private set; } = new Dictionary<FQID, string>();

        /// <summary>
        /// カメラ一覧実行時間
        /// </summary>
        private static DateTime _runCameraFqidLisDatetime = DateTime.MinValue;

        /// <summary>
        /// CSVファイル毎のエクスポート情報管理インスタンス
        /// </summary>
        private static CsvListManager _csvManager = null;

        /// <summary>
        /// エクスポートの排他処理用ロックオブジェクト
        /// </summary>
        private static Object _lock = new Object();

        /// <summary>
        /// ログイン結果
        /// </summary>
        private enum LoginResult
        {
            /// <summary>成功</summary>
            Success,
            /// <summary>失敗</summary>
            Failure,
            /// <summary>中断</summary>
            Suspend
        }// enum LoginResult 

        /// <summary>
        /// サービスステータス
        /// </summary>
        public enum ServiceState
        {
            SERVICE_STOPPED = 0x00000001,
            SERVICE_START_PENDING = 0x00000002,
            SERVICE_STOP_PENDING = 0x00000003,
            SERVICE_RUNNING = 0x00000004,
            SERVICE_CONTINUE_PENDING = 0x00000005,
            SERVICE_PAUSE_PENDING = 0x00000006,
            SERVICE_PAUSED = 0x00000007,
        }// enum ServiceState

        /// <summary>
        /// サービスステータス構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct ServiceStatus
        {
            public int dwServiceType;
            public ServiceState dwCurrentState;
            public int dwControlsAccepted;
            public int dwWin32ExitCode;
            public int dwServiceSpecificExitCode;
            public int dwCheckPoint;
            public int dwWaitHint;
        };

        /// <summary>
        /// 呼び出し側サービスに関するサービス制御マネージャのステータス情報を更新する
        /// </summary>
        /// <param name="handle"></param>
        /// <param name="serviceStatus"></param>
        /// <returns></returns>
        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool SetServiceStatus(IntPtr handle, ref ServiceStatus serviceStatus);


        /// <summary>
        /// デバッグ用コンソール表示
        /// </summary>
        /// <returns></returns>
        [DllImport("kernel32.dll")]
        private static extern bool AllocConsole();

        /// <summary>
        /// csvファイル拡張子
        /// </summary>
        private const string CsvExt = ".csv";

        /// <summary>
        /// errファイル拡張子
        /// </summary>
        private const string ErrExt = ".err";

        /// <summary>
        /// エクスポート時刻テンプレート
        /// </summary>
        private const string ExportTimeTemplate = "yyyy/MM/dd HH:mm:ss";

        /// <summary>
        /// エクスポート時刻（ファイル名）テンプレート
        /// </summary>
        private const string FileNmExportTimeTemplate = "yyyyMMdd_HHmmss";


        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="args"></param>
        public XPAutoExport(string[] _)
        {
            this.InitializeComponent();
        }// XPAutoExport()

        /// <summary>
        /// デバッグ用アプリ実行
        /// </summary>
        /// <param name="args">引数リスト</param>
        internal void TestStartupAndStop(string[] args)
        {
            AllocConsole(); // デバッグ用コンソール表示

            this.OnStart(args);
            Console.WriteLine("Exit for press \"Enter\" key.");
            Task.Run(async delegate
            {
                while (Console.ReadLine() == null)
                {
                    await Task.Delay(1000);
                }// while
            }).Wait();

        }// TestStartupAndStop()


        /// <summary>
        /// サービスの開始
        /// </summary>
        /// <param name="args"></param>
        protected override void OnStart(string[] args)
        {
            Logger.Instace.Info("XPAutoExport :: OnStart : >>>>>>>>>>>>>>>> start.");

            // サービス状態を「開始保留」に更新する
            var serviceStatus = new ServiceStatus() {
                dwCurrentState = ServiceState.SERVICE_START_PENDING, 
                dwWaitHint = 100000 
            };
            SetServiceStatus(this.ServiceHandle, ref serviceStatus);

            autoExportStartCancellationTokenSource = new CancellationTokenSource();

            _csvManager = new CsvListManager();
            _csvManager.ClearCsvInfoList();

            //Xprotectへログイン開始
            this._xpManagementServer = new XPManagementServer(this.appConfig.XProtectServer.Uri,
                                                              this.appConfig.XProtectServer.User,
                                                              this.appConfig.XProtectServer.Password,
                                                              this.appConfig.XProtectServer.AuthenticationType);
            Logger.Instace.Debug("XPAutoExport :: OnStart : service initialize completed.");

            // 自動エクスポート開始タスク実行
            autoExportStartTask = Task.Run(() => this.AutoExportStartTask(autoExportStartCancellationTokenSource.Token));

            Logger.Instace.Info("XPAutoExport :: OnStart : >>>>>>>>>>>>>>>> end.");
        }// OnStart()


        /// <summary>
        /// サービスの停止
        /// </summary>
        protected override void OnStop()
        {
            Logger.Instace.Info("XPAutoExport :: OnStop : >>>>>>>>>>>>>>>> start.");

            // サービス状態を「停止保留」に更新する
            var serviceStatus = new ServiceStatus()
            {
                dwCurrentState = ServiceState.SERVICE_STOP_PENDING,
                dwWaitHint = 100000
            };
            SetServiceStatus(this.ServiceHandle, ref serviceStatus);

            // 処理キャンセル
            if ((this.autoExportStartCancellationTokenSource != null) && (!this.autoExportStartCancellationTokenSource.IsCancellationRequested))
            {
                this.autoExportStartCancellationTokenSource?.Cancel();
                if (autoExportStartTask != null)
                {
                    autoExportStartTask.Wait(10000);
                }
                this.autoExportStartCancellationTokenSource.Dispose();
            }

            // XProtect Management Serverからログアウト
            this._xpManagementServer?.Logout();
            this._xpManagementServer = null;

            Logger.Instace.Info("XPAutoExport :: OnStop : >>>>>>>>>>>>>>>> end.");
        }// OnStop()


        /// <summary>
        /// 自動エクスポート開始タスク
        /// <param name="token">自動エクスポート開始タスク用キャンセルトクーン</param>
        /// </summary>
        public void AutoExportStartTask(CancellationToken token)
        {
            try
            {
                Logger.Instace.Info("XPAutoExport :: AutoExportStartTask : start.");

                //-------------------
                // Xprotectへログイン
                //------------------
                LoginResult res = this.LoginToXProtect(token);
                if (res == LoginResult.Failure)
                {
                    Logger.Instace.Debug("XPAutoExport :: AutoExportStartTask : service stop.");
                    // サービス停止
                    this.Stop();
                    return;
                }
                else if (res == LoginResult.Suspend)
                {
                    Logger.Instace.Debug($"XPAutoExport :: AutoExportStartTask : end canceled. [true]");
                    return;
                }

                Logger.Instace.Debug("XPAutoExport :: AutoExportStartTask : login ok.");

                // サービスステータス：実行中
                var serviceStatus = new ServiceStatus()
                {
                    dwCurrentState = ServiceState.SERVICE_RUNNING,
                    dwWaitHint = 100000
                };
                SetServiceStatus(this.ServiceHandle, ref serviceStatus);

                //----------------
                // カメラ一覧取得
                //----------------
                CameraFqidList = XPManagementServer.GetCameraFqidList();
                _runCameraFqidLisDatetime = DateTime.Now;
                Logger.Instace.Info($"XPAutoExport :: AutoExportStartTask : get a list of cameras. datetime:{_runCameraFqidLisDatetime.ToString("yyyy/MM/dd HH:mm:ss")}");

                Logger.Instace.Info($"XPAutoExport :: AutoExportStartTask : csv file existence confirmation start.");

                //-------------------------------------
                // ワークフォルダのCSVファイル情報取得
                //-------------------------------------
                this.GetCsvInfoForWorkFolder(token);

                //---------------------------------
                // ホットフォルダ監視処理スタート
                //---------------------------------
                this.HotFolderMonitoringProcess(autoExportStartCancellationTokenSource.Token);

                Logger.Instace.Info("XPAutoExport :: AutoExportStartTask : end.");
                return;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPAutoExport :: AutoExportStartTask : exception error.");
                Logger.Instace.ErrorException(ex);
                // サービス停止
                this.Stop();
                Logger.Instace.Info("XPAutoExport :: AutoExportStartTask : error end.");
                return;
            }
        }// AutoExportStartTask()


        /// <summary>
        /// XProtectにログインする
        /// </summary>
        /// <param name="token">タスクキャンセルトクーン</param>
        /// <returns></returns>
        private LoginResult LoginToXProtect(CancellationToken token)
        {
            Logger.Instace.Debug("XPAutoExport :: LoginToXProtect : start.");
            LoginResult res = LoginResult.Suspend;
            try
            {
                int cnt = 0;
                while (true)
                {
                    // サービス停止時、例外OperationCanceledExceptionを通知
                    token.ThrowIfCancellationRequested();

                    try
                    {
                        bool ret = this._xpManagementServer.Login();
                        if (ret)
                        {
                            Logger.Instace.Info($"XPAutoExport :: LoginToXProtect : successed to login to XProtect.  ServerId:{this._xpManagementServer.ServerId.ToString()}");
                            res = LoginResult.Success;
                            break;
                        }// if
                    }
                    catch (Exception ex)
                    {
                        Logger.Instace.Warn($"XPAutoExport :: LoginToXProtect : Exception error.");
                        Logger.Instace.Warn(ex.StackTrace);
                    }
                    Logger.Instace.Info("XPAutoExport :: LoginToXProtect : failed to login to XProtect.");

                    // リトライ回数上限チェック
                    cnt++;
                    if (this.appConfig.XProtectServer.LoginRetryCount != -1)
                    {
                        if (this.appConfig.XProtectServer.LoginRetryCount < cnt)
                        {
                            Logger.Instace.Error("XPAutoExport :: LoginToXProtect : I tried the maximum number of times, but I could not login.");
                            res = LoginResult.Failure;
                            break;
                        }
                    }
                    Logger.Instace.Info($"XPAutoExport :: LoginToXProtect : login retry. cnt:{cnt}");

                    // リトライ時間待ち
                    Task.Run(async () =>
                    {
                        try
                        {
                            await Task.Delay(this.appConfig.XProtectServer.LoginRetryInterval * 1000, token);
                        }
                        catch (OperationCanceledException)
                        {
                            Logger.Instace.Debug($"XPAutoExport :: LoginToXProtect : Task.Delay() canceled.");
                        }
                    }).Wait();

                }// while
            }// try
            catch (OperationCanceledException)
            {
                Logger.Instace.Info("XPAutoExport :: LoginToXProtect : canceled end.");
                res = LoginResult.Suspend;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPAutoExport :: LoginToXProtect : Exception error");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Info("XPAutoExport :: LoginToXProtect : error end.");
                res = LoginResult.Failure;
            }

            Logger.Instace.Debug("XPAutoExport :: LoginToXProtect : end.  return:{res}");
            return res;
        }// LoginToXProtect()


        /// <summary>
        /// ホットフォルダ監視処理
        /// </summary>
        /// <param name="token">ホットフォルダ監視タスク用キャンセルトークン</param>
        public void HotFolderMonitoringProcess(CancellationToken token)
        {
            try
            {
                Logger.Instace.Info("XPAutoExport :: HotFolderMonitoringProcess : start.");
                while (!token.IsCancellationRequested)
                {
                    if (!Directory.Exists(appConfig.Folder.HotFolderPath))
                    {
                        Logger.Instace.Warn($"XPAutoExport :: HotFolderMonitoringProcess : hot folder not found. folder:{appConfig.Folder.HotFolderPath}");
                    }
                    else
                    {
                        try
                        {
                            Logger.Instace.Info("XPAutoExport :: HotFolderMonitoringProcess : perform hot folder monitoring.");

                            // カメラ一覧更新
                            CameraFqidListUpdate();

                            // ホットフォルダCSVファイル情報取得
                            if (!this.WatchHotFolder(token))
                            {
                                Logger.Instace.Warn("XPAutoExport :: HotFolderMonitoringProcess : hot folder csv file information acquisition failure.");
                            }// if

                            // エクスポート処理
                            if (!this.ExportProcess(token))
                            {
                                Logger.Instace.Warn("XPAutoExport :: HotFolderMonitoringProcess : Export process failed.");
                            }// if

                            // ホットフォルダ内のCSVファイル
                            string[] csvFiles = FileManager.GetCsvFileListInFolder(appConfig.Folder.HotFolderPath);
                            if (csvFiles.Length > 0)
                            {
                                csvFiles = null;
                                continue;
                            }// if
                            csvFiles = null;
                        }
                        catch (OperationCanceledException)
                        {
                            Logger.Instace.Info("XPAutoExport :: HotFolderMonitoringProcess : canceled end.");
                            break;
                        }
                        catch (Exception ex)
                        {
                            Logger.Instace.Warn($"XPAutoExport :: HotFolderMonitoringProcess : Exception error");
                            Logger.Instace.Warn(ex.ToString());
                        }
                    }

                    // 監視時間待ち
                    Task.Run(async () =>
                    {
                        try
                        {
                            await Task.Delay(this.appConfig.Folder.HotFolderPollingInterval * 1000, token);
                        }
                        catch (OperationCanceledException)
                        {
                            Logger.Instace.Debug("XPAutoExport :: HotFolderMonitoringProcess : Task.Delay canceled.");
                        }
                    }).Wait();

                }//while
                // 終了はサービス停止が行われた時

                Logger.Instace.Info("XPAutoExport :: HotFolderMonitoringProcess : end.");
                return;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPAutoExport :: HotFolderMonitoringProcess : Exception error");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Info("XPAutoExport :: HotFolderMonitoringProcess : error end.");
                // サービス停止
                this.Stop();
                return;
            }
        }// HotFolderMonitoringProcess()


        /// <summary>
        /// ホットフォルダCSVファイル情報取得
        /// </summary>
        /// <param name="token">タスクキャンセルトクーン</param>
        /// <returns>結果</returns>
        private bool WatchHotFolder(CancellationToken token)
        {
            Logger.Instace.Debug("XPAutoExport :: WatchHotFolder : start.");
            lock (_lock)
            {
                try
                {
                    //---------------------------------------------
                    // ホットフォルダ内のCSVファイルパスを取得する
                    //---------------------------------------------
                    string[] csvFiles = FileManager.GetCsvFileListInFolder(appConfig.Folder.HotFolderPath);
                    if (csvFiles.Length == 0)
                    {
                        Logger.Instace.Debug("XPAutoExport :: WatchHotFolder : there is no csv file in the hot folder.");
                        Logger.Instace.Debug("XPAutoExport :: WatchHotFolder : end. ret:true");
                        return true;
                    }// if
                    Logger.Instace.Debug($"XPAutoExport :: WatchHotFolder : number of csv in hot folder. cnt:{csvFiles.Length}");

                    //-------------------------------------------
                    // ホットフォルダ上の全CSVファイルを処理する
                    //-------------------------------------------
                    foreach (string csvFile in csvFiles)
                    {
                        // サービス停止時、例外OperationCanceledExceptionを通知
                        token.ThrowIfCancellationRequested();

                        Logger.Instace.Debug($"XPAutoExport :: WatchHotFolder : csv file discovery. file:{csvFile}");

                        //--------------------------------------------------------------
                        // ホットフォルダ上の全CSVファイルをワークフォルダ上に移動させる
                        //--------------------------------------------------------------
                        FileManager fileManager = new FileManager();
                        if (fileManager.MoveCsvFileToWorkFolder(csvFile) == false)
                        {
                            Logger.Instace.Warn($"XPAutoExport :: WatchHotFolder : csv file copy to work folder failed, so replace with err file.  csv:{csvFile}");
                            fileManager.SendErrorFileToHotFolder();
                            fileManager = null;
                            continue;
                        }// if

                        //-------------------------------------------------
                        // CSVファイルの内容からエクスポート情報を取得する
                        //-------------------------------------------------
                        // ワークフォルダ内のカレントなCSVファイルパスの取得
                        string currentCsvFilePath = fileManager.GetCurrentWorkCsvFilePath();
                        Logger.Instace.Debug($"XPAutoExport :: WatchHotFolder : get export information from csv file under work folder. csv:{currentCsvFilePath}");
                        // エクスポート情報を取得
                        if (!GetExportInfoFromCsv(currentCsvFilePath))
                        {
                            fileManager = null;
                            Logger.Instace.Debug("XPAutoExport :: WatchHotFolder : end. ret:false");
                            return false;
                        }// if

                        fileManager = null;
                    }// foreach
                }
                catch (OperationCanceledException)
                {
                    Logger.Instace.Info("XPAutoExport :: WatchHotFolder : canceled end.");
                    return true;
                }
                catch (Exception ex)
                {
                    Logger.Instace.Warn($"XPAutoExport :: WatchHotFolder : exception error");
                    Logger.Instace.Warn(ex.ToString());
                    Logger.Instace.Debug("XPAutoExport :: WatchHotFolder : end. ret:false");
                    return false;
                }
            } // lock

            Logger.Instace.Debug("XPAutoExport :: WatchHotFolder : end. ret:true");
            return true;
        }// WatchHotFolder()


        /// <summary>
        /// ワークフォルダCSVファイル情報取得
        /// </summary>
        /// <param name="token">タスクキャンセルトクーン</param>
        private void GetCsvInfoForWorkFolder(CancellationToken token)
        {
            Logger.Instace.Debug("XPAutoExport :: GetCsvInfoForWorkFolder : start.");
            bool endflg = false;
            while (!token.IsCancellationRequested)
            {
                if (!Directory.Exists(appConfig.Folder.WorkFolderPath))
                {
                    Logger.Instace.Warn($"XPAutoExport :: GetCsvInfoForWorkFolder : work folder not found. folder:{appConfig.Folder.WorkFolderPath}");
                }
                else
                {
                    lock (_lock)
                    {
                        try
                        {
                            //---------------------------------------------
                            // ワークフォルダ内のCSVファイルパスを取得する
                            //---------------------------------------------
                            string[] csvFiles = FileManager.GetCsvFileListInFolder(appConfig.Folder.WorkFolderPath);
                            Logger.Instace.Debug($"XPAutoExport :: GetCsvInfoForWorkFolder :  number of csv in work folder. cnt:{csvFiles.Length}");
                            if (csvFiles.Length == 0)
                            {
                                Logger.Instace.Debug("XPAutoExport :: GetCsvInfoForWorkFolder : there is no csv file in the work folder.");
                                Logger.Instace.Debug("XPAutoExport :: GetCsvInfoForWorkFolder : end.");
                            }// if
                            else
                            {
                                //-------------------------------------------
                                // ワークフォルダ上の全CSVファイルを処理する
                                //-------------------------------------------
                                foreach (string csvFile in csvFiles)
                                {
                                    // サービス停止時、例外OperationCanceledExceptionを通知
                                    token.ThrowIfCancellationRequested();

                                    //-------------------------------------------------
                                    // CSVファイルの内容からエクスポート情報を取得する
                                    //-------------------------------------------------
                                    Logger.Instace.Debug($"XPAutoExport :: GetCsvInfoForWorkFolder : get export information from the contents of a csv file.  csv:{csvFile}");
                                    if (!GetExportInfoFromCsv(csvFile))
                                    {
                                        Logger.Instace.Debug("XPAutoExport :: GetCsvInfoForWorkFolder : failed to get export information from csv file.");
                                    }// if
                                }// foreach
                            }//else
                            endflg = true;
                        }
                        catch (OperationCanceledException)
                        {
                            Logger.Instace.Debug("XPAutoExport :: GetCsvInfoForWorkFolder : canceled end.");
                            endflg = true;
                        }
                        catch (Exception ex)
                        {
                            Logger.Instace.Warn($"XPAutoExport :: GetCsvInfoForWorkFolder : exception error");
                            Logger.Instace.Warn(ex.ToString());
                        }
                    }// lock
                    if (endflg)
                    {
                        break;
                    }
                }

                // 監視時間待ち
                Task.Run(async () =>
                {
                    try
                    {
                        await Task.Delay(this.appConfig.Folder.HotFolderPollingInterval * 1000, token);
                    }
                    catch (OperationCanceledException)
                    {
                        Logger.Instace.Debug("XPAutoExport :: GetCsvInfoForWorkFolder : Task.Delay canceled.");
                    }
                }).Wait();

            }// while
            Logger.Instace.Debug("XPAutoExport :: GetCsvInfoForWorkFolder : end.");
            return;
        }// GetCsvInfoForWorkFolder()


        /// <summary>
        /// CSVファイルの内容からエクスポート情報を取得する。
        /// </summary>
        /// <param name="CsvFilePath">CSVファイルパス</param>
        /// <remarks>処理結果</remarks>
        private static bool GetExportInfoFromCsv(string csvFilePath)
        {
            try
            {
                Logger.Instace.Debug($"XPAutoExport :: GetExportInfoFromCsv : start.  csv:{csvFilePath}");

                //---------------------
                // CSVファイル情報作成
                //---------------------
                CsvInfo csvInfo = new CsvInfo(csvFilePath);

                //------------------------------------------------------------
                // CSVファイルをロードしてエクスポート情報リストとして展開する
                //------------------------------------------------------------
                var res = csvInfo.CreateExportInfoList();
                if (!res || csvInfo.GetExportInfoListCnt() <= 0)
                {
                    if (!res)
                    {
                        Logger.Instace.Warn("XPAutoExport :: GetExportInfoFromCsv : failed to create export list.");
                        csvInfo.SetErrorFlag(true);
                    }// if
                    if (csvInfo.GetExportInfoListCnt() == 0)
                    {
                        Logger.Instace.Warn($"XPAutoExport :: GetExportInfoFromCsv : valid export list is empty.  csv:{csvFilePath}");
                        csvInfo.SetErrorFlag(true);
                    }// if
                }

                //-------------------------------------------------------------
                // CSVファイル毎のエクスポート情報追加(配列の先頭に追加する。)
                //-------------------------------------------------------------
                _csvManager.InsertTopCsvInfoList(csvInfo);

                Logger.Instace.Debug("XPAutoExport :: GetExportInfoFromCsv : end. ret:true");
                return true;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPAutoExport :: GetExportInfoFromCsv : exception error");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Debug("XPAutoExport :: GetExportInfoFromCsv : end. ret:false");
                return false;
            }
        }// GetExportInfoFromCsv()


        /// <summary>
        /// エクスポート処理
        /// </summary>
        /// <param name="token">タスクキャンセルトクーン</param>
        /// <remarks>処理結果</remarks>
        private bool ExportProcess(CancellationToken token)
        {
            try
            {
                Logger.Instace.Debug($"XPAutoExport :: ExportProcess : start.");
 
                //-------------
                //エクスポート
                //-------------
                if (appConfig.Export.Format == ExportFormat.Mkv)
                {
                    // Mkvエクスポート処理
                    if (!MkvExportProcess(token))
                    {
                        Logger.Instace.Debug($"XPAutoExport :: ExportProcess : end. ret:false");
                        return false;
                    }
                }// if
                else if (appConfig.Export.Format == ExportFormat.Jpeg)
                {
                    // Jpegエクスポート処理
                    if (!JpegExportProcess(token))
                    {
                        Logger.Instace.Debug($"XPAutoExport :: ExportProcess : end. ret:false");
                        return false;
                    }// if
                }// else if
                else
                {
                    Logger.Instace.Error($"XPAutoExport :: ExportProcess : illegal export format.  export format:{appConfig.Export.Format}");
                    Logger.Instace.Debug($"XPAutoExport :: ExportProcess : end. ret:false");
                    return false;
                }// else

                Logger.Instace.Debug($"XPAutoExport :: ExportProcess : end. ret:true");
                return true;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPAutoExport :: ExportProcess : Exception error");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Debug($"XPAutoExport :: ExportProcess : end. ret:false");
                return false;
            }
        }// ExportProcess()


        /// <summary>
        /// Mkvエクスポート処理
        /// </summary>
        /// <param name="token">タスクキャンセルトクーン</param>
        /// <remarks>処理結果</remarks>
        private bool MkvExportProcess(CancellationToken token)
        {
            try
            {
                Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : start.");

                // CsvInfoListの処理済み要素を消していくので、配列番号がずれないように配列の末尾から処理を行う
                int csvInfoListCnt = _csvManager.CountCsvInfoList();
                Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : number of csv file information.  cnt:{csvInfoListCnt}");
                for (int csvFileNo = (csvInfoListCnt - 1); csvFileNo >= 0; csvFileNo--)
                {
                    //N件目のCSVファイル情報取得
                    CsvInfo csvInfo = _csvManager.GetCsvInfoList(csvFileNo);

                    Logger.Instace.Info($"XPAutoExport :: MkvExportProcess : export target.  csv:{csvInfo.GetCsvFileName()}");
                    Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : number of exports in csv file.  cnt:{csvInfo.GetExportInfoListCnt()}");
                    int untreatedCnt = 0;
                    for (int exprtNo = 0; exprtNo < csvInfo.GetExportInfoListCnt(); exprtNo++)
                    {
                        // サービス停止時、例外OperationCanceledExceptionを通知
                        token.ThrowIfCancellationRequested();

                        //N件目のエクスポート情報取得
                        ExportInfo exportInfo = csvInfo.GetExportInfoFromExportList(exprtNo);
                        if (exportInfo.Stat != Status.Untreated)
                        {
                            //ステータス未処理以外は処理しない
                            continue;
                        }// if

                        // エクスポート終了時間が未来の時間である場合
                        DateTime nowTime = DateTime.Now;
                        var eTime = exportInfo.ExportEndTime.ToString(ExportTimeTemplate);
                        var nTime = nowTime.ToString(ExportTimeTemplate);
                        Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : export end time:{eTime}  now:{nTime}");
                        if (exportInfo.ExportEndTime > nowTime)
                        {
                            Logger.Instace.Info($"XPAutoExport :: MkvExportProcess : csv export end time is future time.  csv：{csvInfo.GetCsvFileName()} line(0origin):{exprtNo}  export end time:{eTime}  now time:{nTime}");
                            untreatedCnt++;
                            continue;
                        }// if

                        //-----------------
                        //映像エクスポート
                        //-----------------
                        string cameraMkvPath = appConfig.Folder.ExportFolderPath + "\\" + exportInfo.ExportFileOutputFolder;
                        if (!Directory.Exists(cameraMkvPath))
                        {
                            DirectoryInfo di = new DirectoryInfo(cameraMkvPath);
                            di.Create();
                        }// if

                        // 映像エクスポートファイル名編集（拡張子無し）
                        string mkvFileName = EditExportFileName(exportInfo);

                        //カメラID取得
                        Guid cameraId = exportInfo.CameraFqid.ObjectId;
                        Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : video export start.  camera id:{cameraId.ToString()} mkv path:{cameraMkvPath} mkv file name:{mkvFileName}");
                        Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : export begin time:{exportInfo.ExportBeginTime.ToString(ExportTimeTemplate)} export end time:{exportInfo.ExportEndTime.ToString(ExportTimeTemplate)}");
                        ExportResponse exprsp = MkvExportClass.Instace.MkvExport(
                                                    cameraId.ToString(),
                                                    cameraMkvPath,
                                                    mkvFileName,
                                                    exportInfo.ExportBeginTime.ToUniversalTime(),
                                                    exportInfo.ExportEndTime.ToUniversalTime(),
                                                    true,
                                                    MkvExportClass.MkvExport_NoTimeout,
                                                    token);
                        if (exprsp < 0)
                        {
                            Logger.Instace.Error($"XPAutoExport :: MkvExportProcess : video export error.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo}");
                            // ステータス：異常
                            exportInfo.Stat = Status.Error;
                            csvInfo.SetErrorFlag(true);
                            Logger.Instace.Info($"XPAutoExport :: MkvExportProcess : set error status.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo}");

                            // XProtectからログアウト後にログイン
                            if (!ReLoginToXProtect(token))
                            {
                                Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : end. ret:false");
                                return false;
                            }
                            continue;
                        }// if
                        else if (exprsp == ExportResponse.Suspend)
                        {
                            Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : video export suspend.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo} camera id:{cameraId.ToString()} mkv path:{cameraMkvPath} mkv file name:{mkvFileName}");
                            continue;
                        }// else if
                        else if (exprsp != ExportResponse.Success)
                        {
                            Logger.Instace.Error($"XPAutoExport :: MkvExportProcess : there is no recorded video.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo} camera id:{cameraId.ToString()} mkv path:{cameraMkvPath} mkv file name:{mkvFileName}");

                            // ステータス：異常
                            exportInfo.Stat = Status.Error;
                            csvInfo.SetErrorFlag(true);
                            Logger.Instace.Info($"XPAutoExport :: MkvExportProcess : set error status.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo} camera id:{cameraId.ToString()} mkv path:{cameraMkvPath} mkv file name:{mkvFileName}");
                            continue;
                        }// else if

                        Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : video export ok.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo}");

                        // ステータス：完了
                        exportInfo.Stat = Status.Comple;
                    }// for

                    //未処理のエクスポートが存在する
                    if (untreatedCnt > 0)
                    {
                        continue;
                    }// if

                    //ステータス：異常が存在する
                    if (csvInfo.GetErrorFlag() == true)
                    {
                        Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : error status exists.");
                        // ホットフォルダにエラーファイルを移動
                        MoveErrorFile(csvInfo.GetCsvFileName());
                    }// if
                    else
                    {
                        // ワークフォルダ内のCSVファイルを削除
                        DeleteWorkFolderFile(csvInfo.GetCsvFileName() + CsvExt);
                    }// else

                    //CSVファイル情報１件削除
                    _csvManager.RemoveAtCsvInfoList(csvFileNo);

                }// for

                Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : end. ret:true");
                return true;
            }
            catch (OperationCanceledException)
            {
                Logger.Instace.Warn($"XPAutoExport :: MkvExportProcess : canceled.");
                Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : end. ret:true");
                return true;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPAutoExport :: MkvExportProcess : exception error");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : end. ret:false");
                return false;
            }
        }// MkvExportProcess


        /// <summary>
        /// Jpegエクスポート処理
        /// </summary>
        /// <param name="token">タスクキャンセルトクーン</param>
        /// <remarks>処理結果</remarks>
        private bool JpegExportProcess(CancellationToken token)
        {
            try
            {
                Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : start.");

                // CsvInfoListの処理済み要素を消していくので、配列番号がずれないように配列の末尾から処理を行う
                int csvInfoListCnt = _csvManager.CountCsvInfoList();
                Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : number of csv file information.  cnt:{csvInfoListCnt}");
                for (int csvFileNo = (csvInfoListCnt - 1); csvFileNo >= 0; csvFileNo--)
                {
                    //N件目のCSVファイル情報取得
                    CsvInfo csvInfo = _csvManager.GetCsvInfoList(csvFileNo);

                    Logger.Instace.Info($"XPAutoExport :: JpegExportProcess : export target.  csv:{csvInfo.GetCsvFileName()}");
                    Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : number of exports in csv file.  cnt::{csvInfo.GetExportInfoListCnt()}");
                    int untreatedCnt = 0;
                    for (int exprtNo = 0; exprtNo < csvInfo.GetExportInfoListCnt(); exprtNo++)
                    {
                        // サービス停止時、例外OperationCanceledExceptionを通知
                        token.ThrowIfCancellationRequested();

                        //N件目のエクスポート情報取得
                        ExportInfo exportInfo = csvInfo.GetExportInfoFromExportList(exprtNo);

                        if (exportInfo.Stat != Status.Untreated)
                        {
                            //ステータス未処理以外は処理しない
                            continue;
                        }// if

                        // エクスポート終了時間が未来の時間である場合
                        DateTime nowTime = DateTime.Now;
                        var eTime = exportInfo.ExportEndTime.ToString(ExportTimeTemplate);
                        var nTime = nowTime.ToString(ExportTimeTemplate);
                        Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : export end time:{eTime}  now:{nTime}");
                        if (exportInfo.ExportEndTime > nowTime)
                        {
                            Logger.Instace.Info($"XPAutoExport :: JpegExportProcess : csv export end time is future time .  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo}  export end time:{eTime}  now:{nTime}");
                            untreatedCnt++;
                            continue;
                        }// if

                        //------------------
                        //静止画エクスポート
                        //------------------
                        string cameraJpegPath = appConfig.Folder.ExportFolderPath + "\\" + exportInfo.ExportFileOutputFolder;
                        if (!Directory.Exists(cameraJpegPath))
                        {
                            DirectoryInfo di = new DirectoryInfo(cameraJpegPath);
                            di.Create();
                        }// if

                        // 静止画エクスポートファイル名編集（拡張子無し）
                        string jpegFileName = EditExportFileName(exportInfo);

                        //カメラID取得
                        Guid cameraId = exportInfo.CameraFqid.ObjectId;
                        Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : still image export start.  camera id:{cameraId.ToString()} jpeg path:{cameraJpegPath} jpeg file name:{jpegFileName}");
                        Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : export date time:{exportInfo.ExportBeginTime.ToString(ExportTimeTemplate)}");
                        ExportResponse exprsp = MkvExportClass.Instace.JpegExport(
                                                    cameraId.ToString(),
                                                    cameraJpegPath,
                                                    jpegFileName,
                                                    exportInfo.ExportDateTime.ToUniversalTime(),
                                                    MkvExportClass.JpegExport_NoImageSizeSpecified,
                                                    MkvExportClass.JpegExport_NoImageSizeSpecified);
                        if (exprsp < 0)
                        {
                            Logger.Instace.Error($"XPAutoExport :: JpegExportProcess : still image export error.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo}");

                            // ステータス：異常
                            exportInfo.Stat = Status.Error;
                            csvInfo.SetErrorFlag(true);
                            Logger.Instace.Info($"XPAutoExport :: JpegExportProcess : set error status.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo}");

                            // XProtectからログアウト後にログイン
                            if (!ReLoginToXProtect(token))
                            {
                                return false;
                            }
                            continue;
                        }// if
                        else if (exprsp == ExportResponse.Suspend)
                        {
                            Logger.Instace.Debug($"XPAutoExport :: MkvExportProcess : still image export suspend.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo} camera id:{cameraId.ToString()} mkv path:{cameraJpegPath} mkv file name:{jpegFileName}");
                            continue;
                        }// else if
                        else if (exprsp != ExportResponse.Success)
                        {
                            Logger.Instace.Error($"XPAutoExport :: JpegExportProcess : there is no recorded video.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo} camera id:{cameraId.ToString()} jpeg path:{cameraJpegPath} jpeg file name:{jpegFileName}");
                            
                            // ステータス：異常
                            exportInfo.Stat = Status.Error;
                            csvInfo.SetErrorFlag(true);
                            Logger.Instace.Info($"XPAutoExport :: JpegExportProcess : set error status.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo}");
                            continue;
                        }// else if

                        Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : still image export ok.  csv:{csvInfo.GetCsvFileName()} line(0origin):{exprtNo}");
                        // ステータス：完了
                        exportInfo.Stat = Status.Comple;
                    }// for

                    //未処理のエクスポートが存在する
                    if (untreatedCnt > 0)
                    {
                        continue;
                    }// if

                    //ステータス：異常が存在する
                    if (csvInfo.GetErrorFlag() == true)
                    {
                        Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : error status exists.");
                        // ホットフォルダにエラーファイルを移動
                        MoveErrorFile(csvInfo.GetCsvFileName());
                    }// if
                    else
                    {
                        // ワークフォルダ内のCSVファイルを削除
                        DeleteWorkFolderFile(csvInfo.GetCsvFileName() + CsvExt);
                    }// else

                    //CSVファイル情報１件削除
                    _csvManager.RemoveAtCsvInfoList(csvFileNo);

                }// for

                Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : end. ret:true");
                return true;
            }
            catch (OperationCanceledException)
            {
                Logger.Instace.Warn($"XPAutoExport :: JpegExportProcess : canceled.");
                Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : end. ret:true");
                return true;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPAutoExport :: JpegExportProcess : Exception error");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Debug($"XPAutoExport :: JpegExportProcess : end. ret:false");
                return false;
            }
        }// JpegExportProcess

        
        /// <summary>
        /// エクスポートファイル名編集
        /// </summary>
        /// <param name="exportInfo">エクスポート情報</param>
        /// <returns>エクスポートファイル名（拡張子無）</returns>
        private string EditExportFileName(ExportInfo exportInfo)
        {
            string exFileName = "";
            if (appConfig.FileName.Type == FileNameType.CameraNm_Timestamp)
            {
                exFileName = exFileName + exportInfo.CameraName + "_" + exportInfo.ExportDateTime.ToString(FileNmExportTimeTemplate);
            }// if
            else
            {
                exFileName = exFileName + exportInfo.ExportDateTime.ToString(FileNmExportTimeTemplate) + "_" + exportInfo.CameraName;
            }// else
            if (exportInfo.FileNamePart1.Length > 0)
            {
                exFileName = exFileName + "_" + exportInfo.FileNamePart1;
                if (exportInfo.FileNamePart2.Length > 0)
                {
                    exFileName = exFileName + "_" + exportInfo.FileNamePart2;
                    if (exportInfo.FileNamePart3.Length > 0)
                    {
                        exFileName = exFileName + "_" + exportInfo.FileNamePart3;
                        if (exportInfo.FileNamePart4.Length > 0)
                        {
                            exFileName = exFileName + "_" + exportInfo.FileNamePart4;
                            if (exportInfo.FileNamePart5.Length > 0)
                            {
                                exFileName = exFileName + "_" + exportInfo.FileNamePart5;

                            }// if
                        }// if
                    }// if
                }// if
            }// if

            // ファイルパスに使用できない文字を'_’に置き換える
            exFileName = MakeStringPathValid(exFileName);
            return exFileName;
        }


        /// <summary>
        /// ワークフォルダ→ホットフォルダにエラーファイルを移動
        /// </summary>
        /// <param name="csvFileName">CSVファイル名（パスなし・拡張子なし）</param>
        /// <returns>結果</returns>
        private bool MoveErrorFile(string csvFileName)
        {
            string dstFilePath = appConfig.Folder.HotFolderPath + "\\" + csvFileName + CsvExt + ErrExt;
            string srcFilePath = appConfig.Folder.WorkFolderPath + "\\" + csvFileName + CsvExt;
            try
            {
                Logger.Instace.Debug($"XPAutoExport :: MoveErrorFile : move error file. \"{srcFilePath}\" => \"{dstFilePath}\"");
                File.Move(srcFilePath, dstFilePath);
                return true;
            }
            catch (IOException ex)
            {
                Logger.Instace.Error($"XPAutoExport :: MoveErrorFile : move error file error. \"{srcFilePath}\" => \"{dstFilePath}\"");
                Logger.Instace.ErrorException(ex);
                return false;
            }
        }// MoveErrorFile()


        /// <summary>
        /// ワークフォルダ内のファイルを削除
        /// </summary>
        /// <param name="fileName">削除するファイル名（パスなし）</param>
        /// <returns>結果</returns>
　　    private bool DeleteWorkFolderFile(string filename)
        {
            // ワークフォルダ内のCSVファイルを削除
            string delFile = appConfig.Folder.WorkFolderPath + "\\" + filename;
            Logger.Instace.Debug($"XPAutoExport :: DeleteWorkFolderFile : file delete.  file:{delFile}");
            try
            {
                File.Delete(delFile);
                return true;
            }
            catch (IOException ex)
            {
                Logger.Instace.Error($"XPAutoExport :: DeleteWorkFolderFile : file delete error.  file:{delFile}");
                Logger.Instace.ErrorException(ex);
                return false;
            }
        }


        /// <summary>
        /// ファイルパスに使用できない文字を'_’に置き換える
        /// </summary>
        /// <param name="unsafeString">編集前文字列</param>
        /// <returns>編集後文字列</returns>
        private static string MakeStringPathValid(string unsafeString)
        {
            char[] invalidCharacters = Path.GetInvalidFileNameChars();
            string result = unsafeString;
            foreach (var invalidCharacter in invalidCharacters)
            {
                result = result.Replace(invalidCharacter, '_');
            }// foreach
            return result;
        }// MakeStringPathValid()


        /// <summary>
        /// XProtectからログアウト後にログイン
        /// </summary>
        /// <param name="token">タスクキャンセルトクーン</param>
        /// <returns></returns>
        private bool ReLoginToXProtect(CancellationToken token)
        {
            Logger.Instace.Info($"XPAutoExport :: ReLoginToXProtect : start.");
            try {
                //-----------------------------------------
                // XProtect Management Serverからログアウト
                //-----------------------------------------
                this._xpManagementServer?.RetryLogout();

                //-------------------
                // Xprotectへログイン
                //------------------
                LoginResult res = this.LoginToXProtect(token);
                if (res == LoginResult.Failure)
                {
                    Logger.Instace.Info($"XPAutoExport :: ReLoginToXProtect : end. ret:false");
                    return false;
                }
                else if (res == LoginResult.Suspend)
                {
                    Logger.Instace.Info($"XPAutoExport :: ReLoginToXProtect : end. ret:true");
                    return true;
                }

                Logger.Instace.Debug("XPAutoExport :: ReLoginToXProtect : login ok.");

                // カメラ一覧取得
                CameraFqidList = XPManagementServer.GetCameraFqidList();
                _runCameraFqidLisDatetime = DateTime.Now;
                Logger.Instace.Info($"XPAutoExport :: ReLoginToXProtect : get a list of cameras. datetime:{_runCameraFqidLisDatetime.ToString("yyyy/MM/dd HH:mm:ss")}");
                Logger.Instace.Info($"XPAutoExport :: ReLoginToXProtect : end. ret:true");
                return true;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPAutoExport :: ReLoginToXProtect : exception error.");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Info($"XPAutoExport :: ReLoginToXProtect : end. ret:false");
                return false;
            }

        }// ReLoginToXProtect()


        /// <summary>
        /// カメラ一覧更新
        /// </summary>
        private void CameraFqidListUpdate()
        {
            try
            {
                if (appConfig.XProtectServer.GetCameraListInterval == 0)
                {
                    return;
                }

                DateTime nowDatetime = DateTime.Now;
                TimeSpan interval = nowDatetime - _runCameraFqidLisDatetime;
                if (interval.TotalMinutes >= appConfig.XProtectServer.GetCameraListInterval)
                {
                    // カメラ一覧取得
                    Logger.Instace.Debug($"XPAutoExport :: CameraFqidListUpdate : camera fqid list update.");
                    CameraFqidList = XPManagementServer.GetCameraFqidList();
                    _runCameraFqidLisDatetime = nowDatetime;
                    Logger.Instace.Info($"XPAutoExport :: CameraFqidListUpdate : get a list of cameras. datetime:{_runCameraFqidLisDatetime.ToString("yyyy/MM/dd HH:mm:ss")}");

                }
                return;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"XPAutoExport :: CameraFqidListUpdate : exception error.");
                Logger.Instace.WarnException(ex);
                return;
            }
        }// CameraFqidListUpdate()

    }// class XPAutoExport

}// namespace XPAutoExport
