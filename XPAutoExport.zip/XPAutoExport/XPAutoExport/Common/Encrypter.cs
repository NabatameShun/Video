// ----------------------------------------------------------------------------
// <copyright file="Encrypter.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Security.Cryptography;
using System.Text;

namespace XPAutoExport.Common
{
    /// <summary>
    /// 暗号化・復号化クラス
    /// </summary>
	public class Encrypter : IDisposable
    {
        /// <summary>
        /// 解放済みフラグ
        /// </summary>
        private bool DisposedValue;

        //-----------------------------------------------------------------
        // 定数
        //-----------------------------------------------------------------
        /// <summary>
        /// 鍵名
        /// </summary>
        private const string KeyName = @"XPAutoExport";

        /// <summary>
        /// RSA鍵
        /// </summary>
        private static readonly CngKey Key = CngKey.Exists(KeyName) ? CngKey.Open(KeyName) : CngKey.Create(CngAlgorithm.Rsa, KeyName);

        /// <summary>
        /// RSA暗号化オブジェクト
        /// </summary>
        private readonly RSACng rsa;

        //-----------------------------------------------------------------
        // メソッド
        //-----------------------------------------------------------------
        /// <summary>
        /// デフォルトコンストラクタ
        /// </summary>
        public Encrypter()
        {
            this.rsa = new RSACng(Key);
        }

        /// <summary>
        /// バイト配列を暗号化する
        /// </summary>
        /// <param name="plainBytes">暗号化前のバイト配列</param>
        /// <returns>暗号化バイト配列</returns>
        public byte[] Encrypt(byte[] plainBytes)
        {
            return this.rsa.Encrypt(plainBytes, RSAEncryptionPadding.Pkcs1);
        }

        /// <summary>
        /// UTF8文字列を暗号化し、UTF8エンコードした文字列を返す
        /// </summary>
        /// <param name="plainString">UTF8文字列</param>
        /// <returns>暗号化バイト配列をUTF8エンコードした文字列</returns>
        public string Encrypt(string plainString)
        {
            var encryptedBytes = this.Encrypt(Encoding.UTF8.GetBytes(plainString));
            return Convert.ToBase64String(encryptedBytes);
        }

        /// <summary>
        /// 暗号化バイト配列を復号化する
        /// </summary>
        /// <param name="encryptedBytes">暗号化バイト配列</param>
        /// <returns>復号化バイト配列</returns>
        public byte[] Decrypt(byte[] encryptedBytes)
        {
            return this.rsa.Decrypt(encryptedBytes, RSAEncryptionPadding.Pkcs1);
        }

        /// <summary>
        /// 暗号化バイト配列のUTF8エンコード文字列を復号化し、UTF8文字列を返す
        /// </summary>
        /// <param name="encryptedEncodedBytes">暗号化バイト配列のUTF8エンコード文字列</param>
        /// <returns>復号化UTF8文字列</returns>
        public string Decrypt(string encryptedEncodedBytes)
        {
            var plainBytes = this.Decrypt(Convert.FromBase64String(encryptedEncodedBytes));
            return Encoding.UTF8.GetString(plainBytes);
        }

        /// <summary>
        /// ファイナライザ
        /// </summary>
        ~Encrypter()
        {
            this.Dispose(false);
        }

        /// <summary>
        /// ディスポーザー
        /// </summary>
        /// <param name="disposing">マネージドリソース解放フラグ</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.DisposedValue)
            {
                if (disposing)
                {
                    // マネージド状態を破棄します (マネージド オブジェクト)
                    this.rsa.Dispose();
                }
            }

            // アンマネージド リソース (アンマネージド オブジェクト) を解放し、ファイナライザーをオーバーライドします
            // 大きなフィールドを null に設定します
            this.DisposedValue = true;
        }

        /// <summary>
        /// ディスポーザー
        /// </summary>
        public void Dispose()
        {
            this.Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}

