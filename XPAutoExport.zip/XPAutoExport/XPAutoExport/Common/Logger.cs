// ----------------------------------------------------------------------------
// <copyright file="Logger.cs" company="Canon IT Solutions Inc.">
// (c) 2021 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;

namespace XPAutoExport.Common
{
    /// <summary>
    /// ログクラス
    /// </summary>
	public class Logger
    {
        /// <summary>
        /// 内部用ロガー
        /// </summary>
        public NLog.Logger InternalNLogger { get; private set; }

        /// <summary>
        /// シングルトンインスタンス
        /// </summary>
        private static Logger loggerInstace;

        /// <summary>
        /// 内部ログ用ロガー名称
        /// </summary>
        private const string InternalLogName = "XPAutoExport";

        /// <summary>
        /// コンストラクタ
        /// </summary>
        private Logger()
        {
            this.InternalNLogger = NLog.LogManager.GetLogger(InternalLogName);
        }

        /// <summary>
        /// シングルトンインスタンス取得
        /// </summary>
        public static Logger Instace
        {
            get
            {
                if (loggerInstace == null)
                {
                    loggerInstace = new Logger();
                }

                return loggerInstace;
            }
        }

        /// <summary>
        /// Debugログを出力する
        /// </summary>
        /// <param name="message">メッセージ</param>
        public void Debug(string message)
        {
            this.InternalNLogger.Debug(message);
        }

        /// <summary>
        /// Infoログを出力する
        /// </summary>
        /// <param name="message">メッセージ</param>
        public void Info(string message)
        {
            this.InternalNLogger.Info(message);
        }

        /// <summary>
        /// Warningログを出力する
        /// </summary>
        /// <param name="message">メッセージ</param>
        public void Warn(string message)
        {
            this.InternalNLogger.Warn(message);
        }

        /// <summary>
        /// Errorログを出力する
        /// </summary>
        /// <param name="message">メッセージ</param>
        public void Error(string message)
        {
            this.InternalNLogger.Error(message);
        }

        /// <summary>
        /// 例外ログを出力する
        /// </summary>
        /// <param name="ex">例外</param>
        public void ErrorException(Exception ex)
        {
            if (ex != null)
            {
                var logger = this.InternalNLogger;

                logger.Error($"0x{ex.HResult:X8}|{ex.Message}");
                // 内部例外があればInfoログ出力
                var e = ex.InnerException;
                while (e != null)
                {
                    logger.Info(e, $"0x{e.HResult:X8}|{e.Message}");
                    e = e.InnerException;
                }
            }
        }

        /// <summary>
        /// 例外ログを出力する
        /// </summary>
        /// <param name="ex">例外</param>
        public void WarnException(Exception ex)
        {
            if (ex != null)
            {
                var logger = this.InternalNLogger;

                logger.Warn($"0x{ex.HResult:X8}|{ex.Message}");
                // 内部例外があればInfoログ出力
                var e = ex.InnerException;
                while (e != null)
                {
                    logger.Info(e, $"0x{e.HResult:X8}|{e.Message}");
                    logger.Info(e, $"0x{e.HResult:X8}|{e.Message}");
                    e = e.InnerException;
                }
            }
        }

        /// <summary>
        /// NLogクローズ
        /// </summary>
        public static void ShutdownLogger()
        {
            NLog.LogManager.Shutdown();
        }
    }
}

