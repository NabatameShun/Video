// ----------------------------------------------------------------------------
// <copyright file="ExportInfo.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using VideoOS.Platform;

namespace XPAutoExport
{
    /// <summary>
    /// ステータス
    /// </summary>
    public enum Status
    {
        Untreated, // 未処理
        Comple,　　// 完了
        Error      // エラー
    }// enum Status

    /// <summary>
    /// エクスポート情報クラス
    /// </summary>
    public class ExportInfo
    {
        /// <summary>
        /// ステータス
        /// </summary>
        public Status Stat { get; set; } = Status.Untreated;

        /// <summary>
        /// エクスポート時刻
        /// </summary>
        public DateTime ExportDateTime { get; set; }

        /// <summary>
        /// エクスポートを開始する時間
        /// </summary>
        public DateTime ExportBeginTime { get; set; }

        /// <summary>
        /// エクスポートを終了する時間
        /// </summary>
        public DateTime ExportEndTime { get; set; }

        /// <summary>
        /// カメラ名
        /// </summary>
        public string CameraName { get; set; }

        /// <summary>
        /// カメラFQID
        /// </summary>
        public FQID CameraFqid { get; set; }

        /// <summary>
        /// エクスポートファイル出力フォルダ名
        /// </summary>
        public string ExportFileOutputFolder { get; set; }

        /// <summary>
        /// ファイル名パーツ１
        /// </summary>
        public string FileNamePart1 { get; set; }

        /// <summary>
        /// ファイル名パーツ２
        /// </summary>
        public string FileNamePart2 { get; set; }

        /// <summary>
        /// ファイル名パーツ３
        /// </summary>
        public string FileNamePart3 { get; set; }

        /// <summary>
        /// ファイル名パーツ４
        /// </summary>
        public string FileNamePart4 { get; set; }

        /// <summary>
        /// ファイル名パーツ５
        /// </summary>
        public string FileNamePart5 { get; set; }
    }// class ExportInfo
}// namespace XPAutoExport

