// ----------------------------------------------------------------------------
// <copyright file="CsvInfo.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using VideoOS.Platform;
using XPAutoExport.Common;
using XPAutoExport.Config;

namespace XPAutoExport
{
    /// <summary>
    /// CSVファイル情報クラス
    /// </summary>
    public class CsvInfo
    {
        /// <summary>
        /// CSVファイルのカラムインデックス
        /// </summary>
        public enum CsvColumnIndex
        {
            /// <summary>省略可能</summary>
            Optional = -1,
            /// <summary>インデックス最小値</summary>
            Min = 3,
            /// <summary>インデックス最大値</summary>
            Max = 10,
        }// enum CsvColumnIndex

        /// <summary>
        /// CSVファイルのデフォルトエンコード名称
        /// </summary>
        private const string DefaultCsvEncode = "SJIS";

        /// <summary>
        /// 小数点
        /// </summary>
        private const string Dot = ".";

        /// <summary>
        /// エラー時間値
        /// </summary>
        private const int ErrTimeValue = -1;

        /// <summary>
        /// 設定情報
        /// </summary>
        private readonly AppConfig appConfig = Program.GetAppConfigInstace();

        /// <summary>
        /// CSVファイルパス
        /// </summary>
        private string CsvFilePath = null;

        /// <summary>
        /// CSVファイル名（パス・拡張子無し）
        /// </summary>
        private string CsvFileName = null;

        /// <summary>
        /// エラー発生有無
        /// </summary>
        private bool ErrorFlag = false;

        /// <summary>
        /// ExportInfoインスタンスリスト
        /// </summary>
        private List<ExportInfo> ExportList = new List<ExportInfo>();


        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="csvFileName">CSVファイルパス</param>
        public CsvInfo(string csvFilePath)
        {
            try
            {
                this.CsvFilePath = csvFilePath;
                Logger.Instace.Debug($"CsvInfo :: CsvInfo : csv file path:{this.CsvFilePath}");

                //------------------------------------------
                //パスと拡張子無しのCSVファイル名を取得する
                //------------------------------------------
                this.CsvFileName = Path.GetFileNameWithoutExtension(this.CsvFilePath);
                Logger.Instace.Debug($"CsvInfo :: CsvInfo : csv file name:{this.CsvFileName}");
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"CsvInfo :: CsvInfo : exception error. csv file path:{csvFilePath}");
                Logger.Instace.WarnException(ex);
            }
        }// CsvInfo()


        /// <summary>
        /// CSVファイルからエクスポート情報リスト
        /// （ExportInfoクラスインスタンスのリスト）を作成する
        /// </summary>
        /// <returns>処理結果</returns>
        public bool CreateExportInfoList()
        {
            Logger.Instace.Debug($"CsvInfo :: CreateExportInfoList : start. csv file path:{this.CsvFilePath}");

            List<List<string>> rows;
            try
            {
                // CSVのロード
                rows = CSVParser.LoadFromPath(this.CsvFilePath, CSVParser.Delimiter.Comma, Encoding.GetEncoding(DefaultCsvEncode));
                Logger.Instace.Debug($"CsvInfo :: CreateExportInfoList : csv rows count:{rows.Count}");
                if (rows.Count <= 0)
                {
                    Logger.Instace.Debug($"CsvInfo :: CreateExportInfoList : end. ret:true");
                    return true;
                }// if
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"CsvInfo :: CreateExportInfoList : exception occurred while loading the bookmark file.  csv file path:{this.CsvFilePath}");
                Logger.Instace.ErrorException(ex);
                Logger.Instace.Debug($"CsvInfo :: CreateExportInfoList : end. ret:false");
                return false;
            }

            //全行処理する
            this.ExportList.Clear();
            var result = true;
            // CSVの先頭をヘッダとする場合は2行目から読み込み
            int line_cnt = this.appConfig.CsvRow.UseCsvHeader ? 1 : 0;
            for (; line_cnt < rows.Count; line_cnt++)
            {
                var exportStat = Status.Untreated;

                // 「エクスポート時刻」取得
                DateTime exportTimeTriggered = GetExportInfo_ExportDateTime(rows, line_cnt);
                if (exportTimeTriggered == DateTime.MaxValue)
                {
                    exportStat = Status.Error;
                    result = false;
                }

                // 「カメラ名」取得
                string exportCameraName = GetExportInfo_CameraName(rows, line_cnt);
                if (exportCameraName == null)
                {
                    exportCameraName = "";
                    exportStat = Status.Error;
                    result = false;
                }

                //エクスポート形式が「映像」の場合のみ
                int preTime = this.appConfig.Export.PreTime;
                int exportTime = this.appConfig.Export.ExportTime;
                if (appConfig.Export.Format == ExportFormat.Mkv)
                {
                    // プレ時間を取得
                    preTime = GetExportInfo_PreTime(rows, line_cnt);
                    if (preTime == ErrTimeValue)
                    {
                        exportStat = Status.Error;
                        result = false;
                    }

                    // エクスポート時間を取得
                    exportTime = GetExportInfo_ExportTime(rows, line_cnt);
                    if (exportTime == ErrTimeValue)
                    {
                        exportStat = Status.Error;
                        result = false;
                    }
                }// if
                else
                {
                    Logger.Instace.Info($"CsvInfo :: CreateExportInfoList : Since it is a still image export, the \"pre - time\" and \"export time\" are not acquired from csv.");
                }// else

                // 「エクスポートファイル出力フォルダ名」取得
                string exportFileOutputFolder = GetExportInfo_ExportFileOutputFoldere(rows, line_cnt, exportCameraName);
                if (exportFileOutputFolder == null)
                {
                    exportFileOutputFolder = exportCameraName;
                    Logger.Instace.Warn($"CsvInfo :: CreateExportInfoList : csv use \"Camera name\" for \"Export file output folder name\".  line:{line_cnt}  export file output folder:{exportFileOutputFolder}");
                }

                //ファイル名パーツ
                List<string> exportFileNamePartList = GetExportInfo_ExportFileNamePart(rows, line_cnt);

                var exportTimeBegin = DateTime.MaxValue;
                var exportTimeEnd = DateTime.MaxValue;
                if (exportTimeTriggered != DateTime.MaxValue)
                {
                    // エクスポートを開始する時間
                    exportTimeBegin = exportTimeTriggered.AddSeconds(preTime * -1);

                    // エクスポートを終了する時間
                    exportTimeEnd = exportTimeTriggered.AddSeconds(exportTime);
                }// if

                // カメラ名称からFQID取得
                var exportCamraFQID = (FQID)null;
                if (exportCameraName.Length > 0)
                {
                    var cameraDic = XPAutoExport.CameraFqidList.FirstOrDefault(camera => camera.Value == exportCameraName);
                    if (cameraDic.Equals(default(KeyValuePair<FQID, string>)))
                    {
                        Logger.Instace.Error($"CsvInfo :: CreateExportInfoList : camera not found. line:{line_cnt}, camera name:\"{exportCameraName}\"");
                        Logger.Instace.Debug($"CsvInfo :: CreateExportInfoList : line:{line_cnt} camera.Value:{cameraDic.Value}");
                        exportStat = Status.Error;
                        result = false;
                    }// if
                    else
                    {
                        exportCamraFQID = cameraDic.Key;
                        Logger.Instace.Debug($"CsvInfo :: CreateExportInfoList : line:{line_cnt} camraFQID:{exportCamraFQID}");
                        Logger.Instace.Debug($"CsvInfo :: CreateExportInfoList : line:{line_cnt} camera.Value:{cameraDic.Value}");
                    }// else
                }// if

                // エクスポート情報作成
                var exportInfo = new ExportInfo()
                {
                    Stat = exportStat,
                    ExportDateTime = exportTimeTriggered,
                    ExportBeginTime = exportTimeBegin,
                    ExportEndTime = exportTimeEnd,
                    CameraName = exportCameraName,
                    CameraFqid = exportCamraFQID,
                    ExportFileOutputFolder = exportFileOutputFolder,
                    FileNamePart1 = exportFileNamePartList[0],
                    FileNamePart2 = exportFileNamePartList[1],
                    FileNamePart3 = exportFileNamePartList[2],
                    FileNamePart4 = exportFileNamePartList[3],
                    FileNamePart5 = exportFileNamePartList[4]
                };
                Logger.Instace.Info($"CsvInfo :: CreateExportInfoList : Export information list added.  line:{line_cnt} status:{exportInfo.Stat}");
                this.ExportList.Add(exportInfo);
                exportFileNamePartList = null;
            }//for
            if (result)
            {
                Logger.Instace.Debug($"CsvInfo :: CreateExportInfoList : end. ret:true");
            }
            else
            {
                Logger.Instace.Debug($"CsvInfo :: CreateExportInfoList : end. ret:false");
            }
            return result;
        }// CreateExportInfoList()


        /// <summary>
        /// エクスポート情報から「エクスポート時刻」取得
        /// </summary>
        /// <param name="csvColumnsList">CSVのエクスポート情報リスト</param>
        /// <param name="csvLineNo">CSVの行番号(0オリジン)</param>
        /// <returns>エクスポート時刻 ※異常終了 : DateTime.MaxValue</returns>
        private DateTime GetExportInfo_ExportDateTime(List<List<string>> csvColumnsList, int csvLineNo)
        {
            string exportDateTime = "";
            DateTime exportTimeTriggered = DateTime.MaxValue;

            if (csvColumnsList.Count <= csvLineNo)
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_ExportDateTime : invalid csv file format. line:{csvLineNo}");
                return DateTime.MaxValue;
            }

            List<string> csvColumns = csvColumnsList[csvLineNo];

            int idx = appConfig.CsvColumn.ExportDateTimeIndex;
            if (csvColumns.Count <= idx)
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_ExportDateTime : invalid csv file format. line:{csvLineNo} idx:{idx}");
                return DateTime.MaxValue;
            }

            exportDateTime = csvColumns[idx];
            if (String.IsNullOrEmpty(exportDateTime))
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_ExportDateTime : csv exportDateTime is incorrect. line:{csvLineNo} idx:{idx}");
                return DateTime.MaxValue;
            }// if
            else
            {
                var datetimeFormat = "";
                bool retflg = false;
                bool endflg = false;
                var wkDateTime = DateTime.MaxValue;
                int cnt = 0;
                while (true)
                {
                    switch(cnt)
                    {
                        case 0:
                            datetimeFormat = "yyyy/M/d H:m:s";
                            break;
                        case 1:
                            datetimeFormat = "yyyy/M/d H:m";
                            break;
                        case 2:
                            datetimeFormat = "yyyy/M/d H";
                            break;
                        default:
                            datetimeFormat = "yyyy/M/d";
                            endflg = true;
                            break;
                    } //switch

                    wkDateTime = DateTime.MaxValue;
                    if (DateTime.TryParseExact(exportDateTime, datetimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out wkDateTime))
                    {
                        retflg = true;
                        break;
                    }
                    if (endflg)
                    {
                        break;
                    }
                    cnt++;
                }// while

                if (!retflg)
                {
                    Logger.Instace.Error($"CsvInfo :: GetExportInfo_ExportDateTime : invalid exportDateTime data/time. line:{csvLineNo} idx:{idx} value:{exportDateTime}");
                    return DateTime.MaxValue;
                }// if
                else
                {
                    exportTimeTriggered = wkDateTime;
                    Logger.Instace.Info($"CsvInfo :: GetExportInfo_ExportDateTime : csv exportDateTime. string:{exportDateTime} DateTime:{exportTimeTriggered.ToString("yyyy/MM/dd HH:mm:ss")}");
                }// else
            }// else

            Logger.Instace.Debug($"CsvInfo :: GetExportInfo_ExportDateTime : csv exportDateTime. line:{csvLineNo} idx:{idx} export date time:{exportDateTime}");
            return exportTimeTriggered;
        }// GetExportInfo_ExportDateTime()


        /// <summary>
        /// エクスポート情報から「カメラ名」取得
        /// </summary>
        /// <param name="csvColumnsList">CSVのエクスポート情報リスト</param>
        /// <param name="csvLineNo">CSVの行番号(0オリジン)</param>
        /// <returns>カメラ名 ※異常終了 : null</returns>
        private string GetExportInfo_CameraName(List<List<string>> csvColumnsList, int csvLineNo)
        {
            string exportCameraName = null;

            if (csvColumnsList.Count <= csvLineNo)
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_CameraName : invalid csv file format. line:{csvLineNo}");
                return null;
            }

            List<string> csvColumns = csvColumnsList[csvLineNo];
            int idx = appConfig.CsvColumn.ExportCameraNameIndex;
            if (csvColumns.Count <= idx)
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_CameraName : invalid csv file format. line:{csvLineNo} idx:{idx}");
                return null;
            }

            exportCameraName = csvColumns[idx];
            if (String.IsNullOrEmpty(exportCameraName))
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_CameraName : csv export camera name is incorrect. line:{csvLineNo} idx:{idx}");
                return null;
            }// if

            Logger.Instace.Info($"CsvInfo :: GetExportInfo_CameraName : line:{csvLineNo} idx:{idx} export camera name:{exportCameraName}");
            return exportCameraName;
        }// GetExportInfo_CameraName()


        /// <summary>
        /// エクスポート情報から「プレ時間」取得
        /// </summary>
        /// <param name="csvColumnsList">CSVのエクスポート情報リスト</param>
        /// <param name="csvLineNo">CSVの行番号(0オリジン)</param>
        /// <returns>プレ時間 ※異常終了 : ErrTimeValue</returns>
        private int GetExportInfo_PreTime(List<List<string>> csvColumnsList, int csvLineNo)
        {
            int preTime = ErrTimeValue;

            if (csvColumnsList.Count <= csvLineNo)
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_PreTime : invalid csv file format. line:{csvLineNo}");
                return ErrTimeValue;
            }

            List<string> csvColumns = csvColumnsList[csvLineNo];
            int idx = appConfig.CsvColumn.PreTimeIndex;
            if (csvColumns.Count <= idx)
            {
                Logger.Instace.Info($"CsvInfo :: GetExportInfo_PreTime : pre-time uses the value in the configuration file . line:{csvLineNo} idx:{idx}");
                preTime = this.appConfig.Export.PreTime;
            }// if
            else
            {
                var wkStr = csvColumns[idx];
                if (String.IsNullOrEmpty(wkStr))
                {
                    Logger.Instace.Info($"CsvInfo :: GetExportInfo_PreTime : pre-time uses the value in the configuration file . line:{csvLineNo} idx:{idx}");
                    preTime = this.appConfig.Export.PreTime;
                }// if
                else
                {
                    if (!int.TryParse(wkStr, out preTime))
                    {
                        Logger.Instace.Error($"CsvInfo :: GetExportInfo_PreTime : csv pre-time is incorrect . line:{csvLineNo} idx:{idx} pre-time:{wkStr}");
                        return ErrTimeValue;
                    }// if
                }// else
            }// else

            Logger.Instace.Info($"CsvInfo :: GetExportInfo_PreTime : line:{csvLineNo} idx:{idx} pre-time:{preTime}");
            return preTime;
        }// GetExportInfo_PreTime()


        /// <summary>
        /// エクスポート情報から「エクスポート時間」取得
        /// </summary>
        /// <param name="csvColumnsList">CSVのエクスポート情報リスト</param>
        /// <param name="csvLineNo">CSVの行番号(0オリジン)</param>
        /// <returns>エクスポート時間 ※異常終了 : ErrTimeValue</returns>
        private int GetExportInfo_ExportTime(List<List<string>> csvColumnsList, int csvLineNo)
        {
            int exportTime = ErrTimeValue;

            if (csvColumnsList.Count <= csvLineNo)
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_ExportTime : invalid csv file format. line:{csvLineNo}");
                return ErrTimeValue;
            }

            List<string> csvColumns = csvColumnsList[csvLineNo];
            int idx = appConfig.CsvColumn.ExportTimeIndex;
            if (csvColumns.Count <= idx)
            {
                Logger.Instace.Info($"CsvInfo :: GetExportInfo_ExportTime : export time uses the value in the configuration file . line:{csvLineNo} idx:{idx}");
                exportTime = this.appConfig.Export.ExportTime;
            }// if
            else
            {
                var wkStr = csvColumns[idx];
                if (String.IsNullOrEmpty(wkStr))
                {
                    Logger.Instace.Info($"CsvInfo :: GetExportInfo_ExportTime : export time uses the value in the configuration file . line:{csvLineNo} idx:{idx}");
                    exportTime = this.appConfig.Export.ExportTime;
                }// if
                else
                {
                    if (!int.TryParse(wkStr, out exportTime))
                    {
                        Logger.Instace.Error($"CsvInfo :: GetExportInfo_ExportTime : csv export time is incorrect . line:{csvLineNo} idx:{idx} pre-time:{wkStr}");
                        return ErrTimeValue;
                    }// if
                }// else
            } //else
            Logger.Instace.Info($"CsvInfo :: GetExportInfo_ExportTime : line:{csvLineNo} idx:{idx} export time:{exportTime}");
            return exportTime;
        }// GetExportInfo_ExportTime()


        /// <summary>
        /// エクスポート情報から「エクスポートファイル出力フォルダ名」取得
        /// </summary>
        /// <param name="csvColumnsList">CSVのエクスポート情報リスト</param>
        /// <param name="csvLineNo">CSVの行番号(0オリジン)</param>
        /// <param name="defaultFolder">省略時のフォルダ名</param>
        /// <returns>エクスポートファイル出力フォルダ名 ※異常終了 : null</returns>
        private string GetExportInfo_ExportFileOutputFoldere(List<List<string>> csvColumnsList, int csvLineNo, string defaultFolder)
        {
            string exportFileOutputFolder = null;

            if (csvColumnsList.Count <= csvLineNo)
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_ExportFileOutputFoldere : invalid csv file format. line:{csvLineNo}");
                return null;
            }

            List<string> csvColumns = csvColumnsList[csvLineNo];
            int idx = appConfig.CsvColumn.ExportFileOutputFolderIndex;
            if (csvColumns.Count <= idx)
            {
                Logger.Instace.Info($"CsvInfo :: GetExportInfo_ExportFileOutputFoldere : csv Use \"Camera name\" for \"Export file output folder name\" . line:{csvLineNo} idx:{idx}");
                exportFileOutputFolder = defaultFolder;
            }// if
            else
            {
                exportFileOutputFolder = csvColumns[idx];
                if (String.IsNullOrEmpty(exportFileOutputFolder))
                {
                    Logger.Instace.Info($"CsvInfo :: GetExportInfo_ExportFileOutputFoldere : csv Use \"Camera name\" for \"Export file output folder name\" . line:{csvLineNo} idx:{idx}");
                    exportFileOutputFolder = defaultFolder;
                }// if
            }// else

            Logger.Instace.Info($"CsvInfo :: GetExportInfo_ExportFileOutputFoldere : line:{csvLineNo} idx:{idx} export file output folder:{exportFileOutputFolder}");
            return exportFileOutputFolder;
        }// GetExportInfo_ExportFileOutputFoldere


        /// <summary>
        /// エクスポート情報から「ファイル名パーツ」取得
        /// </summary>
        /// <param name="csvColumnsList">CSVのエクスポート情報リスト</param>
        /// <param name="csvLineNo">CSVの行番号(0オリジン)</param>
        /// <returns>ファイル名パーツリスト</returns>
        private List<string> GetExportInfo_ExportFileNamePart(List<List<string>> csvColumnsList, int csvLineNo)
        {
            List<string> exportFileNamePartList = new List<string>();

            if (csvColumnsList.Count <= csvLineNo)
            {
                Logger.Instace.Error($"CsvInfo :: GetExportInfo_ExportFileNamePart : invalid csv file format. line:{csvLineNo}");
                return exportFileNamePartList;
            }
            List<string> csvColumns = csvColumnsList[csvLineNo];

            List<int> idxtList = new List<int>();
            idxtList.Add(appConfig.CsvColumn.ExportFileNamePart1Index);
            idxtList.Add(appConfig.CsvColumn.ExportFileNamePart2Index);
            idxtList.Add(appConfig.CsvColumn.ExportFileNamePart3Index);
            idxtList.Add(appConfig.CsvColumn.ExportFileNamePart4Index);
            idxtList.Add(appConfig.CsvColumn.ExportFileNamePart5Index);

            int fileno = 0;
            bool setend = false;
            foreach (var idx in idxtList)
            {
                fileno++;
                string wkStr = "";
                if (!setend)
                {
                    if (csvColumns.Count <= idx)
                    {
                        Logger.Instace.Debug($"CsvInfo :: GetExportInfo_ExportFileNamePart : invalid csv file format. line:{csvLineNo} idx:{idx}");
                        setend = true;
                    }
                    else
                    {
                        wkStr = csvColumns[idx];
                        if (String.IsNullOrEmpty(wkStr))
                        {
                            Logger.Instace.Debug($"CsvInfo :: GetExportInfo_ExportFileNamePart : csv file name part{fileno} omitted.  line:{csvLineNo} idx:{idx}");
                            wkStr = "";
                            setend = true;
                        }// if
                    }// else
                }// if
                Logger.Instace.Info($"CsvInfo :: GetExportInfo_ExportFileNamePart : line:{csvLineNo} idx:{idx} export fileName part{fileno}:{wkStr}");
                exportFileNamePartList.Add(wkStr);
            }// foreach

            idxtList = null;
            return exportFileNamePartList;
        }// GetExportInfo_ExportFileNamePart()


        /// <summary>
        /// エクスポート情報リストの取得
        /// </summary>
        /// <returns></returns>
        public List<ExportInfo> GetExportInfoList()
        {
            return this.ExportList;
        }// GetExportInfoList()


        /// <summary>
        /// エクスポート情報リストの件数取得
        /// </summary>
        /// <returns>エクスポート情報リストの件数</returns>
        public int GetExportInfoListCnt()
        {
            return this.ExportList.Count;
        }// GetExportInfoListCnt()


        /// <summary>
        /// CSVファイル名（パス・拡張子無し）取得
        /// </summary>
        /// <returns>CSVファイル名（パス・拡張子無し）</returns>
        public string GetCsvFileName()
        {
            return this.CsvFileName;
        }// GetCsvFileName()

        /// <summary>
        /// CSV内のエクスポートでエラー発生有無取得
        /// </summary>
        /// <returns>エラー発生有無</returns>
        public bool GetErrorFlag()
        {
            return this.ErrorFlag;
        }// GetErrorFlag()


        /// <summary>
        /// CSV内のエクスポートでエラー発生有無設定
        /// </summary>
        /// <returns>エラー発生有無</returns>
        public void SetErrorFlag(bool falg)
        {
            this.ErrorFlag = falg;
        }// SetErrorFlag()


        /// <summary>
        /// ExportListからExportInfoを取得する
        /// </summary>
        /// <param name="idx">ExportListの配列番号</param>
        /// <returns>エラー発生有無</returns>
        public ExportInfo GetExportInfoFromExportList(int idx)
        {
            if ((idx >= ExportList.Count) || (idx < 0))
            {
                return null;
            }
            return this.ExportList[idx];
        }// GetExportInfoFromExportList()

    }// class CsvInfo

}// namespace XPAutoExport
