﻿// ----------------------------------------------------------------------------
// <copyright file="MkvExport.cs" company="Canon IT Solutions Inc.">
// (c) 2022 Canon IT Solutions Inc.
// </copyright>
// ----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using VideoOS.Platform;
using VideoOS.Platform.Data;
using XpMkvExportDll.Common;

namespace XpMkvExportDll
{
    /// <summary>
    /// エクスポート結果
    /// </summary>
    public enum ExportResponse
    {
        /// <summary>正常終了（エクスポート有）</summary>
        Success = 0,
        /// <summary>正常終了（エクスポート無）</summary>
        NoExportSuccess,
        /// <summary>正常終了（MkvExport停止設定のため中断）</summary>
        Suspend,
        /// <summary>異常終了</summary>
        Error = -1,
        /// <summary>タイムアウト</summary>
        Timeout = -2
    }

    static class Constants
    {
        public const string DateTimeFormat = "yyyy/MM/dd HH:mm:ss";
        public const string StrYes = "Y";
        public const string StrNo = "N";
        public const string ExtensionJpeg = ".jpg";
    }

    public class MkvExportClass
    {
        /// <summary>
        /// シングルトンインスタンス
        /// </summary>
        private static MkvExportClass mkvExportInstace;

        /// <summary>
        /// シングルトンインスタンス取得
        /// </summary>
        public static MkvExportClass Instace
        {
            get
            {
                if (mkvExportInstace == null)
                {
                    mkvExportInstace = new MkvExportClass();
                }

                return mkvExportInstace;
            }// get
        } 

        /// <summary>
        /// MkvExportClassクラス　コンストラクタ
        /// </summary>
        public MkvExportClass()
        {

        }// MkvExportClass()

        /// <summary>
        /// MkvExport関数の引数
        /// </summary>
        public const uint MkvExport_NoTimeout = 0; // タイムアウト無し

        /// <summary>
        /// JpegExport関数の引数
        /// </summary>
        public const int JpegExport_NoImageSizeSpecified = 0; // 画像サイズ指定なし


        /// <summary>
        /// MKV形式で動画エクスポート
        /// </summary>
        /// <param name="pCameraId">カメラID</param>
        /// <param name="pExportPath">出力先パス</param>
        /// <param name="pExportFileName">出力ファイル名（拡張子は付加しない）</param>
        /// <param name="pStartTime">開始時刻（秒迄）</param>
        /// <param name="pEndTime">終了時刻（秒迄）</param>
        /// <param name="pAudioDeviceAdd">AUDIOデバイス付加有無(true：付加する)</param>
        /// <param name="pTimeOutSec">タイムアウト秒(MkvExport_NoTimeout：タイムアウト無し)</param>
        /// <param name="pToken">エクスポートキャンセル用トクーン</param>
        /// <returns>ExportResponse : 正常終了（エクスポート有り）,正常終了（エクスポート無し）,正常終了（MkvExport停止設定のため中断）,異常終了,タイムアウト</returns>
        public ExportResponse MkvExport(string pCameraId, 
                                        string pExportPath, 
                                        string pExportFileName, 
                                        DateTime pStartTime, 
                                        DateTime pEndTime, 
                                        bool pAudioDeviceAdd, 
                                        uint pTimeOutSec,
            　　　　　　　　　　　　　　CancellationToken pToken)
        {
            DateTime startDateTime = DateTime.Now;

            string strStartTime = pStartTime.ToString(Constants.DateTimeFormat);
            string strEndTime = pEndTime.ToString(Constants.DateTimeFormat);
            string strAudioDevAdd = Constants.StrNo;
            if (pAudioDeviceAdd)
            {
                strAudioDevAdd = Constants.StrYes;
            }// if
            string strLogTarget = "CameraId[" + pCameraId + "] [" + strStartTime + "] -> [" + strEndTime + "] Audio[" + strAudioDevAdd + "]"; 

            Logger.Instace.Info($"MkvExportClass :: MkvExport : start. param:{strLogTarget} .");

            //----------------
            // パラメータ確認
            //----------------
            if (!MkvExportParameterCheck(pCameraId, pExportPath, pExportFileName, pStartTime, pEndTime))
            {
                Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.Error}");
                return ExportResponse.Error;
            }

            //---------------
            // カメラ情報取得
            //---------------
            Item cameraItem = null;
            try
            {
                // サービス停止時、例外:OperationCanceledException
                pToken.ThrowIfCancellationRequested();

                cameraItem = Configuration.Instance.GetItem(new Guid(pCameraId), Kind.Camera);
                if (cameraItem == null)
                {
                    Logger.Instace.Error($"MkvExportClass :: MkvExport : camera id does not exist.  camera id:{pCameraId}");
                    Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.Error}");
                    return ExportResponse.Error;
                }// if
            }
            catch (OperationCanceledException)
            {
                Logger.Instace.Warn($"MkvExportClass :: .MkvExport : MkvExport canceled.");
                Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.Suspend}");
                return ExportResponse.Suspend;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"MkvExportClass :: MkvExport : exception [0x{ex.HResult:X8}] [{ex.Message}]");
                Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.Error}");
                return ExportResponse.Error;
            }

            //--------------------------------
            // エクスポートパラメータ情報生成
            //--------------------------------
            VideoOS.Platform.Data.IExporter _exporter = new VideoOS.Platform.Data.MKVExporter
            {
                Filename = pExportFileName
            };

            //--------------------
            // MKVExporter初期化
            //--------------------
            _exporter.Init();

            // MKVファイル出力先パス設定
            _exporter.Path = pExportPath;

            // 対象カメラ追加
            _exporter.CameraList.Add(cameraItem);

            // AUDIOデバイス追加
            var audioItem = new Item[0];
            if (pAudioDeviceAdd)
            {
                List<Item> audioItemList = new List<Item>();
                audioItemList.AddRange(cameraItem.GetRelated()
                    .Where(x => x.FQID.Kind == Kind.Microphone || x.FQID.Kind == Kind.Speaker));
                audioItem = audioItemList.ToArray();
            }// if
            _exporter.AudioList.AddRange(audioItem);

            try
            {
                //------------------
                // エクスポート開始
                //------------------
                Logger.Instace.Debug($"MkvExportClass :: MkvExport : export start.  start time:{pStartTime.ToString(Constants.DateTimeFormat)} end time:{pEndTime.ToString(Constants.DateTimeFormat)}");
                if (false == _exporter.StartExport(pStartTime.ToUniversalTime(), pEndTime.ToUniversalTime()))
                {
                    int lastError = _exporter.LastError;
                    string lastErrorString = _exporter.LastErrorString;
                    Logger.Instace.Error($"MkvExportClass :: MkvExport : StartExport() error.  LastError[{lastError}][{lastErrorString}]");
                    Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.Error}");
                    return ExportResponse.Error;
                }// if

                //----------------------
                // エクスポート終了待ち
                //----------------------
                bool export_end = false;
                while (!pToken.IsCancellationRequested)
                {
                    int progress = _exporter.Progress;
                    if (progress >= 0)
                    {
                        Logger.Instace.Debug($"MkvExportClass :: MkvExport : export ing.  progress:{progress}");
                        if (progress >= 100)
                        {
                            // 完了
                            export_end = true;
                            break;
                        }// if
                    }// if
                    int lastError = _exporter.LastError;
                    string lastErrorString = _exporter.LastErrorString;
                    if (lastError > 0)
                    {
                        Logger.Instace.Error($"MkvExportClass :: MkvExport() : export error.  LastError[{lastError}][{lastErrorString}] progress:{progress}");
                        Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret::{ExportResponse.Error}");
                        return ExportResponse.Error;
                    }// if

                    // タイムアウト確認
                    if (pTimeOutSec != MkvExport_NoTimeout)
                    {
                        DateTime nowDateTime = DateTime.Now;
                        TimeSpan ts = nowDateTime - startDateTime;
                        if (ts.TotalSeconds >= pTimeOutSec)
                        {
                            // タイムアウト
                            Logger.Instace.Error($"MkvExportClass :: MkvExport : export timeout.  sec:{pTimeOutSec}");
                            // エクスポートキャンセル 
                            Logger.Instace.Debug($"MkvExportClass :: MkvExport : export cancel.");
                            _exporter.Cancel();
                            Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.Timeout}");
                            return ExportResponse.Timeout;
                        }// if
                    }// if
                    Logger.Instace.Debug($"MkvExportClass :: MkvExport : export end.");

                    Task.Run(async () =>
                    {
                        try
                        {
                            await Task.Delay(500, pToken);
                        }
                        catch (OperationCanceledException)
                        {
                        }
                    }).Wait();

                }// while
                 // サービス停止時、例外:OperationCanceledException
                pToken.ThrowIfCancellationRequested();

                // エクスポートが中断された場合
                if (export_end == false)
                {
                    Logger.Instace.Warn($"MkvExportClass :: MkvExport : MkvExport stop setting.");
                    // エクスポートキャンセル
                    Logger.Instace.Debug($"MkvExportClass :: MkvExport : export cancel.");
                    _exporter.Cancel();
                    Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.Suspend}");
                    return ExportResponse.Suspend;
                }
            }
            catch (NoVideoInTimeSpanMIPException ex)
            {//ビデオが存在しない
                Logger.Instace.Info($"MkvExportClass :: MkvExport : no video.  message:{ex.Message}");
                Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.NoExportSuccess}");
                return ExportResponse.NoExportSuccess;
            }
            catch (OperationCanceledException)
            {
                Logger.Instace.Warn($"MkvExportClass :: MkvExport : MkvExport canceled.");
                Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.Suspend}");
                return ExportResponse.Suspend;
            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"MkvExportClass :: MkvExport : exception. [0x{ex.HResult:X8}] [{ex.Message}]");
                Logger.Instace.Info($"MkvExportClass :: MkvExport : end.  ret:{ExportResponse.Error}");
                return ExportResponse.Error;
            }
            finally
            {
                if (_exporter != null)
                {
                    Logger.Instace.Debug($"MkvExportClass :: MkvExport : export end.");
                    _exporter.EndExport();
                    _exporter.Close();
                    _exporter = null;
                }
            }

            Logger.Instace.Info($"MkvExportClass :: MkvExport : end. ret:{ExportResponse.Success}");
            return ExportResponse.Success;
        }// MkvExport()


        /// <summary>
        /// MKV形式で動画エクスポートパラメータ確認
        /// </summary>
        /// <param name="pCameraId">カメラID</param>
        /// <param name="pExportPath">出力先パス</param>
        /// <param name="pExportFileName">出力ファイル名（拡張子は付加しない）</param>
        /// <param name="pStartTime">開始時刻（秒迄）</param>
        /// <param name="pEndTime">終了時刻（秒迄）</param>
        /// <returns>処理結果</returns>
        private bool MkvExportParameterCheck(string pCameraId,
                                             string pExportPath,
                                             string pExportFileName,
                                             DateTime pStartTime,
                                             DateTime pEndTime)
        {
            //----------------
            // パラメータ確認
            //----------------
            if (pCameraId == null)
            {
                Logger.Instace.Error($"MkvExportClass :: MkvExportParameterCheck : parameter error.  pCameraId:null");
                return false;
            }// if
            if (pCameraId.Length == 0)
            {
                Logger.Instace.Error($"MkvExportClass :: MkvExportParameterCheck : parameter error.  pCameraId:");
                return false;
            }// if

            if (pExportPath == null)
            {
                Logger.Instace.Error($"MkvExportClass :: MkvExportParameterCheck : parameter error.  pExportPath:null");
                return false;
            }// if
            if (pExportPath.Length == 0)
            {
                Logger.Instace.Error($"MkvExportClass :: MkvExportParameterCheck : parameter error.  pExportPath:");
                return false;
            }// if

            if (pExportFileName == null)
            {
                Logger.Instace.Error($"MkvExportClass :: MkvExportParameterCheck : parameter error.  pExportFileName:null");
                return false;
            }// if
            if (pExportFileName.Length == 0)
            {
                Logger.Instace.Error($"MkvExportClass :: MkvExportParameterCheck : parameter error.  pExportFileName:");
                return false;
            }// if

            if (pStartTime > pEndTime)
            {
                Logger.Instace.Error($"MkvExportClass :: MkvExportParameterCheck : parameter error.  pStartTime:{pStartTime} > pEndTime:{pEndTime}");
                return false;
            }// if

            return true;
        }// MkvExportParameterCheck


        /// <summary>
        /// JPEG形式で静止画エクスポート
        /// </summary>
        /// <param name="pCameraId">カメラID</param>
        /// <param name="pExportPath">出力先パス</param>
        /// <param name="pExportFileName">出力ファイル名（拡張子は付加しない）</param>
        /// <param name="pStartTime">エクスポート時刻（秒迄）</param>
        /// <param name="pWidth">画像幅（※pHeight，pWidth何れかでJpegExport_NoImageSizeSpecifiedが指定された場合は指定なしとする）</param>
        /// <param name="pHeight">画像高さ（※pHeight，pWidth何れかでJpegExport_NoImageSizeSpecifiedが指定された場合は指定なしとする）</param>
        /// <returns>ExportResponse : 正常終了（エクスポート有り）, 正常終了（エクスポート無し）, 異常終了</returns>
        public ExportResponse JpegExport(string pCameraId,
                                         string pExportPath,
                                         string pExportFileName,
                                         DateTime pExportTime,
                                         int pWidth,
                                         int pHeight)
        {
            string strLogTarget = "CameraId[" + pCameraId + "][" + pExportTime.ToString(Constants.DateTimeFormat) + "] Width[" + pWidth.ToString() + "] Height[" + pHeight.ToString() + "]";
            Logger.Instace.Info($"MkvExportClass :: JpegExport : start.  param:{strLogTarget}");

            //----------------
            // パラメータ確認
            //----------------
            if (!JpegExportParameterCheck(pCameraId, pExportPath, pExportFileName, pWidth, pHeight))
            {
                Logger.Instace.Info($"MkvExportClass :: JpegExport : end.  ret:{ExportResponse.Error}");
                return ExportResponse.Error;
            }

            //--------------------------------
            // エクスポートパラメータ情報生成
            //--------------------------------
            VideoOS.Platform.Data.JPEGVideoSource _exporter;

            Item cameraItem;
            try
            {
                // カメラ情報取得
                cameraItem = Configuration.Instance.GetItem(new Guid(pCameraId), Kind.Camera);
                if (cameraItem == null)
                {
                    Logger.Instace.Error($"MkvExportClass :: JpegExport : camera id does not exist.  camera id:{pCameraId}");
                    Logger.Instace.Info($"MkvExportClass :: JpegExport : end.  ret:{ExportResponse.Error}");
                    return ExportResponse.Error;
                }// if

                // エクスポートパラメータ情報生成
                _exporter = new VideoOS.Platform.Data.JPEGVideoSource(cameraItem);

            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExport : exception. [0x{ex.HResult:X8}] [{ex.Message}]");
                Logger.Instace.Info($"MkvExportClass :: JpegExport : end.  ret:{ExportResponse.Error}");
                return ExportResponse.Error;
            }

            try
            {
                //----------------------
                // JPEGVideoSource初期化
                //----------------------
                if ((pWidth == JpegExport_NoImageSizeSpecified) || (pHeight == JpegExport_NoImageSizeSpecified))
                {
                    // 画像サイズ指定なし
                    _exporter.Init();
                }// if
                else
                {
                    // 画像サイズ指定あり
                    _exporter.Init(pWidth, pHeight);
                }// else

                //-------------------------------------------------
                // エクスポート時刻に録画映像が存在しているかを確認
                //-------------------------------------------------
                StartEndDateTime[] timeList = this.GetPlaybackPeriodOfTheFirstVideo(cameraItem, pExportTime, pExportTime);
                if (timeList.Length <= 0)
                {
                    Logger.Instace.Warn($"MkvExportClass :: JpegExport : recorded video exists at export time.  export time:{pExportTime.ToString(Constants.DateTimeFormat)}");
                    _exporter.Close();
                    _exporter = null;
                    Logger.Instace.Info($"MkvExportClass :: JpegExport : end.  ret:{ExportResponse.NoExportSuccess}");
                    return ExportResponse.NoExportSuccess;
                }// if

                //---------
                //JPEG取得
                //---------
                JPEGData jpegData = (JPEGData)_exporter.Get(pExportTime);
                if (jpegData == null)
                {
                    Logger.Instace.Error($"MkvExportClass :: JpegExport : VideoOS.Platform.Data.JPEGVideoSource.Get() error.  export time:{pExportTime.ToString(Constants.DateTimeFormat)}");
                    _exporter.Close();
                    _exporter = null;
                    Logger.Instace.Info($"MkvExportClass :: JpegExport : end.  ret:{ExportResponse.Error}");
                    return ExportResponse.Error;
                }// if

                //------------------------
                //JPEGデータをファイル出力
                //------------------------
                byte[] jpegbyte = jpegData.Bytes;
                string path = pExportPath + "\\" + pExportFileName + Constants.ExtensionJpeg;
                using (BinaryWriter bw = new BinaryWriter(new FileStream(path, FileMode.Create)))
                {
                    bw.Write(jpegbyte);
                }// using
                jpegbyte = null;
                jpegData = null;

            }
            catch (Exception ex)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExport : exception. [0x{ex.HResult:X8}] [{ex.Message}]");
                _exporter.Close();
                Logger.Instace.Info($"MkvExportClass :: JpegExport : end  ret:{ExportResponse.Error}");
                return ExportResponse.Error;
            }

            _exporter.Close();
            Logger.Instace.Info($"MkvExportClass :: JpegExport : end.  ret:{ExportResponse.Success}");
            return ExportResponse.Success;
        }// JpegExport()


        /// <summary>
        /// JPEG形式で静止画エクスポートパラメータ確認
        /// </summary>
        /// <param name="pCameraId">カメラID</param>
        /// <param name="pExportPath">出力先パス</param>
        /// <param name="pExportFileName">出力ファイル名（拡張子は付加しない）</param>
        /// <param name="pWidth">画像幅（※pHeight，pWidth何れかでJpegExport_NoImageSizeSpecifiedが指定された場合は指定なしとする）</param>
        /// <param name="pHeight">画像高さ（※pHeight，pWidth何れかでJpegExport_NoImageSizeSpecifiedが指定された場合は指定なしとする）</param>
        /// <returns>処理結果</returns>
        private bool JpegExportParameterCheck(string pCameraId,
                                              string pExportPath,
                                              string pExportFileName,
                                              int pWidth,
                                              int pHeight)
        {
            //----------------
            // パラメータ確認
            //----------------
            if (pCameraId == null)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExportParameterCheck : parameter error.  pCameraId:null");
                return false;
            }// if
            if (pCameraId.Length == 0)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExportParameterCheck : parameter error.  pCameraId:");
                return false;
            }// if

            if (pExportPath == null)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExportParameterCheck : parameter error.  pExportPath:null");
                return false;
            }// if
            if (pExportPath.Length == 0)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExportParameterCheck : parameter error.  pExportPath:");
                return false;
            }// if

            if (pExportFileName == null)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExportParameterCheck : parameter error.  pExportFileName:null");
                return false;
            }// if
            if (pExportFileName.Length == 0)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExportParameterCheck : parameter error.  pExportFileName:");
                return false;
            }// if
            if (pWidth < 0)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExportParameterCheck : parameter error.  pWidth:{pWidth}");
                return false;
            }// if
            if (pHeight < 0)
            {
                Logger.Instace.Error($"MkvExportClass :: JpegExportParameterCheck : parameter error.  pHeight:{pHeight}");
                return false;
            }// if
            return true;
        }// 


        /// <summary>
        /// 指定期間内にXProtect上に存在する先頭動画の開始時間、終了時間を取得する
        /// </summary>
        /// <param name="pCameraItem">カメラItem</param>
        /// <param name="pStartDateTime">指定期間（開始）</param>
        /// <param name="pEndDateTime">指定期間（終了）</param>
        /// <returns>XProtect上に存在する先頭動画の開始時間、終了時間</returns>
        public StartEndDateTime[] GetPlaybackPeriodOfTheFirstVideo(Item pCameraItem, 
                                                                   DateTime pStartDateTime,
                                                                   DateTime pEndDateTime)
        {
            string strLogTarget = "CameraName[" + pCameraItem.Name + "] StartDateTime[" + pStartDateTime.ToString(Constants.DateTimeFormat) + "] StartDateTime[" + pEndDateTime.ToString(Constants.DateTimeFormat) + "]";
            Logger.Instace.Info($"MkvExportClass :: GetPlaybackPeriodOfTheFirstVideo : start.  param:{strLogTarget}");

            SequenceDataSource dataSource = new SequenceDataSource(pCameraItem);
            dataSource.Init();

            TimeSpan maxTimeBefore = pStartDateTime - pStartDateTime;
            TimeSpan maxTimeAfter = pEndDateTime - pStartDateTime;

            List<object> cacheRecordings = dataSource.GetData(pStartDateTime.ToUniversalTime(), maxTimeBefore, 1, maxTimeAfter, 1);

            //最大１件になるはず
            StartEndDateTime[] retList = new StartEndDateTime[cacheRecordings.Count];
            int i = 0;
            foreach (SequenceData recording in cacheRecordings)
            {
                retList[i] = new StartEndDateTime() { };
                retList[i].startTime = recording.EventSequence.StartDateTime.ToLocalTime();
                retList[i].endTime = recording.EventSequence.EndDateTime.ToLocalTime();
                Logger.Instace.Debug($"MkvExportClass :: GetPlaybackPeriodOfTheFirstVideo : get information. cnt:{i} start:{retList[i].startTime.ToString(Constants.DateTimeFormat)} end:{retList[i].endTime.ToString(Constants.DateTimeFormat)}");
                i++;
            }// foreach
            dataSource.Close();

            Logger.Instace.Info($"MkvExportClass :: GetPlaybackPeriodOfTheFirstVideo : end.");
            return retList;
        }// GetPlaybackPeriodOfTheFirstVideo()

    }// class MkvExportClass

}// namespace XpMkvExportDll
