﻿using System;

namespace XpMkvExportDll
{
    public class StartEndDateTime
    {
        public DateTime startTime;
        public DateTime endTime;
    }
}

