// MP4 録画フローとエラーハンドリングの結合テスト
// タスク 7.2: MP4 録画フロー、RTSP 切断時自動停止、ディスク書き込みエラー、設定永続化
// Requirements: 2.1, 4.3, 4.4, 5.1, 5.2

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.Integration;

/// <summary>
/// RTSP 切断時の自動録画停止と録画データ保存の結合テスト（タスク 7.2）。
/// mock ベースで ViewModel - RecordingService 間の統合動作を検証する。
/// </summary>
public class RecordingRtspDisconnectIntegrationTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly Mock<IRecordingService> _mockRecordingService;

    public RecordingRtspDisconnectIntegrationTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();
        _mockRecordingService = new Mock<IRecordingService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
    }

    private StreamPaneViewModel CreateSut()
    {
        return new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object,
            _mockRecordingService.Object);
    }

    // ─── RTSP 切断時の自動停止テスト（Req 5.1）─────────────────────

    [Fact]
    public void RtspDisconnect_WhileRecording_CallsStop_AndStateBecomesIdle()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Recording);
        var sut = CreateSut();

        // RTSP 切断イベントを発火
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            _mockRtspService.Object,
            new StreamStateChangedEventArgs(ConnectionState.Disconnected));

        // Stop が呼ばれることを検証
        _mockRecordingService.Verify(s => s.Stop(), Times.Once);
    }

    [Fact]
    public void RtspDisconnect_WhileRecording_ClearsPacketCallback()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Recording);
        var sut = CreateSut();

        // RTSP 切断イベントを発火
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            _mockRtspService.Object,
            new StreamStateChangedEventArgs(ConnectionState.Disconnected));

        // PacketReceived が null に設定されることを検証
        _mockRtspService.VerifySet(s => s.PacketReceived = null, Times.Once);
    }

    [Fact]
    public void RtspError_WhileRecording_CallsStop()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Recording);
        var sut = CreateSut();

        // RTSP エラーイベントを発火（切断と同様に Disconnected に遷移）
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            _mockRtspService.Object,
            new StreamStateChangedEventArgs(ConnectionState.Disconnected,
                new RtspError(RtspErrorKind.NetworkUnreachable, "ネットワーク接続が失われました", null)));

        _mockRecordingService.Verify(s => s.Stop(), Times.Once);
    }

    [Fact]
    public void RtspReconnect_AfterDisconnect_DoesNotAutoStartRecording()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        var sut = CreateSut();

        // RTSP 再接続イベントを発火
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            _mockRtspService.Object,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // Start が呼ばれないことを検証（Req 5.4）
        _mockRecordingService.Verify(s => s.Start(
            It.IsAny<string>(),
            It.IsAny<Sdcb.FFmpeg.Codecs.CodecParameters>(),
            It.IsAny<Sdcb.FFmpeg.Raw.AVRational>(),
            It.IsAny<string?>()), Times.Never);
    }

    [Fact]
    public void RtspConnect_SetsUpPacketCallback()
    {
        var sut = CreateSut();

        // RTSP 接続イベントを発火
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            _mockRtspService.Object,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // PacketReceived コールバックが設定されることを検証
        _mockRtspService.VerifySet(
            s => s.PacketReceived = It.IsNotNull<Action<Sdcb.FFmpeg.Codecs.Packet, Sdcb.FFmpeg.Raw.AVRational, Sdcb.FFmpeg.Codecs.CodecParameters>>(),
            Times.Once);
    }
}

/// <summary>
/// ディスク書き込みエラー時の録画停止とエラーメッセージ表示の結合テスト（タスク 7.2）。
/// Requirements: 5.2
/// </summary>
public class RecordingDiskErrorIntegrationTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly Mock<IRecordingService> _mockRecordingService;

    public RecordingDiskErrorIntegrationTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();
        _mockRecordingService = new Mock<IRecordingService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
    }

    private StreamPaneViewModel CreateSut()
    {
        return new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object,
            _mockRecordingService.Object);
    }

    [Fact]
    public void DiskWriteError_SetsErrorMessageOnViewModel()
    {
        var sut = CreateSut();
        var errorMessage = "ディスク容量が不足しています";

        // RecordingError イベントを発火
        _mockRecordingService.Raise(
            s => s.RecordingError += null,
            _mockRecordingService.Object,
            new RecordingErrorEventArgs(RecordingErrorKind.DiskWriteError, errorMessage));

        Assert.Equal(errorMessage, sut.ErrorMessage);
    }

    [Fact]
    public void PermissionDeniedError_SetsErrorMessageOnViewModel()
    {
        var sut = CreateSut();
        var errorMessage = "録画保存先フォルダへの書き込み権限がありません";

        _mockRecordingService.Raise(
            s => s.RecordingError += null,
            _mockRecordingService.Object,
            new RecordingErrorEventArgs(RecordingErrorKind.PermissionDenied, errorMessage));

        Assert.Equal(errorMessage, sut.ErrorMessage);
    }

    [Fact]
    public void DirectoryCreationFailedError_SetsErrorMessageOnViewModel()
    {
        var sut = CreateSut();
        var errorMessage = "録画保存先フォルダの作成に失敗しました";

        _mockRecordingService.Raise(
            s => s.RecordingError += null,
            _mockRecordingService.Object,
            new RecordingErrorEventArgs(RecordingErrorKind.DirectoryCreationFailed, errorMessage));

        Assert.Equal(errorMessage, sut.ErrorMessage);
    }

    [Fact]
    public void RecordingStateChanged_ToIdle_AfterError_ResetsIsRecording()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        var sut = CreateSut();

        // まず Recording 状態にする
        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Recording);

        Assert.True(sut.IsRecording);

        // エラーで停止後 Idle に戻る
        _mockRecordingService.Raise(
            s => s.RecordingError += null,
            _mockRecordingService.Object,
            new RecordingErrorEventArgs(RecordingErrorKind.DiskWriteError, "エラー発生"));

        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Idle);

        Assert.False(sut.IsRecording);
        Assert.Equal(string.Empty, sut.RecordingElapsedTime);
    }

    [Fact]
    public void RecordingStateChanged_ToStopping_ThenIdle_TransitionsCorrectly()
    {
        var sut = CreateSut();

        // Recording -> Stopping -> Idle の遷移を検証
        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Recording);
        Assert.True(sut.IsRecording);

        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Stopping);
        Assert.False(sut.IsRecording);

        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Idle);
        Assert.False(sut.IsRecording);
        Assert.Equal(string.Empty, sut.RecordingElapsedTime);
    }
}

/// <summary>
/// RecordingFolderPath の永続化・復元の結合テスト（タスク 7.2）。
/// Requirements: 4.3, 4.4
/// </summary>
public class RecordingFolderPathPersistenceTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly Mock<IRecordingService> _mockRecordingService;

    public RecordingFolderPathPersistenceTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();
        _mockRecordingService = new Mock<IRecordingService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
    }

    private StreamPaneViewModel CreateSut()
    {
        return new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object,
            _mockRecordingService.Object);
    }

    // ─── RecordingFolderPath の復元テスト（Req 4.4）────────────────

    [Fact]
    public void LoadSettings_RestoresRecordingFolderPath()
    {
        var customPath = @"D:\CustomRecordings";
        var settings = AppSettings.Default with { RecordingFolderPath = customPath };
        _mockSettingsService.Setup(s => s.Load()).Returns(settings);

        var pane1 = CreateSut();
        var pane2 = CreateSut();

        var pane3 = CreateSut();
        var mainVm = new MainWindowViewModel(pane1, pane2, pane3, _mockSettingsService.Object);
        mainVm.LoadSettings();

        Assert.Equal(customPath, pane1.RecordingFolderPath);
        Assert.Equal(customPath, pane2.RecordingFolderPath);
    }

    [Fact]
    public void LoadSettings_DefaultPath_WhenNoSavedSettings()
    {
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);

        var pane1 = CreateSut();
        var pane2 = CreateSut();

        var pane3 = CreateSut();
        var mainVm = new MainWindowViewModel(pane1, pane2, pane3, _mockSettingsService.Object);
        mainVm.LoadSettings();

        Assert.Equal(AppSettings.Default.RecordingFolderPath, pane1.RecordingFolderPath);
        Assert.Equal(AppSettings.Default.RecordingFolderPath, pane2.RecordingFolderPath);
    }

    // ─── RecordingFolderPath の永続化テスト（Req 4.3）───────────────

    [Fact]
    public void OnClosing_SavesRecordingFolderPath()
    {
        AppSettings? savedSettings = null;
        _mockSettingsService.Setup(s => s.Save(It.IsAny<AppSettings>()))
            .Callback<AppSettings>(s => savedSettings = s);

        var pane1 = CreateSut();
        var pane2 = CreateSut();
        pane1.RecordingFolderPath = @"E:\MyRecordings";

        var pane3 = CreateSut();
        var mainVm = new MainWindowViewModel(pane1, pane2, pane3, _mockSettingsService.Object);
        mainVm.OnClosing();

        Assert.NotNull(savedSettings);
        Assert.Equal(@"E:\MyRecordings", savedSettings!.RecordingFolderPath);
    }

    [Fact]
    public void OnClosing_WithEmptyPanePath_UsesDefaultFolderPath()
    {
        AppSettings? savedSettings = null;
        _mockSettingsService.Setup(s => s.Save(It.IsAny<AppSettings>()))
            .Callback<AppSettings>(s => savedSettings = s);

        var pane1 = CreateSut();
        var pane2 = CreateSut();
        // RecordingFolderPath は空のまま

        var pane3 = CreateSut();
        var mainVm = new MainWindowViewModel(pane1, pane2, pane3, _mockSettingsService.Object);
        mainVm.OnClosing();

        Assert.NotNull(savedSettings);
        // デフォルトの RecordingFolderPath が使用される
        Assert.Equal(AppSettings.Default.RecordingFolderPath, savedSettings!.RecordingFolderPath);
    }

    // ─── SettingsService による実際の永続化・復元テスト ─────────────

    [Fact]
    public void SettingsService_SaveAndLoad_PreservesRecordingFolderPath()
    {
        var tempDir = Path.Combine(Path.GetTempPath(), $"SettingsTest_{Guid.NewGuid():N}");

        try
        {
            var settingsService = new SettingsService(tempDir);
            var customPath = @"F:\CustomRecordings\Test";

            var settings = AppSettings.Default with { RecordingFolderPath = customPath };
            settingsService.Save(settings);

            var loaded = settingsService.Load();

            Assert.Equal(customPath, loaded.RecordingFolderPath);
        }
        finally
        {
            if (Directory.Exists(tempDir))
                Directory.Delete(tempDir, true);
        }
    }

    [Fact]
    public void SettingsService_Load_WithMissingRecordingFolderPath_FallsBackToDefault()
    {
        var tempDir = Path.Combine(Path.GetTempPath(), $"SettingsTest_{Guid.NewGuid():N}");

        try
        {
            Directory.CreateDirectory(tempDir);

            // RecordingFolderPath を含まない旧形式 JSON を書き込む
            var json = """
            {
                "pane1": {
                    "rtspUrl": "",
                    "transport": "Tcp"
                },
                "pane2": {
                    "rtspUrl": "",
                    "transport": "Tcp"
                },
                "layout": "Horizontal"
            }
            """;
            File.WriteAllText(Path.Combine(tempDir, "settings.json"), json);

            var settingsService = new SettingsService(tempDir);
            var loaded = settingsService.Load();

            Assert.Equal(AppSettings.Default.RecordingFolderPath, loaded.RecordingFolderPath);
        }
        finally
        {
            if (Directory.Exists(tempDir))
                Directory.Delete(tempDir, true);
        }
    }

    [Fact]
    public void SettingsService_Load_WithNullRecordingFolderPath_FallsBackToDefault()
    {
        var tempDir = Path.Combine(Path.GetTempPath(), $"SettingsTest_{Guid.NewGuid():N}");

        try
        {
            Directory.CreateDirectory(tempDir);

            // RecordingFolderPath が null の JSON を書き込む
            var json = """
            {
                "pane1": {
                    "rtspUrl": "",
                    "transport": "Tcp"
                },
                "pane2": {
                    "rtspUrl": "",
                    "transport": "Tcp"
                },
                "layout": "Horizontal",
                "recordingFolderPath": null
            }
            """;
            File.WriteAllText(Path.Combine(tempDir, "settings.json"), json);

            var settingsService = new SettingsService(tempDir);
            var loaded = settingsService.Load();

            Assert.Equal(AppSettings.Default.RecordingFolderPath, loaded.RecordingFolderPath);
        }
        finally
        {
            if (Directory.Exists(tempDir))
                Directory.Delete(tempDir, true);
        }
    }
}

/// <summary>
/// 録画フローの操作シーケンス結合テスト（タスク 7.2）。
/// ToggleRecording -> Start/Stop の完全なフローを mock ベースで検証する。
/// Requirements: 2.1
/// </summary>
public class RecordingFlowIntegrationTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly Mock<IRecordingService> _mockRecordingService;

    public RecordingFlowIntegrationTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();
        _mockRecordingService = new Mock<IRecordingService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
    }

    private StreamPaneViewModel CreateSut()
    {
        return new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object,
            _mockRecordingService.Object);
    }

    [Fact]
    public void FullRecordingCycle_Start_Record_Stop()
    {
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connected;
        sut.RecordingFolderPath = @"C:\TestRecordings";

        // 1. 録画開始
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        sut.ToggleRecording();

        _mockRecordingService.Verify(s => s.Start(
            It.IsAny<string>(),
            It.IsAny<Sdcb.FFmpeg.Codecs.CodecParameters>(),
            It.IsAny<Sdcb.FFmpeg.Raw.AVRational>(),
            It.IsAny<string?>()), Times.Once);

        // 2. StateChanged で Recording に遷移
        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Recording);
        Assert.True(sut.IsRecording);

        // 3. 録画停止
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Recording);
        sut.ToggleRecording();

        _mockRecordingService.Verify(s => s.Stop(), Times.Once);

        // 4. StateChanged で Stopping -> Idle に遷移
        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Stopping);
        Assert.False(sut.IsRecording);

        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Idle);
        Assert.False(sut.IsRecording);
        Assert.Equal(string.Empty, sut.RecordingElapsedTime);
    }

    [Fact]
    public void ToggleRecording_UsesRecordingFolderPath_WhenSet()
    {
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connected;
        sut.RecordingFolderPath = @"D:\MyRecordings";

        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        sut.ToggleRecording();

        _mockRecordingService.Verify(s => s.Start(
            @"D:\MyRecordings",
            It.IsAny<Sdcb.FFmpeg.Codecs.CodecParameters>(),
            It.IsAny<Sdcb.FFmpeg.Raw.AVRational>(),
            It.IsAny<string?>()), Times.Once);
    }

    [Fact]
    public void ToggleRecording_UsesDefaultPath_WhenRecordingFolderPathEmpty()
    {
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connected;
        sut.RecordingFolderPath = string.Empty;

        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        sut.ToggleRecording();

        _mockRecordingService.Verify(s => s.Start(
            AppSettings.Default.RecordingFolderPath,
            It.IsAny<Sdcb.FFmpeg.Codecs.CodecParameters>(),
            It.IsAny<Sdcb.FFmpeg.Raw.AVRational>(),
            It.IsAny<string?>()), Times.Once);
    }

    [Fact]
    public void ToggleRecording_UsesDefaultPath_WhenRecordingFolderPathWhitespace()
    {
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connected;
        sut.RecordingFolderPath = "   ";

        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        sut.ToggleRecording();

        _mockRecordingService.Verify(s => s.Start(
            AppSettings.Default.RecordingFolderPath,
            It.IsAny<Sdcb.FFmpeg.Codecs.CodecParameters>(),
            It.IsAny<Sdcb.FFmpeg.Raw.AVRational>(),
            It.IsAny<string?>()), Times.Once);
    }
}

/// <summary>
/// RecordingService のバリデーション結合テスト（タスク 7.2）。
/// 実際のファイルシステムを使用したバリデーション動作を検証する。
/// </summary>
public class RecordingServiceFileSystemIntegrationTests : IDisposable
{
    private readonly RecordingService _sut;
    private readonly List<RecordingErrorEventArgs> _errors;
    private readonly List<RecordingState> _stateTransitions;

    public RecordingServiceFileSystemIntegrationTests()
    {
        _sut = new RecordingService();
        _errors = new List<RecordingErrorEventArgs>();
        _stateTransitions = new List<RecordingState>();

        _sut.RecordingError += (_, e) => _errors.Add(e);
        _sut.StateChanged += (_, state) => _stateTransitions.Add(state);
    }

    public void Dispose()
    {
        _sut.Dispose();
    }

    [Fact]
    public void Start_WithReadOnlyFolder_RaisesPermissionDenied()
    {
        // Windows では読み取り専用属性をフォルダに設定しても書き込みは通常可能なため、
        // 存在しないドライブのパスでテスト
        var result = _sut.Start(@"Z:\NoAccess\ReadOnly", null!, default);

        Assert.False(result);
        Assert.Equal(RecordingState.Idle, _sut.State);
        Assert.Single(_errors);
        Assert.True(
            _errors[0].Kind == RecordingErrorKind.DirectoryCreationFailed ||
            _errors[0].Kind == RecordingErrorKind.PermissionDenied);
    }

    [Fact]
    public void Start_WithValidPath_ButNullCodecpar_RaisesError()
    {
        var tempDir = Path.Combine(Path.GetTempPath(), $"RecordingIntTest_{Guid.NewGuid():N}");
        Directory.CreateDirectory(tempDir);

        try
        {
            var result = _sut.Start(tempDir, null!, default);

            Assert.False(result);
            Assert.Equal(RecordingState.Idle, _sut.State);
            Assert.Single(_errors);
            Assert.Equal(RecordingErrorKind.DiskWriteError, _errors[0].Kind);
        }
        finally
        {
            Directory.Delete(tempDir, true);
        }
    }

    [Fact]
    public void Start_AutoCreatesOutputDirectory()
    {
        var tempDir = Path.Combine(Path.GetTempPath(), $"RecordingIntTest_{Guid.NewGuid():N}", "auto_created");

        try
        {
            Assert.False(Directory.Exists(tempDir));

            // Start は codecpar が null なので最終的には失敗するが、
            // ディレクトリは作成されているはず
            _sut.Start(tempDir, null!, default);

            Assert.True(Directory.Exists(tempDir));
        }
        finally
        {
            var rootDir = Path.GetDirectoryName(tempDir)!;
            if (Directory.Exists(rootDir))
                Directory.Delete(rootDir, true);
        }
    }

    [Fact]
    public void ErrorEventArgs_ContainsMeaningfulMessage()
    {
        _sut.Start(string.Empty, null!, default);

        Assert.Single(_errors);
        Assert.False(string.IsNullOrWhiteSpace(_errors[0].Message));
        Assert.True(_errors[0].Message.Length > 5);
    }
}
