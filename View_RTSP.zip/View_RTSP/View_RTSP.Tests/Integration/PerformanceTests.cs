// パフォーマンス計測テスト
// タスク 12.3 に対応
// Requirements: 6.1, 6.2, 8.3, 9.7, 9.9

using System.Diagnostics;
using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.Integration;

/// <summary>
/// パフォーマンス計測テスト。
/// <para>
/// Stopwatch を使用してサービス・ViewModel 間の処理時間を計測し、以下の目標値を検証する:
/// - 状態変化イベントの ViewModel 反映: 100ms 以内
/// - 統計情報更新処理: 100ms 以内
/// - 接続・切断サイクル後のメモリリークなし（GC.GetTotalMemory で概算計測）
/// - デュアルストリーム同時操作の独立性（一方の遅延が他方に影響しない）
/// </para>
/// Requirements: 6.1, 6.2, 8.3, 9.7, 9.9
/// </summary>
public class PerformanceTests
{
    // ─── タイムアウト定数 ─────────────────────────────────────────

    /// <summary>UI イベント処理タイムアウト（100ms 以内: UI 操作レスポンスタイム要件）</summary>
    private const int UiResponseTimeoutMs = 100;

    /// <summary>状態遷移処理タイムアウト（100ms 以内）</summary>
    private const int StateTransitionTimeoutMs = 100;

    // ─── テスト用フィクスチャー ───────────────────────────────────

    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly StreamPaneViewModel _viewModel;

    public PerformanceTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);

        _viewModel = new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);
    }

    // ─── 状態変化イベントのレスポンスタイム計測 ──────────────────

    /// <summary>
    /// 状態変化イベントが ViewModel へ反映されるまでの時間が 100ms 以内
    /// Requirements: 9.7（UI 操作レスポンスタイム 100ms 以内）
    /// </summary>
    [Fact]
    public void StateChangedEvent_ResponseTime_IsWithin100Ms()
    {
        // Arrange: Stopwatch でイベント処理時間を計測
        var sw = new Stopwatch();

        // Act: イベント発行前後の時間を計測
        sw.Start();
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));
        sw.Stop();

        // Assert: 処理時間が 100ms 以内であること
        Assert.True(
            sw.ElapsedMilliseconds < UiResponseTimeoutMs,
            $"状態変化イベントの処理時間 {sw.ElapsedMilliseconds}ms が目標値 {UiResponseTimeoutMs}ms を超過しました");

        // 状態が正しく反映されていること
        Assert.Equal(ConnectionState.Connected, _viewModel.ConnectionState);
    }

    /// <summary>
    /// 連続する状態変化イベントの処理時間の合計が許容範囲内
    /// Requirements: 9.7（UI 操作レスポンスタイム）
    /// </summary>
    [Fact]
    public void MultipleStateChangedEvents_TotalResponseTime_IsAcceptable()
    {
        // Arrange: 複数の状態変化を繰り返す
        var states = new[]
        {
            ConnectionState.Connecting,
            ConnectionState.Connected,
            ConnectionState.Disconnected,
            ConnectionState.Connecting,
            ConnectionState.Error
        };

        var sw = new Stopwatch();

        // Act: 各状態変化イベントを連続発行して合計時間を計測
        sw.Start();
        foreach (var state in states)
        {
            RtspError? error = state == ConnectionState.Error
                ? new RtspError(RtspErrorKind.NetworkUnreachable, "テストエラー", null)
                : null;
            _mockRtspService.Raise(
                s => s.StateChanged += null,
                new StreamStateChangedEventArgs(state, error));
        }
        sw.Stop();

        // Assert: 5 回のイベント処理合計が 500ms 以内（1 回あたり 100ms）
        Assert.True(
            sw.ElapsedMilliseconds < UiResponseTimeoutMs * states.Length,
            $"連続状態変化イベントの処理時間 {sw.ElapsedMilliseconds}ms が目標値 {UiResponseTimeoutMs * states.Length}ms を超過しました");
    }

    // ─── 統計情報更新のレスポンスタイム計測 ──────────────────────

    /// <summary>
    /// 統計情報更新イベントの処理時間が 100ms 以内
    /// Requirements: 9.7（UI 操作レスポンスタイム）, 6.1（フレームレート統計）
    /// </summary>
    [Fact]
    public void StatsUpdatedEvent_ResponseTime_IsWithin100Ms()
    {
        // Arrange
        var stats = new ConnectionStats(29.97, 1500, TimeSpan.FromMinutes(5));
        var sw = new Stopwatch();

        // Act
        sw.Start();
        _mockRtspService.Raise(
            s => s.StatsUpdated += null,
            (object?)null,
            stats);
        sw.Stop();

        // Assert: 処理時間が 100ms 以内であること
        Assert.True(
            sw.ElapsedMilliseconds < UiResponseTimeoutMs,
            $"統計情報更新イベントの処理時間 {sw.ElapsedMilliseconds}ms が目標値 {UiResponseTimeoutMs}ms を超過しました");

        Assert.Equal(29.97, _viewModel.Stats.FrameRate, precision: 2);
    }

    // ─── 接続・切断サイクルのメモリ計測 ─────────────────────────

    /// <summary>
    /// 接続・切断を繰り返しても ViewModel のメモリ使用量が過度に増加しない
    /// Requirements: 9.9（FFmpeg リソースのリークなし）
    /// </summary>
    [Fact]
    public async Task RepeatedConnectDisconnect_MemoryUsage_DoesNotGrowSignificantly()
    {
        // Arrange: 接続・切断サービスのモック設定
        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        _viewModel.RtspUrl = "rtsp://192.168.1.100/stream";

        // GC を実行してベースラインを取得
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        long memoryBefore = GC.GetTotalMemory(forceFullCollection: true);

        // Act: 10 回の接続・切断サイクルを実行
        const int cycleCount = 10;
        for (int i = 0; i < cycleCount; i++)
        {
            await _viewModel.ConnectAsync();

            // Connected 状態に遷移
            _mockRtspService.Raise(
                s => s.StateChanged += null,
                new StreamStateChangedEventArgs(ConnectionState.Connected));

            // Disconnected 状態に遷移
            _mockRtspService.Raise(
                s => s.StateChanged += null,
                new StreamStateChangedEventArgs(ConnectionState.Disconnected));

            _viewModel.Disconnect();
        }

        // GC を実行して最終メモリを計測
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        long memoryAfter = GC.GetTotalMemory(forceFullCollection: true);

        // Assert: メモリ増加が 1MB 以内（大幅なリークがないこと）
        // 注: モックサービスなので実際の FFmpeg リソースは解放されないが、
        //     ViewModel 層でのオブジェクトリークがないことを確認する
        long memoryDiffBytes = memoryAfter - memoryBefore;
        const long maxAllowedMemoryGrowthBytes = 1 * 1024 * 1024; // 1MB

        Assert.True(
            memoryDiffBytes < maxAllowedMemoryGrowthBytes,
            $"メモリ使用量の増加 {memoryDiffBytes / 1024}KB が許容値 {maxAllowedMemoryGrowthBytes / 1024}KB を超過しました");
    }

    /// <summary>
    /// 統計情報を大量に更新してもメモリが過度に増加しない
    /// Requirements: 9.9（メモリリークなし）, 6.2（統計情報の更新）
    /// </summary>
    [Fact]
    public void ManyStatsUpdates_MemoryUsage_StaysStable()
    {
        // Arrange
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        long memoryBefore = GC.GetTotalMemory(forceFullCollection: true);

        // Act: 1000 回の統計情報更新
        const int updateCount = 1000;
        for (int i = 0; i < updateCount; i++)
        {
            var stats = new ConnectionStats(
                FrameRate: 29.97 + (i % 5),
                ReceivedFrames: i * 30L,
                Uptime: TimeSpan.FromSeconds(i));

            _mockRtspService.Raise(
                s => s.StatsUpdated += null,
                (object?)null,
                stats);
        }

        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        long memoryAfter = GC.GetTotalMemory(forceFullCollection: true);

        // Assert: メモリ増加が 512KB 以内
        long memoryDiffBytes = memoryAfter - memoryBefore;
        const long maxAllowedMemoryGrowthBytes = 512 * 1024; // 512KB

        Assert.True(
            memoryDiffBytes < maxAllowedMemoryGrowthBytes,
            $"1000 回の統計情報更新後のメモリ増加 {memoryDiffBytes / 1024}KB が許容値 {maxAllowedMemoryGrowthBytes / 1024}KB を超過しました");
    }

    // ─── デュアルストリーム同時操作のパフォーマンス ──────────────

    /// <summary>
    /// デュアルストリームで同時に状態変化イベントが発生しても、
    /// 各 ViewModel の処理時間が 100ms 以内
    /// Requirements: 8.3（デュアルストリームの独立受信・表示）, 9.7
    /// </summary>
    [Fact]
    public void DualStream_SimultaneousStateChanges_EachWithin100Ms()
    {
        // Arrange: 2 つ目のペイン用モック
        var mockRtspService2 = new Mock<IRtspStreamService>();
        var mockRenderer2 = new Mock<IVideoFrameRenderer>();
        mockRtspService2.Setup(s => s.State).Returns(ConnectionState.Disconnected);

        var viewModel2 = new StreamPaneViewModel(
            mockRtspService2.Object,
            mockRenderer2.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);

        var sw1 = new Stopwatch();
        var sw2 = new Stopwatch();

        // Act: Pane1 のイベント処理時間を計測
        sw1.Start();
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));
        sw1.Stop();

        // Act: Pane2 のイベント処理時間を計測
        sw2.Start();
        mockRtspService2.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));
        sw2.Stop();

        // Assert: 両ペインの処理時間が 100ms 以内
        Assert.True(
            sw1.ElapsedMilliseconds < UiResponseTimeoutMs,
            $"Pane1 の状態変化処理時間 {sw1.ElapsedMilliseconds}ms が目標値 {UiResponseTimeoutMs}ms を超過しました");

        Assert.True(
            sw2.ElapsedMilliseconds < UiResponseTimeoutMs,
            $"Pane2 の状態変化処理時間 {sw2.ElapsedMilliseconds}ms が目標値 {UiResponseTimeoutMs}ms を超過しました");

        // 両ペインが独立して Connected 状態になっていること
        Assert.Equal(ConnectionState.Connected, _viewModel.ConnectionState);
        Assert.Equal(ConnectionState.Connected, viewModel2.ConnectionState);
    }

    // ─── URL バリデーション処理のレスポンスタイム ────────────────

    /// <summary>
    /// URL バリデーション処理は瞬時（1ms 以内）に完了する
    /// Requirements: 9.7（UI 操作レスポンスタイム）
    /// </summary>
    [Fact]
    public void UrlValidation_ResponseTime_IsImmediate()
    {
        // Arrange
        _viewModel.RtspUrl = "rtsp://192.168.1.100/stream";
        var sw = new Stopwatch();

        // Act: 1000 回のバリデーションを実行して合計時間を計測
        const int iterations = 1000;
        sw.Start();
        for (int i = 0; i < iterations; i++)
        {
            _ = _viewModel.IsUrlValid();
        }
        sw.Stop();

        // Assert: 1000 回のバリデーションが 100ms 以内（1 回あたり 0.1ms）
        Assert.True(
            sw.ElapsedMilliseconds < UiResponseTimeoutMs,
            $"1000 回の URL バリデーション処理時間 {sw.ElapsedMilliseconds}ms が目標値 {UiResponseTimeoutMs}ms を超過しました");
    }

    // ─── RtspConnectionOptions の構築時間 ─────────────────────

    /// <summary>
    /// ConnectAsync の接続オプション構築は高速（全体の処理が 100ms 以内）
    /// Requirements: 9.7（UI 操作レスポンスタイム）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_OptionBuilding_IsWithin100Ms()
    {
        // Arrange
        _viewModel.RtspUrl = "rtsp://192.168.1.100/stream";
        _viewModel.Username = "admin";
        _viewModel.Password = "password";

        var sw = new Stopwatch();

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act: ConnectAsync の呼び出し時間を計測（モックサービスなので接続自体は即時）
        sw.Start();
        await _viewModel.ConnectAsync();
        sw.Stop();

        // Assert: 100ms 以内に完了すること
        Assert.True(
            sw.ElapsedMilliseconds < UiResponseTimeoutMs,
            $"ConnectAsync の処理時間 {sw.ElapsedMilliseconds}ms が目標値 {UiResponseTimeoutMs}ms を超過しました");
    }

    // ─── 大量エラーイベントの処理 ────────────────────────────────

    /// <summary>
    /// 大量のエラーイベントが発生しても処理時間が線形に増加する（指数的ではない）
    /// Requirements: 9.7（UI 操作レスポンスタイム）
    /// </summary>
    [Fact]
    public void ManyErrorEvents_ProcessingTime_IsLinear()
    {
        // Arrange: エラーシナリオ
        var error = new RtspError(RtspErrorKind.NetworkUnreachable, "テストエラー", null);
        var sw = new Stopwatch();

        // Act: 100 回のエラーイベントを計測
        const int eventCount = 100;
        sw.Start();
        for (int i = 0; i < eventCount; i++)
        {
            _mockRtspService.Raise(
                s => s.StateChanged += null,
                new StreamStateChangedEventArgs(ConnectionState.Error, error));
        }
        sw.Stop();

        // Assert: 100 回のイベント処理が 1000ms 以内（1 回あたり 10ms 以内）
        Assert.True(
            sw.ElapsedMilliseconds < 1000,
            $"100 回のエラーイベント処理時間 {sw.ElapsedMilliseconds}ms が目標値 1000ms を超過しました");
    }

    // ─── 接続オプション生成のベンチマーク ───────────────────────

    /// <summary>
    /// RtspConnectionOptions の不変レコード生成は高速
    /// Requirements: 6.1（フレームデコード時の処理効率）
    /// </summary>
    [Fact]
    public void RtspConnectionOptions_Creation_IsHighPerformance()
    {
        // Arrange
        var sw = new Stopwatch();

        // Act: 10000 回の不変レコード生成
        const int iterations = 10_000;
        sw.Start();
        for (int i = 0; i < iterations; i++)
        {
            _ = new RtspConnectionOptions(
                Url: "rtsp://192.168.1.100/stream",
                Username: "admin",
                Password: "pass",
                Transport: RtspTransport.Tcp,
                LowLatencyMode: true);
        }
        sw.Stop();

        // Assert: 10000 回の生成が 100ms 以内
        Assert.True(
            sw.ElapsedMilliseconds < UiResponseTimeoutMs,
            $"10000 回の RtspConnectionOptions 生成時間 {sw.ElapsedMilliseconds}ms が目標値 {UiResponseTimeoutMs}ms を超過しました");
    }

    // ─── ConnectionStats 更新の効率性 ────────────────────────────

    /// <summary>
    /// ConnectionStats の不変レコード置き換えが効率的（大量更新でもメモリ効率が良い）
    /// Requirements: 6.2（CPU 使用率目標）
    /// </summary>
    [Fact]
    public void ConnectionStats_FrequentUpdates_AreMemoryEfficient()
    {
        // Arrange
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        long memoryBefore = GC.GetTotalMemory(forceFullCollection: false);

        var sw = new Stopwatch();

        // Act: 高頻度での統計情報更新（1 秒間に ~30 回 → 5 秒で 150 回相当）
        const int updateCount = 150;
        sw.Start();
        for (int i = 0; i < updateCount; i++)
        {
            var stats = new ConnectionStats(
                FrameRate: 29.97,
                ReceivedFrames: i * 30L,
                Uptime: TimeSpan.FromSeconds(i / 30.0));

            _mockRtspService.Raise(
                s => s.StatsUpdated += null,
                (object?)null,
                stats);
        }
        sw.Stop();

        long memoryAfter = GC.GetTotalMemory(forceFullCollection: false);

        // Assert: 150 回の更新が 100ms 以内
        Assert.True(
            sw.ElapsedMilliseconds < UiResponseTimeoutMs,
            $"150 回の統計情報更新時間 {sw.ElapsedMilliseconds}ms が目標値 {UiResponseTimeoutMs}ms を超過しました");

        // 最後の統計情報が正しく反映されていること
        Assert.Equal(29.97, _viewModel.Stats.FrameRate, precision: 2);
    }
}
