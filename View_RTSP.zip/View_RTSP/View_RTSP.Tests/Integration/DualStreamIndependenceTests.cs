// デュアルストリーム独立動作の結合テスト
// タスク 10 に対応
// Requirements: 8.2, 8.3, 8.6, 8.7, 8.8

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.Integration;

/// <summary>
/// マルチストリーム独立動作の結合テスト。
/// <para>
/// 3 つの <see cref="StreamPaneViewModel"/> インスタンスが互いに影響を与えず、
/// それぞれ独立したサービスインスタンスで動作することを検証する。
/// </para>
/// Requirements: 8.2, 8.3, 8.6, 8.7, 8.8
/// </summary>
public class DualStreamIndependenceTests
{
    // ─── テスト用フィクスチャー ───────────────────────────────────

    private readonly Mock<IRtspStreamService> _mockRtspService1;
    private readonly Mock<IRtspStreamService> _mockRtspService2;
    private readonly Mock<IRtspStreamService> _mockRtspService3;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer1;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer2;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer3;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;

    private readonly StreamPaneViewModel _pane1;
    private readonly StreamPaneViewModel _pane2;
    private readonly StreamPaneViewModel _pane3;
    private readonly MainWindowViewModel _mainVm;

    public DualStreamIndependenceTests()
    {
        _mockRtspService1 = new Mock<IRtspStreamService>();
        _mockRtspService2 = new Mock<IRtspStreamService>();
        _mockRtspService3 = new Mock<IRtspStreamService>();
        _mockRenderer1 = new Mock<IVideoFrameRenderer>();
        _mockRenderer2 = new Mock<IVideoFrameRenderer>();
        _mockRenderer3 = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();

        _mockRtspService1.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockRtspService2.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockRtspService3.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);

        _pane1 = new StreamPaneViewModel(
            _mockRtspService1.Object,
            _mockRenderer1.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);

        _pane2 = new StreamPaneViewModel(
            _mockRtspService2.Object,
            _mockRenderer2.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);

        _pane3 = new StreamPaneViewModel(
            _mockRtspService3.Object,
            _mockRenderer3.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);

        _mainVm = new MainWindowViewModel(
            _pane1,
            _pane2,
            _pane3,
            _mockSettingsService.Object);
    }

    // ─── 独立したサービスインスタンスの確認 ──────────────────────

    /// <summary>
    /// 各ペインはそれぞれ異なる IRtspStreamService インスタンスを持つ
    /// Requirements: 8.3（全ストリームの独立受信・表示）
    /// </summary>
    [Fact]
    public void ThreePanes_HaveIndependentRtspServiceInstances()
    {
        // Assert: 同じ ViewModel インスタンスではないことを確認
        Assert.NotSame(_mainVm.Pane1, _mainVm.Pane2);
        Assert.NotSame(_mainVm.Pane2, _mainVm.Pane3);

        // 接続コマンドが独立したサービスを呼ぶことを確認するため、
        // 各ペインに別々の URL を設定して接続を試みる
        _mainVm.Pane1.RtspUrl = "rtsp://192.168.1.100/stream1";
        _mainVm.Pane2.RtspUrl = "rtsp://192.168.1.200/stream2";

        _mockRtspService1.Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);
        _mockRtspService2.Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act: Pane1 のみ接続
        _ = _mainVm.Pane1.ConnectAsync();

        // Assert: Service1 のみが呼ばれ、Service2 は呼ばれていない
        _mockRtspService1.Verify(
            s => s.ConnectAsync(It.Is<RtspConnectionOptions>(o => o.Url == "rtsp://192.168.1.100/stream1"), It.IsAny<CancellationToken>()),
            Times.Once);
        _mockRtspService2.Verify(
            s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    /// <summary>
    /// 各ペインはそれぞれ異なる IVideoFrameRenderer インスタンスを持つ
    /// Requirements: 8.3（独立したデコードスレッドで動作）
    /// </summary>
    [Fact]
    public void ThreePanes_HaveIndependentVideoFrameRenderers()
    {
        // Pane1 の Renderer からビットマップ更新イベントを発行しても Pane2 の VideoFrame は変化しない
        // （Pane2 は別の Renderer インスタンスをリスニングしているため）

        // Arrange
        System.Windows.Media.Imaging.WriteableBitmap? pane1VideoFrame = null;
        System.Windows.Media.Imaging.WriteableBitmap? pane2VideoFrame = null;
        Exception? threadException = null;

        var thread = new Thread(() =>
        {
            try
            {
                var bitmap = new System.Windows.Media.Imaging.WriteableBitmap(
                    640, 480, 96.0, 96.0,
                    System.Windows.Media.PixelFormats.Bgra32, null);

                // Pane1 の Renderer からビットマップ更新イベントを発行
                _mockRenderer1.Raise(
                    r => r.BitmapUpdated += null,
                    (object?)null,
                    bitmap);

                pane1VideoFrame = _pane1.VideoFrame;
                pane2VideoFrame = _pane2.VideoFrame;
            }
            catch (Exception ex)
            {
                threadException = ex;
            }
        });

        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        thread.Join();

        if (threadException != null)
            throw new Exception("STA スレッド内でエラーが発生しました", threadException);

        // Assert: Pane1 のみ VideoFrame が更新され、Pane2 は null のまま
        Assert.NotNull(pane1VideoFrame);
        Assert.Null(pane2VideoFrame);
    }

    // ─── 独立した接続・切断操作の確認 ────────────────────────────

    /// <summary>
    /// Pane1 を接続しても Pane2 の接続状態は変化しない
    /// Requirements: 8.7（各ペインの独立接続・切断操作）
    /// </summary>
    [Fact]
    public async Task ConnectPane1_DoesNotAffectPane2ConnectionState()
    {
        // Arrange
        _mainVm.Pane1.RtspUrl = "rtsp://192.168.1.100/stream1";

        _mockRtspService1.Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act: Pane1 のみ接続を開始
        await _mainVm.Pane1.ConnectAsync();

        // Assert: Pane2 の ConnectionState は Disconnected のまま
        Assert.Equal(ConnectionState.Disconnected, _mainVm.Pane2.ConnectionState);
    }

    /// <summary>
    /// Pane2 を接続しても Pane1 の接続状態は変化しない
    /// Requirements: 8.7（各ペインの独立接続・切断操作）
    /// </summary>
    [Fact]
    public async Task ConnectPane2_DoesNotAffectPane1ConnectionState()
    {
        // Arrange
        _mainVm.Pane2.RtspUrl = "rtsp://192.168.1.200/stream2";

        _mockRtspService2.Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act: Pane2 のみ接続を開始
        await _mainVm.Pane2.ConnectAsync();

        // Assert: Pane1 の ConnectionState は Disconnected のまま
        Assert.Equal(ConnectionState.Disconnected, _mainVm.Pane1.ConnectionState);
    }

    /// <summary>
    /// Pane1 を切断しても Pane2 のサービスには影響しない
    /// Requirements: 8.7（各ペインの独立接続・切断操作）
    /// </summary>
    [Fact]
    public void DisconnectPane1_DoesNotCallPane2Service()
    {
        // Act: Pane1 のみ切断
        _mainVm.Pane1.Disconnect();

        // Assert: Service1 の Disconnect が呼ばれ、Service2 は呼ばれていない
        _mockRtspService1.Verify(s => s.Disconnect(), Times.Once);
        _mockRtspService2.Verify(s => s.Disconnect(), Times.Never);
    }

    /// <summary>
    /// Pane2 を切断しても Pane1 のサービスには影響しない
    /// Requirements: 8.7（各ペインの独立接続・切断操作）
    /// </summary>
    [Fact]
    public void DisconnectPane2_DoesNotCallPane1Service()
    {
        // Act: Pane2 のみ切断
        _mainVm.Pane2.Disconnect();

        // Assert: Service2 の Disconnect が呼ばれ、Service1 は呼ばれていない
        _mockRtspService2.Verify(s => s.Disconnect(), Times.Once);
        _mockRtspService1.Verify(s => s.Disconnect(), Times.Never);
    }

    // ─── 片方切断時の独立エラー表示の確認 ────────────────────────

    /// <summary>
    /// Pane1 でストリームが切断されたとき、Pane2 の接続状態は維持される
    /// Requirements: 8.6（片方切断時の独立エラー表示）
    /// </summary>
    [Fact]
    public void Pane1StreamDisconnected_Pane2RemainsConnected()
    {
        // Arrange: Pane2 を Connected 状態にする
        _mockRtspService2.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        Assert.Equal(ConnectionState.Connected, _mainVm.Pane2.ConnectionState);

        // Act: Pane1 でストリームが切断される
        _mockRtspService1.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Disconnected));

        // Assert: Pane1 は Disconnected に遷移するが、Pane2 は Connected のまま
        Assert.Equal(ConnectionState.Disconnected, _mainVm.Pane1.ConnectionState);
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane2.ConnectionState);
    }

    /// <summary>
    /// Pane2 でストリームが切断されたとき、Pane1 の接続状態は維持される
    /// Requirements: 8.6（片方切断時の独立エラー表示）
    /// </summary>
    [Fact]
    public void Pane2StreamDisconnected_Pane1RemainsConnected()
    {
        // Arrange: Pane1 を Connected 状態にする
        _mockRtspService1.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        Assert.Equal(ConnectionState.Connected, _mainVm.Pane1.ConnectionState);

        // Act: Pane2 でストリームが切断される
        _mockRtspService2.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Disconnected));

        // Assert: Pane2 は Disconnected に遷移するが、Pane1 は Connected のまま
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane1.ConnectionState);
        Assert.Equal(ConnectionState.Disconnected, _mainVm.Pane2.ConnectionState);
    }

    /// <summary>
    /// Pane1 でエラーが発生したとき、Pane2 の ErrorMessage には影響しない
    /// Requirements: 8.6（片方切断時の独立エラー表示）
    /// </summary>
    [Fact]
    public void Pane1ErrorOccurred_Pane2ErrorMessageUnchanged()
    {
        // Act: Pane1 でエラーが発生する
        var error = new RtspError(RtspErrorKind.NetworkUnreachable, "ネットワーク不達", null);
        _mockRtspService1.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Error, error));

        // Assert: Pane1 にエラーメッセージが設定されるが、Pane2 は null のまま
        Assert.NotNull(_mainVm.Pane1.ErrorMessage);
        Assert.Null(_mainVm.Pane2.ErrorMessage);
    }

    /// <summary>
    /// Pane2 でエラーが発生したとき、Pane1 の ErrorMessage には影響しない
    /// Requirements: 8.6（片方切断時の独立エラー表示）
    /// </summary>
    [Fact]
    public void Pane2ErrorOccurred_Pane1ErrorMessageUnchanged()
    {
        // Act: Pane2 でエラーが発生する
        var error = new RtspError(RtspErrorKind.AuthenticationFailed, "認証失敗", null);
        _mockRtspService2.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Error, error));

        // Assert: Pane2 にエラーメッセージが設定されるが、Pane1 は null のまま
        Assert.NotNull(_mainVm.Pane2.ErrorMessage);
        Assert.Null(_mainVm.Pane1.ErrorMessage);
    }

    // ─── 個別ステータス表示の確認 ─────────────────────────────────

    /// <summary>
    /// 各ペインは独立したステータスメッセージを持つ
    /// Requirements: 8.8（各ペインの個別ステータス表示）
    /// </summary>
    [Fact]
    public void EachPane_HasIndependentStatusMessage()
    {
        // Arrange: 初期状態でどちらも "未接続"
        Assert.Equal("未接続", _mainVm.Pane1.StatusMessage);
        Assert.Equal("未接続", _mainVm.Pane2.StatusMessage);

        // Act: Pane1 のみ Connected 状態に遷移させる
        _mockRtspService1.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // Assert: Pane1 は "接続済み"、Pane2 は "未接続" のまま
        Assert.Equal("接続済み", _mainVm.Pane1.StatusMessage);
        Assert.Equal("未接続", _mainVm.Pane2.StatusMessage);
    }

    /// <summary>
    /// 各ペインは独立した統計情報を持つ
    /// Requirements: 8.8（各ペインの個別ステータス表示）
    /// </summary>
    [Fact]
    public void EachPane_HasIndependentConnectionStats()
    {
        // Arrange: Pane1 の統計情報を更新する
        var stats1 = new ConnectionStats(30.0, 1500, TimeSpan.FromMinutes(5));

        _mockRtspService1.Raise(
            s => s.StatsUpdated += null,
            (object?)null,
            stats1);

        // Assert: Pane1 の Stats が更新されたが、Pane2 の Stats は初期値のまま
        Assert.Equal(30.0, _mainVm.Pane1.Stats.FrameRate);
        Assert.Equal(1500, _mainVm.Pane1.Stats.ReceivedFrames);
        Assert.Equal(0.0, _mainVm.Pane2.Stats.FrameRate);
        Assert.Equal(0, _mainVm.Pane2.Stats.ReceivedFrames);
    }

    /// <summary>
    /// 各ペインは独立した URL を持つ
    /// Requirements: 8.2（各ペインの独立 URL・認証情報設定）
    /// </summary>
    [Fact]
    public void EachPane_HasIndependentRtspUrl()
    {
        // Arrange & Act: 各ペインに別々の URL を設定
        _mainVm.Pane1.RtspUrl = "rtsp://192.168.1.100/stream1";
        _mainVm.Pane2.RtspUrl = "rtsp://192.168.1.200/stream2";

        // Assert: 独立した URL が維持される
        Assert.Equal("rtsp://192.168.1.100/stream1", _mainVm.Pane1.RtspUrl);
        Assert.Equal("rtsp://192.168.1.200/stream2", _mainVm.Pane2.RtspUrl);
    }

    /// <summary>
    /// 各ペインは独立した認証情報を持つ
    /// Requirements: 8.2（各ペインの独立 URL・認証情報設定）
    /// </summary>
    [Fact]
    public void EachPane_HasIndependentCredentials()
    {
        // Arrange & Act: 各ペインに別々の認証情報を設定
        _mainVm.Pane1.Username = "admin1";
        _mainVm.Pane1.Password = "pass1";
        _mainVm.Pane2.Username = "admin2";
        _mainVm.Pane2.Password = "pass2";

        // Assert: 独立した認証情報が維持される
        Assert.Equal("admin1", _mainVm.Pane1.Username);
        Assert.Equal("pass1", _mainVm.Pane1.Password);
        Assert.Equal("admin2", _mainVm.Pane2.Username);
        Assert.Equal("pass2", _mainVm.Pane2.Password);
    }

    // ─── タブ切り替え時のストリーム継続確認 ─────────────────────

    /// <summary>
    /// タブ切り替えを行っても全ペインの接続状態は変化しない
    /// Requirements: 8.3（全ストリームの独立受信・表示）
    /// </summary>
    [Fact]
    public void SwitchTab_DoesNotAffectConnectionStates()
    {
        // Arrange: 両ペインを Connected 状態にする
        _mockRtspService1.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockRtspService2.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        Assert.Equal(ConnectionState.Connected, _mainVm.Pane1.ConnectionState);
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane2.ConnectionState);

        // Act: タブをカメラ1単独に切り替え
        _mainVm.SelectedTabIndex = 0;

        // Assert: タブが変更されたが、全ペインの接続状態は維持される
        Assert.Equal(0, _mainVm.SelectedTabIndex);
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane1.ConnectionState);
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane2.ConnectionState);
    }

    /// <summary>
    /// タブ切り替えを行っても全ペインのサービスに Disconnect が呼ばれない
    /// Requirements: 8.3（全ストリームの独立受信・表示）
    /// </summary>
    [Fact]
    public void SwitchTab_DoesNotCallDisconnectOnAnyService()
    {
        // Act: タブを切り替え
        _mainVm.SelectedTabIndex = 1;

        // Assert: どのサービスの Disconnect も呼ばれていない
        _mockRtspService1.Verify(s => s.Disconnect(), Times.Never);
        _mockRtspService2.Verify(s => s.Disconnect(), Times.Never);
        _mockRtspService3.Verify(s => s.Disconnect(), Times.Never);
    }

    /// <summary>
    /// タブを複数回切り替えても全ペインの接続状態は変化しない
    /// Requirements: 8.3（全ストリームの独立受信・表示）
    /// </summary>
    [Fact]
    public void MultipleTabSwitches_DoNotAffectStreamStates()
    {
        // Arrange: 両ペインを Connected 状態にする
        _mockRtspService1.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockRtspService2.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // Act: タブを複数回切り替え
        _mainVm.SelectedTabIndex = 0;
        _mainVm.SelectedTabIndex = 1;
        _mainVm.SelectedTabIndex = 2;
        _mainVm.SelectedTabIndex = 3;

        // Assert: 最終的に全カメラタブに戻り、全ペインの接続状態は維持される
        Assert.Equal(3, _mainVm.SelectedTabIndex);
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane1.ConnectionState);
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane2.ConnectionState);
    }

    /// <summary>
    /// タブ切り替えを行っても各ペインのステータスメッセージは変化しない
    /// Requirements: 8.8（各ペインの個別ステータス表示）
    /// </summary>
    [Fact]
    public void SwitchTab_DoesNotAffectStatusMessages()
    {
        // Arrange: Pane1 のみ Connected 状態にする
        _mockRtspService1.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        var pane1StatusBefore = _mainVm.Pane1.StatusMessage;
        var pane2StatusBefore = _mainVm.Pane2.StatusMessage;

        // Act: タブを切り替え
        _mainVm.SelectedTabIndex = 0;

        // Assert: ステータスメッセージは変化しない
        Assert.Equal(pane1StatusBefore, _mainVm.Pane1.StatusMessage);
        Assert.Equal(pane2StatusBefore, _mainVm.Pane2.StatusMessage);
    }

    // ─── 全ペインの同時接続シナリオ ──────────────────────────────

    /// <summary>
    /// 全ペインが同時に接続状態になれる（マルチストリーム同時受信）
    /// Requirements: 8.3（全ストリームの独立受信・表示）
    /// </summary>
    [Fact]
    public void AllPanes_CanBeConnectedSimultaneously()
    {
        // Act: 全ペインを Connected 状態にする
        _mockRtspService1.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockRtspService2.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockRtspService3.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // Assert: 全ペインが同時に Connected 状態
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane1.ConnectionState);
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane2.ConnectionState);
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane3.ConnectionState);
    }

    /// <summary>
    /// 全ペインが異なる接続状態を同時に持てる
    /// Requirements: 8.7（各ペインの独立接続・切断操作）
    /// </summary>
    [Fact]
    public void AllPanes_CanHaveDifferentConnectionStatesConcurrently()
    {
        // Arrange & Act: 各ペインを異なる状態にする
        _mockRtspService1.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockRtspService2.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connecting));

        // Pane3 は Disconnected のまま

        // Assert: 各ペインが独立した接続状態を保持
        Assert.Equal(ConnectionState.Connected, _mainVm.Pane1.ConnectionState);
        Assert.Equal(ConnectionState.Connecting, _mainVm.Pane2.ConnectionState);
        Assert.Equal(ConnectionState.Disconnected, _mainVm.Pane3.ConnectionState);
    }

    /// <summary>
    /// 全ペインの統計情報を同時に独立して更新できる
    /// Requirements: 8.8（各ペインの個別ステータス表示）
    /// </summary>
    [Fact]
    public void AllPanes_CanUpdateStatisticsIndependently()
    {
        // Arrange
        var stats1 = new ConnectionStats(30.0, 1500, TimeSpan.FromMinutes(5));
        var stats2 = new ConnectionStats(25.0, 1200, TimeSpan.FromMinutes(3));

        // Act: 各ペインの統計情報を独立して更新
        _mockRtspService1.Raise(
            s => s.StatsUpdated += null,
            (object?)null,
            stats1);

        _mockRtspService2.Raise(
            s => s.StatsUpdated += null,
            (object?)null,
            stats2);

        // Assert: 各ペインが独立した統計情報を保持
        Assert.Equal(30.0, _mainVm.Pane1.Stats.FrameRate);
        Assert.Equal(1500, _mainVm.Pane1.Stats.ReceivedFrames);
        Assert.Equal(25.0, _mainVm.Pane2.Stats.FrameRate);
        Assert.Equal(1200, _mainVm.Pane2.Stats.ReceivedFrames);
    }

    // ─── Pane オブジェクト同一性の確認 ───────────────────────────

    /// <summary>
    /// MainWindowViewModel が所有する Pane1, Pane2, Pane3 はそれぞれ異なるインスタンス
    /// </summary>
    [Fact]
    public void MainWindowViewModel_AllPanes_AreDifferentInstances()
    {
        // Assert
        Assert.NotSame(_mainVm.Pane1, _mainVm.Pane2);
        Assert.NotSame(_mainVm.Pane2, _mainVm.Pane3);
        Assert.NotSame(_mainVm.Pane1, _mainVm.Pane3);
    }

    /// <summary>
    /// Pane1 への URL 変更は Pane2 の URL に影響しない
    /// Requirements: 8.2（各ペインの独立 URL・認証情報設定）
    /// </summary>
    [Fact]
    public void ChangingPane1Url_DoesNotChangePane2Url()
    {
        // Arrange: 初期 URL を設定
        _mainVm.Pane2.RtspUrl = "rtsp://192.168.1.200/stream2";

        // Act: Pane1 の URL を変更
        _mainVm.Pane1.RtspUrl = "rtsp://10.0.0.1/camera1";

        // Assert: Pane2 の URL は変化していない
        Assert.Equal("rtsp://192.168.1.200/stream2", _mainVm.Pane2.RtspUrl);
        Assert.Equal("rtsp://10.0.0.1/camera1", _mainVm.Pane1.RtspUrl);
    }
}
