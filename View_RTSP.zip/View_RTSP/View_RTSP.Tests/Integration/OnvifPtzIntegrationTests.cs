// ONVIF PTZ 統合テスト
// タスク 12.2 に対応
// Requirements: 7.1, 7.3, 7.4, 7.7, 7.8

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.Integration;

/// <summary>
/// ONVIF PTZ 統合テスト。
/// <para>
/// 実 ONVIF カメラはテスト環境で利用できないため、<see cref="IOnvifPtzService"/> および
/// <see cref="IRtspStreamService"/> をモック化して以下を検証する:
/// - ONVIF 接続・PTZ 対応能力確認
/// - ContinuousMove / Stop / Zoom コマンドの送信
/// - PTZ コマンド失敗時の RTSP ストリーム継続
/// </para>
/// Requirements: 7.1, 7.3, 7.4, 7.7, 7.8
/// </summary>
public class OnvifPtzIntegrationTests
{
    // ─── テスト用フィクスチャー ───────────────────────────────────

    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly StreamPaneViewModel _viewModel;

    // テスト用 ONVIF 接続オプション
    private static readonly OnvifConnectionOptions ValidOnvifOptions = new(
        EndpointUrl: "http://192.168.1.100/onvif/device_service",
        Username: "admin",
        Password: "password",
        ProfileToken: "Profile_1"
    );

    public OnvifPtzIntegrationTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);

        _viewModel = new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);
    }

    // ─── ONVIF 接続・PTZ 対応能力確認 ─────────────────────────

    /// <summary>
    /// PTZ 対応カメラへ接続すると IsPtzEnabled が true になる
    /// Requirements: 7.1（ONVIF 接続と PTZ 対応能力確認）
    /// </summary>
    [Fact]
    public async Task ConnectOnvif_WhenCameraSupportsPtz_SetsPtzEnabledTrue()
    {
        // Arrange: PTZ 対応カメラのモック設定
        _mockOnvifService
            .Setup(s => s.GetPtzCapabilitiesAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        _viewModel.OnvifEndpointUrl = ValidOnvifOptions.EndpointUrl;
        _viewModel.OnvifUsername = ValidOnvifOptions.Username;
        _viewModel.OnvifPassword = ValidOnvifOptions.Password;

        // Act: PTZ 対応能力確認（ONVIF 接続設定後に能力チェック）
        await _viewModel.CheckPtzCapabilitiesAsync();

        // Assert: PTZ が有効化されること
        Assert.True(_viewModel.IsPtzEnabled);
    }

    /// <summary>
    /// PTZ 非対応カメラへ接続すると IsPtzEnabled が false のまま
    /// Requirements: 7.1（非対応カメラの場合は PTZ 無効）
    /// </summary>
    [Fact]
    public async Task ConnectOnvif_WhenCameraDoesNotSupportPtz_KeepsPtzEnabledFalse()
    {
        // Arrange: PTZ 非対応カメラのモック設定
        _mockOnvifService
            .Setup(s => s.GetPtzCapabilitiesAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);

        _viewModel.OnvifEndpointUrl = ValidOnvifOptions.EndpointUrl;
        _viewModel.OnvifUsername = ValidOnvifOptions.Username;
        _viewModel.OnvifPassword = ValidOnvifOptions.Password;

        // Act
        await _viewModel.CheckPtzCapabilitiesAsync();

        // Assert: PTZ が無効のまま
        Assert.False(_viewModel.IsPtzEnabled);
    }

    /// <summary>
    /// ONVIF 接続失敗時、IsPtzEnabled は false のまま（例外が伝播しない）
    /// Requirements: 7.1（接続失敗時は false）
    /// </summary>
    [Fact]
    public async Task ConnectOnvif_WhenConnectionFails_DoesNotThrowAndKeepsPtzDisabled()
    {
        // Arrange: 接続失敗のモック設定
        _mockOnvifService
            .Setup(s => s.GetPtzCapabilitiesAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);

        _viewModel.OnvifEndpointUrl = "http://invalid-host/onvif";
        _viewModel.OnvifUsername = "admin";
        _viewModel.OnvifPassword = "pass";

        // Act & Assert: 例外が発生しないこと
        await _viewModel.CheckPtzCapabilitiesAsync();
        Assert.False(_viewModel.IsPtzEnabled);
    }

    // ─── ContinuousMove コマンド送信テスト ──────────────────────

    /// <summary>
    /// StartMoveCommand 実行時、StartMoveAsync が呼ばれる（ContinuousMove 送信）
    /// Requirements: 7.3（ContinuousMove コマンド）, 7.7（WS-Security 認証付き）
    /// </summary>
    [Fact]
    public async Task StartMoveCommand_WhenPtzEnabled_CallsStartMoveAsync()
    {
        // Arrange: PTZ 有効状態にする
        SetupPtzEnabled();

        _mockOnvifService
            .Setup(s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<PtzDirection>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act: 上方向への移動コマンド
        await _viewModel.StartMoveAsync(PtzDirection.Up);

        // Assert: StartMoveAsync が呼ばれること
        _mockOnvifService.Verify(
            s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.Is<PtzDirection>(d => d == PtzDirection.Up),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// すべての 8 方向で StartMoveAsync が対応する方向で呼ばれる
    /// Requirements: 7.3（8 方向制御）
    /// </summary>
    [Theory]
    [InlineData(PtzDirection.Up)]
    [InlineData(PtzDirection.Down)]
    [InlineData(PtzDirection.Left)]
    [InlineData(PtzDirection.Right)]
    [InlineData(PtzDirection.UpLeft)]
    [InlineData(PtzDirection.UpRight)]
    [InlineData(PtzDirection.DownLeft)]
    [InlineData(PtzDirection.DownRight)]
    public async Task StartMoveAsync_ForEachDirection_SendsCorrectDirectionCommand(PtzDirection direction)
    {
        // Arrange
        SetupPtzEnabled();

        _mockOnvifService
            .Setup(s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<PtzDirection>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await _viewModel.StartMoveAsync(direction);

        // Assert: 正しい方向でコマンドが送信されること
        _mockOnvifService.Verify(
            s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.Is<PtzDirection>(d => d == direction),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    // ─── Stop コマンド送信テスト ──────────────────────────────

    /// <summary>
    /// StopMoveCommand 実行時、StopMoveAsync が呼ばれる
    /// Requirements: 7.3（Stop コマンド）
    /// </summary>
    [Fact]
    public async Task StopMoveCommand_WhenPtzEnabled_CallsStopMoveAsync()
    {
        // Arrange
        SetupPtzEnabled();

        _mockOnvifService
            .Setup(s => s.StopMoveAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await _viewModel.StopMoveAsync();

        // Assert
        _mockOnvifService.Verify(
            s => s.StopMoveAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    // ─── Zoom コマンド送信テスト ─────────────────────────────

    /// <summary>
    /// ZoomCommand に正のズーム速度を渡すと、ズームイン コマンドが送信される
    /// Requirements: 7.4（ズームイン/アウト）
    /// </summary>
    [Fact]
    public async Task ZoomCommand_WithPositiveSpeed_SendsZoomInCommand()
    {
        // Arrange
        SetupPtzEnabled();

        float capturedZoomSpeed = 0f;
        _mockOnvifService
            .Setup(s => s.ZoomAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Callback<OnvifConnectionOptions, float, CancellationToken>(
                (opts, speed, ct) => { capturedZoomSpeed = speed; })
            .Returns(Task.CompletedTask);

        // Act: ズームイン
        await _viewModel.ZoomAsync(0.8f);

        // Assert: 正の速度でコマンドが送信されること
        Assert.True(capturedZoomSpeed > 0);
    }

    /// <summary>
    /// ZoomCommand に負のズーム速度を渡すと、ズームアウト コマンドが送信される
    /// Requirements: 7.4（ズームアウト）
    /// </summary>
    [Fact]
    public async Task ZoomCommand_WithNegativeSpeed_SendsZoomOutCommand()
    {
        // Arrange
        SetupPtzEnabled();

        float capturedZoomSpeed = 0f;
        _mockOnvifService
            .Setup(s => s.ZoomAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Callback<OnvifConnectionOptions, float, CancellationToken>(
                (opts, speed, ct) => { capturedZoomSpeed = speed; })
            .Returns(Task.CompletedTask);

        // Act: ズームアウト
        await _viewModel.ZoomAsync(-0.8f);

        // Assert: 負の速度でコマンドが送信されること
        Assert.True(capturedZoomSpeed < 0);
    }

    // ─── PTZ コマンド失敗時の RTSP 継続テスト ────────────────

    /// <summary>
    /// StartMoveAsync が失敗しても RTSP ストリームの接続状態は維持される
    /// Requirements: 7.8（PTZ コマンド失敗時の RTSP 継続）
    /// </summary>
    [Fact]
    public async Task StartMoveAsync_WhenCommandFails_RtspStreamStateIsUnchanged()
    {
        // Arrange: PTZ コマンドを失敗させる
        SetupPtzEnabled();
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockOnvifService
            .Setup(s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<PtzDirection>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("PTZ コマンド失敗"));

        // Act: PTZ コマンドを実行（失敗する）
        await _viewModel.StartMoveAsync(PtzDirection.Up);

        // Assert: RTSP 接続状態が維持されること（Disconnect は呼ばれていない）
        _mockRtspService.Verify(s => s.Disconnect(), Times.Never);
        // ViewModel の ConnectionState は Connected のまま
        Assert.Equal(ConnectionState.Connected, _viewModel.ConnectionState);
    }

    /// <summary>
    /// StopMoveAsync が失敗しても RTSP ストリームの接続状態は維持される
    /// Requirements: 7.8（PTZ コマンド失敗時の RTSP 継続）
    /// </summary>
    [Fact]
    public async Task StopMoveAsync_WhenCommandFails_RtspStreamStateIsUnchanged()
    {
        // Arrange: RTSP を Connected にして PTZ を失敗させる
        SetupPtzEnabled();
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockOnvifService
            .Setup(s => s.StopMoveAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("Stop コマンド失敗"));

        // Act
        await _viewModel.StopMoveAsync();

        // Assert: Disconnect が呼ばれていないこと
        _mockRtspService.Verify(s => s.Disconnect(), Times.Never);
        Assert.Equal(ConnectionState.Connected, _viewModel.ConnectionState);
    }

    /// <summary>
    /// ZoomAsync が失敗しても RTSP ストリームの接続状態は維持される
    /// Requirements: 7.8（PTZ コマンド失敗時の RTSP 継続）
    /// </summary>
    [Fact]
    public async Task ZoomAsync_WhenCommandFails_RtspStreamStateIsUnchanged()
    {
        // Arrange
        SetupPtzEnabled();
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockOnvifService
            .Setup(s => s.ZoomAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("Zoom コマンド失敗"));

        // Act
        await _viewModel.ZoomAsync(0.5f);

        // Assert: Disconnect が呼ばれていないこと
        _mockRtspService.Verify(s => s.Disconnect(), Times.Never);
        Assert.Equal(ConnectionState.Connected, _viewModel.ConnectionState);
    }

    /// <summary>
    /// PTZ コマンド失敗時にエラーメッセージが設定される（RTSP は継続）
    /// Requirements: 7.8（PTZ コマンド失敗の通知）
    /// </summary>
    [Fact]
    public async Task StartMoveAsync_WhenCommandFails_SetsErrorMessageWithoutDisconnectingRtsp()
    {
        // Arrange
        SetupPtzEnabled();
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockOnvifService
            .Setup(s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<PtzDirection>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new InvalidOperationException("PTZ サービス接続失敗"));

        // Act
        await _viewModel.StartMoveAsync(PtzDirection.Left);

        // Assert: RTSP は継続し、エラー情報が設定される（またはエラーなしで静かに失敗）
        // 重要: RTSP サービスの Disconnect が呼ばれていないこと
        _mockRtspService.Verify(s => s.Disconnect(), Times.Never);
        Assert.Equal(ConnectionState.Connected, _viewModel.ConnectionState);
    }

    // ─── WS-Security 認証情報の受け渡しテスト ──────────────────

    /// <summary>
    /// StartMoveAsync 呼び出し時、設定済みの ONVIF 認証情報がオプションに含まれる
    /// Requirements: 7.7（WS-Security UsernameToken 認証）
    /// </summary>
    [Fact]
    public async Task StartMoveAsync_WithCredentials_PassesCredentialsInOptions()
    {
        // Arrange
        SetupPtzEnabled();

        OnvifConnectionOptions? capturedOptions = null;
        _mockOnvifService
            .Setup(s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<PtzDirection>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Callback<OnvifConnectionOptions, PtzDirection, float, CancellationToken>(
                (opts, dir, speed, ct) => { capturedOptions = opts; })
            .Returns(Task.CompletedTask);

        // Act
        await _viewModel.StartMoveAsync(PtzDirection.Right);

        // Assert: 認証情報が含まれること
        Assert.NotNull(capturedOptions);
        Assert.NotEmpty(capturedOptions!.Value.Username);
        Assert.NotEmpty(capturedOptions!.Value.Password);
    }

    // ─── ヘルパーメソッド ─────────────────────────────────────

    /// <summary>
    /// テスト用に PTZ 有効状態を設定する
    /// </summary>
    private void SetupPtzEnabled()
    {
        _viewModel.OnvifEndpointUrl = ValidOnvifOptions.EndpointUrl;
        _viewModel.OnvifUsername = ValidOnvifOptions.Username;
        _viewModel.OnvifPassword = ValidOnvifOptions.Password;
        _viewModel.IsPtzEnabled = true;
    }
}
