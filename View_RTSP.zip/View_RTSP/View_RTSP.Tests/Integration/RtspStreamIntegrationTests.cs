// RTSP ストリーム接続・デコードの統合テスト
// タスク 12.1 に対応
// Requirements: 1.3, 1.5, 3.1, 5.2, 5.3, 9.1, 9.2, 9.8

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.Integration;

/// <summary>
/// RTSP ストリーム接続・デコードの統合テスト。
/// <para>
/// 実 RTSP サーバーはテスト環境で利用できないため、<see cref="IRtspStreamService"/> をモック化して
/// 各シナリオ（接続成功・タイムアウト・認証失敗・自動再試行）を検証する。
/// ViewModel 層を経由することで、サービス→VM 間の状態連携も併せて確認する。
/// </para>
/// Requirements: 1.3, 1.5, 3.1, 5.2, 5.3, 9.1, 9.2, 9.8
/// </summary>
public class RtspStreamIntegrationTests
{
    // ─── テスト用フィクスチャー ───────────────────────────────────

    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly StreamPaneViewModel _viewModel;

    public RtspStreamIntegrationTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);

        _viewModel = new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);
    }

    // ─── TCP トランスポートでの接続シナリオ ──────────────────────

    /// <summary>
    /// TCP トランスポートで ConnectAsync を呼ぶと、ConnectAsync にオプションが渡される
    /// Requirements: 1.3（RTSP 接続確立）, 9.3（TCP トランスポート）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithTcpTransport_CallsServiceWithTcpOption()
    {
        // Arrange
        _viewModel.RtspUrl = "rtsp://192.168.1.100/stream";
        _viewModel.Transport = RtspTransport.Tcp;

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await _viewModel.ConnectAsync();

        // Assert: TCP トランスポートでサービスが呼ばれること
        _mockRtspService.Verify(
            s => s.ConnectAsync(
                It.Is<RtspConnectionOptions>(o =>
                    o.Url == "rtsp://192.168.1.100/stream" &&
                    o.Transport == RtspTransport.Tcp),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// UDP トランスポートで ConnectAsync を呼ぶと、ConnectAsync に UDP オプションが渡される
    /// Requirements: 1.3（RTSP 接続確立）, 9.3（UDP トランスポート切り替え）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithUdpTransport_CallsServiceWithUdpOption()
    {
        // Arrange
        _viewModel.RtspUrl = "rtsp://192.168.1.100/stream";
        _viewModel.Transport = RtspTransport.Udp;

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await _viewModel.ConnectAsync();

        // Assert: UDP トランスポートでサービスが呼ばれること
        _mockRtspService.Verify(
            s => s.ConnectAsync(
                It.Is<RtspConnectionOptions>(o =>
                    o.Transport == RtspTransport.Udp),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    // ─── 認証情報の受け渡し ──────────────────────────────────────

    /// <summary>
    /// 認証情報が設定されている場合、ConnectAsync に認証情報が渡される
    /// Requirements: 5.2（認証情報の送信）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithCredentials_PassesCredentialsToService()
    {
        // Arrange
        _viewModel.RtspUrl = "rtsp://192.168.1.100/stream";
        _viewModel.Username = "admin";
        _viewModel.Password = "secret";

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await _viewModel.ConnectAsync();

        // Assert: 認証情報がオプションに含まれること
        _mockRtspService.Verify(
            s => s.ConnectAsync(
                It.Is<RtspConnectionOptions>(o =>
                    o.Username == "admin" &&
                    o.Password == "secret"),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// 認証情報なしで ConnectAsync を呼ぶと、null 認証情報でサービスが呼ばれる
    /// Requirements: 5.5（認証なし接続サポート）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithoutCredentials_PassesNullCredentials()
    {
        // Arrange: ユーザー名・パスワードは空文字（未設定）
        _viewModel.RtspUrl = "rtsp://192.168.1.100/stream";
        _viewModel.Username = string.Empty;
        _viewModel.Password = string.Empty;

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await _viewModel.ConnectAsync();

        // Assert: 空文字または null の認証情報でサービスが呼ばれること
        _mockRtspService.Verify(
            s => s.ConnectAsync(
                It.Is<RtspConnectionOptions>(o =>
                    (o.Username == null || o.Username == string.Empty) &&
                    (o.Password == null || o.Password == string.Empty)),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    // ─── 接続成功シナリオ ─────────────────────────────────────────

    /// <summary>
    /// Connected 状態が通知されると ViewModel の ConnectionState が Connected になる
    /// Requirements: 1.3（接続成功後の状態変化通知）
    /// </summary>
    [Fact]
    public void StateChanged_WhenConnected_UpdatesViewModelToConnected()
    {
        // Act: Connected 状態変化イベントを発行
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // Assert
        Assert.Equal(ConnectionState.Connected, _viewModel.ConnectionState);
    }

    /// <summary>
    /// Connected 状態になるとステータスメッセージが更新される
    /// Requirements: 1.3（接続成功の通知）
    /// </summary>
    [Fact]
    public void StateChanged_WhenConnected_UpdatesStatusMessage()
    {
        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // Assert: ステータスメッセージが「未接続」以外になること
        Assert.NotEqual("未接続", _viewModel.StatusMessage);
    }

    // ─── 接続失敗シナリオ ─────────────────────────────────────────

    /// <summary>
    /// 接続タイムアウトが発生すると Error 状態に遷移し、エラー種別が通知される
    /// Requirements: 1.5（接続失敗時のエラー種別通知）, 5.3（タイムアウトエラー）
    /// </summary>
    [Fact]
    public void StateChanged_WhenConnectionTimeout_TransitionsToErrorWithCorrectKind()
    {
        // Arrange
        var error = new RtspError(RtspErrorKind.ConnectionTimeout, "接続タイムアウト", null);

        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Error, error));

        // Assert: Error 状態に遷移し、エラーメッセージが設定されること
        Assert.Equal(ConnectionState.Error, _viewModel.ConnectionState);
        Assert.NotNull(_viewModel.ErrorMessage);
    }

    /// <summary>
    /// 認証失敗が発生すると Error 状態に遷移し、認証失敗エラーが通知される
    /// Requirements: 1.5（接続失敗時のエラー種別通知）, 5.3（認証失敗エラーメッセージ）
    /// </summary>
    [Fact]
    public void StateChanged_WhenAuthenticationFailed_TransitionsToErrorWithAuthMessage()
    {
        // Arrange
        var error = new RtspError(RtspErrorKind.AuthenticationFailed, "認証に失敗しました", null);

        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Error, error));

        // Assert: Error 状態に遷移し、認証エラーメッセージが設定されること
        Assert.Equal(ConnectionState.Error, _viewModel.ConnectionState);
        Assert.NotNull(_viewModel.ErrorMessage);
        // エラーメッセージにエラー内容が反映されること
        Assert.NotEmpty(_viewModel.ErrorMessage!);
    }

    /// <summary>
    /// ネットワーク不達エラーが発生すると Error 状態に遷移する
    /// Requirements: 1.5（接続失敗時のエラー種別通知）
    /// </summary>
    [Fact]
    public void StateChanged_WhenNetworkUnreachable_TransitionsToError()
    {
        // Arrange
        var error = new RtspError(RtspErrorKind.NetworkUnreachable, "ネットワーク不達", -111);

        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Error, error));

        // Assert
        Assert.Equal(ConnectionState.Error, _viewModel.ConnectionState);
        Assert.NotNull(_viewModel.ErrorMessage);
    }

    /// <summary>
    /// デコードエラーが発生すると Error 状態に遷移する
    /// Requirements: 1.5（デコードエラー通知）
    /// </summary>
    [Fact]
    public void StateChanged_WhenDecodeError_TransitionsToError()
    {
        // Arrange
        var error = new RtspError(RtspErrorKind.DecodeError, "デコードエラーが発生しました", -1094995529);

        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Error, error));

        // Assert
        Assert.Equal(ConnectionState.Error, _viewModel.ConnectionState);
    }

    // ─── 自動再試行シナリオ ──────────────────────────────────────

    /// <summary>
    /// Connecting 状態のイベントが届くと ViewModel が Connecting 状態になる
    /// Requirements: 9.8（自動再試行中の状態通知）
    /// </summary>
    [Fact]
    public void StateChanged_WhenConnecting_UpdatesViewModelToConnecting()
    {
        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connecting));

        // Assert
        Assert.Equal(ConnectionState.Connecting, _viewModel.ConnectionState);
    }

    /// <summary>
    /// 再試行上限到達後に Disconnected 状態に遷移することを確認する
    /// Requirements: 3.1（最大試行回数後の切断状態遷移）, 9.8（再試行上限後の通知）
    /// </summary>
    [Fact]
    public void StateChanged_AfterMaxRetryReached_TransitionsToDisconnected()
    {
        // Arrange: 複数回 Connecting を経た後に Error → Disconnected に遷移するシナリオ
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connecting));
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connecting));
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connecting));

        // 最後にエラーで切断状態へ
        var error = new RtspError(RtspErrorKind.NetworkUnreachable, "再試行上限到達", null);
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Error, error));

        // Assert: 最終的に Error 状態になること（切断状態遷移は実装依存）
        Assert.Equal(ConnectionState.Error, _viewModel.ConnectionState);
        Assert.NotNull(_viewModel.ErrorMessage);
    }

    /// <summary>
    /// 接続後に切断すると Disconnected 状態に遷移する
    /// Requirements: 3.1（予期せぬ切断後の状態遷移）
    /// </summary>
    [Fact]
    public void StateChanged_AfterConnectedThenDisconnected_TransitionsToDisconnected()
    {
        // Arrange: 一旦接続状態にする
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        Assert.Equal(ConnectionState.Connected, _viewModel.ConnectionState);

        // Act: 切断状態に遷移
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Disconnected));

        // Assert
        Assert.Equal(ConnectionState.Disconnected, _viewModel.ConnectionState);
    }

    // ─── 再試行ロジックの検証（モック経由） ─────────────────────

    /// <summary>
    /// Connecting イベントが連続して届いても ViewModel は Connecting 状態を維持する
    /// Requirements: 9.8（自動再試行の状態通知）
    /// </summary>
    [Fact]
    public void StateChanged_MultipleConnectingEvents_ViewModelRemainsConnecting()
    {
        // Act: 3 回の Connecting イベント（3 回の再試行に対応）
        for (int i = 0; i < 3; i++)
        {
            _mockRtspService.Raise(
                s => s.StateChanged += null,
                new StreamStateChangedEventArgs(ConnectionState.Connecting));
        }

        // Assert: Connecting 状態が維持されること
        Assert.Equal(ConnectionState.Connecting, _viewModel.ConnectionState);
    }

    /// <summary>
    /// 接続オプションの RtspTransport を切り替えて再接続すると、新しいトランスポートが使用される
    /// Requirements: 1.3（TCP/UDP トランスポート切り替え）, 9.3
    /// </summary>
    [Fact]
    public async Task ConnectAsync_AfterTransportChange_UsesNewTransport()
    {
        // Arrange: 最初に TCP で接続
        _viewModel.RtspUrl = "rtsp://192.168.1.100/stream";
        _viewModel.Transport = RtspTransport.Tcp;

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        await _viewModel.ConnectAsync();

        // Act: UDP に変更して再接続
        _viewModel.Transport = RtspTransport.Udp;
        await _viewModel.ConnectAsync();

        // Assert: 2 回目の呼び出しが UDP で行われること
        _mockRtspService.Verify(
            s => s.ConnectAsync(
                It.Is<RtspConnectionOptions>(o => o.Transport == RtspTransport.Udp),
                It.IsAny<CancellationToken>()),
            Times.AtLeastOnce);
    }

    // ─── 統計情報の更新 ──────────────────────────────────────────

    /// <summary>
    /// 統計情報更新イベントが届くと ViewModel の Stats プロパティが更新される
    /// Requirements: 9.2（フレーム受信統計情報の更新）
    /// </summary>
    [Fact]
    public void StatsUpdated_WhenEventFired_UpdatesViewModelStats()
    {
        // Arrange
        var stats = new ConnectionStats(29.97, 1500, TimeSpan.FromSeconds(50));

        // Act
        _mockRtspService.Raise(
            s => s.StatsUpdated += null,
            (object?)null,
            stats);

        // Assert
        Assert.Equal(29.97, _viewModel.Stats.FrameRate, precision: 2);
        Assert.Equal(1500L, _viewModel.Stats.ReceivedFrames);
    }

    // ─── URL バリデーションと接続拒否 ───────────────────────────

    /// <summary>
    /// 不正な URL で ConnectAsync を呼ぶと、サービスの ConnectAsync は呼ばれない
    /// Requirements: 1.5（URL バリデーション後のエラー通知）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithInvalidUrl_DoesNotCallService()
    {
        // Arrange: rtsp:// スキームなしの URL
        _viewModel.RtspUrl = "http://192.168.1.100/stream";

        // Act
        await _viewModel.ConnectAsync();

        // Assert: サービスが呼ばれないこと
        _mockRtspService.Verify(
            s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    /// <summary>
    /// 空文字 URL で ConnectAsync を呼ぶと、サービスの ConnectAsync は呼ばれない
    /// Requirements: 1.5（URL バリデーション）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithEmptyUrl_DoesNotCallService()
    {
        // Arrange
        _viewModel.RtspUrl = string.Empty;

        // Act
        await _viewModel.ConnectAsync();

        // Assert
        _mockRtspService.Verify(
            s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    // ─── RtspConnectionOptions の設定確認 ─────────────────────

    /// <summary>
    /// TCP と UDP それぞれのトランスポートで RtspConnectionOptions を正しく構築できる
    /// Requirements: 9.3（トランスポート選択）
    /// </summary>
    [Theory]
    [InlineData(RtspTransport.Tcp)]
    [InlineData(RtspTransport.Udp)]
    public async Task ConnectAsync_WithTransport_PassesCorrectTransportToService(RtspTransport transport)
    {
        // Arrange
        _viewModel.RtspUrl = "rtsp://192.168.1.100/stream";
        _viewModel.Transport = transport;

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await _viewModel.ConnectAsync();

        // Assert
        _mockRtspService.Verify(
            s => s.ConnectAsync(
                It.Is<RtspConnectionOptions>(o => o.Transport == transport),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
