// DI 構成と録画保存先設定の永続化テスト
// タスク 6.1, 6.2 に対応
// Requirements: 1.5, 4.3, 4.4

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.Integration;

/// <summary>
/// App.OnStartup の DI 組み立てに相当するロジックのテスト。
/// 実際の App クラスは WPF ランタイムに依存するため、
/// 組み立てロジックを検証可能な形でテストする。
/// </summary>
public class DiCompositionTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService1 = new();
    private readonly Mock<IRtspStreamService> _mockRtspService2 = new();
    private readonly Mock<IRtspStreamService> _mockRtspService3 = new();
    private readonly Mock<IVideoFrameRenderer> _mockRenderer1 = new();
    private readonly Mock<IVideoFrameRenderer> _mockRenderer2 = new();
    private readonly Mock<IVideoFrameRenderer> _mockRenderer3 = new();
    private readonly Mock<IOnvifPtzService> _mockOnvifService = new();
    private readonly Mock<ISettingsService> _mockSettingsService = new();

    public DiCompositionTests()
    {
        _mockRtspService1.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockRtspService2.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockRtspService3.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
    }

    // ─── Task 6.1: RecordingService DI テスト ──────────────────────

    /// <summary>
    /// ペインごとに独立した RecordingService インスタンスが生成される。
    /// Requirements: 1.5（ペインごとに独立した録画制御）
    /// </summary>
    [Fact]
    public void EachPane_GetsIndependentRecordingServiceInstance()
    {
        // Arrange: ペインごとに独立した RecordingService を生成
        var recordingService1 = new RecordingService();
        var recordingService2 = new RecordingService();
        var recordingService3 = new RecordingService();

        // Act & Assert: 別のインスタンスであること
        Assert.NotSame(recordingService1, recordingService2);
        Assert.NotSame(recordingService2, recordingService3);
        Assert.NotSame(recordingService1, recordingService3);

        recordingService1.Dispose();
        recordingService2.Dispose();
        recordingService3.Dispose();
    }

    /// <summary>
    /// StreamPaneViewModel に RecordingService が注入される。
    /// Requirements: 1.5
    /// </summary>
    [Fact]
    public void StreamPaneViewModel_ReceivesRecordingService()
    {
        // Arrange
        var recordingService = new Mock<IRecordingService>();

        // Act
        var vm = new StreamPaneViewModel(
            _mockRtspService1.Object,
            _mockRenderer1.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object,
            recordingService.Object);

        // Assert: CanToggleRecording references RecordingService state
        // (verifying injection by testing behavior that depends on it)
        recordingService.Setup(r => r.State).Returns(RecordingState.Idle);
        // With disconnected state, recording should not be available
        Assert.False(vm.CanToggleRecording());
    }

    /// <summary>
    /// 3つのペインの RecordingService が独立して動作する。
    /// 一方の状態変更が他方に影響しない。
    /// Requirements: 1.5
    /// </summary>
    [Fact]
    public void ThreePanes_RecordingServicesOperateIndependently()
    {
        // Arrange
        var recordingService1 = new Mock<IRecordingService>();
        var recordingService2 = new Mock<IRecordingService>();
        var recordingService3 = new Mock<IRecordingService>();

        recordingService1.Setup(r => r.State).Returns(RecordingState.Recording);
        recordingService2.Setup(r => r.State).Returns(RecordingState.Idle);
        recordingService3.Setup(r => r.State).Returns(RecordingState.Idle);

        var pane1 = new StreamPaneViewModel(
            _mockRtspService1.Object, _mockRenderer1.Object,
            _mockOnvifService.Object, _mockSettingsService.Object,
            recordingService1.Object);

        var pane2 = new StreamPaneViewModel(
            _mockRtspService2.Object, _mockRenderer2.Object,
            _mockOnvifService.Object, _mockSettingsService.Object,
            recordingService2.Object);

        var pane3 = new StreamPaneViewModel(
            _mockRtspService3.Object, _mockRenderer3.Object,
            _mockOnvifService.Object, _mockSettingsService.Object,
            recordingService3.Object);

        // Act & Assert: all panes have independent state
        Assert.False(pane1.CanToggleRecording());
        Assert.False(pane2.CanToggleRecording());
        Assert.False(pane3.CanToggleRecording());
    }

    /// <summary>
    /// アプリケーション終了時に RecordingService が Dispose される。
    /// Requirements: 1.5
    /// </summary>
    [Fact]
    public void OnApplicationExit_RecordingServicesAreDisposed()
    {
        // Arrange
        var recordingService1 = new Mock<IRecordingService>();
        var recordingService2 = new Mock<IRecordingService>();
        var recordingService3 = new Mock<IRecordingService>();

        // Simulate the DI assembly and disposal pattern from App.OnStartup
        var services = new List<IRecordingService>
        {
            recordingService1.Object,
            recordingService2.Object,
            recordingService3.Object
        };

        // Act: Simulate app exit by disposing all recording services
        foreach (var service in services)
        {
            service.Dispose();
        }

        // Assert
        recordingService1.Verify(s => s.Dispose(), Times.Once);
        recordingService2.Verify(s => s.Dispose(), Times.Once);
        recordingService3.Verify(s => s.Dispose(), Times.Once);
    }

    // ─── Task 6.2: 録画保存先フォルダ設定の永続化テスト ──────────

    /// <summary>
    /// アプリケーション終了時に RecordingFolderPath が AppSettings 経由で JSON に保存される。
    /// Requirements: 4.3
    /// </summary>
    [Fact]
    public void OnClosing_SavesRecordingFolderPath_InAppSettings()
    {
        // Arrange
        var pane1Vm = new StreamPaneViewModel(
            _mockRtspService1.Object, _mockRenderer1.Object,
            _mockOnvifService.Object, _mockSettingsService.Object);
        var pane2Vm = new StreamPaneViewModel(
            _mockRtspService2.Object, _mockRenderer2.Object,
            _mockOnvifService.Object, _mockSettingsService.Object);
        var pane3Vm = new StreamPaneViewModel(
            _mockRtspService3.Object, _mockRenderer3.Object,
            _mockOnvifService.Object, _mockSettingsService.Object);

        var mainVm = new MainWindowViewModel(pane1Vm, pane2Vm, pane3Vm, _mockSettingsService.Object);

        // Load settings with custom recording folder path
        var customPath = @"D:\CustomRecordings";
        var settings = AppSettings.Default with { RecordingFolderPath = customPath };
        _mockSettingsService.Setup(s => s.Load()).Returns(settings);
        mainVm.LoadSettings();

        AppSettings? savedSettings = null;
        _mockSettingsService.Setup(s => s.Save(It.IsAny<AppSettings>()))
            .Callback<AppSettings>(s => savedSettings = s);

        // Act
        mainVm.OnClosing();

        // Assert
        Assert.NotNull(savedSettings);
        Assert.Equal(customPath, savedSettings!.RecordingFolderPath);
    }

    /// <summary>
    /// アプリケーション起動時に前回の RecordingFolderPath を復元し、ViewModel に反映する。
    /// Requirements: 4.4
    /// </summary>
    [Fact]
    public void LoadSettings_RestoresRecordingFolderPath_ToViewModels()
    {
        // Arrange
        var recordingService1 = new Mock<IRecordingService>();
        var recordingService2 = new Mock<IRecordingService>();
        var recordingService3 = new Mock<IRecordingService>();

        var pane1Vm = new StreamPaneViewModel(
            _mockRtspService1.Object, _mockRenderer1.Object,
            _mockOnvifService.Object, _mockSettingsService.Object,
            recordingService1.Object);
        var pane2Vm = new StreamPaneViewModel(
            _mockRtspService2.Object, _mockRenderer2.Object,
            _mockOnvifService.Object, _mockSettingsService.Object,
            recordingService2.Object);
        var pane3Vm = new StreamPaneViewModel(
            _mockRtspService3.Object, _mockRenderer3.Object,
            _mockOnvifService.Object, _mockSettingsService.Object,
            recordingService3.Object);

        var mainVm = new MainWindowViewModel(pane1Vm, pane2Vm, pane3Vm, _mockSettingsService.Object);

        var customPath = @"E:\Surveillance\Recordings";
        var settings = AppSettings.Default with { RecordingFolderPath = customPath };
        _mockSettingsService.Setup(s => s.Load()).Returns(settings);

        // Act
        mainVm.LoadSettings();

        // Assert: All panes should have the recording folder path set
        Assert.Equal(customPath, pane1Vm.RecordingFolderPath);
        Assert.Equal(customPath, pane2Vm.RecordingFolderPath);
        Assert.Equal(customPath, pane3Vm.RecordingFolderPath);
    }

    /// <summary>
    /// 設定が存在しない場合はデフォルト値にフォールバックする。
    /// Requirements: 4.4
    /// </summary>
    [Fact]
    public void LoadSettings_WhenNoSettingsExist_UsesDefaultRecordingFolderPath()
    {
        // Arrange
        var pane1Vm = new StreamPaneViewModel(
            _mockRtspService1.Object, _mockRenderer1.Object,
            _mockOnvifService.Object, _mockSettingsService.Object);
        var pane2Vm = new StreamPaneViewModel(
            _mockRtspService2.Object, _mockRenderer2.Object,
            _mockOnvifService.Object, _mockSettingsService.Object);
        var pane3Vm = new StreamPaneViewModel(
            _mockRtspService3.Object, _mockRenderer3.Object,
            _mockOnvifService.Object, _mockSettingsService.Object);

        var mainVm = new MainWindowViewModel(pane1Vm, pane2Vm, pane3Vm, _mockSettingsService.Object);

        // Default settings (no prior save)
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);

        // Act
        mainVm.LoadSettings();

        // Assert: Panes should have the default recording folder path
        Assert.Equal(AppSettings.Default.RecordingFolderPath, pane1Vm.RecordingFolderPath);
        Assert.Equal(AppSettings.Default.RecordingFolderPath, pane2Vm.RecordingFolderPath);
        Assert.Equal(AppSettings.Default.RecordingFolderPath, pane3Vm.RecordingFolderPath);
    }

    /// <summary>
    /// 録画保存先フォルダ設定の永続化のラウンドトリップテスト。
    /// SettingsService を使用して実際に JSON に保存・復元する。
    /// Requirements: 4.3, 4.4
    /// </summary>
    [Fact]
    public void RecordingFolderPath_RoundTrips_ThroughSettingsService()
    {
        // Arrange
        var testDir = Path.Combine(Path.GetTempPath(), $"RtspViewerTest_{Guid.NewGuid():N}");
        try
        {
            Directory.CreateDirectory(testDir);
            var settingsService = new SettingsService(testDir);

            var customPath = @"C:\MyRecordings\Camera";
            var settings = AppSettings.Default with { RecordingFolderPath = customPath };

            // Act
            settingsService.Save(settings);
            var loaded = settingsService.Load();

            // Assert
            Assert.Equal(customPath, loaded.RecordingFolderPath);
        }
        finally
        {
            if (Directory.Exists(testDir))
                Directory.Delete(testDir, recursive: true);
        }
    }

    /// <summary>
    /// JSON に RecordingFolderPath が存在しない場合、デフォルト値にフォールバックする。
    /// Requirements: 4.4
    /// </summary>
    [Fact]
    public void SettingsService_MissingRecordingFolderPath_FallsBackToDefault()
    {
        // Arrange
        var testDir = Path.Combine(Path.GetTempPath(), $"RtspViewerTest_{Guid.NewGuid():N}");
        try
        {
            Directory.CreateDirectory(testDir);
            // Write a JSON file without RecordingFolderPath (old format with layout)
            var json = """
            {
                "pane1": {
                    "rtspUrl": "",
                    "transport": "Tcp"
                },
                "pane2": {
                    "rtspUrl": "",
                    "transport": "Tcp"
                },
                "layout": "Horizontal"
            }
            """;
            File.WriteAllText(Path.Combine(testDir, "settings.json"), json);

            var settingsService = new SettingsService(testDir);

            // Act
            var loaded = settingsService.Load();

            // Assert: Should fall back to default
            Assert.Equal(AppSettings.Default.RecordingFolderPath, loaded.RecordingFolderPath);
        }
        finally
        {
            if (Directory.Exists(testDir))
                Directory.Delete(testDir, recursive: true);
        }
    }

    /// <summary>
    /// OnClosing 時に ViewModel の RecordingFolderPath が変更されていた場合、
    /// 変更後の値が保存される。
    /// Requirements: 4.3
    /// </summary>
    [Fact]
    public void OnClosing_SavesUpdatedRecordingFolderPath_WhenChangedByUser()
    {
        // Arrange
        var pane1Vm = new StreamPaneViewModel(
            _mockRtspService1.Object, _mockRenderer1.Object,
            _mockOnvifService.Object, _mockSettingsService.Object);
        var pane2Vm = new StreamPaneViewModel(
            _mockRtspService2.Object, _mockRenderer2.Object,
            _mockOnvifService.Object, _mockSettingsService.Object);
        var pane3Vm = new StreamPaneViewModel(
            _mockRtspService3.Object, _mockRenderer3.Object,
            _mockOnvifService.Object, _mockSettingsService.Object);

        var mainVm = new MainWindowViewModel(pane1Vm, pane2Vm, pane3Vm, _mockSettingsService.Object);
        mainVm.LoadSettings();

        // User changes recording folder path via UI
        var newPath = @"F:\NewRecordings";
        pane1Vm.RecordingFolderPath = newPath;

        AppSettings? savedSettings = null;
        _mockSettingsService.Setup(s => s.Save(It.IsAny<AppSettings>()))
            .Callback<AppSettings>(s => savedSettings = s);

        // Act
        mainVm.OnClosing();

        // Assert: The updated path should be saved
        Assert.NotNull(savedSettings);
        Assert.Equal(newPath, savedSettings!.RecordingFolderPath);
    }
}
