// RtspStreamService パケットコールバック機構のユニットテスト
// タスク 2: IRtspStreamService にパケット受信コールバックプロパティを追加
// Requirements: 1.1

using Moq;
using Sdcb.FFmpeg.Codecs;
using Sdcb.FFmpeg.Raw;
using View_RTSP.Models;
using View_RTSP.Services;

namespace View_RTSP.Tests.Services;

/// <summary>
/// パケットコールバック機構のテスト
/// </summary>
public class RtspStreamServicePacketCallbackTests : IDisposable
{
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;

    public RtspStreamServicePacketCallbackTests()
    {
        _mockRenderer = new Mock<IVideoFrameRenderer>();
    }

    public void Dispose() { }

    /// <summary>
    /// IRtspStreamService に PacketReceived プロパティが定義されている
    /// </summary>
    [Fact]
    public void PacketReceived_ExistsOnInterface()
    {
        // IRtspStreamService に PacketReceived プロパティが存在することを型チェックで確認
        var mock = new Mock<IRtspStreamService>();
        mock.SetupProperty(s => s.PacketReceived);

        Assert.Null(mock.Object.PacketReceived);
    }

    /// <summary>
    /// PacketReceived プロパティの初期値は null
    /// </summary>
    [Fact]
    public void PacketReceived_Initially_IsNull()
    {
        using var sut = new RtspStreamService(_mockRenderer.Object);

        Assert.Null(sut.PacketReceived);
    }

    /// <summary>
    /// PacketReceived プロパティに値を設定・取得できる
    /// </summary>
    [Fact]
    public void PacketReceived_CanBeSetAndGet()
    {
        using var sut = new RtspStreamService(_mockRenderer.Object);

        Action<Packet, AVRational, CodecParameters> callback = (_, _, _) => { };
        sut.PacketReceived = callback;

        Assert.Same(callback, sut.PacketReceived);
    }

    /// <summary>
    /// PacketReceived プロパティを null に戻せる（コールバック解除）
    /// </summary>
    [Fact]
    public void PacketReceived_CanBeSetToNull()
    {
        using var sut = new RtspStreamService(_mockRenderer.Object);

        sut.PacketReceived = (_, _, _) => { };
        sut.PacketReceived = null;

        Assert.Null(sut.PacketReceived);
    }
}
