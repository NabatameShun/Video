// RecordingService の状態マシンとバリデーションの包括テスト
// タスク 7.1: 状態マシン遷移、バリデーション、ファイル名生成、CanToggleRecording
// Requirements: 1.1, 1.2, 1.3, 1.4, 2.2, 5.3

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.Services;

/// <summary>
/// RecordingService の状態マシン遷移の包括テスト（タスク 7.1）。
/// タスク 3 のテストを補完し、正常系の完全な状態遷移と
/// エッジケースのバリデーションをカバーする。
/// </summary>
public class RecordingServiceStateMachineTransitionTests : IDisposable
{
    private readonly RecordingService _sut;
    private readonly List<RecordingState> _stateTransitions;
    private readonly List<RecordingErrorEventArgs> _errors;

    public RecordingServiceStateMachineTransitionTests()
    {
        _sut = new RecordingService();
        _stateTransitions = new List<RecordingState>();
        _errors = new List<RecordingErrorEventArgs>();

        _sut.StateChanged += (_, state) => _stateTransitions.Add(state);
        _sut.RecordingError += (_, e) => _errors.Add(e);
    }

    public void Dispose()
    {
        _sut.Dispose();
    }

    // ─── 状態マシン遷移 正常系 ────────────────────────────────────

    [Fact]
    public void Stop_WhenIdle_DoesNotRaiseStateChanged()
    {
        _sut.Stop();

        Assert.Empty(_stateTransitions);
        Assert.Equal(RecordingState.Idle, _sut.State);
    }

    [Fact]
    public void Stop_WhenIdle_DoesNotRaiseRecordingError()
    {
        _sut.Stop();

        Assert.Empty(_errors);
    }

    // ─── Start バリデーション 拡張テスト ──────────────────────────

    [Theory]
    [InlineData("   ")]
    [InlineData("\t")]
    [InlineData("\n")]
    public void Start_WithWhitespaceOnlyPath_ReturnsFalse_AndRaisesPermissionDenied(string path)
    {
        var result = _sut.Start(path, null!, default);

        Assert.False(result);
        Assert.Equal(RecordingState.Idle, _sut.State);
        Assert.Single(_errors);
        Assert.Equal(RecordingErrorKind.PermissionDenied, _errors[0].Kind);
    }

    [Fact]
    public void Start_WithNullCodecpar_AfterValidPath_ReturnsFalse()
    {
        // 一時ディレクトリを使用して書き込み権限チェックを通過させる
        var tempDir = Path.Combine(Path.GetTempPath(), $"RecordingTest_{Guid.NewGuid():N}");
        Directory.CreateDirectory(tempDir);

        try
        {
            var result = _sut.Start(tempDir, null!, default);

            Assert.False(result);
            Assert.Equal(RecordingState.Idle, _sut.State);
            Assert.Single(_errors);
        }
        finally
        {
            Directory.Delete(tempDir, true);
        }
    }

    [Fact]
    public void Start_AfterDispose_ReturnsFalse()
    {
        _sut.Dispose();

        var result = _sut.Start(@"C:\Temp", null!, default);

        Assert.False(result);
    }

    [Fact]
    public void Stop_AfterDispose_DoesNotThrow()
    {
        _sut.Dispose();

        var exception = Record.Exception(() => _sut.Stop());

        Assert.Null(exception);
    }

    [Fact]
    public void Start_CreatesOutputFolder_WhenNotExists()
    {
        var tempDir = Path.Combine(Path.GetTempPath(), $"RecordingTest_{Guid.NewGuid():N}", "subfolder");

        try
        {
            // フォルダは存在しないが作成可能なパス
            // sourceCodecpar が null なので Start は false だが、フォルダは作成されるはず
            _sut.Start(tempDir, null!, default);

            Assert.True(Directory.Exists(tempDir));
        }
        finally
        {
            var rootDir = Path.GetDirectoryName(tempDir)!;
            if (Directory.Exists(rootDir))
                Directory.Delete(rootDir, true);
        }
    }

    [Fact]
    public void Start_EmptyPath_ErrorMessageContainsJapanese()
    {
        _sut.Start(string.Empty, null!, default);

        Assert.Single(_errors);
        Assert.Contains("録画保存先", _errors[0].Message);
    }

    [Fact]
    public void Start_InvalidDrive_RaisesDirectoryCreationFailedOrPermissionDenied()
    {
        // 存在しないドライブレターを使用
        var result = _sut.Start(@"Q:\NonExistentDrive\TestFolder", null!, default);

        Assert.False(result);
        Assert.Single(_errors);
        Assert.True(
            _errors[0].Kind == RecordingErrorKind.DirectoryCreationFailed ||
            _errors[0].Kind == RecordingErrorKind.PermissionDenied);
    }

    // ─── Dispose 後の動作テスト ────────────────────────────────────

    [Fact]
    public void WritePacket_AfterDispose_DoesNotThrow()
    {
        _sut.Dispose();

        // WritePacket は null packet でも Dispose 後は即リターンするはず
        var exception = Record.Exception(() => _sut.WritePacket(null!, default));

        Assert.Null(exception);
    }

    // ─── 複数回の Start 呼び出しテスト ─────────────────────────────

    [Fact]
    public void Start_CalledMultipleTimes_WithInvalidPath_AllReturnFalse()
    {
        var result1 = _sut.Start(string.Empty, null!, default);
        var result2 = _sut.Start(string.Empty, null!, default);
        var result3 = _sut.Start(string.Empty, null!, default);

        Assert.False(result1);
        Assert.False(result2);
        Assert.False(result3);
        Assert.Equal(RecordingState.Idle, _sut.State);
        Assert.Equal(3, _errors.Count);
    }
}

/// <summary>
/// RecordingService のファイル名生成ロジックの包括テスト（タスク 7.1）。
/// タスク 3 のテストを補完し、エッジケースの日時フォーマットをカバーする。
/// </summary>
public class RecordingServiceFileNameFormatTests
{
    [Theory]
    [InlineData(2026, 1, 1, 0, 0, 0, "20260101_000000.mp4")]
    [InlineData(2026, 12, 31, 23, 59, 59, "20261231_235959.mp4")]
    [InlineData(2026, 3, 15, 14, 30, 0, "20260315_143000.mp4")]
    [InlineData(2026, 2, 28, 12, 0, 0, "20260228_120000.mp4")]
    [InlineData(2000, 1, 1, 0, 0, 0, "20000101_000000.mp4")]
    public void GenerateFileName_CorrectFormat_ForVariousDates(
        int year, int month, int day, int hour, int minute, int second, string expected)
    {
        var dateTime = new DateTime(year, month, day, hour, minute, second);

        var result = RecordingService.GenerateFileName(dateTime);

        Assert.Equal(expected, result);
    }

    [Fact]
    public void GenerateFileName_Format_IsYyyyMMdd_HHmmss_DotMp4()
    {
        var dateTime = new DateTime(2026, 3, 15, 9, 5, 3);
        var result = RecordingService.GenerateFileName(dateTime);

        // 1桁の月・日・時・分・秒はゼロ埋めされること
        Assert.Equal("20260315_090503.mp4", result);
    }

    [Fact]
    public void GenerateFileName_AlwaysEndsWith_Mp4Extension()
    {
        for (int i = 0; i < 10; i++)
        {
            var dateTime = DateTime.Now.AddMinutes(i);
            var result = RecordingService.GenerateFileName(dateTime);
            Assert.EndsWith(".mp4", result);
        }
    }

    [Fact]
    public void GenerateFileName_ContainsUnderscore_BetweenDateAndTime()
    {
        var dateTime = new DateTime(2026, 6, 15, 10, 20, 30);
        var result = RecordingService.GenerateFileName(dateTime);

        // ファイル名からの拡張子を除く部分にアンダースコアが含まれること
        var nameWithoutExt = Path.GetFileNameWithoutExtension(result);
        Assert.Contains("_", nameWithoutExt);

        var parts = nameWithoutExt.Split('_');
        Assert.Equal(2, parts.Length);
        Assert.Equal(8, parts[0].Length); // yyyyMMdd
        Assert.Equal(6, parts[1].Length); // HHmmss
    }

    [Fact]
    public void GenerateFileName_UsesLocalTime_NotUtc()
    {
        // ローカル時刻を使用することの検証
        // GenerateFileName は引数の DateTime をそのまま使うため、呼び出し元がローカル時刻を渡す
        var localTime = new DateTime(2026, 3, 15, 14, 30, 0, DateTimeKind.Local);
        var utcTime = new DateTime(2026, 3, 15, 5, 30, 0, DateTimeKind.Utc);

        var localResult = RecordingService.GenerateFileName(localTime);
        var utcResult = RecordingService.GenerateFileName(utcTime);

        // 異なる日時を渡すと異なるファイル名になること（ローカル vs UTC の区別を呼び出し元が制御）
        Assert.NotEqual(localResult, utcResult);
    }
}

/// <summary>
/// CanToggleRecording の接続状態 x 録画状態の組み合わせテスト（タスク 7.1）。
/// タスク 4 のテストを補完し、全組み合わせを網羅する。
/// </summary>
public class CanToggleRecordingCombinationTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly Mock<IRecordingService> _mockRecordingService;

    public CanToggleRecordingCombinationTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();
        _mockRecordingService = new Mock<IRecordingService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
    }

    private StreamPaneViewModel CreateSut(ConnectionState connState, RecordingState recState)
    {
        _mockRecordingService.Setup(s => s.State).Returns(recState);
        var sut = new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object,
            _mockRecordingService.Object);
        sut.ConnectionState = connState;
        return sut;
    }

    // ─── 全組み合わせテスト ───────────────────────────────────────

    [Theory]
    [InlineData(ConnectionState.Connected, RecordingState.Idle, true)]
    [InlineData(ConnectionState.Connected, RecordingState.Recording, true)]
    [InlineData(ConnectionState.Connected, RecordingState.Stopping, false)]
    [InlineData(ConnectionState.Disconnected, RecordingState.Idle, false)]
    [InlineData(ConnectionState.Disconnected, RecordingState.Recording, false)]
    [InlineData(ConnectionState.Disconnected, RecordingState.Stopping, false)]
    [InlineData(ConnectionState.Connecting, RecordingState.Idle, false)]
    [InlineData(ConnectionState.Connecting, RecordingState.Recording, true)]
    [InlineData(ConnectionState.Connecting, RecordingState.Stopping, false)]
    [InlineData(ConnectionState.Error, RecordingState.Idle, false)]
    [InlineData(ConnectionState.Error, RecordingState.Recording, false)]
    [InlineData(ConnectionState.Error, RecordingState.Stopping, false)]
    public void CanToggleRecording_AllCombinations(
        ConnectionState connState, RecordingState recState, bool expected)
    {
        var sut = CreateSut(connState, recState);

        var result = sut.CanToggleRecording();

        Assert.Equal(expected, result);
    }

    // ─── RecordingService が null のケース ─────────────────────────

    [Fact]
    public void CanToggleRecording_WithNullRecordingService_ReturnsFalse()
    {
        var sut = new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);
        sut.ConnectionState = ConnectionState.Connected;

        Assert.False(sut.CanToggleRecording());
    }

    [Fact]
    public void ToggleRecording_WithNullRecordingService_DoesNotThrow()
    {
        var sut = new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);

        var exception = Record.Exception(() => sut.ToggleRecording());

        Assert.Null(exception);
    }
}

/// <summary>
/// RecordingService の RecordingStartedAtUtc プロパティのテスト（タスク 7.1）。
/// </summary>
public class RecordingServiceStartedAtTests : IDisposable
{
    private readonly RecordingService _sut;

    public RecordingServiceStartedAtTests()
    {
        _sut = new RecordingService();
    }

    public void Dispose()
    {
        _sut.Dispose();
    }

    [Fact]
    public void RecordingStartedAtUtc_WhenIdle_IsNull()
    {
        Assert.Null(_sut.RecordingStartedAtUtc);
    }

    [Fact]
    public void RecordingStartedAtUtc_AfterFailedStart_RemainsNull()
    {
        _sut.Start(string.Empty, null!, default);

        Assert.Null(_sut.RecordingStartedAtUtc);
    }

    [Fact]
    public void RecordingStartedAtUtc_AfterDispose_IsNull()
    {
        _sut.Dispose();

        Assert.Null(_sut.RecordingStartedAtUtc);
    }
}
