// タスク 9: グローバル例外ハンドリングとアプリケーション基盤のテスト
// ApplicationErrorHandler サービスのユニットテスト
// Requirements: 3.5, 4.2, 4.5

using View_RTSP.Services;

namespace View_RTSP.Tests.Services;

/// <summary>
/// ApplicationErrorHandler のユニットテスト。
/// グローバル例外ハンドリングロジックをテスト可能な形で検証する。
/// </summary>
public class ApplicationErrorHandlerTests
{
    // ─── エラーメッセージ生成テスト ──────────────────────────────

    /// <summary>
    /// FormatUserMessage は例外メッセージをユーザー向けの文字列にフォーマットする。
    /// Requirements: 4.5（未処理例外のユーザー通知）
    /// </summary>
    [Fact]
    public void FormatUserMessage_WithException_ContainsExceptionMessage()
    {
        // Arrange
        var sut = new ApplicationErrorHandler();
        var exception = new InvalidOperationException("テスト用例外メッセージ");

        // Act
        var message = sut.FormatUserMessage(exception);

        // Assert: 例外メッセージが含まれる
        Assert.Contains("テスト用例外メッセージ", message);
    }

    /// <summary>
    /// FormatUserMessage は継続か終了かをユーザーが選択できる旨のメッセージを含む。
    /// Requirements: 4.5（継続または終了を選択できるようにする）
    /// </summary>
    [Fact]
    public void FormatUserMessage_WithException_ContainsActionChoiceDescription()
    {
        // Arrange
        var sut = new ApplicationErrorHandler();
        var exception = new Exception("エラー");

        // Act
        var message = sut.FormatUserMessage(exception);

        // Assert: 継続か終了かを説明するメッセージが含まれる
        Assert.NotEmpty(message);
        Assert.True(message.Length > 10, "メッセージが短すぎます。ユーザー向けの説明が不足しています。");
    }

    /// <summary>
    /// FormatUserMessage は例外の型情報または詳細情報を含む。
    /// </summary>
    [Fact]
    public void FormatUserMessage_WithNestedInnerException_ContainsRootMessage()
    {
        // Arrange
        var sut = new ApplicationErrorHandler();
        var innerException = new ArgumentNullException("param", "パラメーターがnullです");
        var outerException = new InvalidOperationException("操作が無効です", innerException);

        // Act
        var message = sut.FormatUserMessage(outerException);

        // Assert: 外部例外メッセージが含まれる
        Assert.Contains("操作が無効です", message);
    }

    // ─── ShouldTerminate テスト ────────────────────────────────

    /// <summary>
    /// ShouldTerminate は OutOfMemoryException の場合 true を返す。
    /// アプリを継続できない致命的な例外はシャットダウンすべき。
    /// </summary>
    [Fact]
    public void ShouldTerminate_WithOutOfMemoryException_ReturnsTrue()
    {
        // Arrange
        var sut = new ApplicationErrorHandler();
        var exception = new OutOfMemoryException("メモリ不足");

        // Act
        var result = sut.ShouldTerminate(exception);

        // Assert
        Assert.True(result, "OutOfMemoryException は致命的なため終了すべきです。");
    }

    /// <summary>
    /// ShouldTerminate は StackOverflowException の場合 true を返す。
    /// </summary>
    [Fact]
    public void ShouldTerminate_WithStackOverflowException_ReturnsTrue()
    {
        // Arrange
        var sut = new ApplicationErrorHandler();
        // StackOverflowException は直接 new できないため、派生クラスで代替
        var exception = new InsufficientExecutionStackException("スタックオーバーフロー");

        // Act
        var result = sut.ShouldTerminate(exception);

        // Assert
        Assert.True(result, "InsufficientExecutionStackException は致命的なため終了すべきです。");
    }

    /// <summary>
    /// ShouldTerminate は通常の例外（InvalidOperationException）の場合 false を返す。
    /// 通常の例外はアプリを継続できる。
    /// </summary>
    [Fact]
    public void ShouldTerminate_WithNonFatalException_ReturnsFalse()
    {
        // Arrange
        var sut = new ApplicationErrorHandler();
        var exception = new InvalidOperationException("通常の例外");

        // Act
        var result = sut.ShouldTerminate(exception);

        // Assert
        Assert.False(result, "通常の例外はアプリを継続できるため false を返すべきです。");
    }

    /// <summary>
    /// ShouldTerminate は ArgumentException の場合 false を返す。
    /// </summary>
    [Fact]
    public void ShouldTerminate_WithArgumentException_ReturnsFalse()
    {
        // Arrange
        var sut = new ApplicationErrorHandler();
        var exception = new ArgumentException("引数エラー");

        // Act
        var result = sut.ShouldTerminate(exception);

        // Assert
        Assert.False(result);
    }
}

/// <summary>
/// FfmpegDllChecker のユニットテスト。
/// FFmpeg ネイティブ DLL の存在チェックロジックを検証する。
/// Requirements: 4.2（起動時 FFmpeg DLL 存在チェック）
/// </summary>
public class FfmpegDllCheckerTests : IDisposable
{
    // テスト用の一時ディレクトリ
    private readonly string _testDirectory;

    public FfmpegDllCheckerTests()
    {
        _testDirectory = Path.Combine(Path.GetTempPath(), $"FfmpegDllTest_{Guid.NewGuid():N}");
        Directory.CreateDirectory(_testDirectory);
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(_testDirectory))
                Directory.Delete(_testDirectory, recursive: true);
        }
        catch
        {
            // クリーンアップ失敗は無視
        }
    }

    // ─── DLL チェックテスト ────────────────────────────────────

    /// <summary>
    /// avcodec-*.dll が存在する場合、CheckDllsExist は true を返す。
    /// Requirements: 4.2
    /// </summary>
    [Fact]
    public void CheckDllsExist_WhenAvcodecDllExists_ReturnsTrue()
    {
        // Arrange: avcodec-61.dll をダミー作成
        File.WriteAllBytes(Path.Combine(_testDirectory, "avcodec-61.dll"), Array.Empty<byte>());
        var sut = new FfmpegDllChecker(_testDirectory);

        // Act
        var result = sut.CheckDllsExist();

        // Assert
        Assert.True(result, "avcodec-*.dll が存在するため true を返すべきです。");
    }

    /// <summary>
    /// avcodec DLL が存在しない場合、CheckDllsExist は false を返す。
    /// </summary>
    [Fact]
    public void CheckDllsExist_WhenNoDllsExist_ReturnsFalse()
    {
        // Arrange: 空のディレクトリ
        var sut = new FfmpegDllChecker(_testDirectory);

        // Act
        var result = sut.CheckDllsExist();

        // Assert
        Assert.False(result, "DLL が存在しないため false を返すべきです。");
    }

    /// <summary>
    /// avformat-*.dll が存在する場合も true を返す（avcodec がなくても avformat で検出する）。
    /// </summary>
    [Fact]
    public void CheckDllsExist_WhenAvformatDllExists_ReturnsTrue()
    {
        // Arrange: avformat-61.dll をダミー作成
        File.WriteAllBytes(Path.Combine(_testDirectory, "avformat-61.dll"), Array.Empty<byte>());
        var sut = new FfmpegDllChecker(_testDirectory);

        // Act
        var result = sut.CheckDllsExist();

        // Assert
        Assert.True(result);
    }

    /// <summary>
    /// GetMissingDlls は存在しない DLL 名のリストを返す。
    /// </summary>
    [Fact]
    public void GetMissingDlls_WhenNoDllsExist_ReturnsExpectedDllNames()
    {
        // Arrange: 空のディレクトリ
        var sut = new FfmpegDllChecker(_testDirectory);

        // Act
        var missing = sut.GetMissingDlls();

        // Assert: 少なくとも 1 件の欠如 DLL パターンが報告される
        Assert.NotEmpty(missing);
    }

    /// <summary>
    /// GetMissingDlls は必要な DLL が揃っている場合、空リストを返す。
    /// </summary>
    [Fact]
    public void GetMissingDlls_WhenAllDllsExist_ReturnsEmptyList()
    {
        // Arrange: 必要な DLL をすべてダミー作成
        var dllNames = new[] { "avcodec-61.dll", "avformat-61.dll", "avutil-59.dll", "swscale-8.dll" };
        foreach (var dll in dllNames)
            File.WriteAllBytes(Path.Combine(_testDirectory, dll), Array.Empty<byte>());

        var sut = new FfmpegDllChecker(_testDirectory);

        // Act
        var missing = sut.GetMissingDlls();

        // Assert
        Assert.Empty(missing);
    }

    /// <summary>
    /// 関係ない .dll ファイルのみ存在する場合、false を返す。
    /// </summary>
    [Fact]
    public void CheckDllsExist_WhenOnlyUnrelatedDllsExist_ReturnsFalse()
    {
        // Arrange: FFmpeg と無関係な DLL のみ
        File.WriteAllBytes(Path.Combine(_testDirectory, "unrelated.dll"), Array.Empty<byte>());
        File.WriteAllBytes(Path.Combine(_testDirectory, "other.dll"), Array.Empty<byte>());
        var sut = new FfmpegDllChecker(_testDirectory);

        // Act
        var result = sut.CheckDllsExist();

        // Assert
        Assert.False(result);
    }

    /// <summary>
    /// GetErrorMessage は欠如 DLL 名をわかりやすいメッセージにフォーマットする。
    /// </summary>
    [Fact]
    public void GetErrorMessage_WhenDllsMissing_ContainsDllPatternNames()
    {
        // Arrange
        var sut = new FfmpegDllChecker(_testDirectory);

        // Act
        var message = sut.GetErrorMessage();

        // Assert: エラーメッセージが空でなく、DLL に関する説明を含む
        Assert.NotEmpty(message);
        Assert.Contains("FFmpeg", message);
    }
}
