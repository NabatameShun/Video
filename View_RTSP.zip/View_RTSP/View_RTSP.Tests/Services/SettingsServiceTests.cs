// 設定永続化サービスのユニットテスト
// タスク 2・タスク 11.2 に対応
// Requirements: 4.6, 5.1, 5.4, 9.3

using System.IO;
using View_RTSP.Models;
using View_RTSP.Services;

namespace View_RTSP.Tests.Services;

/// <summary>
/// SettingsService のユニットテスト
/// </summary>
public class SettingsServiceTests : IDisposable
{
    // テスト用の一時ディレクトリを使用して %AppData% への依存を回避
    private readonly string _testDirectory;
    private readonly SettingsService _sut;

    public SettingsServiceTests()
    {
        _testDirectory = Path.Combine(Path.GetTempPath(), $"RtspViewerTest_{Guid.NewGuid():N}");
        Directory.CreateDirectory(_testDirectory);
        _sut = new SettingsService(_testDirectory);
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(_testDirectory))
                Directory.Delete(_testDirectory, recursive: true);
        }
        catch
        {
            // クリーンアップ失敗は無視
        }
    }

    // ─── Load テスト ───────────────────────────────────────────

    /// <summary>
    /// 設定ファイルが存在しない場合、デフォルト値を返し例外をスローしない
    /// Requirements: 4.6（ファイル不存在時のデフォルト値返却）
    /// </summary>
    [Fact]
    public void Load_WhenFileDoesNotExist_ReturnsDefaultSettings()
    {
        // Arrange: 空のディレクトリ（ファイルなし）

        // Act
        var result = _sut.Load();

        // Assert
        Assert.NotNull(result);
        Assert.Equal(AppSettings.Default.SelectedTabIndex, result.SelectedTabIndex);
        Assert.Equal(AppSettings.Default.Pane1.RtspUrl, result.Pane1.RtspUrl);
        Assert.Equal(AppSettings.Default.Pane2.RtspUrl, result.Pane2.RtspUrl);
        Assert.Equal(AppSettings.Default.Pane3.RtspUrl, result.Pane3.RtspUrl);
    }

    /// <summary>
    /// 設定ファイルが破損している場合、デフォルト値にフォールバックし例外をスローしない
    /// Requirements: 5.1（破損ファイルのフォールバック）
    /// </summary>
    [Fact]
    public void Load_WhenFileIsCorrupt_ReturnsDefaultSettingsWithoutThrowing()
    {
        // Arrange: 破損したJSONファイルを作成
        var settingsPath = Path.Combine(_testDirectory, "settings.json");
        File.WriteAllText(settingsPath, "{ invalid json content ::::");

        // Act
        var exception = Record.Exception(() => _sut.Load());
        var result = _sut.Load();

        // Assert: 例外がスローされない
        Assert.Null(exception);
        // デフォルト値が返される
        Assert.Equal(AppSettings.Default.SelectedTabIndex, result.SelectedTabIndex);
    }

    // ─── Save → Load ラウンドトリップテスト ─────────────────────

    /// <summary>
    /// RTSP URL を保存・読み込みして同じ値が復元される
    /// Requirements: 4.6（URL の往復変換）
    /// </summary>
    [Fact]
    public void SaveAndLoad_RtspUrl_RoundTripsCorrectly()
    {
        // Arrange
        var pane1 = new StreamPaneSettings(
            RtspUrl: "rtsp://192.168.1.100/stream1",
            Username: "admin",
            EncryptedPassword: null,
            Transport: RtspTransport.Tcp,
            OnvifEndpointUrl: null,
            OnvifUsername: null,
            OnvifEncryptedPassword: null
        );
        var settings = AppSettings.Default with { Pane1 = pane1 };

        // Act
        _sut.Save(settings);
        var loaded = _sut.Load();

        // Assert
        Assert.Equal("rtsp://192.168.1.100/stream1", loaded.Pane1.RtspUrl);
        Assert.Equal("admin", loaded.Pane1.Username);
    }

    /// <summary>
    /// SelectedTabIndex を保存・読み込みして同じ値が復元される
    /// </summary>
    [Fact]
    public void SaveAndLoad_SelectedTabIndex_RoundTripsCorrectly()
    {
        // Arrange
        var settings = AppSettings.Default with { SelectedTabIndex = 1 };

        // Act
        _sut.Save(settings);
        var loaded = _sut.Load();

        // Assert
        Assert.Equal(1, loaded.SelectedTabIndex);
    }

    /// <summary>
    /// トランスポート設定（UDP）を保存・読み込みして同じ値が復元される
    /// Requirements: 9.3（トランスポートの往復変換）
    /// </summary>
    [Fact]
    public void SaveAndLoad_Transport_RoundTripsCorrectly()
    {
        // Arrange
        var pane1 = AppSettings.Default.Pane1 with { Transport = RtspTransport.Udp };
        var settings = AppSettings.Default with { Pane1 = pane1 };

        // Act
        _sut.Save(settings);
        var loaded = _sut.Load();

        // Assert
        Assert.Equal(RtspTransport.Udp, loaded.Pane1.Transport);
    }

    /// <summary>
    /// ONVIF エンドポイント URL を保存・読み込みして同じ値が復元される
    /// Requirements: 5.1（ONVIF設定の往復変換）
    /// </summary>
    [Fact]
    public void SaveAndLoad_OnvifEndpointUrl_RoundTripsCorrectly()
    {
        // Arrange
        var pane1 = AppSettings.Default.Pane1 with
        {
            OnvifEndpointUrl = "http://192.168.1.100/onvif/device_service",
            OnvifUsername = "admin"
        };
        var settings = AppSettings.Default with { Pane1 = pane1 };

        // Act
        _sut.Save(settings);
        var loaded = _sut.Load();

        // Assert
        Assert.Equal("http://192.168.1.100/onvif/device_service", loaded.Pane1.OnvifEndpointUrl);
        Assert.Equal("admin", loaded.Pane1.OnvifUsername);
    }

    // ─── パスワード暗号化テスト ────────────────────────────────

    /// <summary>
    /// パスワードを暗号化して保存し、復号して同じ値が取得できる
    /// Requirements: 5.4（パスワードの暗号化・復号ラウンドトリップ）
    /// </summary>
    [Fact]
    public void EncryptPassword_ThenDecrypt_ReturnsOriginalPassword()
    {
        // Arrange
        const string originalPassword = "MySecretPassword123!";

        // Act
        var encrypted = _sut.EncryptPassword(originalPassword);
        var decrypted = _sut.DecryptPassword(encrypted);

        // Assert
        Assert.Equal(originalPassword, decrypted);
    }

    /// <summary>
    /// 暗号化されたパスワードは元の平文と異なる
    /// Requirements: 5.4（DPAPI 暗号化の確認）
    /// </summary>
    [Fact]
    public void EncryptPassword_ReturnsEncryptedString_DifferentFromOriginal()
    {
        // Arrange
        const string originalPassword = "MySecretPassword123!";

        // Act
        var encrypted = _sut.EncryptPassword(originalPassword);

        // Assert: 暗号化後は平文と異なる
        Assert.NotEqual(originalPassword, encrypted);
        // Base64 エンコードされた文字列であることを確認（デコード可能）
        var exception = Record.Exception(() => Convert.FromBase64String(encrypted));
        Assert.Null(exception);
    }

    /// <summary>
    /// 空パスワードの暗号化・復号が正常に動作する
    /// </summary>
    [Fact]
    public void EncryptPassword_EmptyString_RoundTripsCorrectly()
    {
        // Arrange
        const string emptyPassword = "";

        // Act
        var encrypted = _sut.EncryptPassword(emptyPassword);
        var decrypted = _sut.DecryptPassword(encrypted);

        // Assert
        Assert.Equal(emptyPassword, decrypted);
    }

    /// <summary>
    /// Save でパスワードを暗号化して保存し、Load で復号できる
    /// Requirements: 5.4（保存・読み込み時のパスワード暗号化サイクル）
    /// </summary>
    [Fact]
    public void Save_WithEncryptedPassword_CanBeLoadedAndDecrypted()
    {
        // Arrange
        const string plainPassword = "AdminPassword!";
        var encrypted = _sut.EncryptPassword(plainPassword);
        var pane1 = new StreamPaneSettings(
            RtspUrl: "rtsp://192.168.1.100/stream1",
            Username: "admin",
            EncryptedPassword: encrypted,
            Transport: RtspTransport.Tcp,
            OnvifEndpointUrl: null,
            OnvifUsername: null,
            OnvifEncryptedPassword: null
        );
        var settings = AppSettings.Default with { Pane1 = pane1 };

        // Act
        _sut.Save(settings);
        var loaded = _sut.Load();
        var decrypted = _sut.DecryptPassword(loaded.Pane1.EncryptedPassword!);

        // Assert
        Assert.Equal(plainPassword, decrypted);
    }

    // ─── ファイル作成テスト ────────────────────────────────────

    /// <summary>
    /// Save を呼び出すと settings.json ファイルが作成される
    /// </summary>
    [Fact]
    public void Save_CreatesSettingsFile_InConfiguredDirectory()
    {
        // Arrange
        var settings = AppSettings.Default;

        // Act
        _sut.Save(settings);

        // Assert
        var settingsPath = Path.Combine(_testDirectory, "settings.json");
        Assert.True(File.Exists(settingsPath));
    }

    /// <summary>
    /// settings.json は有効な JSON として保存される
    /// </summary>
    [Fact]
    public void Save_WritesValidJson_ToFile()
    {
        // Arrange
        var settings = AppSettings.Default;

        // Act
        _sut.Save(settings);

        // Assert
        var settingsPath = Path.Combine(_testDirectory, "settings.json");
        var json = File.ReadAllText(settingsPath);
        var exception = Record.Exception(() =>
            System.Text.Json.JsonDocument.Parse(json));
        Assert.Null(exception);
    }

    // ─── 全ペイン設定の往復変換テスト ─────────────────────────

    /// <summary>
    /// Pane1, Pane2, Pane3 の設定が独立して保存・読み込みされる
    /// </summary>
    [Fact]
    public void SaveAndLoad_AllPanes_RoundTripIndependently()
    {
        // Arrange
        var pane1 = new StreamPaneSettings(
            RtspUrl: "rtsp://192.168.1.100/stream1",
            Username: "user1",
            EncryptedPassword: null,
            Transport: RtspTransport.Tcp,
            OnvifEndpointUrl: null,
            OnvifUsername: null,
            OnvifEncryptedPassword: null
        );
        var pane2 = new StreamPaneSettings(
            RtspUrl: "rtsp://192.168.1.200/stream2",
            Username: "user2",
            EncryptedPassword: null,
            Transport: RtspTransport.Udp,
            OnvifEndpointUrl: "http://192.168.1.200/onvif/device_service",
            OnvifUsername: "admin2",
            OnvifEncryptedPassword: null
        );
        var pane3 = new StreamPaneSettings(
            RtspUrl: "rtsp://192.168.1.300/stream3",
            Username: "user3",
            EncryptedPassword: null,
            Transport: RtspTransport.Tcp,
            OnvifEndpointUrl: null,
            OnvifUsername: null,
            OnvifEncryptedPassword: null
        );
        var settings = AppSettings.Default with { Pane1 = pane1, Pane2 = pane2, Pane3 = pane3, SelectedTabIndex = 2 };

        // Act
        _sut.Save(settings);
        var loaded = _sut.Load();

        // Assert Pane1
        Assert.Equal("rtsp://192.168.1.100/stream1", loaded.Pane1.RtspUrl);
        Assert.Equal("user1", loaded.Pane1.Username);
        Assert.Equal(RtspTransport.Tcp, loaded.Pane1.Transport);

        // Assert Pane2
        Assert.Equal("rtsp://192.168.1.200/stream2", loaded.Pane2.RtspUrl);
        Assert.Equal("user2", loaded.Pane2.Username);
        Assert.Equal(RtspTransport.Udp, loaded.Pane2.Transport);
        Assert.Equal("http://192.168.1.200/onvif/device_service", loaded.Pane2.OnvifEndpointUrl);

        // Assert Pane3
        Assert.Equal("rtsp://192.168.1.300/stream3", loaded.Pane3.RtspUrl);
        Assert.Equal("user3", loaded.Pane3.Username);

        // Assert SelectedTabIndex
        Assert.Equal(2, loaded.SelectedTabIndex);
    }

    // ─── 後方互換テスト ───────────────────────────────────────

    /// <summary>
    /// 旧 2ペイン形式の JSON ファイルを読み込んだ場合、
    /// Pane3 はデフォルト値、SelectedTabIndex は 3 にフォールバックする
    /// </summary>
    [Fact]
    public void Load_OldTwoPaneFormat_FallsBackToDefaults()
    {
        // Arrange: 旧形式の JSON（Pane3 なし、layout あり）
        var json = """
            {
                "pane1": {
                    "rtspUrl": "rtsp://192.168.1.100/stream1",
                    "transport": "Tcp"
                },
                "pane2": {
                    "rtspUrl": "rtsp://192.168.1.200/stream2",
                    "transport": "Udp"
                },
                "layout": "Horizontal"
            }
            """;
        File.WriteAllText(Path.Combine(_testDirectory, "settings.json"), json);

        // Act
        var loaded = _sut.Load();

        // Assert: Pane1, Pane2 は読み込まれる
        Assert.Equal("rtsp://192.168.1.100/stream1", loaded.Pane1.RtspUrl);
        Assert.Equal("rtsp://192.168.1.200/stream2", loaded.Pane2.RtspUrl);
        // Pane3 はデフォルト、SelectedTabIndex は 3
        Assert.Equal(string.Empty, loaded.Pane3.RtspUrl);
        Assert.Equal(3, loaded.SelectedTabIndex);
    }
}
