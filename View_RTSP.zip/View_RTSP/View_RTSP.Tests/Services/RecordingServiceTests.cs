// RecordingService のユニットテスト
// タスク 3.1, 3.2, 3.3: 状態マシン、バリデーション、ファイル名生成
// Requirements: 1.1, 1.2, 1.5, 2.2, 5.3

using View_RTSP.Models;
using View_RTSP.Services;

namespace View_RTSP.Tests.Services;

/// <summary>
/// RecordingService の状態マシンとバリデーションのテスト。
/// FFmpeg ネイティブ層を使用するテストは結合テストに委譲し、
/// ここでは状態遷移・バリデーション・ファイル名生成ロジックをテストする。
/// </summary>
public class RecordingServiceStateMachineTests : IDisposable
{
    private readonly RecordingService _sut;

    public RecordingServiceStateMachineTests()
    {
        _sut = new RecordingService();
    }

    public void Dispose()
    {
        _sut.Dispose();
    }

    // ─── 初期状態テスト ────────────────────────────────────────────

    [Fact]
    public void State_Initially_IsIdle()
    {
        Assert.Equal(RecordingState.Idle, _sut.State);
    }

    [Fact]
    public void RecordingStartedAtUtc_Initially_IsNull()
    {
        Assert.Null(_sut.RecordingStartedAtUtc);
    }

    // ─── Start バリデーションテスト ─────────────────────────────────

    [Fact]
    public void Start_WithNullPath_ReturnsFalse_AndRaisesError()
    {
        RecordingErrorEventArgs? errorArgs = null;
        _sut.RecordingError += (_, e) => errorArgs = e;

        var result = _sut.Start(null!, null!, default);

        Assert.False(result);
        Assert.Equal(RecordingState.Idle, _sut.State);
        Assert.NotNull(errorArgs);
    }

    [Fact]
    public void Start_WithEmptyPath_ReturnsFalse_AndRaisesError()
    {
        RecordingErrorEventArgs? errorArgs = null;
        _sut.RecordingError += (_, e) => errorArgs = e;

        var result = _sut.Start(string.Empty, null!, default);

        Assert.False(result);
        Assert.Equal(RecordingState.Idle, _sut.State);
        Assert.NotNull(errorArgs);
    }

    [Fact]
    public void Start_WithInvalidPath_ReturnsFalse_AndRaisesPermissionDeniedOrDirectoryCreationFailed()
    {
        RecordingErrorEventArgs? errorArgs = null;
        _sut.RecordingError += (_, e) => errorArgs = e;

        // 無効なパス（ルートに近い書き込み不可パス）
        var result = _sut.Start(@"Z:\NonExistent\Invalid\Path", null!, default);

        Assert.False(result);
        Assert.Equal(RecordingState.Idle, _sut.State);
        Assert.NotNull(errorArgs);
        Assert.True(
            errorArgs!.Kind == RecordingErrorKind.DirectoryCreationFailed ||
            errorArgs!.Kind == RecordingErrorKind.PermissionDenied);
    }

    // ─── Stop テスト ─────────────────────────────────────────────

    [Fact]
    public void Stop_WhenIdle_DoesNotThrow()
    {
        var exception = Record.Exception(() => _sut.Stop());
        Assert.Null(exception);
    }

    [Fact]
    public void Stop_WhenIdle_StateRemainsIdle()
    {
        _sut.Stop();
        Assert.Equal(RecordingState.Idle, _sut.State);
    }

    // ─── Dispose テスト ──────────────────────────────────────────

    [Fact]
    public void Dispose_WhenIdle_DoesNotThrow()
    {
        var exception = Record.Exception(() => _sut.Dispose());
        Assert.Null(exception);
    }

    [Fact]
    public void Dispose_CalledTwice_DoesNotThrow()
    {
        _sut.Dispose();
        var exception = Record.Exception(() => _sut.Dispose());
        Assert.Null(exception);
    }

    // ─── IRecordingService インターフェース適合テスト ─────────────

    [Fact]
    public void RecordingService_ImplementsIRecordingService()
    {
        Assert.IsAssignableFrom<IRecordingService>(_sut);
    }

    [Fact]
    public void RecordingService_ImplementsIDisposable()
    {
        Assert.IsAssignableFrom<IDisposable>(_sut);
    }
}

/// <summary>
/// RecordingService のファイル名生成テスト
/// </summary>
public class RecordingServiceFileNameTests
{
    [Fact]
    public void GenerateFileName_ContainsDateTimeFormat()
    {
        var now = new DateTime(2026, 3, 15, 14, 30, 0);
        var fileName = RecordingService.GenerateFileName(now);

        Assert.Equal("20260315_143000.mp4", fileName);
    }

    [Fact]
    public void GenerateFileName_DifferentTimes_ProduceDifferentNames()
    {
        var time1 = new DateTime(2026, 1, 1, 0, 0, 0);
        var time2 = new DateTime(2026, 1, 1, 0, 0, 1);

        var name1 = RecordingService.GenerateFileName(time1);
        var name2 = RecordingService.GenerateFileName(time2);

        Assert.NotEqual(name1, name2);
    }

    [Fact]
    public void GenerateFileName_HasMp4Extension()
    {
        var fileName = RecordingService.GenerateFileName(DateTime.Now);

        Assert.EndsWith(".mp4", fileName);
    }
}

/// <summary>
/// RecordingService の StateChanged イベントテスト
/// </summary>
public class RecordingServiceEventTests : IDisposable
{
    private readonly RecordingService _sut;

    public RecordingServiceEventTests()
    {
        _sut = new RecordingService();
    }

    public void Dispose()
    {
        _sut.Dispose();
    }

    [Fact]
    public void StateChanged_CanSubscribe()
    {
        var exception = Record.Exception(() =>
        {
            _sut.StateChanged += (_, _) => { };
        });
        Assert.Null(exception);
    }

    [Fact]
    public void RecordingError_CanSubscribe()
    {
        var exception = Record.Exception(() =>
        {
            _sut.RecordingError += (_, _) => { };
        });
        Assert.Null(exception);
    }

    [Fact]
    public void Start_WithInvalidPath_RaisesRecordingErrorEvent()
    {
        var errors = new List<RecordingErrorEventArgs>();
        _sut.RecordingError += (_, e) => errors.Add(e);

        _sut.Start(@"Z:\NonExistent\Path", null!, default);

        Assert.Single(errors);
        Assert.NotNull(errors[0].Message);
        Assert.NotEmpty(errors[0].Message);
    }
}
