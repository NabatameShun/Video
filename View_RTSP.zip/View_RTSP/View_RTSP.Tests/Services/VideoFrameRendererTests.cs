// 映像フレーム描画サービスのユニットテスト
// タスク 3 に対応
// Requirements: 2.1, 2.3, 6.2, 6.4, 9.5, 9.7

using System.Threading;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using View_RTSP.Services;

namespace View_RTSP.Tests.Services;

/// <summary>
/// VideoFrameRenderer のユニットテスト
/// </summary>
public class VideoFrameRendererTests : IDisposable
{
    private readonly VideoFrameRenderer _sut;
    private readonly Dispatcher _dispatcher;

    public VideoFrameRendererTests()
    {
        // WPF Dispatcher を初期化（テスト用の STA スレッドで実行）
        _dispatcher = Dispatcher.CurrentDispatcher;
        _sut = new VideoFrameRenderer(_dispatcher);
    }

    public void Dispose()
    {
        _sut.Dispose();
    }

    // ─── 初期状態テスト ──────────────────────────────────────────

    /// <summary>
    /// 初期状態では CurrentBitmap は null
    /// Requirements: 2.5（未接続時プレースホルダー状態）
    /// </summary>
    [Fact]
    [System.STAThread]
    public void CurrentBitmap_Initially_IsNull()
    {
        // Arrange: コンストラクタで初期化済み

        // Assert
        Assert.Null(_sut.CurrentBitmap);
    }

    // ─── RenderFrame テスト ──────────────────────────────────────

    /// <summary>
    /// RenderFrame を呼び出すと CurrentBitmap が生成される
    /// Requirements: 9.5（WritableBitmap への直接描画）
    /// </summary>
    [Fact]
    [System.STAThread]
    public void RenderFrame_WithValidData_CreatesBitmap()
    {
        // Arrange
        const int width = 320;
        const int height = 240;
        var bgraData = CreateBgraData(width, height);
        WriteableBitmap? capturedBitmap = null;
        var resetEvent = new ManualResetEventSlim(false);

        _sut.BitmapUpdated += (_, bitmap) =>
        {
            capturedBitmap = bitmap;
            resetEvent.Set();
        };

        // Act
        _sut.RenderFrame(bgraData, width, height);

        // Dispatcher のキューを処理
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
        resetEvent.Wait(TimeSpan.FromSeconds(2));

        // Assert
        Assert.NotNull(_sut.CurrentBitmap);
        Assert.Equal(width, _sut.CurrentBitmap!.PixelWidth);
        Assert.Equal(height, _sut.CurrentBitmap.PixelHeight);
    }

    /// <summary>
    /// 同じ解像度のフレームを描画しても WritableBitmap は再生成されない
    /// Requirements: 9.5（解像度変更時のみ WritableBitmap を再生成）
    /// </summary>
    [Fact]
    [System.STAThread]
    public void RenderFrame_SameResolution_DoesNotRecreateBitmap()
    {
        // Arrange
        const int width = 320;
        const int height = 240;
        var bgraData = CreateBgraData(width, height);

        _sut.RenderFrame(bgraData, width, height);
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

        var firstBitmap = _sut.CurrentBitmap;

        // Act: 同じ解像度で再度描画
        _sut.RenderFrame(bgraData, width, height);
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

        // Assert: 同じ WritableBitmap インスタンスを再利用
        Assert.Same(firstBitmap, _sut.CurrentBitmap);
    }

    /// <summary>
    /// 解像度が変わった場合は WritableBitmap を再生成する
    /// Requirements: 9.5（解像度変更時の WritableBitmap 再生成）
    /// </summary>
    [Fact]
    [System.STAThread]
    public void RenderFrame_DifferentResolution_RecreatesBitmap()
    {
        // Arrange
        const int width1 = 320;
        const int height1 = 240;
        const int width2 = 640;
        const int height2 = 480;

        var bgraData1 = CreateBgraData(width1, height1);
        var bgraData2 = CreateBgraData(width2, height2);

        _sut.RenderFrame(bgraData1, width1, height1);
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

        var firstBitmap = _sut.CurrentBitmap;

        // Act: 異なる解像度で描画
        _sut.RenderFrame(bgraData2, width2, height2);
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

        // Assert: 新しい WritableBitmap が生成される
        Assert.NotNull(_sut.CurrentBitmap);
        Assert.NotSame(firstBitmap, _sut.CurrentBitmap);
        Assert.Equal(width2, _sut.CurrentBitmap!.PixelWidth);
        Assert.Equal(height2, _sut.CurrentBitmap.PixelHeight);
    }

    /// <summary>
    /// bgraData の長さが width * height * 4 と異なる場合は ArgumentException をスローする
    /// Requirements: 事前条件検証
    /// </summary>
    [Fact]
    [System.STAThread]
    public void RenderFrame_WithInvalidDataLength_ThrowsArgumentException()
    {
        // Arrange: 不正なデータ長（width * height * 4 より短い）
        const int width = 320;
        const int height = 240;
        var invalidData = new byte[100]; // 正しくは 320 * 240 * 4 = 307200

        // Act & Assert
        Assert.Throws<ArgumentException>(() =>
            _sut.RenderFrame(invalidData, width, height));
    }

    // ─── BitmapUpdated イベントテスト ───────────────────────────

    /// <summary>
    /// RenderFrame 後に BitmapUpdated イベントが発行される
    /// Requirements: 2.1（リアルタイムフレーム表示）
    /// </summary>
    [Fact]
    [System.STAThread]
    public void RenderFrame_AfterRender_RaisesBitmapUpdatedEvent()
    {
        // Arrange
        const int width = 320;
        const int height = 240;
        var bgraData = CreateBgraData(width, height);
        var eventRaised = false;
        var resetEvent = new ManualResetEventSlim(false);

        _sut.BitmapUpdated += (_, _) =>
        {
            eventRaised = true;
            resetEvent.Set();
        };

        // Act
        _sut.RenderFrame(bgraData, width, height);
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
        resetEvent.Wait(TimeSpan.FromSeconds(2));

        // Assert
        Assert.True(eventRaised);
    }

    /// <summary>
    /// BitmapUpdated イベントのペイロードは CurrentBitmap と同じインスタンス
    /// </summary>
    [Fact]
    [System.STAThread]
    public void RenderFrame_BitmapUpdatedEvent_ProvidesCurrentBitmap()
    {
        // Arrange
        const int width = 320;
        const int height = 240;
        var bgraData = CreateBgraData(width, height);
        WriteableBitmap? eventBitmap = null;
        var resetEvent = new ManualResetEventSlim(false);

        _sut.BitmapUpdated += (_, bitmap) =>
        {
            eventBitmap = bitmap;
            resetEvent.Set();
        };

        // Act
        _sut.RenderFrame(bgraData, width, height);
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
        resetEvent.Wait(TimeSpan.FromSeconds(2));

        // Assert
        Assert.NotNull(eventBitmap);
        Assert.Same(_sut.CurrentBitmap, eventBitmap);
    }

    // ─── Clear テスト ─────────────────────────────────────────

    /// <summary>
    /// Clear() を呼び出すと CurrentBitmap が null にリセットされる
    /// Requirements: Clear() 呼び出しでプレースホルダー状態にリセット
    /// </summary>
    [Fact]
    [System.STAThread]
    public void Clear_AfterRenderFrame_SetsBitmapToNull()
    {
        // Arrange: 先にフレームを描画して CurrentBitmap を生成
        const int width = 320;
        const int height = 240;
        var bgraData = CreateBgraData(width, height);

        _sut.RenderFrame(bgraData, width, height);
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

        Assert.NotNull(_sut.CurrentBitmap);

        // Act
        _sut.Clear();
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

        // Assert
        Assert.Null(_sut.CurrentBitmap);
    }

    /// <summary>
    /// Clear() は初期状態（CurrentBitmap == null）からでも安全に呼び出せる
    /// Requirements: 不変条件（Clear() はいつでも呼び出し可能）
    /// </summary>
    [Fact]
    [System.STAThread]
    public void Clear_WhenBitmapIsAlreadyNull_DoesNotThrow()
    {
        // Arrange: 初期状態（CurrentBitmap == null）

        // Act & Assert: 例外がスローされない
        var exception = Record.Exception(() =>
        {
            _sut.Clear();
            _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
        });

        Assert.Null(exception);
    }

    /// <summary>
    /// Clear() の後に RenderFrame を再度呼び出すと正常に動作する
    /// Requirements: Clear() 後の再利用可能性
    /// </summary>
    [Fact]
    [System.STAThread]
    public void Clear_ThenRenderFrame_WorksCorrectly()
    {
        // Arrange
        const int width = 320;
        const int height = 240;
        var bgraData = CreateBgraData(width, height);

        _sut.RenderFrame(bgraData, width, height);
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
        _sut.Clear();
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

        Assert.Null(_sut.CurrentBitmap);

        // Act: Clear() 後に再度 RenderFrame
        _sut.RenderFrame(bgraData, width, height);
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

        // Assert
        Assert.NotNull(_sut.CurrentBitmap);
        Assert.Equal(width, _sut.CurrentBitmap!.PixelWidth);
        Assert.Equal(height, _sut.CurrentBitmap.PixelHeight);
    }

    // ─── フレームスキップテスト ──────────────────────────────────

    /// <summary>
    /// 複数のフレームを高速に連続送信した場合に例外が発生しない
    /// Requirements: 6.4（フレームレート低下時の継続表示、古いフレームスキップ）
    /// </summary>
    [Fact]
    [System.STAThread]
    public void RenderFrame_HighFrequencyFrames_DoesNotThrow()
    {
        // Arrange
        const int width = 1920;
        const int height = 1080;
        var bgraData = CreateBgraData(width, height);

        // Act: 高速で複数フレームをエンキュー
        var exception = Record.Exception(() =>
        {
            for (int i = 0; i < 10; i++)
            {
                _sut.RenderFrame(bgraData, width, height);
            }
            _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);
        });

        // Assert: 例外が発生しない
        Assert.Null(exception);
    }

    /// <summary>
    /// 高速連続フレーム送信後、最終的に CurrentBitmap が正しい解像度を持つ
    /// Requirements: 6.4（最新フレームのみ描画）
    /// </summary>
    [Fact]
    [System.STAThread]
    public void RenderFrame_HighFrequencyFrames_CurrentBitmapHasCorrectSize()
    {
        // Arrange
        const int width = 1280;
        const int height = 720;
        var bgraData = CreateBgraData(width, height);

        // Act: 連続フレーム送信
        for (int i = 0; i < 5; i++)
        {
            _sut.RenderFrame(bgraData, width, height);
        }
        _dispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

        // Assert: 正しい解像度を持つ
        Assert.NotNull(_sut.CurrentBitmap);
        Assert.Equal(width, _sut.CurrentBitmap!.PixelWidth);
        Assert.Equal(height, _sut.CurrentBitmap.PixelHeight);
    }

    // ─── Dispose テスト ──────────────────────────────────────────

    /// <summary>
    /// Dispose 後に RenderFrame を呼び出しても ObjectDisposedException がスローされる
    /// Requirements: リソース管理
    /// </summary>
    [Fact]
    [System.STAThread]
    public void RenderFrame_AfterDispose_ThrowsObjectDisposedException()
    {
        // Arrange
        const int width = 320;
        const int height = 240;
        var bgraData = CreateBgraData(width, height);
        var renderer = new VideoFrameRenderer(_dispatcher);
        renderer.Dispose();

        // Act & Assert
        Assert.Throws<ObjectDisposedException>(() =>
            renderer.RenderFrame(bgraData, width, height));
    }

    /// <summary>
    /// Dispose を複数回呼び出しても例外が発生しない
    /// Requirements: IDisposable パターンの冪等性
    /// </summary>
    [Fact]
    [System.STAThread]
    public void Dispose_CalledMultipleTimes_DoesNotThrow()
    {
        // Arrange
        var renderer = new VideoFrameRenderer(_dispatcher);

        // Act & Assert
        var exception = Record.Exception(() =>
        {
            renderer.Dispose();
            renderer.Dispose();
        });

        Assert.Null(exception);
    }

    // ─── ヘルパーメソッド ─────────────────────────────────────

    /// <summary>
    /// 指定サイズの BGRA テストデータを生成する
    /// </summary>
    private static byte[] CreateBgraData(int width, int height)
    {
        var data = new byte[width * height * 4];
        // テスト用に各ピクセルをグラデーションで埋める（B=x%256, G=y%256, R=0, A=255）
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                int offset = (y * width + x) * 4;
                data[offset] = (byte)(x % 256);     // B
                data[offset + 1] = (byte)(y % 256); // G
                data[offset + 2] = 0;               // R
                data[offset + 3] = 255;             // A
            }
        }
        return data;
    }
}
