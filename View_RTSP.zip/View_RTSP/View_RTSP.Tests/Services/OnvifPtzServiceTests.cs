// ONVIF PTZ サービスのユニットテスト
// タスク 5.1, 5.2 に対応
// Requirements: 7.1, 7.2, 7.3, 7.4, 7.6, 7.7, 7.8

using System.Threading;
using System.Threading.Tasks;
using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.Services.OnvifAdapters;
using Xunit;

namespace View_RTSP.Tests.Services;

/// <summary>
/// OnvifPtzService のユニットテスト。
/// Onvif.Core のネイティブ SOAP 通信は IOnvifClientFactory をモックして分離する。
/// </summary>
public class OnvifPtzServiceTests
{
    // ─── テスト対象・モック ────────────────────────────────────────────

    private readonly Mock<IOnvifClientFactory> _mockFactory;
    private readonly Mock<IOnvifDeviceClient> _mockDevice;
    private readonly Mock<IOnvifMediaClient> _mockMedia;
    private readonly Mock<IOnvifPtzClient> _mockPtz;
    private readonly OnvifPtzService _sut;

    // テスト用の接続オプション（PTZ 対応カメラ想定）
    private static readonly OnvifConnectionOptions ValidOptions = new(
        EndpointUrl: "http://192.168.1.100/onvif/device_service",
        Username: "admin",
        Password: "password",
        ProfileToken: null
    );

    private static readonly OnvifConnectionOptions OptionsWithToken = new(
        EndpointUrl: "http://192.168.1.100/onvif/device_service",
        Username: "admin",
        Password: "password",
        ProfileToken: "Profile_1"
    );

    public OnvifPtzServiceTests()
    {
        _mockFactory = new Mock<IOnvifClientFactory>();
        _mockDevice = new Mock<IOnvifDeviceClient>();
        _mockMedia = new Mock<IOnvifMediaClient>();
        _mockPtz = new Mock<IOnvifPtzClient>();
        _sut = new OnvifPtzService(_mockFactory.Object);
    }

    // ─── 5.1: GetPtzCapabilitiesAsync テスト ──────────────────────────

    /// <summary>
    /// カメラが PTZ をサポートしている場合、GetPtzCapabilitiesAsync は true を返す。
    /// Requirements: 7.1, 7.6
    /// </summary>
    [Fact]
    public async Task GetPtzCapabilitiesAsync_WhenCameraSupportsPtz_ReturnsTrue()
    {
        // Arrange: PTZ XAddr が存在するレスポンスを返すファクトリをセットアップ
        _mockFactory
            .Setup(f => f.CreateDeviceClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockDevice.Object);
        _mockFactory
            .Setup(f => f.CreateMediaClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockMedia.Object);

        _mockDevice
            .Setup(d => d.GetCapabilitiesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new OnvifCapabilitiesResult { HasPtz = true });

        _mockMedia
            .Setup(m => m.GetProfilesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new[] { new OnvifProfileInfo { Token = "Profile_1", Name = "MainStream" } });

        // Act
        var result = await _sut.GetPtzCapabilitiesAsync(ValidOptions);

        // Assert
        Assert.True(result);
    }

    /// <summary>
    /// カメラが PTZ をサポートしていない場合、GetPtzCapabilitiesAsync は false を返す。
    /// Requirements: 7.6（非対応カメラ）
    /// </summary>
    [Fact]
    public async Task GetPtzCapabilitiesAsync_WhenCameraDoesNotSupportPtz_ReturnsFalse()
    {
        // Arrange
        _mockFactory
            .Setup(f => f.CreateDeviceClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockDevice.Object);

        _mockDevice
            .Setup(d => d.GetCapabilitiesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new OnvifCapabilitiesResult { HasPtz = false });

        // Act
        var result = await _sut.GetPtzCapabilitiesAsync(ValidOptions);

        // Assert
        Assert.False(result);
    }

    /// <summary>
    /// ファクトリが例外をスローした場合、GetPtzCapabilitiesAsync は例外をスローせず false を返す。
    /// Requirements: 7.6（接続失敗時は false）
    /// </summary>
    [Fact]
    public async Task GetPtzCapabilitiesAsync_WhenConnectionFails_ReturnsFalseWithoutThrowing()
    {
        // Arrange: ファクトリが接続エラーをスロー
        _mockFactory
            .Setup(f => f.CreateDeviceClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(new InvalidOperationException("接続に失敗しました"));

        // Act & Assert: 例外がスローされないこと
        var result = await _sut.GetPtzCapabilitiesAsync(ValidOptions);
        Assert.False(result);
    }

    /// <summary>
    /// GetCapabilities が例外をスローした場合、false を返して例外を伝播しない。
    /// Requirements: 7.6
    /// </summary>
    [Fact]
    public async Task GetPtzCapabilitiesAsync_WhenGetCapabilitiesThrows_ReturnsFalse()
    {
        // Arrange
        _mockFactory
            .Setup(f => f.CreateDeviceClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockDevice.Object);

        _mockDevice
            .Setup(d => d.GetCapabilitiesAsync(It.IsAny<CancellationToken>()))
            .ThrowsAsync(new System.ServiceModel.CommunicationException("SOAP エラー"));

        // Act
        var result = await _sut.GetPtzCapabilitiesAsync(ValidOptions);

        // Assert
        Assert.False(result);
    }

    /// <summary>
    /// ProfileToken が null の場合、GetProfiles() で最初のプロファイルを自動取得してキャッシュする。
    /// Requirements: 7.1（プロファイル自動選択）
    /// </summary>
    [Fact]
    public async Task GetPtzCapabilitiesAsync_WhenProfileTokenIsNull_AutoSelectsFirstProfile()
    {
        // Arrange
        _mockFactory
            .Setup(f => f.CreateDeviceClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockDevice.Object);
        _mockFactory
            .Setup(f => f.CreateMediaClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockMedia.Object);

        _mockDevice
            .Setup(d => d.GetCapabilitiesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new OnvifCapabilitiesResult { HasPtz = true });

        _mockMedia
            .Setup(m => m.GetProfilesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new[] { new OnvifProfileInfo { Token = "AutoProfile_1", Name = "MainStream" } });

        // Act
        var result = await _sut.GetPtzCapabilitiesAsync(ValidOptions);

        // Assert: GetProfiles が呼び出されてプロファイルが自動取得されること
        Assert.True(result);
        _mockMedia.Verify(m => m.GetProfilesAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    /// <summary>
    /// ProfileToken が指定されている場合、GetProfiles() は呼び出されない。
    /// Requirements: 7.1
    /// </summary>
    [Fact]
    public async Task GetPtzCapabilitiesAsync_WhenProfileTokenSpecified_DoesNotCallGetProfiles()
    {
        // Arrange
        _mockFactory
            .Setup(f => f.CreateDeviceClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockDevice.Object);
        _mockFactory
            .Setup(f => f.CreateMediaClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockMedia.Object);

        _mockDevice
            .Setup(d => d.GetCapabilitiesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new OnvifCapabilitiesResult { HasPtz = true });

        // Act
        var result = await _sut.GetPtzCapabilitiesAsync(OptionsWithToken);

        // Assert: GetProfiles が呼び出されないこと（トークンは指定済み）
        Assert.True(result);
        _mockMedia.Verify(m => m.GetProfilesAsync(It.IsAny<CancellationToken>()), Times.Never);
    }

    /// <summary>
    /// CancellationToken がキャンセルされた場合、false を返して例外をスローしない。
    /// Requirements: 7.6
    /// </summary>
    [Fact]
    public async Task GetPtzCapabilitiesAsync_WhenCancelled_ReturnsFalse()
    {
        // Arrange
        using var cts = new CancellationTokenSource();
        cts.Cancel();

        _mockFactory
            .Setup(f => f.CreateDeviceClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(new TaskCanceledException());

        // Act
        var result = await _sut.GetPtzCapabilitiesAsync(ValidOptions, cts.Token);

        // Assert
        Assert.False(result);
    }

    // ─── 5.2: StartMoveAsync テスト ───────────────────────────────────

    /// <summary>
    /// 有効なオプションで StartMoveAsync を呼び出すと、ContinuousMove コマンドが送信される。
    /// Requirements: 7.2, 7.3, 7.7
    /// </summary>
    [Fact]
    public async Task StartMoveAsync_WithValidOptions_SendsContinuousMoveCommand()
    {
        // Arrange: PTZ 接続を確立済みと想定
        SetupPtzClientFactory();

        // Act
        await _sut.StartMoveAsync(OptionsWithToken, PtzDirection.Up, 0.5f);

        // Assert: ContinuousMove が呼び出されること
        _mockPtz.Verify(
            p => p.ContinuousMoveAsync(
                It.Is<string>(t => t == "Profile_1"),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// PTZ コマンドが失敗した場合、StartMoveAsync は例外を伝播する（呼び出し元でキャッチして RTSP 継続）。
    /// Requirements: 7.8（コマンド失敗時は例外を伝達）
    /// </summary>
    [Fact]
    public async Task StartMoveAsync_WhenPtzCommandFails_ThrowsException()
    {
        // Arrange
        SetupPtzClientFactory();
        _mockPtz
            .Setup(p => p.ContinuousMoveAsync(
                It.IsAny<string>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new System.ServiceModel.CommunicationException("PTZ コマンド失敗"));

        // Act & Assert: 例外が呼び出し元に伝播すること
        await Assert.ThrowsAsync<System.ServiceModel.CommunicationException>(
            () => _sut.StartMoveAsync(OptionsWithToken, PtzDirection.Up, 0.5f));
    }

    /// <summary>
    /// すべての PTZ 方向で ContinuousMove が正しいパン・チルト速度で送信される。
    /// Requirements: 7.3（8 方向制御）
    /// </summary>
    [Theory]
    [InlineData(PtzDirection.Up, 0f, 1f)]
    [InlineData(PtzDirection.Down, 0f, -1f)]
    [InlineData(PtzDirection.Left, -1f, 0f)]
    [InlineData(PtzDirection.Right, 1f, 0f)]
    [InlineData(PtzDirection.UpLeft, -1f, 1f)]
    [InlineData(PtzDirection.UpRight, 1f, 1f)]
    [InlineData(PtzDirection.DownLeft, -1f, -1f)]
    [InlineData(PtzDirection.DownRight, 1f, -1f)]
    public async Task StartMoveAsync_ForEachDirection_SendsCorrectPanTiltValues(
        PtzDirection direction, float expectedPan, float expectedTilt)
    {
        // Arrange
        SetupPtzClientFactory();
        float capturedPan = 0f;
        float capturedTilt = 0f;

        _mockPtz
            .Setup(p => p.ContinuousMoveAsync(
                It.IsAny<string>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Callback<string, float, float, float, CancellationToken>(
                (token, pan, tilt, zoom, ct) =>
                {
                    capturedPan = pan;
                    capturedTilt = tilt;
                })
            .Returns(Task.CompletedTask);

        // Act
        await _sut.StartMoveAsync(OptionsWithToken, direction, 1.0f);

        // Assert: パン・チルト速度の符号が方向と一致すること
        Assert.Equal(expectedPan, capturedPan / (capturedPan == 0 ? 1 : Math.Abs(capturedPan)), 1);
        Assert.Equal(expectedTilt, capturedTilt / (capturedTilt == 0 ? 1 : Math.Abs(capturedTilt)), 1);
    }

    // ─── 5.2: StopMoveAsync テスト ────────────────────────────────────

    /// <summary>
    /// 有効なオプションで StopMoveAsync を呼び出すと、Stop コマンドが送信される。
    /// Requirements: 7.3（Stop コマンド）
    /// </summary>
    [Fact]
    public async Task StopMoveAsync_WithValidOptions_SendsStopCommand()
    {
        // Arrange
        SetupPtzClientFactory();

        // Act
        await _sut.StopMoveAsync(OptionsWithToken);

        // Assert: Stop が呼び出されること
        _mockPtz.Verify(
            p => p.StopAsync(
                It.Is<string>(t => t == "Profile_1"),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// PTZ Stop コマンドが失敗した場合、例外を伝播する。
    /// Requirements: 7.8
    /// </summary>
    [Fact]
    public async Task StopMoveAsync_WhenCommandFails_ThrowsException()
    {
        // Arrange
        SetupPtzClientFactory();
        _mockPtz
            .Setup(p => p.StopAsync(
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new System.ServiceModel.CommunicationException("Stop コマンド失敗"));

        // Act & Assert
        await Assert.ThrowsAsync<System.ServiceModel.CommunicationException>(
            () => _sut.StopMoveAsync(OptionsWithToken));
    }

    // ─── 5.2: ZoomAsync テスト ────────────────────────────────────────

    /// <summary>
    /// 正のズーム速度で ZoomAsync を呼び出すと、ズームイン コマンドが送信される。
    /// Requirements: 7.4（ズームイン）
    /// </summary>
    [Fact]
    public async Task ZoomAsync_WithPositiveSpeed_SendsZoomInCommand()
    {
        // Arrange
        SetupPtzClientFactory();
        float capturedZoom = 0f;
        _mockPtz
            .Setup(p => p.ContinuousMoveAsync(
                It.IsAny<string>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Callback<string, float, float, float, CancellationToken>(
                (token, pan, tilt, zoom, ct) => { capturedZoom = zoom; })
            .Returns(Task.CompletedTask);

        // Act: 正のズーム速度（ズームイン）
        await _sut.ZoomAsync(OptionsWithToken, 0.8f);

        // Assert: ズーム速度が正であること
        Assert.True(capturedZoom > 0);
    }

    /// <summary>
    /// 負のズーム速度で ZoomAsync を呼び出すと、ズームアウト コマンドが送信される。
    /// Requirements: 7.4（ズームアウト）
    /// </summary>
    [Fact]
    public async Task ZoomAsync_WithNegativeSpeed_SendsZoomOutCommand()
    {
        // Arrange
        SetupPtzClientFactory();
        float capturedZoom = 0f;
        _mockPtz
            .Setup(p => p.ContinuousMoveAsync(
                It.IsAny<string>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Callback<string, float, float, float, CancellationToken>(
                (token, pan, tilt, zoom, ct) => { capturedZoom = zoom; })
            .Returns(Task.CompletedTask);

        // Act: 負のズーム速度（ズームアウト）
        await _sut.ZoomAsync(OptionsWithToken, -0.8f);

        // Assert: ズーム速度が負であること
        Assert.True(capturedZoom < 0);
    }

    /// <summary>
    /// PTZ Zoom コマンドが失敗した場合、例外を伝播する。
    /// Requirements: 7.8
    /// </summary>
    [Fact]
    public async Task ZoomAsync_WhenCommandFails_ThrowsException()
    {
        // Arrange
        SetupPtzClientFactory();
        _mockPtz
            .Setup(p => p.ContinuousMoveAsync(
                It.IsAny<string>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new System.ServiceModel.CommunicationException("Zoom コマンド失敗"));

        // Act & Assert
        await Assert.ThrowsAsync<System.ServiceModel.CommunicationException>(
            () => _sut.ZoomAsync(OptionsWithToken, 0.5f));
    }

    // ─── ProfileToken 自動解決テスト ─────────────────────────────────

    /// <summary>
    /// ProfileToken が null の場合、StartMoveAsync は GetProfiles() で取得したトークンを使用する。
    /// Requirements: 7.1（プロファイル自動選択）
    /// </summary>
    [Fact]
    public async Task StartMoveAsync_WhenProfileTokenIsNull_UsesAutoResolvedToken()
    {
        // Arrange: PTZ 接続オプション（ProfileToken = null）
        SetupPtzClientFactoryWithMediaAutoResolve("AutoToken_123");

        string? capturedToken = null;
        _mockPtz
            .Setup(p => p.ContinuousMoveAsync(
                It.IsAny<string>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Callback<string, float, float, float, CancellationToken>(
                (token, pan, tilt, zoom, ct) => { capturedToken = token; })
            .Returns(Task.CompletedTask);

        // Act: ProfileToken = null のオプションで移動
        await _sut.StartMoveAsync(ValidOptions, PtzDirection.Up, 0.5f);

        // Assert: 自動取得したトークンが使用されること
        Assert.Equal("AutoToken_123", capturedToken);
    }

    // ─── ヘルパーメソッド ──────────────────────────────────────────────

    /// <summary>
    /// ProfileToken が指定されている場合の PTZ ファクトリセットアップ
    /// </summary>
    private void SetupPtzClientFactory()
    {
        _mockFactory
            .Setup(f => f.CreatePtzClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockPtz.Object);

        _mockPtz
            .Setup(p => p.ContinuousMoveAsync(
                It.IsAny<string>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        _mockPtz
            .Setup(p => p.StopAsync(
                It.IsAny<string>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);
    }

    /// <summary>
    /// ProfileToken = null の場合にメディアクライアントで自動解決するファクトリセットアップ
    /// </summary>
    private void SetupPtzClientFactoryWithMediaAutoResolve(string autoToken)
    {
        _mockFactory
            .Setup(f => f.CreatePtzClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockPtz.Object);

        _mockFactory
            .Setup(f => f.CreateMediaClientAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(_mockMedia.Object);

        _mockMedia
            .Setup(m => m.GetProfilesAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new[] { new OnvifProfileInfo { Token = autoToken, Name = "MainStream" } });

        _mockPtz
            .Setup(p => p.ContinuousMoveAsync(
                It.IsAny<string>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);
    }
}
