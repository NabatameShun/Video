// StreamPaneViewModel 録画機能統合のユニットテスト
// タスク 4.1, 4.2, 4.3
// Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 3.2, 5.1, 5.2, 5.4

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.ViewModels;

/// <summary>
/// StreamPaneViewModel の録画コマンドと状態プロパティのテスト
/// </summary>
public class StreamPaneViewModelRecordingCommandTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly Mock<IRecordingService> _mockRecordingService;

    public StreamPaneViewModelRecordingCommandTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();
        _mockRecordingService = new Mock<IRecordingService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
    }

    private StreamPaneViewModel CreateSut()
    {
        return new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object,
            _mockRecordingService.Object);
    }

    // ─── IsRecording プロパティ ──────────────────────────────────

    [Fact]
    public void IsRecording_Initially_IsFalse()
    {
        var sut = CreateSut();
        Assert.False(sut.IsRecording);
    }

    // ─── RecordingElapsedTime プロパティ ─────────────────────────

    [Fact]
    public void RecordingElapsedTime_Initially_IsEmpty()
    {
        var sut = CreateSut();
        Assert.Equal(string.Empty, sut.RecordingElapsedTime);
    }

    // ─── RecordingFolderPath プロパティ ──────────────────────────

    [Fact]
    public void RecordingFolderPath_Initially_IsEmpty()
    {
        var sut = CreateSut();
        Assert.Equal(string.Empty, sut.RecordingFolderPath);
    }

    // ─── CanToggleRecording ─────────────────────────────────────

    [Fact]
    public void CanToggleRecording_WhenDisconnected_ReturnsFalse()
    {
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Disconnected;

        Assert.False(sut.CanToggleRecording());
    }

    [Fact]
    public void CanToggleRecording_WhenConnectedAndIdle_ReturnsTrue()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connected;

        Assert.True(sut.CanToggleRecording());
    }

    [Fact]
    public void CanToggleRecording_WhenConnectedAndRecording_ReturnsTrue()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Recording);
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connected;

        Assert.True(sut.CanToggleRecording());
    }

    [Fact]
    public void CanToggleRecording_WhenConnectedAndStopping_ReturnsFalse()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Stopping);
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connected;

        Assert.False(sut.CanToggleRecording());
    }

    [Fact]
    public void CanToggleRecording_WhenConnecting_ReturnsFalse()
    {
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connecting;

        Assert.False(sut.CanToggleRecording());
    }

    // ─── ToggleRecording コマンド ────────────────────────────────

    [Fact]
    public void ToggleRecording_WhenIdle_CallsStart()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connected;
        sut.RecordingFolderPath = @"C:\TestPath";

        sut.ToggleRecording();

        _mockRecordingService.Verify(s => s.Start(
            It.IsAny<string>(),
            It.IsAny<Sdcb.FFmpeg.Codecs.CodecParameters>(),
            It.IsAny<Sdcb.FFmpeg.Raw.AVRational>(),
            It.IsAny<string?>()), Times.Once);
    }

    [Fact]
    public void ToggleRecording_WhenRecording_CallsStop()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Recording);
        var sut = CreateSut();
        sut.ConnectionState = ConnectionState.Connected;

        sut.ToggleRecording();

        _mockRecordingService.Verify(s => s.Stop(), Times.Once);
    }
}

/// <summary>
/// StreamPaneViewModel の録画イベントハンドリングのテスト
/// </summary>
public class StreamPaneViewModelRecordingEventTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly Mock<IRecordingService> _mockRecordingService;

    public StreamPaneViewModelRecordingEventTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();
        _mockRecordingService = new Mock<IRecordingService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
    }

    private StreamPaneViewModel CreateSut()
    {
        return new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object,
            _mockRecordingService.Object);
    }

    [Fact]
    public void RecordingError_SetsErrorMessage()
    {
        var sut = CreateSut();

        // RecordingError イベントを発火
        _mockRecordingService.Raise(
            s => s.RecordingError += null,
            _mockRecordingService.Object,
            new RecordingErrorEventArgs(RecordingErrorKind.DiskWriteError, "ディスクエラー"));

        Assert.Equal("ディスクエラー", sut.ErrorMessage);
    }

    [Fact]
    public void RecordingStateChanged_ToRecording_SetsIsRecordingTrue()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Recording);
        var sut = CreateSut();

        // StateChanged イベントを発火
        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Recording);

        Assert.True(sut.IsRecording);
    }

    [Fact]
    public void RecordingStateChanged_ToIdle_SetsIsRecordingFalse()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        var sut = CreateSut();

        // 一度 Recording にしてから Idle に
        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Recording);

        _mockRecordingService.Raise(
            s => s.StateChanged += null,
            _mockRecordingService.Object,
            RecordingState.Idle);

        Assert.False(sut.IsRecording);
    }
}

/// <summary>
/// StreamPaneViewModel の RTSP 切断時自動録画停止テスト
/// </summary>
public class StreamPaneViewModelRecordingDisconnectTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;
    private readonly Mock<IRecordingService> _mockRecordingService;

    public StreamPaneViewModelRecordingDisconnectTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();
        _mockRecordingService = new Mock<IRecordingService>();

        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
    }

    private StreamPaneViewModel CreateSut()
    {
        return new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object,
            _mockRecordingService.Object);
    }

    [Fact]
    public void RtspDisconnect_WhenRecording_StopsRecording()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Recording);
        var sut = CreateSut();

        // RTSP 切断イベント発火
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            _mockRtspService.Object,
            new StreamStateChangedEventArgs(ConnectionState.Disconnected));

        _mockRecordingService.Verify(s => s.Stop(), Times.Once);
    }

    [Fact]
    public void RtspDisconnect_WhenNotRecording_DoesNotCallStop()
    {
        _mockRecordingService.Setup(s => s.State).Returns(RecordingState.Idle);
        var sut = CreateSut();

        // RTSP 切断イベント発火
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            _mockRtspService.Object,
            new StreamStateChangedEventArgs(ConnectionState.Disconnected));

        _mockRecordingService.Verify(s => s.Stop(), Times.Never);
    }

    [Fact]
    public void RtspReconnect_DoesNotAutoStartRecording()
    {
        var sut = CreateSut();

        // RTSP 再接続イベント発火
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            _mockRtspService.Object,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockRecordingService.Verify(s => s.Start(
            It.IsAny<string>(),
            It.IsAny<Sdcb.FFmpeg.Codecs.CodecParameters>(),
            It.IsAny<Sdcb.FFmpeg.Raw.AVRational>(),
            It.IsAny<string?>()), Times.Never);
    }
}

/// <summary>
/// StreamPaneViewModel のコンストラクタ互換性テスト
/// (旧4引数コンストラクタが引き続き動作することを確認)
/// </summary>
public class StreamPaneViewModelConstructorCompatTests
{
    [Fact]
    public void OldConstructor_StillWorks_WithFourArgs()
    {
        var rtspService = new Mock<IRtspStreamService>();
        var renderer = new Mock<IVideoFrameRenderer>();
        var onvifService = new Mock<IOnvifPtzService>();
        var settingsService = new Mock<ISettingsService>();

        rtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        settingsService.Setup(s => s.Load()).Returns(AppSettings.Default);

        var sut = new StreamPaneViewModel(
            rtspService.Object,
            renderer.Object,
            onvifService.Object,
            settingsService.Object);

        Assert.NotNull(sut);
        Assert.False(sut.IsRecording);
    }
}
