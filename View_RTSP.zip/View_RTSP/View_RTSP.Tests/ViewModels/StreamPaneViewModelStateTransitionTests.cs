// StreamPaneViewModel 状態遷移ユニットテスト
// タスク 11.1 に対応
// Requirements: 1.4, 1.6, 1.7, 7.6

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.ViewModels;

/// <summary>
/// StreamPaneViewModel の状態遷移に特化したユニットテスト。
/// ConnectCommand → Connecting → Connected / Error、
/// DisconnectCommand → Disconnected、PTZ 有効フラグの切り替えを検証する。
/// Requirements: 1.4, 1.6, 1.7, 7.6
/// </summary>
public class StreamPaneViewModelStateTransitionTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;

    public StreamPaneViewModelStateTransitionTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();

        // デフォルト設定
        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
    }

    private StreamPaneViewModel CreateSut()
    {
        return new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);
    }

    // ─── ConnectCommand → Connecting 状態遷移テスト ────────────────

    /// <summary>
    /// ConnectAsync 実行時に ConnectionState が Connecting に遷移する
    /// Requirements: 1.7（接続中ステータス表示）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithValidUrl_TransitionsToConnectingState()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "rtsp://192.168.1.100/stream1";

        ConnectionState? stateAtServiceCall = null;

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Callback(() => stateAtServiceCall = sut.ConnectionState)
            .Returns(Task.CompletedTask);

        // Act
        await sut.ConnectAsync();

        // Assert: サービス呼び出し時点で Connecting 状態であることを確認
        Assert.Equal(ConnectionState.Connecting, stateAtServiceCall);
    }

    /// <summary>
    /// ConnectAsync 実行後にサービスが Connected イベントを発行すると
    /// ConnectionState が Connected に遷移する
    /// Requirements: 1.7（接続状態表示）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WhenServiceFiresConnectedEvent_TransitionsToConnectedState()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "rtsp://192.168.1.100/stream1";

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Callback(() =>
            {
                // ConnectAsync 中にサービスが Connected イベントを発行するシナリオをシミュレート
                _mockRtspService.Raise(
                    s => s.StateChanged += null,
                    new StreamStateChangedEventArgs(ConnectionState.Connected));
            })
            .Returns(Task.CompletedTask);

        // Act
        await sut.ConnectAsync();

        // Assert: Connected 状態に遷移している
        Assert.Equal(ConnectionState.Connected, sut.ConnectionState);
    }

    /// <summary>
    /// ConnectAsync 実行後にサービスが Error イベントを発行すると
    /// ConnectionState が Error に遷移し、エラーメッセージが設定される
    /// Requirements: 1.5（接続失敗エラーメッセージ）, 1.7（接続状態表示）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WhenServiceFiresErrorEvent_TransitionsToErrorStateWithMessage()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "rtsp://192.168.1.100/stream1";

        var rtspError = new RtspError(RtspErrorKind.ConnectionTimeout, "接続タイムアウト: サーバーに到達できません", null);

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Callback(() =>
            {
                // サービスが Error イベントを発行するシナリオをシミュレート
                _mockRtspService.Raise(
                    s => s.StateChanged += null,
                    new StreamStateChangedEventArgs(ConnectionState.Error, rtspError));
            })
            .Returns(Task.CompletedTask);

        // Act
        await sut.ConnectAsync();

        // Assert: Error 状態に遷移し、エラーメッセージが設定される
        Assert.Equal(ConnectionState.Error, sut.ConnectionState);
        Assert.NotNull(sut.ErrorMessage);
        Assert.Contains("接続タイムアウト", sut.ErrorMessage);
    }

    /// <summary>
    /// ConnectAsync 実行後にサービスが AuthenticationFailed イベントを発行すると
    /// エラーメッセージに認証失敗の情報が含まれる
    /// Requirements: 5.3（認証失敗エラーメッセージ）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WhenServiceFiresAuthFailedEvent_SetsAuthErrorMessage()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "rtsp://192.168.1.100/stream1";
        sut.Username = "wronguser";
        sut.Password = "wrongpass";

        var rtspError = new RtspError(
            RtspErrorKind.AuthenticationFailed,
            "認証失敗: ユーザー名またはパスワードを確認してください",
            null);

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Callback(() =>
            {
                _mockRtspService.Raise(
                    s => s.StateChanged += null,
                    new StreamStateChangedEventArgs(ConnectionState.Error, rtspError));
            })
            .Returns(Task.CompletedTask);

        // Act
        await sut.ConnectAsync();

        // Assert
        Assert.Equal(ConnectionState.Error, sut.ConnectionState);
        Assert.NotNull(sut.ErrorMessage);
        Assert.Contains("認証失敗", sut.ErrorMessage);
    }

    // ─── DisconnectCommand → Disconnected 状態遷移テスト ──────────

    /// <summary>
    /// Disconnect 実行後、サービスが Disconnected イベントを発行すると
    /// ConnectionState が Disconnected に遷移する
    /// Requirements: 1.6（切断ボタンで接続切断）
    /// </summary>
    [Fact]
    public void Disconnect_WhenServiceFiresDisconnectedEvent_TransitionsToDisconnectedState()
    {
        // Arrange
        var sut = CreateSut();

        // 事前に Connected 状態にする
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));
        Assert.Equal(ConnectionState.Connected, sut.ConnectionState);

        _mockRtspService
            .Setup(s => s.Disconnect())
            .Callback(() =>
            {
                // Disconnect 呼び出し後にサービスが Disconnected イベントを発行
                _mockRtspService.Raise(
                    s => s.StateChanged += null,
                    new StreamStateChangedEventArgs(ConnectionState.Disconnected));
            });

        // Act
        sut.Disconnect();

        // Assert: Disconnected 状態に遷移している
        Assert.Equal(ConnectionState.Disconnected, sut.ConnectionState);
    }

    /// <summary>
    /// Disconnect 実行後に ConnectionState が Disconnected になると
    /// StatusMessage が「未接続」に更新される
    /// Requirements: 1.6, 1.7
    /// </summary>
    [Fact]
    public void Disconnect_AfterConnected_UpdatesStatusMessageToDisconnected()
    {
        // Arrange
        var sut = CreateSut();

        // 接続状態にする
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockRtspService
            .Setup(s => s.Disconnect())
            .Callback(() =>
            {
                _mockRtspService.Raise(
                    s => s.StateChanged += null,
                    new StreamStateChangedEventArgs(ConnectionState.Disconnected));
            });

        // Act
        sut.Disconnect();

        // Assert
        Assert.Equal(ConnectionState.Disconnected, sut.ConnectionState);
        Assert.Equal("未接続", sut.StatusMessage);
    }

    // ─── RTSP URL バリデーション詳細テスト ─────────────────────────

    /// <summary>
    /// rtsp:// と rtsps:// の両方が有効と判定される
    /// Requirements: 1.4（URL バリデーション）
    /// </summary>
    [Theory]
    [InlineData("rtsp://192.168.1.100/stream1")]
    [InlineData("rtsp://user:pass@192.168.1.100:554/stream")]
    [InlineData("rtsp://localhost/stream")]
    [InlineData("RTSP://192.168.1.100/stream1")]  // 大文字スキーム
    public void IsUrlValid_WithValidRtspUrls_ReturnsTrue(string url)
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = url;

        // Act
        var result = sut.IsUrlValid();

        // Assert
        Assert.True(result);
    }

    /// <summary>
    /// 不正スキームの URL は ConnectAsync を呼び出しても接続を試みない
    /// Requirements: 1.4（不正スキームの接続ブロック）
    /// </summary>
    [Theory]
    [InlineData("http://192.168.1.100/stream")]
    [InlineData("https://192.168.1.100/stream")]
    [InlineData("ftp://192.168.1.100/stream")]
    public async Task ConnectAsync_WithNonRtspScheme_DoesNotCallRtspService(string invalidUrl)
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = invalidUrl;

        // Act
        await sut.ConnectAsync();

        // Assert: サービスは呼び出されない
        _mockRtspService.Verify(
            s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    /// <summary>
    /// 空文字列または空白文字の URL は ConnectAsync を呼び出しても接続を試みない
    /// Requirements: 1.4（空 URL の接続ブロック）
    /// </summary>
    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public async Task ConnectAsync_WithEmptyUrl_DoesNotCallRtspService(string emptyUrl)
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = emptyUrl;

        // Act
        await sut.ConnectAsync();

        // Assert: サービスは呼び出されない
        _mockRtspService.Verify(
            s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    // ─── PTZ 有効フラグ切り替えテスト ─────────────────────────────

    /// <summary>
    /// ONVIF エンドポイント未設定の場合、CheckPtzCapabilitiesAsync は IsPtzEnabled を false にする
    /// Requirements: 7.6（PTZ 有効フラグの管理）
    /// </summary>
    [Fact]
    public async Task CheckPtzCapabilities_WhenEndpointUrlEmpty_SetsPtzDisabled()
    {
        // Arrange
        var sut = CreateSut();
        sut.OnvifEndpointUrl = string.Empty;  // エンドポイント未設定

        // Act
        await sut.CheckPtzCapabilitiesAsync();

        // Assert
        Assert.False(sut.IsPtzEnabled);
        // サービスは呼び出されない
        _mockOnvifService.Verify(
            s => s.GetPtzCapabilitiesAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    /// <summary>
    /// GetPtzCapabilitiesAsync が例外をスローした場合、IsPtzEnabled が false に設定される
    /// Requirements: 7.6（PTZ 非対応時の UI 無効化）
    /// </summary>
    [Fact]
    public async Task CheckPtzCapabilities_WhenServiceThrows_SetsPtzDisabled()
    {
        // Arrange
        var sut = CreateSut();
        sut.OnvifEndpointUrl = "http://192.168.1.100/onvif/device_service";
        sut.OnvifUsername = "admin";
        sut.OnvifPassword = "password";

        _mockOnvifService
            .Setup(s => s.GetPtzCapabilitiesAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new Exception("ONVIF 接続タイムアウト"));

        // Act
        await sut.CheckPtzCapabilitiesAsync();

        // Assert: 例外が発生しても IsPtzEnabled は false になり、アプリはクラッシュしない
        Assert.False(sut.IsPtzEnabled);
    }

    /// <summary>
    /// PTZ 対応確認後（true）に IsPtzEnabled が true に切り替わり、
    /// その後非対応確認（false）で false に切り替わる
    /// Requirements: 7.6（PTZ 有効フラグの動的切り替え）
    /// </summary>
    [Fact]
    public async Task CheckPtzCapabilities_FlipsIsPtzEnabled_BasedOnCapabilityResult()
    {
        // Arrange
        var sut = CreateSut();
        sut.OnvifEndpointUrl = "http://192.168.1.100/onvif/device_service";
        sut.OnvifUsername = "admin";
        sut.OnvifPassword = "password";

        // 1回目: PTZ 対応
        _mockOnvifService
            .Setup(s => s.GetPtzCapabilitiesAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        await sut.CheckPtzCapabilitiesAsync();
        Assert.True(sut.IsPtzEnabled);

        // 2回目: PTZ 非対応
        _mockOnvifService
            .Setup(s => s.GetPtzCapabilitiesAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);

        await sut.CheckPtzCapabilitiesAsync();

        // Assert: false に切り替わっている
        Assert.False(sut.IsPtzEnabled);
    }

    // ─── 接続状態と StatusMessage の一貫性テスト ──────────────────

    /// <summary>
    /// ConnectAsync 実行中（Connecting 状態）に StatusMessage が「接続中...」になる
    /// Requirements: 1.7（接続中ステータス表示）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithValidUrl_SetsStatusMessageToConnecting()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "rtsp://192.168.1.100/stream1";

        string? statusAtServiceCall = null;

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Callback(() => statusAtServiceCall = sut.StatusMessage)
            .Returns(Task.CompletedTask);

        // Act
        await sut.ConnectAsync();

        // Assert: サービス呼び出し時点でステータスメッセージが「接続中...」
        Assert.Equal("接続中...", statusAtServiceCall);
    }

    /// <summary>
    /// Connected イベント受信後に StatusMessage が「接続済み」になる
    /// Requirements: 1.7（接続状態表示）
    /// </summary>
    [Fact]
    public void StateChanged_Connected_SetsStatusMessageToConnected()
    {
        // Arrange
        var sut = CreateSut();

        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // Assert
        Assert.Equal("接続済み", sut.StatusMessage);
        Assert.Null(sut.ErrorMessage);  // エラーメッセージはクリアされる
    }

    /// <summary>
    /// Error イベント受信後に StatusMessage が「エラー」になる
    /// Requirements: 1.7（接続状態表示）
    /// </summary>
    [Fact]
    public void StateChanged_Error_SetsStatusMessageToError()
    {
        // Arrange
        var sut = CreateSut();
        var error = new RtspError(RtspErrorKind.NetworkUnreachable, "ネットワーク不達", null);

        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Error, error));

        // Assert
        Assert.Equal("エラー", sut.StatusMessage);
        Assert.Equal(ConnectionState.Error, sut.ConnectionState);
    }
}
