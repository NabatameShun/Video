// StreamPaneViewModel のユニットテスト
// タスク 6.1, 6.2 に対応
// Requirements: 1.1, 1.2, 1.4, 1.5, 1.6, 1.7, 2.1, 3.2, 5.2, 5.3, 5.5, 6.3, 7.2, 7.3, 7.4, 7.6, 7.8, 8.2, 8.7, 8.8

using System.Windows.Media.Imaging;
using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.ViewModels;

/// <summary>
/// StreamPaneViewModel のユニットテスト
/// </summary>
public class StreamPaneViewModelTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;

    public StreamPaneViewModelTests()
    {
        _mockRtspService = new Mock<IRtspStreamService>();
        _mockRenderer = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();

        // デフォルト設定
        _mockRtspService.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
    }

    private StreamPaneViewModel CreateSut()
    {
        return new StreamPaneViewModel(
            _mockRtspService.Object,
            _mockRenderer.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);
    }

    // ─── 6.1: URL バリデーションテスト ────────────────────────────

    /// <summary>
    /// 正常な RTSP URL は有効と判定される
    /// Requirements: 1.4（URL バリデーション）
    /// </summary>
    [Fact]
    public void ValidateUrl_WithValidRtspUrl_ReturnsTrue()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "rtsp://192.168.1.100/stream1";

        // Act
        var result = sut.IsUrlValid();

        // Assert
        Assert.True(result);
    }

    /// <summary>
    /// rtsp:// スキーム以外の URL は無効と判定される
    /// Requirements: 1.4（不正スキームの拒否）
    /// </summary>
    [Theory]
    [InlineData("http://192.168.1.100/stream1")]
    [InlineData("https://192.168.1.100/stream1")]
    [InlineData("ftp://192.168.1.100/stream1")]
    [InlineData("192.168.1.100/stream1")]
    public void ValidateUrl_WithNonRtspScheme_ReturnsFalse(string url)
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = url;

        // Act
        var result = sut.IsUrlValid();

        // Assert
        Assert.False(result);
    }

    /// <summary>
    /// 空文字の URL は無効と判定される
    /// Requirements: 1.4（空 URL の拒否）
    /// </summary>
    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData(null)]
    public void ValidateUrl_WithEmptyOrNullUrl_ReturnsFalse(string? url)
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = url ?? string.Empty;

        // Act
        var result = sut.IsUrlValid();

        // Assert
        Assert.False(result);
    }

    /// <summary>
    /// 不正な URL の場合、ConnectCommand 実行でエラーメッセージが設定される
    /// Requirements: 1.4（エラーメッセージ表示）
    /// </summary>
    [Fact]
    public async Task ConnectCommand_WithInvalidUrl_SetsErrorMessage()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "http://invalid-url";

        // Act
        await sut.ConnectAsync();

        // Assert
        Assert.NotNull(sut.ErrorMessage);
        Assert.NotEmpty(sut.ErrorMessage);
        // 接続サービスは呼ばれていない
        _mockRtspService.Verify(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    /// <summary>
    /// 不正な URL の場合、ConnectionState は Disconnected のまま
    /// Requirements: 1.4（接続試みない）
    /// </summary>
    [Fact]
    public async Task ConnectCommand_WithInvalidUrl_StateRemainsDisconnected()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "not-rtsp://something";

        // Act
        await sut.ConnectAsync();

        // Assert
        Assert.Equal(ConnectionState.Disconnected, sut.ConnectionState);
    }

    // ─── 6.1: 接続状態管理テスト ──────────────────────────────────

    /// <summary>
    /// 初期状態は Disconnected
    /// Requirements: 1.7（接続状態表示）
    /// </summary>
    [Fact]
    public void InitialState_IsDisconnected()
    {
        // Arrange & Act
        var sut = CreateSut();

        // Assert
        Assert.Equal(ConnectionState.Disconnected, sut.ConnectionState);
    }

    /// <summary>
    /// ConnectCommand 実行時、接続中状態へ遷移して接続サービスを呼び出す
    /// Requirements: 1.2（接続ボタンで接続開始）, 1.7（接続中ステータス）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithValidUrl_CallsRtspServiceConnectAsync()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "rtsp://192.168.1.100/stream1";

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await sut.ConnectAsync();

        // Assert
        _mockRtspService.Verify(
            s => s.ConnectAsync(
                It.Is<RtspConnectionOptions>(o => o.Url == "rtsp://192.168.1.100/stream1"),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// 認証情報が設定されている場合、接続オプションに含まれる
    /// Requirements: 5.2（認証情報を用いた接続）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithCredentials_PassesCredentialsToService()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "rtsp://192.168.1.100/stream1";
        sut.Username = "admin";
        sut.Password = "secret";

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await sut.ConnectAsync();

        // Assert
        _mockRtspService.Verify(
            s => s.ConnectAsync(
                It.Is<RtspConnectionOptions>(o =>
                    o.Username == "admin" &&
                    o.Password == "secret"),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// 認証情報なしでも接続できる
    /// Requirements: 5.5（認証なし接続サポート）
    /// </summary>
    [Fact]
    public async Task ConnectAsync_WithoutCredentials_CallsServiceWithNullCredentials()
    {
        // Arrange
        var sut = CreateSut();
        sut.RtspUrl = "rtsp://192.168.1.100/stream1";
        sut.Username = string.Empty;
        sut.Password = string.Empty;

        _mockRtspService
            .Setup(s => s.ConnectAsync(It.IsAny<RtspConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await sut.ConnectAsync();

        // Assert
        _mockRtspService.Verify(
            s => s.ConnectAsync(
                It.Is<RtspConnectionOptions>(o =>
                    o.Username == null &&
                    o.Password == null),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// StateChanged イベント（Connected）を受信すると ConnectionState が更新される
    /// Requirements: 1.7（接続状態表示）
    /// </summary>
    [Fact]
    public void StateChanged_ConnectedEvent_UpdatesConnectionState()
    {
        // Arrange
        var sut = CreateSut();

        // Act: StateChanged イベントを発行
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // Assert
        Assert.Equal(ConnectionState.Connected, sut.ConnectionState);
    }

    /// <summary>
    /// StateChanged イベント（Error）を受信するとエラーメッセージが設定される
    /// Requirements: 1.5（接続失敗エラーメッセージ）, 5.3（認証失敗エラー）
    /// </summary>
    [Fact]
    public void StateChanged_ErrorEvent_SetsErrorMessage()
    {
        // Arrange
        var sut = CreateSut();
        var error = new RtspError(RtspErrorKind.AuthenticationFailed, "認証に失敗しました", null);

        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Error, error));

        // Assert
        Assert.NotNull(sut.ErrorMessage);
        Assert.Contains("認証に失敗しました", sut.ErrorMessage);
    }

    /// <summary>
    /// StateChanged イベント（Disconnected）を受信すると ConnectionState が Disconnected になる
    /// Requirements: 3.2（切断後に未接続状態へ遷移）
    /// </summary>
    [Fact]
    public void StateChanged_DisconnectedEvent_UpdatesConnectionState()
    {
        // Arrange
        var sut = CreateSut();

        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Disconnected));

        // Assert
        Assert.Equal(ConnectionState.Disconnected, sut.ConnectionState);
    }

    /// <summary>
    /// DisconnectAsync 実行後、ConnectionState が Disconnected になる
    /// Requirements: 1.6（切断ボタンで切断）
    /// </summary>
    [Fact]
    public void Disconnect_CallsRtspServiceDisconnect()
    {
        // Arrange
        var sut = CreateSut();

        // Act
        sut.Disconnect();

        // Assert
        _mockRtspService.Verify(s => s.Disconnect(), Times.Once);
    }

    /// <summary>
    /// StatsUpdated イベントを受信すると Stats プロパティが更新される
    /// Requirements: 6.3（フレームレート・接続状態表示）
    /// </summary>
    [Fact]
    public void StatsUpdated_Event_UpdatesStatsProperty()
    {
        // Arrange
        var sut = CreateSut();
        var stats = new ConnectionStats(30.0, 1500, TimeSpan.FromMinutes(1));

        // Act
        // EventHandler<ConnectionStats> は (object sender, ConnectionStats e) シグネチャなので
        // sender として null を渡す
        _mockRtspService.Raise(
            s => s.StatsUpdated += null,
            (object?)null,
            stats);

        // Assert
        Assert.Equal(30.0, sut.Stats.FrameRate);
        Assert.Equal(1500, sut.Stats.ReceivedFrames);
    }

    // ─── 6.2: VideoFrame 受信テスト ───────────────────────────────

    /// <summary>
    /// BitmapUpdated イベントを受信すると VideoFrame プロパティが更新される
    /// Requirements: 2.1（リアルタイムフレーム表示）
    /// </summary>
    [Fact]
    public void BitmapUpdated_Event_UpdatesVideoFrameProperty()
    {
        // Arrange
        // WriteableBitmap は STA スレッドが必要なため、STA スレッド上でテストを実行する
        WriteableBitmap? capturedBitmap = null;
        WriteableBitmap? videoFrame = null;
        Exception? threadException = null;

        var thread = new Thread(() =>
        {
            try
            {
                var sut = new StreamPaneViewModel(
                    _mockRtspService.Object,
                    _mockRenderer.Object,
                    _mockOnvifService.Object,
                    _mockSettingsService.Object);

                capturedBitmap = new WriteableBitmap(
                    640, 480, 96.0, 96.0,
                    System.Windows.Media.PixelFormats.Bgra32, null);

                // Act
                _mockRenderer.Raise(
                    r => r.BitmapUpdated += null,
                    (object?)null,
                    capturedBitmap);

                videoFrame = sut.VideoFrame;
            }
            catch (Exception ex)
            {
                threadException = ex;
            }
        });

        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        thread.Join();

        // スレッド内例外を再スロー
        if (threadException != null)
            throw new Exception("STA スレッド内でエラーが発生しました", threadException);

        // Assert
        Assert.NotNull(capturedBitmap);
        Assert.Equal(capturedBitmap, videoFrame);
    }

    // ─── 6.2: PTZ コマンドテスト ─────────────────────────────────

    /// <summary>
    /// IsPtzEnabled が false の場合、PTZ コマンドは実行されない
    /// Requirements: 7.6（PTZ 非対応カメラでの UI 無効化）
    /// </summary>
    [Fact]
    public async Task StartMoveCommand_WhenPtzDisabled_DoesNotCallService()
    {
        // Arrange
        var sut = CreateSut();
        // IsPtzEnabled はデフォルト false

        // Act
        await sut.StartMoveAsync(PtzDirection.Up);

        // Assert
        _mockOnvifService.Verify(
            s => s.StartMoveAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<PtzDirection>(), It.IsAny<float>(), It.IsAny<CancellationToken>()),
            Times.Never);
    }

    /// <summary>
    /// IsPtzEnabled が true の場合、StartMoveCommand は ONVIF サービスを呼び出す
    /// Requirements: 7.2, 7.3（ContinuousMove コマンド）
    /// </summary>
    [Fact]
    public async Task StartMoveCommand_WhenPtzEnabled_CallsOnvifService()
    {
        // Arrange
        var sut = CreateSut();
        sut.OnvifEndpointUrl = "http://192.168.1.100/onvif/device_service";
        sut.OnvifUsername = "admin";
        sut.OnvifPassword = "password";
        sut.IsPtzEnabled = true;

        _mockOnvifService
            .Setup(s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<PtzDirection>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await sut.StartMoveAsync(PtzDirection.Up);

        // Assert
        _mockOnvifService.Verify(
            s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                PtzDirection.Up,
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// StopMoveCommand は ONVIF サービスの StopMove を呼び出す
    /// Requirements: 7.3（Stop コマンド）
    /// </summary>
    [Fact]
    public async Task StopMoveCommand_WhenPtzEnabled_CallsOnvifServiceStop()
    {
        // Arrange
        var sut = CreateSut();
        sut.OnvifEndpointUrl = "http://192.168.1.100/onvif/device_service";
        sut.OnvifUsername = "admin";
        sut.OnvifPassword = "password";
        sut.IsPtzEnabled = true;

        _mockOnvifService
            .Setup(s => s.StopMoveAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await sut.StopMoveAsync();

        // Assert
        _mockOnvifService.Verify(
            s => s.StopMoveAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// ZoomCommand は ONVIF サービスの Zoom を呼び出す
    /// Requirements: 7.4（ズーム制御コマンド）
    /// </summary>
    [Fact]
    public async Task ZoomCommand_WhenPtzEnabled_CallsOnvifServiceZoom()
    {
        // Arrange
        var sut = CreateSut();
        sut.OnvifEndpointUrl = "http://192.168.1.100/onvif/device_service";
        sut.OnvifUsername = "admin";
        sut.OnvifPassword = "password";
        sut.IsPtzEnabled = true;

        _mockOnvifService
            .Setup(s => s.ZoomAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<float>(), It.IsAny<CancellationToken>()))
            .Returns(Task.CompletedTask);

        // Act
        await sut.ZoomAsync(0.5f);

        // Assert
        _mockOnvifService.Verify(
            s => s.ZoomAsync(It.IsAny<OnvifConnectionOptions>(), 0.5f, It.IsAny<CancellationToken>()),
            Times.Once);
    }

    /// <summary>
    /// PTZ コマンド失敗時もエラーメッセージを設定し RTSP 状態を維持する
    /// Requirements: 7.8（PTZ エラー時の RTSP 継続表示）
    /// </summary>
    [Fact]
    public async Task StartMoveCommand_WhenServiceThrows_SetsErrorMessageAndContinues()
    {
        // Arrange
        var sut = CreateSut();
        sut.OnvifEndpointUrl = "http://192.168.1.100/onvif/device_service";
        sut.OnvifUsername = "admin";
        sut.OnvifPassword = "password";
        sut.IsPtzEnabled = true;

        // 接続状態を Connected に設定
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        _mockOnvifService
            .Setup(s => s.StartMoveAsync(
                It.IsAny<OnvifConnectionOptions>(),
                It.IsAny<PtzDirection>(),
                It.IsAny<float>(),
                It.IsAny<CancellationToken>()))
            .ThrowsAsync(new Exception("PTZ コマンド失敗"));

        // Act
        await sut.StartMoveAsync(PtzDirection.Up);

        // Assert: エラーメッセージが設定される
        Assert.NotNull(sut.ErrorMessage);
        // RTSP の接続状態は維持される
        Assert.Equal(ConnectionState.Connected, sut.ConnectionState);
    }

    /// <summary>
    /// GetPtzCapabilitiesAsync が true を返した場合、IsPtzEnabled が true になる
    /// Requirements: 7.6（PTZ 有効フラグの設定）
    /// </summary>
    [Fact]
    public async Task CheckPtzCapabilities_WhenSupported_SetsPtzEnabled()
    {
        // Arrange
        var sut = CreateSut();
        sut.OnvifEndpointUrl = "http://192.168.1.100/onvif/device_service";
        sut.OnvifUsername = "admin";
        sut.OnvifPassword = "password";

        _mockOnvifService
            .Setup(s => s.GetPtzCapabilitiesAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(true);

        // Act
        await sut.CheckPtzCapabilitiesAsync();

        // Assert
        Assert.True(sut.IsPtzEnabled);
    }

    /// <summary>
    /// GetPtzCapabilitiesAsync が false を返した場合、IsPtzEnabled が false のまま
    /// Requirements: 7.6（PTZ 非対応カメラの UI 無効化）
    /// </summary>
    [Fact]
    public async Task CheckPtzCapabilities_WhenNotSupported_PtzRemainsDisabled()
    {
        // Arrange
        var sut = CreateSut();
        sut.OnvifEndpointUrl = "http://192.168.1.100/onvif/device_service";
        sut.OnvifUsername = "admin";
        sut.OnvifPassword = "password";

        _mockOnvifService
            .Setup(s => s.GetPtzCapabilitiesAsync(It.IsAny<OnvifConnectionOptions>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(false);

        // Act
        await sut.CheckPtzCapabilitiesAsync();

        // Assert
        Assert.False(sut.IsPtzEnabled);
    }

    // ─── 6.2: 設定読み込みテスト ──────────────────────────────────

    /// <summary>
    /// LoadSettingsFromService で設定サービスから設定を読み込む
    /// Requirements: 8.2（各ペインの独立 URL・認証情報設定）
    /// </summary>
    [Fact]
    public void LoadSettings_WithPaneSettings_UpdatesViewModelProperties()
    {
        // Arrange
        var paneSettings = new StreamPaneSettings(
            RtspUrl: "rtsp://192.168.1.100/stream1",
            Username: "admin",
            EncryptedPassword: null,
            Transport: RtspTransport.Tcp,
            OnvifEndpointUrl: "http://192.168.1.100/onvif/device_service",
            OnvifUsername: "admin",
            OnvifEncryptedPassword: null);

        var sut = CreateSut();

        // Act
        sut.LoadSettings(paneSettings, decryptedPassword: null, decryptedOnvifPassword: null);

        // Assert
        Assert.Equal("rtsp://192.168.1.100/stream1", sut.RtspUrl);
        Assert.Equal("admin", sut.Username);
        Assert.Equal("http://192.168.1.100/onvif/device_service", sut.OnvifEndpointUrl);
        Assert.Equal("admin", sut.OnvifUsername);
    }

    // ─── INotifyPropertyChanged テスト ───────────────────────────

    /// <summary>
    /// ConnectionState が変わると PropertyChanged イベントが発行される
    /// Requirements: 1.7（バインド可能プロパティ）
    /// </summary>
    [Fact]
    public void ConnectionState_WhenChanged_RaisesPropertyChanged()
    {
        // Arrange
        var sut = CreateSut();
        var raisedProperties = new List<string>();
        sut.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName != null)
                raisedProperties.Add(e.PropertyName);
        };

        // Act
        _mockRtspService.Raise(
            s => s.StateChanged += null,
            new StreamStateChangedEventArgs(ConnectionState.Connected));

        // Assert
        Assert.Contains(nameof(sut.ConnectionState), raisedProperties);
    }

    /// <summary>
    /// RtspUrl プロパティが変わると PropertyChanged イベントが発行される
    /// </summary>
    [Fact]
    public void RtspUrl_WhenChanged_RaisesPropertyChanged()
    {
        // Arrange
        var sut = CreateSut();
        var raisedProperties = new List<string>();
        sut.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName != null)
                raisedProperties.Add(e.PropertyName);
        };

        // Act
        sut.RtspUrl = "rtsp://new-url/stream";

        // Assert
        Assert.Contains(nameof(sut.RtspUrl), raisedProperties);
    }
}
