// MainWindowViewModel のユニットテスト
// タスク 6.3 に対応
// Requirements: 4.3, 4.6, 8.1, 8.4

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.ViewModels;

/// <summary>
/// MainWindowViewModel のユニットテスト
/// </summary>
public class MainWindowViewModelTests
{
    private readonly Mock<IRtspStreamService> _mockRtspService1;
    private readonly Mock<IRtspStreamService> _mockRtspService2;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer1;
    private readonly Mock<IVideoFrameRenderer> _mockRenderer2;
    private readonly Mock<IOnvifPtzService> _mockOnvifService;
    private readonly Mock<ISettingsService> _mockSettingsService;

    public MainWindowViewModelTests()
    {
        _mockRtspService1 = new Mock<IRtspStreamService>();
        _mockRtspService2 = new Mock<IRtspStreamService>();
        _mockRenderer1 = new Mock<IVideoFrameRenderer>();
        _mockRenderer2 = new Mock<IVideoFrameRenderer>();
        _mockOnvifService = new Mock<IOnvifPtzService>();
        _mockSettingsService = new Mock<ISettingsService>();

        _mockRtspService1.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockRtspService2.Setup(s => s.State).Returns(ConnectionState.Disconnected);
        _mockSettingsService.Setup(s => s.Load()).Returns(AppSettings.Default);
    }

    private MainWindowViewModel CreateSut()
    {
        var pane1Vm = new StreamPaneViewModel(
            _mockRtspService1.Object,
            _mockRenderer1.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);

        var pane2Vm = new StreamPaneViewModel(
            _mockRtspService2.Object,
            _mockRenderer2.Object,
            _mockOnvifService.Object,
            _mockSettingsService.Object);

        return new MainWindowViewModel(
            pane1Vm,
            pane2Vm,
            _mockSettingsService.Object);
    }

    // ─── Pane 管理テスト ──────────────────────────────────────────

    /// <summary>
    /// MainWindowViewModel は Pane1 と Pane2 を所有する
    /// Requirements: 8.1（2ペイン並列表示）
    /// </summary>
    [Fact]
    public void Constructor_CreatesTwoPaneViewModels()
    {
        // Arrange & Act
        var sut = CreateSut();

        // Assert
        Assert.NotNull(sut.Pane1);
        Assert.NotNull(sut.Pane2);
        Assert.NotSame(sut.Pane1, sut.Pane2);
    }

    // ─── レイアウト切り替えテスト ─────────────────────────────────

    /// <summary>
    /// 初期レイアウトは Horizontal
    /// Requirements: 8.4（左右・上下分割レイアウト選択）
    /// </summary>
    [Fact]
    public void InitialLayout_IsHorizontal()
    {
        // Arrange & Act
        var sut = CreateSut();

        // Assert
        Assert.Equal(DualPaneLayout.Horizontal, sut.Layout);
    }

    /// <summary>
    /// ToggleLayout で Horizontal から Vertical に切り替わる
    /// Requirements: 8.4（左右・上下分割レイアウト選択）
    /// </summary>
    [Fact]
    public void ToggleLayout_FromHorizontal_SwitchesToVertical()
    {
        // Arrange
        var sut = CreateSut();
        Assert.Equal(DualPaneLayout.Horizontal, sut.Layout);

        // Act
        sut.ToggleLayout();

        // Assert
        Assert.Equal(DualPaneLayout.Vertical, sut.Layout);
    }

    /// <summary>
    /// ToggleLayout で Vertical から Horizontal に切り替わる
    /// Requirements: 8.4
    /// </summary>
    [Fact]
    public void ToggleLayout_FromVertical_SwitchesToHorizontal()
    {
        // Arrange
        var sut = CreateSut();
        sut.ToggleLayout(); // Horizontal -> Vertical

        // Act
        sut.ToggleLayout(); // Vertical -> Horizontal

        // Assert
        Assert.Equal(DualPaneLayout.Horizontal, sut.Layout);
    }

    /// <summary>
    /// Layout が変わると PropertyChanged が発行される
    /// </summary>
    [Fact]
    public void Layout_WhenChanged_RaisesPropertyChanged()
    {
        // Arrange
        var sut = CreateSut();
        var raisedProperties = new List<string>();
        sut.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName != null)
                raisedProperties.Add(e.PropertyName);
        };

        // Act
        sut.ToggleLayout();

        // Assert
        Assert.Contains(nameof(sut.Layout), raisedProperties);
    }

    // ─── アプリ終了処理テスト ─────────────────────────────────────

    /// <summary>
    /// OnClosing で両ペインを切断してから設定を保存する
    /// Requirements: 4.3（ウィンドウ閉じる時の切断・終了処理）
    /// </summary>
    [Fact]
    public void OnClosing_DisconnectsBothPanes_ThenSavesSettings()
    {
        // Arrange
        var sut = CreateSut();

        // Act
        sut.OnClosing();

        // Assert: 両サービスの Disconnect が呼ばれる
        _mockRtspService1.Verify(s => s.Disconnect(), Times.Once);
        _mockRtspService2.Verify(s => s.Disconnect(), Times.Once);
        // 設定が保存される
        _mockSettingsService.Verify(s => s.Save(It.IsAny<AppSettings>()), Times.Once);
    }

    /// <summary>
    /// OnClosing で設定保存が Disconnect の後に呼ばれる（順序確認）
    /// Requirements: 4.3
    /// </summary>
    [Fact]
    public void OnClosing_SavesSettingsAfterDisconnect()
    {
        // Arrange
        var sut = CreateSut();
        var callOrder = new List<string>();

        _mockRtspService1.Setup(s => s.Disconnect()).Callback(() => callOrder.Add("Disconnect1"));
        _mockRtspService2.Setup(s => s.Disconnect()).Callback(() => callOrder.Add("Disconnect2"));
        _mockSettingsService.Setup(s => s.Save(It.IsAny<AppSettings>())).Callback<AppSettings>(_ => callOrder.Add("Save"));

        // Act
        sut.OnClosing();

        // Assert: Save は Disconnect の後
        var saveIndex = callOrder.IndexOf("Save");
        var disconnect1Index = callOrder.IndexOf("Disconnect1");
        var disconnect2Index = callOrder.IndexOf("Disconnect2");

        Assert.True(saveIndex > disconnect1Index, "Save は Disconnect1 の後に呼ばれる必要があります");
        Assert.True(saveIndex > disconnect2Index, "Save は Disconnect2 の後に呼ばれる必要があります");
    }

    // ─── 起動時設定読み込みテスト ─────────────────────────────────

    /// <summary>
    /// LoadSettings で SettingsService から設定を読み込み各 ViewModel に反映する
    /// Requirements: 8.4（起動時設定読み込み）
    /// </summary>
    [Fact]
    public void LoadSettings_ReadsFromService_AndAppliesLayout()
    {
        // Arrange
        var settings = new AppSettings(
            Pane1: new StreamPaneSettings(
                RtspUrl: "rtsp://192.168.1.100/stream1",
                Username: "user1",
                EncryptedPassword: null,
                Transport: RtspTransport.Tcp,
                OnvifEndpointUrl: null,
                OnvifUsername: null,
                OnvifEncryptedPassword: null),
            Pane2: StreamPaneSettings.Default,
            Layout: DualPaneLayout.Vertical);

        _mockSettingsService.Setup(s => s.Load()).Returns(settings);

        // Act
        var sut = CreateSut();
        sut.LoadSettings();

        // Assert
        Assert.Equal(DualPaneLayout.Vertical, sut.Layout);
        Assert.Equal("rtsp://192.168.1.100/stream1", sut.Pane1.RtspUrl);
    }

    /// <summary>
    /// OnClosing で保存される設定に現在のレイアウトが含まれる
    /// Requirements: 4.6（RTSP URL の永続化）
    /// </summary>
    [Fact]
    public void OnClosing_SavesCurrentLayoutInSettings()
    {
        // Arrange
        var sut = CreateSut();
        sut.ToggleLayout(); // Horizontal -> Vertical

        AppSettings? savedSettings = null;
        _mockSettingsService.Setup(s => s.Save(It.IsAny<AppSettings>()))
            .Callback<AppSettings>(s => savedSettings = s);

        // Act
        sut.OnClosing();

        // Assert
        Assert.NotNull(savedSettings);
        Assert.Equal(DualPaneLayout.Vertical, savedSettings!.Layout);
    }

    /// <summary>
    /// OnClosing で保存される設定に両ペインの URL が含まれる
    /// Requirements: 4.6
    /// </summary>
    [Fact]
    public void OnClosing_SavesBothPaneUrls()
    {
        // Arrange
        var sut = CreateSut();
        sut.Pane1.RtspUrl = "rtsp://192.168.1.100/stream1";
        sut.Pane2.RtspUrl = "rtsp://192.168.1.200/stream2";

        AppSettings? savedSettings = null;
        _mockSettingsService.Setup(s => s.Save(It.IsAny<AppSettings>()))
            .Callback<AppSettings>(s => savedSettings = s);

        // Act
        sut.OnClosing();

        // Assert
        Assert.NotNull(savedSettings);
        Assert.Equal("rtsp://192.168.1.100/stream1", savedSettings!.Pane1.RtspUrl);
        Assert.Equal("rtsp://192.168.1.200/stream2", savedSettings!.Pane2.RtspUrl);
    }
}
