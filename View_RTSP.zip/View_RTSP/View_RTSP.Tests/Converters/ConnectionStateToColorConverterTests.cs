// タスク 7.2: ConnectionStateToColorConverter のユニットテスト
// TDD: RED フェーズ - テストを先に記述する

using System.Globalization;
using System.Windows.Media;
using View_RTSP.Converters;
using View_RTSP.Models;

namespace View_RTSP.Tests.Converters;

/// <summary>
/// ConnectionStateToColorConverter のユニットテスト。
/// 接続状態（Disconnected / Connecting / Connected / Error）に対して
/// 期待するブラシが返されることを検証する。
/// </summary>
public class ConnectionStateToColorConverterTests
{
    private readonly ConnectionStateToColorConverter _converter = new();
    private readonly CultureInfo _culture = CultureInfo.InvariantCulture;

    // ─── Convert メソッドのテスト ─────────────────────────────────────

    [Fact]
    public void Convert_WhenConnected_ReturnsSolidColorBrushGreen()
    {
        // Arrange
        var state = ConnectionState.Connected;

        // Act
        var result = _converter.Convert(state, typeof(Brush), null, _culture);

        // Assert
        var brush = Assert.IsType<SolidColorBrush>(result);
        // 緑: #4CAF50 相当（接続中）
        Assert.Equal(Colors.Green.A, brush.Color.A);
        Assert.True(brush.Color.G > brush.Color.R, "緑成分が赤成分より大きいこと（グリーン系）");
    }

    [Fact]
    public void Convert_WhenConnecting_ReturnsSolidColorBrushBlue()
    {
        // Arrange
        var state = ConnectionState.Connecting;

        // Act
        var result = _converter.Convert(state, typeof(Brush), null, _culture);

        // Assert
        var brush = Assert.IsType<SolidColorBrush>(result);
        // 青: 0078D4 相当（接続試行中）
        Assert.True(brush.Color.B > brush.Color.R, "青成分が赤成分より大きいこと（ブルー系）");
    }

    [Fact]
    public void Convert_WhenDisconnected_ReturnsSolidColorBrushGray()
    {
        // Arrange
        var state = ConnectionState.Disconnected;

        // Act
        var result = _converter.Convert(state, typeof(Brush), null, _culture);

        // Assert
        var brush = Assert.IsType<SolidColorBrush>(result);
        // グレー: R ≒ G ≒ B（グレー系）
        Assert.True(
            Math.Abs(brush.Color.R - brush.Color.G) < 30 &&
            Math.Abs(brush.Color.G - brush.Color.B) < 30,
            "RGB値がほぼ等しいこと（グレー系）");
    }

    [Fact]
    public void Convert_WhenError_ReturnsSolidColorBrushRed()
    {
        // Arrange
        var state = ConnectionState.Error;

        // Act
        var result = _converter.Convert(state, typeof(Brush), null, _culture);

        // Assert
        var brush = Assert.IsType<SolidColorBrush>(result);
        // 赤: 赤成分が最大（エラー状態）
        Assert.True(brush.Color.R > brush.Color.G, "赤成分が緑成分より大きいこと（レッド系）");
        Assert.True(brush.Color.R > brush.Color.B, "赤成分が青成分より大きいこと（レッド系）");
    }

    [Fact]
    public void Convert_WhenValueIsNull_ReturnsGrayBrush()
    {
        // Arrange: null 値（不明状態として扱う）

        // Act
        var result = _converter.Convert(null, typeof(Brush), null, _culture);

        // Assert
        Assert.IsType<SolidColorBrush>(result);
    }

    [Fact]
    public void Convert_WhenValueIsNotConnectionState_ReturnsGrayBrush()
    {
        // Arrange: 予期しない型

        // Act
        var result = _converter.Convert("unexpected_string", typeof(Brush), null, _culture);

        // Assert
        Assert.IsType<SolidColorBrush>(result);
    }

    // ─── ConvertBack メソッドのテスト ─────────────────────────────────

    [Fact]
    public void ConvertBack_AlwaysThrowsNotSupportedException()
    {
        // ConvertBack は逆変換をサポートしない（一方向バインディング）
        Assert.Throws<NotSupportedException>(() =>
            _converter.ConvertBack(new SolidColorBrush(Colors.Green), typeof(ConnectionState), null, _culture));
    }

    // ─── 各状態で返されるブラシが Frozen（不変）であることの確認 ──────

    [Theory]
    [InlineData(ConnectionState.Connected)]
    [InlineData(ConnectionState.Connecting)]
    [InlineData(ConnectionState.Disconnected)]
    [InlineData(ConnectionState.Error)]
    public void Convert_ReturnsNonNullBrush_ForAllConnectionStates(ConnectionState state)
    {
        // Act
        var result = _converter.Convert(state, typeof(Brush), null, _culture);

        // Assert
        Assert.NotNull(result);
        Assert.IsAssignableFrom<Brush>(result);
    }
}
