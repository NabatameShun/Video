// タスク 8.1: StreamPaneView コードビハインドのテスト
// PasswordBox.PasswordChanged イベントで ViewModel へパスワードを安全に渡すロジックを検証する

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.Views;

/// <summary>
/// StreamPaneView のコードビハインドでテスト可能なロジックを検証するテストクラス。
/// XAML レンダリングは UI スレッドが必要なため、ビジネスロジックのみテストする。
/// </summary>
public class StreamPaneViewCodeBehindTests
{
    // ─── テスト用ヘルパー ─────────────────────────────────────────

    /// <summary>
    /// PasswordChanged コードビハインドのロジックをシミュレートするメソッド。
    /// StreamPaneView のコードビハインドがこのパターンで動作することを検証する。
    /// </summary>
    private static void SimulatePasswordChanged(StreamPaneViewModel viewModel, string newPassword)
    {
        // コードビハインドが PasswordBox.PasswordChanged で行うロジックを再現
        // PasswordBox.Password プロパティから取得したパスワードを ViewModel の Password プロパティへ設定する
        viewModel.Password = newPassword;
    }

    // ─── PasswordChanged ロジックテスト ──────────────────────────

    [Fact]
    public void PasswordChanged_SetsViewModelPassword()
    {
        // Arrange: テスト用 ViewModel を準備
        var rtspService = new Mock<IRtspStreamService>();
        var renderer = new Mock<IVideoFrameRenderer>();
        var onvifService = new Mock<IOnvifPtzService>();
        var settingsService = new Mock<ISettingsService>();

        // IVideoFrameRenderer の BitmapUpdated イベントを設定
        renderer.SetupAdd(r => r.BitmapUpdated += It.IsAny<EventHandler<System.Windows.Media.Imaging.WriteableBitmap>>());
        rtspService.SetupAdd(r => r.StateChanged += It.IsAny<EventHandler<StreamStateChangedEventArgs>>());
        rtspService.SetupAdd(r => r.StatsUpdated += It.IsAny<EventHandler<ConnectionStats>>());

        var viewModel = new StreamPaneViewModel(
            rtspService.Object,
            renderer.Object,
            onvifService.Object,
            settingsService.Object);

        const string testPassword = "TestPassword123";

        // Act: PasswordChanged イベントのロジックをシミュレート
        SimulatePasswordChanged(viewModel, testPassword);

        // Assert: ViewModel の Password プロパティが更新されている
        Assert.Equal(testPassword, viewModel.Password);
    }

    [Fact]
    public void PasswordChanged_EmptyPassword_SetsViewModelPasswordToEmpty()
    {
        // Arrange
        var rtspService = new Mock<IRtspStreamService>();
        var renderer = new Mock<IVideoFrameRenderer>();
        var onvifService = new Mock<IOnvifPtzService>();
        var settingsService = new Mock<ISettingsService>();

        renderer.SetupAdd(r => r.BitmapUpdated += It.IsAny<EventHandler<System.Windows.Media.Imaging.WriteableBitmap>>());
        rtspService.SetupAdd(r => r.StateChanged += It.IsAny<EventHandler<StreamStateChangedEventArgs>>());
        rtspService.SetupAdd(r => r.StatsUpdated += It.IsAny<EventHandler<ConnectionStats>>());

        var viewModel = new StreamPaneViewModel(
            rtspService.Object,
            renderer.Object,
            onvifService.Object,
            settingsService.Object);

        // Act: 空のパスワードをシミュレート
        SimulatePasswordChanged(viewModel, string.Empty);

        // Assert: 空文字が設定される
        Assert.Equal(string.Empty, viewModel.Password);
    }

    [Fact]
    public void PasswordChanged_OverwritesPreviousPassword()
    {
        // Arrange
        var rtspService = new Mock<IRtspStreamService>();
        var renderer = new Mock<IVideoFrameRenderer>();
        var onvifService = new Mock<IOnvifPtzService>();
        var settingsService = new Mock<ISettingsService>();

        renderer.SetupAdd(r => r.BitmapUpdated += It.IsAny<EventHandler<System.Windows.Media.Imaging.WriteableBitmap>>());
        rtspService.SetupAdd(r => r.StateChanged += It.IsAny<EventHandler<StreamStateChangedEventArgs>>());
        rtspService.SetupAdd(r => r.StatsUpdated += It.IsAny<EventHandler<ConnectionStats>>());

        var viewModel = new StreamPaneViewModel(
            rtspService.Object,
            renderer.Object,
            onvifService.Object,
            settingsService.Object);

        // Act: パスワードを2回変更
        SimulatePasswordChanged(viewModel, "OldPassword");
        SimulatePasswordChanged(viewModel, "NewPassword");

        // Assert: 最新のパスワードが設定されている
        Assert.Equal("NewPassword", viewModel.Password);
    }
}
