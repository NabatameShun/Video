// タスク 8.3: MainWindow コードビハインドのテスト
// Closing イベントで MainWindowViewModel.OnClosing() を呼び出すロジックを検証する

using Moq;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP.Tests.Views;

/// <summary>
/// MainWindow のコードビハインドでテスト可能なロジックを検証するテストクラス。
/// Closing イベントが MainWindowViewModel.OnClosing() を呼び出すことを確認する。
/// </summary>
public class MainWindowCodeBehindTests
{
    // ─── テスト用ヘルパー ─────────────────────────────────────────

    /// <summary>
    /// MainWindow の Closing コードビハインドロジックをシミュレートする。
    /// </summary>
    private static void SimulateWindowClosing(MainWindowViewModel viewModel)
    {
        // MainWindow コードビハインドが Window.Closing イベントで呼び出すロジック
        viewModel.OnClosing();
    }

    // ─── テスト ─────────────────────────────────────────────────

    [Fact]
    public void WindowClosing_CallsOnClosing_DisconnectsAndSavesSettings()
    {
        // Arrange: モック依存を設定
        var rtspService1 = new Mock<IRtspStreamService>();
        var rtspService2 = new Mock<IRtspStreamService>();
        var renderer1 = new Mock<IVideoFrameRenderer>();
        var renderer2 = new Mock<IVideoFrameRenderer>();
        var onvifService = new Mock<IOnvifPtzService>();
        var settingsService = new Mock<ISettingsService>();

        // イベントハンドラーのモック設定
        renderer1.SetupAdd(r => r.BitmapUpdated += It.IsAny<EventHandler<System.Windows.Media.Imaging.WriteableBitmap>>());
        renderer2.SetupAdd(r => r.BitmapUpdated += It.IsAny<EventHandler<System.Windows.Media.Imaging.WriteableBitmap>>());
        rtspService1.SetupAdd(r => r.StateChanged += It.IsAny<EventHandler<StreamStateChangedEventArgs>>());
        rtspService1.SetupAdd(r => r.StatsUpdated += It.IsAny<EventHandler<ConnectionStats>>());
        rtspService2.SetupAdd(r => r.StateChanged += It.IsAny<EventHandler<StreamStateChangedEventArgs>>());
        rtspService2.SetupAdd(r => r.StatsUpdated += It.IsAny<EventHandler<ConnectionStats>>());

        settingsService.Setup(s => s.Load()).Returns(new AppSettings(
            Pane1: new StreamPaneSettings("", null, null, RtspTransport.Tcp, null, null, null),
            Pane2: new StreamPaneSettings("", null, null, RtspTransport.Tcp, null, null, null),
            Layout: DualPaneLayout.Horizontal));

        var pane1 = new StreamPaneViewModel(rtspService1.Object, renderer1.Object, onvifService.Object, settingsService.Object);
        var pane2 = new StreamPaneViewModel(rtspService2.Object, renderer2.Object, onvifService.Object, settingsService.Object);
        var mainVm = new MainWindowViewModel(pane1, pane2, settingsService.Object);

        // Act: Closing イベントのロジックをシミュレート
        SimulateWindowClosing(mainVm);

        // Assert: 両ペインで Disconnect が呼び出される
        rtspService1.Verify(s => s.Disconnect(), Times.Once);
        rtspService2.Verify(s => s.Disconnect(), Times.Once);

        // Assert: 設定が保存される
        settingsService.Verify(s => s.Save(It.IsAny<AppSettings>()), Times.Once);
    }

    [Fact]
    public void WindowClosing_SavesCurrentLayout()
    {
        // Arrange
        var rtspService1 = new Mock<IRtspStreamService>();
        var rtspService2 = new Mock<IRtspStreamService>();
        var renderer1 = new Mock<IVideoFrameRenderer>();
        var renderer2 = new Mock<IVideoFrameRenderer>();
        var onvifService = new Mock<IOnvifPtzService>();
        var settingsService = new Mock<ISettingsService>();

        renderer1.SetupAdd(r => r.BitmapUpdated += It.IsAny<EventHandler<System.Windows.Media.Imaging.WriteableBitmap>>());
        renderer2.SetupAdd(r => r.BitmapUpdated += It.IsAny<EventHandler<System.Windows.Media.Imaging.WriteableBitmap>>());
        rtspService1.SetupAdd(r => r.StateChanged += It.IsAny<EventHandler<StreamStateChangedEventArgs>>());
        rtspService1.SetupAdd(r => r.StatsUpdated += It.IsAny<EventHandler<ConnectionStats>>());
        rtspService2.SetupAdd(r => r.StateChanged += It.IsAny<EventHandler<StreamStateChangedEventArgs>>());
        rtspService2.SetupAdd(r => r.StatsUpdated += It.IsAny<EventHandler<ConnectionStats>>());

        settingsService.Setup(s => s.Load()).Returns(new AppSettings(
            Pane1: new StreamPaneSettings("", null, null, RtspTransport.Tcp, null, null, null),
            Pane2: new StreamPaneSettings("", null, null, RtspTransport.Tcp, null, null, null),
            Layout: DualPaneLayout.Horizontal));

        AppSettings? savedSettings = null;
        settingsService.Setup(s => s.Save(It.IsAny<AppSettings>()))
            .Callback<AppSettings>(s => savedSettings = s);

        var pane1 = new StreamPaneViewModel(rtspService1.Object, renderer1.Object, onvifService.Object, settingsService.Object);
        var pane2 = new StreamPaneViewModel(rtspService2.Object, renderer2.Object, onvifService.Object, settingsService.Object);
        var mainVm = new MainWindowViewModel(pane1, pane2, settingsService.Object);

        // レイアウトを Vertical に変更
        mainVm.ToggleLayout();
        Assert.Equal(DualPaneLayout.Vertical, mainVm.Layout);

        // Act
        SimulateWindowClosing(mainVm);

        // Assert: 変更されたレイアウトが保存される
        Assert.NotNull(savedSettings);
        Assert.Equal(DualPaneLayout.Vertical, savedSettings!.Layout);
    }
}
