// 録画ドメインモデルのユニットテスト
// タスク 1.1: RecordingState・RecordingErrorKind・RecordingErrorEventArgs の検証

using View_RTSP.Models;

namespace View_RTSP.Tests.Models;

/// <summary>
/// RecordingState 列挙型のテスト
/// </summary>
public class RecordingStateTests
{
    [Fact]
    public void RecordingState_HasIdleValue()
    {
        var state = RecordingState.Idle;
        Assert.Equal(RecordingState.Idle, state);
    }

    [Fact]
    public void RecordingState_HasRecordingValue()
    {
        var state = RecordingState.Recording;
        Assert.Equal(RecordingState.Recording, state);
    }

    [Fact]
    public void RecordingState_HasStoppingValue()
    {
        var state = RecordingState.Stopping;
        Assert.Equal(RecordingState.Stopping, state);
    }

    [Fact]
    public void RecordingState_HasExactlyThreeValues()
    {
        var values = Enum.GetValues<RecordingState>();
        Assert.Equal(3, values.Length);
    }
}

/// <summary>
/// RecordingErrorKind 列挙型のテスト
/// </summary>
public class RecordingErrorKindTests
{
    [Theory]
    [InlineData(RecordingErrorKind.DiskWriteError)]
    [InlineData(RecordingErrorKind.PermissionDenied)]
    [InlineData(RecordingErrorKind.DirectoryCreationFailed)]
    public void RecordingErrorKind_HasAllValues(RecordingErrorKind kind)
    {
        Assert.True(Enum.IsDefined(kind));
    }

    [Fact]
    public void RecordingErrorKind_HasExactlyThreeValues()
    {
        var values = Enum.GetValues<RecordingErrorKind>();
        Assert.Equal(3, values.Length);
    }
}

/// <summary>
/// RecordingErrorEventArgs のテスト
/// </summary>
public class RecordingErrorEventArgsTests
{
    [Fact]
    public void RecordingErrorEventArgs_CanBeCreated_WithKindAndMessage()
    {
        var args = new RecordingErrorEventArgs(
            RecordingErrorKind.DiskWriteError,
            "ディスク書き込みに失敗しました");

        Assert.Equal(RecordingErrorKind.DiskWriteError, args.Kind);
        Assert.Equal("ディスク書き込みに失敗しました", args.Message);
    }

    [Fact]
    public void RecordingErrorEventArgs_IsEventArgs()
    {
        var args = new RecordingErrorEventArgs(
            RecordingErrorKind.PermissionDenied,
            "書き込み権限がありません");

        Assert.IsAssignableFrom<EventArgs>(args);
    }

    [Fact]
    public void RecordingErrorEventArgs_PreservesAllErrorKinds()
    {
        var diskError = new RecordingErrorEventArgs(RecordingErrorKind.DiskWriteError, "disk error");
        var permError = new RecordingErrorEventArgs(RecordingErrorKind.PermissionDenied, "permission denied");
        var dirError = new RecordingErrorEventArgs(RecordingErrorKind.DirectoryCreationFailed, "dir creation failed");

        Assert.Equal(RecordingErrorKind.DiskWriteError, diskError.Kind);
        Assert.Equal(RecordingErrorKind.PermissionDenied, permError.Kind);
        Assert.Equal(RecordingErrorKind.DirectoryCreationFailed, dirError.Kind);
    }
}
