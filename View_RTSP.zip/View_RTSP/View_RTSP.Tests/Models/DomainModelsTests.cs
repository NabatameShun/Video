// ドメインモデルのユニットテスト
// タスク 1.2 に対応: 列挙型・不変レコード・イベント引数の定義検証

using View_RTSP.Models;

namespace View_RTSP.Tests.Models;

/// <summary>
/// ConnectionState 列挙型のテスト
/// </summary>
public class ConnectionStateTests
{
    [Fact]
    public void ConnectionState_HasDisconnectedValue()
    {
        var state = ConnectionState.Disconnected;
        Assert.Equal(ConnectionState.Disconnected, state);
    }

    [Fact]
    public void ConnectionState_HasConnectingValue()
    {
        var state = ConnectionState.Connecting;
        Assert.Equal(ConnectionState.Connecting, state);
    }

    [Fact]
    public void ConnectionState_HasConnectedValue()
    {
        var state = ConnectionState.Connected;
        Assert.Equal(ConnectionState.Connected, state);
    }

    [Fact]
    public void ConnectionState_HasErrorValue()
    {
        var state = ConnectionState.Error;
        Assert.Equal(ConnectionState.Error, state);
    }

    [Fact]
    public void ConnectionState_HasExactlyFourValues()
    {
        var values = Enum.GetValues<ConnectionState>();
        Assert.Equal(4, values.Length);
    }
}

/// <summary>
/// RtspTransport 列挙型のテスト
/// </summary>
public class RtspTransportTests
{
    [Fact]
    public void RtspTransport_HasTcpValue()
    {
        var transport = RtspTransport.Tcp;
        Assert.Equal(RtspTransport.Tcp, transport);
    }

    [Fact]
    public void RtspTransport_HasUdpValue()
    {
        var transport = RtspTransport.Udp;
        Assert.Equal(RtspTransport.Udp, transport);
    }
}

/// <summary>
/// RtspErrorKind 列挙型のテスト（全エラー種別の網羅性確認）
/// </summary>
public class RtspErrorKindTests
{
    [Fact]
    public void RtspErrorKind_HasConnectionTimeoutValue()
    {
        var kind = RtspErrorKind.ConnectionTimeout;
        Assert.Equal(RtspErrorKind.ConnectionTimeout, kind);
    }

    [Fact]
    public void RtspErrorKind_HasAuthenticationFailedValue()
    {
        var kind = RtspErrorKind.AuthenticationFailed;
        Assert.Equal(RtspErrorKind.AuthenticationFailed, kind);
    }

    [Fact]
    public void RtspErrorKind_HasNetworkUnreachableValue()
    {
        var kind = RtspErrorKind.NetworkUnreachable;
        Assert.Equal(RtspErrorKind.NetworkUnreachable, kind);
    }

    [Fact]
    public void RtspErrorKind_HasDecodeErrorValue()
    {
        var kind = RtspErrorKind.DecodeError;
        Assert.Equal(RtspErrorKind.DecodeError, kind);
    }

    [Fact]
    public void RtspErrorKind_HasUnknownErrorValue()
    {
        var kind = RtspErrorKind.UnknownError;
        Assert.Equal(RtspErrorKind.UnknownError, kind);
    }

    [Fact]
    public void RtspErrorKind_HasExactlyFiveValues()
    {
        var values = Enum.GetValues<RtspErrorKind>();
        Assert.Equal(5, values.Length);
    }
}

/// <summary>
/// RtspConnectionOptions レコードのテスト
/// </summary>
public class RtspConnectionOptionsTests
{
    [Fact]
    public void RtspConnectionOptions_CanBeCreated_WithAllProperties()
    {
        var options = new RtspConnectionOptions(
            Url: "rtsp://192.168.1.100/stream1",
            Username: "admin",
            Password: "password",
            Transport: RtspTransport.Tcp,
            LowLatencyMode: true
        );

        Assert.Equal("rtsp://192.168.1.100/stream1", options.Url);
        Assert.Equal("admin", options.Username);
        Assert.Equal("password", options.Password);
        Assert.Equal(RtspTransport.Tcp, options.Transport);
        Assert.True(options.LowLatencyMode);
    }

    [Fact]
    public void RtspConnectionOptions_CanBeCreated_WithNullCredentials()
    {
        var options = new RtspConnectionOptions(
            Url: "rtsp://192.168.1.100/stream1",
            Username: null,
            Password: null,
            Transport: RtspTransport.Udp,
            LowLatencyMode: false
        );

        Assert.Null(options.Username);
        Assert.Null(options.Password);
    }

    [Fact]
    public void RtspConnectionOptions_IsImmutable_ValueEquality()
    {
        var options1 = new RtspConnectionOptions("rtsp://host/stream", null, null, RtspTransport.Tcp, true);
        var options2 = new RtspConnectionOptions("rtsp://host/stream", null, null, RtspTransport.Tcp, true);

        // readonly record struct は値の等値比較
        Assert.Equal(options1, options2);
    }

    [Fact]
    public void RtspConnectionOptions_NotEqual_WhenDifferentUrl()
    {
        var options1 = new RtspConnectionOptions("rtsp://host1/stream", null, null, RtspTransport.Tcp, true);
        var options2 = new RtspConnectionOptions("rtsp://host2/stream", null, null, RtspTransport.Tcp, true);

        Assert.NotEqual(options1, options2);
    }
}

/// <summary>
/// RtspError レコードのテスト
/// </summary>
public class RtspErrorTests
{
    [Fact]
    public void RtspError_CanBeCreated_WithKindAndMessage()
    {
        var error = new RtspError(
            Kind: RtspErrorKind.ConnectionTimeout,
            Message: "接続タイムアウト: サーバーに到達できません",
            FfmpegErrorCode: null
        );

        Assert.Equal(RtspErrorKind.ConnectionTimeout, error.Kind);
        Assert.Equal("接続タイムアウト: サーバーに到達できません", error.Message);
        Assert.Null(error.FfmpegErrorCode);
    }

    [Fact]
    public void RtspError_CanBeCreated_WithFfmpegErrorCode()
    {
        var error = new RtspError(
            Kind: RtspErrorKind.DecodeError,
            Message: "デコードエラー",
            FfmpegErrorCode: -1094995529
        );

        Assert.Equal(-1094995529, error.FfmpegErrorCode);
    }
}

/// <summary>
/// StreamStateChangedEventArgs のテスト
/// </summary>
public class StreamStateChangedEventArgsTests
{
    [Fact]
    public void StreamStateChangedEventArgs_CanBeCreated_WithStateOnly()
    {
        var args = new StreamStateChangedEventArgs(
            state: ConnectionState.Connected,
            error: null
        );

        Assert.Equal(ConnectionState.Connected, args.State);
        Assert.Null(args.Error);
    }

    [Fact]
    public void StreamStateChangedEventArgs_CanBeCreated_WithError()
    {
        var error = new RtspError(RtspErrorKind.AuthenticationFailed, "認証失敗", null);
        var args = new StreamStateChangedEventArgs(
            state: ConnectionState.Error,
            error: error
        );

        Assert.Equal(ConnectionState.Error, args.State);
        Assert.NotNull(args.Error);
        Assert.Equal(RtspErrorKind.AuthenticationFailed, args.Error.Value.Kind);
    }
}

/// <summary>
/// ConnectionStats レコードのテスト
/// </summary>
public class ConnectionStatsTests
{
    [Fact]
    public void ConnectionStats_CanBeCreated_WithAllProperties()
    {
        var stats = new ConnectionStats(
            FrameRate: 29.97,
            ReceivedFrames: 1500L,
            Uptime: TimeSpan.FromMinutes(5)
        );

        Assert.Equal(29.97, stats.FrameRate, precision: 2);
        Assert.Equal(1500L, stats.ReceivedFrames);
        Assert.Equal(TimeSpan.FromMinutes(5), stats.Uptime);
    }

    [Fact]
    public void ConnectionStats_Default_HasZeroValues()
    {
        var stats = default(ConnectionStats);

        Assert.Equal(0.0, stats.FrameRate);
        Assert.Equal(0L, stats.ReceivedFrames);
        Assert.Equal(TimeSpan.Zero, stats.Uptime);
    }
}

/// <summary>
/// OnvifConnectionOptions レコードのテスト
/// </summary>
public class OnvifConnectionOptionsTests
{
    [Fact]
    public void OnvifConnectionOptions_CanBeCreated_WithAllProperties()
    {
        var options = new OnvifConnectionOptions(
            EndpointUrl: "http://192.168.1.100/onvif/device_service",
            Username: "admin",
            Password: "password",
            ProfileToken: "Profile_1"
        );

        Assert.Equal("http://192.168.1.100/onvif/device_service", options.EndpointUrl);
        Assert.Equal("admin", options.Username);
        Assert.Equal("password", options.Password);
        Assert.Equal("Profile_1", options.ProfileToken);
    }

    [Fact]
    public void OnvifConnectionOptions_CanBeCreated_WithNullProfileToken()
    {
        var options = new OnvifConnectionOptions(
            EndpointUrl: "http://192.168.1.100/onvif/device_service",
            Username: "admin",
            Password: "password",
            ProfileToken: null
        );

        Assert.Null(options.ProfileToken);
    }
}

/// <summary>
/// PtzDirection 列挙型のテスト（8方向）
/// </summary>
public class PtzDirectionTests
{
    [Theory]
    [InlineData(PtzDirection.Up)]
    [InlineData(PtzDirection.Down)]
    [InlineData(PtzDirection.Left)]
    [InlineData(PtzDirection.Right)]
    [InlineData(PtzDirection.UpLeft)]
    [InlineData(PtzDirection.UpRight)]
    [InlineData(PtzDirection.DownLeft)]
    [InlineData(PtzDirection.DownRight)]
    public void PtzDirection_HasAllEightDirections(PtzDirection direction)
    {
        // 各方向値が定義されていることを確認
        Assert.True(Enum.IsDefined(direction));
    }

    [Fact]
    public void PtzDirection_HasExactlyEightValues()
    {
        var values = Enum.GetValues<PtzDirection>();
        Assert.Equal(8, values.Length);
    }
}

/// <summary>
/// DualPaneLayout 列挙型のテスト
/// </summary>
public class DualPaneLayoutTests
{
    [Fact]
    public void DualPaneLayout_HasHorizontalValue()
    {
        var layout = DualPaneLayout.Horizontal;
        Assert.Equal(DualPaneLayout.Horizontal, layout);
    }

    [Fact]
    public void DualPaneLayout_HasVerticalValue()
    {
        var layout = DualPaneLayout.Vertical;
        Assert.Equal(DualPaneLayout.Vertical, layout);
    }

    [Fact]
    public void DualPaneLayout_HasExactlyTwoValues()
    {
        var values = Enum.GetValues<DualPaneLayout>();
        Assert.Equal(2, values.Length);
    }
}
