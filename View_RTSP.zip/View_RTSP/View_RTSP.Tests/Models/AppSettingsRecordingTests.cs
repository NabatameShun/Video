// AppSettings 録画保存先フォルダ拡張のユニットテスト
// タスク 1.2: RecordingFolderPath フィールドの追加と後方互換性

using System.IO;
using System.Text.Json;
using View_RTSP.Models;
using View_RTSP.Services;

namespace View_RTSP.Tests.Models;

/// <summary>
/// AppSettings の RecordingFolderPath 拡張テスト
/// </summary>
public class AppSettingsRecordingFolderTests
{
    [Fact]
    public void AppSettings_HasRecordingFolderPath()
    {
        var settings = new AppSettings(
            Pane1: StreamPaneSettings.Default,
            Pane2: StreamPaneSettings.Default,
            Pane3: StreamPaneSettings.Default,
            SelectedTabIndex: 3,
            RecordingFolderPath: @"C:\Videos\Test");

        Assert.Equal(@"C:\Videos\Test", settings.RecordingFolderPath);
    }

    [Fact]
    public void AppSettings_Default_HasRecordingFolderPath_InMyVideos()
    {
        var settings = AppSettings.Default;

        var expectedPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),
            "RtspViewer");

        Assert.Equal(expectedPath, settings.RecordingFolderPath);
    }

    [Fact]
    public void AppSettings_WithExpression_CanChangeRecordingFolderPath()
    {
        var original = AppSettings.Default;
        var modified = original with { RecordingFolderPath = @"D:\Recordings" };

        // 元のオブジェクトは変更されない（不変性確認）
        Assert.NotEqual(@"D:\Recordings", original.RecordingFolderPath);
        Assert.Equal(@"D:\Recordings", modified.RecordingFolderPath);
    }

    [Fact]
    public void AppSettings_RecordingFolderPath_IsPreservedInRecordEquality()
    {
        var settings1 = AppSettings.Default;
        var settings2 = AppSettings.Default;

        Assert.Equal(settings1, settings2);
    }
}

/// <summary>
/// SettingsService の RecordingFolderPath 永続化テスト
/// </summary>
public class SettingsServiceRecordingFolderTests : IDisposable
{
    private readonly string _testDirectory;
    private readonly SettingsService _sut;

    public SettingsServiceRecordingFolderTests()
    {
        _testDirectory = Path.Combine(Path.GetTempPath(), $"RtspViewerTest_{Guid.NewGuid():N}");
        Directory.CreateDirectory(_testDirectory);
        _sut = new SettingsService(_testDirectory);
    }

    public void Dispose()
    {
        try
        {
            if (Directory.Exists(_testDirectory))
                Directory.Delete(_testDirectory, recursive: true);
        }
        catch { }
    }

    [Fact]
    public void SaveAndLoad_RecordingFolderPath_RoundTripsCorrectly()
    {
        // Arrange
        var settings = AppSettings.Default with { RecordingFolderPath = @"D:\MyRecordings" };

        // Act
        _sut.Save(settings);
        var loaded = _sut.Load();

        // Assert
        Assert.Equal(@"D:\MyRecordings", loaded.RecordingFolderPath);
    }

    [Fact]
    public void Load_WhenRecordingFolderPathMissing_FallsBackToDefault()
    {
        // Arrange: RecordingFolderPath なしの旧形式 JSON を書き込む
        var oldJson = """
        {
          "pane1": {
            "rtspUrl": "",
            "transport": "Tcp"
          },
          "pane2": {
            "rtspUrl": "",
            "transport": "Tcp"
          },
          "layout": "Horizontal"
        }
        """;
        var settingsPath = Path.Combine(_testDirectory, "settings.json");
        File.WriteAllText(settingsPath, oldJson);

        // Act
        var loaded = _sut.Load();

        // Assert: デフォルト値にフォールバック
        var expectedPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),
            "RtspViewer");
        Assert.Equal(expectedPath, loaded.RecordingFolderPath);
    }
}
