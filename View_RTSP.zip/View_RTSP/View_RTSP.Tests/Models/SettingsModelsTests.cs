// 設定データモデルのユニットテスト
// タスク 1.3 に対応: AppSettings・StreamPaneSettings レコードの検証

using View_RTSP.Models;

namespace View_RTSP.Tests.Models;

/// <summary>
/// StreamPaneSettings レコードのテスト
/// </summary>
public class StreamPaneSettingsTests
{
    [Fact]
    public void StreamPaneSettings_CanBeCreated_WithAllProperties()
    {
        var settings = new StreamPaneSettings(
            RtspUrl: "rtsp://192.168.1.100/stream1",
            Username: "admin",
            EncryptedPassword: "encrypted_base64==",
            Transport: RtspTransport.Tcp,
            OnvifEndpointUrl: "http://192.168.1.100/onvif/device_service",
            OnvifUsername: "admin",
            OnvifEncryptedPassword: "onvif_encrypted=="
        );

        Assert.Equal("rtsp://192.168.1.100/stream1", settings.RtspUrl);
        Assert.Equal("admin", settings.Username);
        Assert.Equal("encrypted_base64==", settings.EncryptedPassword);
        Assert.Equal(RtspTransport.Tcp, settings.Transport);
        Assert.Equal("http://192.168.1.100/onvif/device_service", settings.OnvifEndpointUrl);
        Assert.Equal("admin", settings.OnvifUsername);
        Assert.Equal("onvif_encrypted==", settings.OnvifEncryptedPassword);
    }

    [Fact]
    public void StreamPaneSettings_CanBeCreated_WithNullOptionalFields()
    {
        var settings = new StreamPaneSettings(
            RtspUrl: "",
            Username: null,
            EncryptedPassword: null,
            Transport: RtspTransport.Tcp,
            OnvifEndpointUrl: null,
            OnvifUsername: null,
            OnvifEncryptedPassword: null
        );

        Assert.Null(settings.Username);
        Assert.Null(settings.EncryptedPassword);
        Assert.Null(settings.OnvifEndpointUrl);
        Assert.Null(settings.OnvifUsername);
        Assert.Null(settings.OnvifEncryptedPassword);
    }

    [Fact]
    public void StreamPaneSettings_IsRecord_SupportsValueEquality()
    {
        var settings1 = new StreamPaneSettings("rtsp://host/stream", null, null, RtspTransport.Tcp, null, null, null);
        var settings2 = new StreamPaneSettings("rtsp://host/stream", null, null, RtspTransport.Tcp, null, null, null);

        Assert.Equal(settings1, settings2);
    }
}

/// <summary>
/// AppSettings レコードのテスト
/// </summary>
public class AppSettingsTests
{
    private static StreamPaneSettings CreateDefaultPaneSettings() =>
        new StreamPaneSettings("", null, null, RtspTransport.Tcp, null, null, null);

    [Fact]
    public void AppSettings_CanBeCreated_WithThreePanesAndTabIndex()
    {
        var pane1 = CreateDefaultPaneSettings();
        var pane2 = CreateDefaultPaneSettings();
        var pane3 = CreateDefaultPaneSettings();

        var settings = AppSettings.Default with
        {
            Pane1 = pane1,
            Pane2 = pane2,
            Pane3 = pane3,
            SelectedTabIndex = 0
        };

        Assert.Equal(pane1, settings.Pane1);
        Assert.Equal(pane2, settings.Pane2);
        Assert.Equal(pane3, settings.Pane3);
        Assert.Equal(0, settings.SelectedTabIndex);
    }

    [Fact]
    public void AppSettings_IsRecord_SupportsWithExpression()
    {
        var original = AppSettings.Default;

        var modified = original with { SelectedTabIndex = 1 };

        // 元のオブジェクトは変更されない（不変性確認）
        Assert.Equal(3, original.SelectedTabIndex);
        Assert.Equal(1, modified.SelectedTabIndex);
    }

    [Fact]
    public void AppSettings_Default_HasSelectedTabIndex3()
    {
        var settings = AppSettings.Default;

        Assert.Equal(3, settings.SelectedTabIndex);
    }

    [Fact]
    public void AppSettings_Default_HasEmptyRtspUrls()
    {
        var settings = AppSettings.Default;

        Assert.Equal(string.Empty, settings.Pane1.RtspUrl);
        Assert.Equal(string.Empty, settings.Pane2.RtspUrl);
        Assert.Equal(string.Empty, settings.Pane3.RtspUrl);
    }
}
