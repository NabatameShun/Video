# 技術スタック

## アーキテクチャ

WPFシングルウィンドウアプリケーション。UIとロジックをXAML（ビュー）とコードビハインド（またはViewModel）で分離するパターンを採用する。

## コア技術

- **言語**: C# 13以降（Nullable有効、ImplicitUsings有効）
- **フレームワーク**: WPF（Windows Presentation Foundation）
- **ランタイム**: .NET 10（net10.0-windows）
- **出力形式**: WinExe（Windowsデスクトップアプリケーション）

## 主要ライブラリ

現時点では標準WPFライブラリのみ使用。RTSP再生機能の実装時には以下の候補を検討：
- `LibVLCSharp.WPF`（VideoLAN/libvlc経由でのRTSP再生）
- `FFmpeg.AutoGen`（FFmpegバインディング）

## 開発標準

### 型安全性
- Nullable参照型を有効化（`<Nullable>enable</Nullable>`）
- null許容型は明示的に `?` で宣言する

### コード品質
- `ImplicitUsings` 有効（System名前空間等は自動インポート）
- WPFコードビハインドはUIイベント処理のみに留め、ビジネスロジックはViewModelまたはサービスクラスへ分離する

### UIパターン
- XAMLでUIを定義し、コードビハインドではInitializeComponent()の呼び出しのみを基本とする
- 複雑な状態管理が必要な場合はMVVMパターン（INotifyPropertyChanged）を採用する

## 開発環境

### 必要ツール
- Visual Studio 2022 以降（WPFワークロード）または .NET 10 SDK + VS Code
- Windows OS（WPFはWindows専用）

### 主要コマンド
```bash
# ビルド
dotnet build View_RTSP/View_RTSP.csproj

# 実行
dotnet run --project View_RTSP/View_RTSP.csproj

# 発行
dotnet publish View_RTSP/View_RTSP.csproj -c Release
```

## 技術的決定事項

- **.NET 10採用**: 最新の長期サポート（LTS）ランタイムを選択し、最新C#機能を活用
- **WPF選択**: ネイティブWindowsデスクトップ体験とリッチUIのためにWPFを選択（RTSP映像表示に適したMediaElementやカスタムコントロールの利用が可能）
- **単一プロジェクト構成**: 現時点はシンプルな単一csprojで管理。機能追加に応じてクラスライブラリへの分離を検討

---
_主要なフレームワークと規約を記録するものであり、全依存関係の列挙ではない_
