# 技術スタック

## アーキテクチャ

WPFシングルウィンドウ・MVVMアプリケーション。CommunityToolkit.Mvvm による `ObservableObject` / `[ObservableProperty]` / `[RelayCommand]` を採用し、View（XAML）とViewModel を完全に分離する。

DI は App.xaml.cs のコンポジションルートで手動組み立て（DIコンテナ不使用）。サービスはインターフェース経由で注入し、テスト時にモック差し替えが可能。

## コア技術

- **言語**: C# 13以降（Nullable有効、ImplicitUsings有効）
- **フレームワーク**: WPF（Windows Presentation Foundation）
- **ランタイム**: .NET 10（net10.0-windows）
- **出力形式**: WinExe（Windowsデスクトップアプリケーション）
- **プラットフォーム**: x64 専用（`AllowUnsafeBlocks` 有効、FFmpegネイティブDLLに合わせる）

## 主要ライブラリ

- **Sdcb.FFmpeg 7.0**: RTSP受信・H.264デコード・フレーム変換（BGRA）。unsafeコードでネイティブメモリを直接操作
- **CommunityToolkit.Mvvm 8.4**: MVVM基盤（ObservableProperty、RelayCommand、ObservableObject）
- **Onvif.Core 3.0**: ONVIF Profile S 準拠のデバイス・メディア・PTZクライアント生成

## 開発標準

### 型安全性
- Nullable参照型を有効化（`<Nullable>enable</Nullable>`）
- null許容型は明示的に `?` で宣言する

### データモデリング
- ドメインモデルは `readonly record struct` で不変に定義する（例: `RtspConnectionOptions`, `ConnectionStats`）
- イベント引数は `sealed class` で定義する（例: `StreamStateChangedEventArgs`）

### MVVMパターン
- ViewModelは `ObservableObject` を継承し `partial class` で宣言する
- バインド可能プロパティは `[ObservableProperty]` 属性で自動生成する（`private` フィールドに `_camelCase` で命名）
- コマンドは `[RelayCommand]` 属性または手動の `AsyncRelayCommand` で定義する
- バックグラウンドスレッドからのUIプロパティ更新は `Dispatcher.Invoke` 経由で行う

### サービス層パターン
- 各サービスはインターフェース（`I*`）と実装クラスのペアで構成する
- 外部ライブラリ依存はアダプターパターンで抽象化する（例: `OnvifClientFactoryAdapter` → `IOnvifClientFactory`）
- サービスは `IDisposable` を実装し、リソース解放を明示的に行う

### エラーハンドリング方針
- ONVIF応答のXMLパースエラーは `OnvifResponseParseErrorDetector` で検出し、コマンド送信済みとして無視する（多くのONVIFデバイスが非標準XMLを返すため）
- RTSP接続エラーは `RtspConnectionException` でラップし、`RtspErrorKind` で分類する
- グローバル未処理例外は `App_DispatcherUnhandledException` で捕捉し、致命的/非致命的を判定する

### RTSP再接続戦略
- 指数バックオフ（1秒 → 最大30秒）で最大10回リトライ
- 安定受信（30秒以上フレーム受信継続）後はリトライカウンタをリセット
- 安定受信後の最初3回はサイレントリトライ（UIに「接続中」を表示しない）
- 60秒のストールタイムアウト（InterruptCallback で検知）
- TCPバッファ2MB、パケット並べ替えキュー500

## 開発環境

### 必要ツール
- Visual Studio 2022 以降（WPFワークロード）または .NET 10 SDK + VS Code
- Windows OS（WPFはWindows専用、x64のみ）

### 主要コマンド
```bash
# ビルド
dotnet build View_RTSP/View_RTSP.csproj

# 実行
dotnet run --project View_RTSP/View_RTSP.csproj

# 発行
dotnet publish View_RTSP/View_RTSP.csproj -c Release
```

### ログ出力
- アプリケーションログ: `%APPDATA%/RtspViewer/app.log`（`Trace.WriteLine` 経由）
- FFmpegログ: `%APPDATA%/RtspViewer/ffmpeg.log`（`FFmpegLogger.LogWriter` 経由）

## 技術的決定事項

- **.NET 10採用**: 最新ランタイムを選択し、最新C#機能を活用
- **WPF選択**: ネイティブWindowsデスクトップ体験とリッチUI（WriteableBitmap によるフレーム描画）
- **Sdcb.FFmpeg選択**: LibVLCSharpではなくFFmpegバインディングを選択。RTSP受信とH.264デコードを低レベルで制御し、再接続ロジックとストール検知を自前で実装可能
- **Onvif.Core選択**: WCF/WS-Security ベースのONVIF通信。`StripScheme` でhttp://を除去する回避策が必要（ライブラリが内部でhttp://を付加するため）
- **手動DI**: 現時点のサービス数が少ないためDIコンテナ不使用。コンポジションルートは `App.OnStartup` に集約
- **単一プロジェクト構成**: 機能追加に応じてクラスライブラリへの分離を検討

---
_updated_at: 2026-03-15_
_主要なフレームワークと規約を記録するものであり、全依存関係の列挙ではない_
