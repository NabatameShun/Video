# プロジェクト構造

## 構成哲学

WPF標準の単一プロジェクト構成。現時点はスキャフォールド段階であり、機能追加に応じてディレクトリを拡張していく。ファイルは責務ごとに分離し、1ファイルあたりの肥大化を避ける。

## ディレクトリパターン

### ソリューションルート
**場所**: `/`
**目的**: ソリューションファイルとプロジェクトディレクトリ
**例**: `View_RTSP.slnx`（ソリューション定義）

### アプリケーションプロジェクト
**場所**: `/View_RTSP/`
**目的**: アプリケーションの全ソースコードを格納するメインプロジェクト
**例**: `App.xaml`、`MainWindow.xaml`、`View_RTSP.csproj`

### ウィンドウ・ビュー
**場所**: `/View_RTSP/`（将来的には `/View_RTSP/Views/`）
**目的**: WPFウィンドウとページのXAMLとコードビハインドのペア
**例**: `MainWindow.xaml` + `MainWindow.xaml.cs`

### ViewModel（追加予定）
**場所**: `/View_RTSP/ViewModels/`
**目的**: MVVMパターンのViewModelクラス（INotifyPropertyChanged実装）
**例**: `MainWindowViewModel.cs`

### サービス・ロジック（追加予定）
**場所**: `/View_RTSP/Services/`
**目的**: RTSPクライアント、ストリーム管理など業務ロジック
**例**: `RtspStreamService.cs`

## 命名規則

- **ファイル名**: PascalCase（例: `MainWindow.xaml`、`StreamViewModel.cs`）
- **名前空間**: `View_RTSP` をルートとし、サブディレクトリに対応したサブ名前空間を使用（例: `View_RTSP.ViewModels`）
- **クラス名**: PascalCase
- **XAMLコントロールID**: camelCase（例: `rtspPlayerControl`、`connectButton`）
- **プライベートフィールド**: `_camelCase`（アンダースコアプレフィックス）

## WPFファイルペアの原則

XAMLファイルは必ずコードビハインドとペアを成す：
```
MainWindow.xaml       ← UI定義（レイアウト、バインディング）
MainWindow.xaml.cs    ← コードビハインド（イベント処理、InitializeComponent）
```

コードビハインドはUIイベント処理の最小限に留め、ロジックはViewModelやサービスに委譲する。

## コード組織の原則

- **UIロジック分離**: XAMLはレイアウト、コードビハインドはUI操作の橋渡し、ビジネスロジックはサービスクラスへ
- **単一責任**: 1クラス1責務、大きくなったクラスは分割する
- **プロジェクト分割基準**: 再利用可能なロジック（RTSP処理ライブラリ等）は将来的にクラスライブラリプロジェクトへ分離を検討

---
_パターンを記録するものであり、ディレクトリツリーの網羅的なリストではない。新しいファイルが既存パターンに従う場合、このファイルの更新は不要_
