# プロジェクト構造

## 構成哲学

WPF標準のMVVM構成。責務ごとにディレクトリを分離し、View・ViewModel・Model・Service の4層でコードを整理する。1ファイルあたりの肥大化を避け、単一責任の原則に従う。

## ディレクトリパターン

### ソリューションルート
**場所**: `/`
**目的**: ソリューションファイルとプロジェクトディレクトリ
**例**: `View_RTSP.slnx`（ソリューション定義）

### アプリケーションプロジェクト
**場所**: `/View_RTSP/`
**目的**: アプリケーションの全ソースコードを格納するメインプロジェクト
**例**: `App.xaml`（コンポジションルート）、`MainWindow.xaml`、`View_RTSP.csproj`

### モデル (`/View_RTSP/Models/`)
**目的**: ドメインモデル・列挙型・データ構造の定義
**パターン**: `readonly record struct` で不変データを定義。関連する型は1ファイルにまとめる
**例**: `DomainModels.cs`（ConnectionState, RtspConnectionOptions, OnvifConnectionOptions 等）、`SettingsModels.cs`

### ビューモデル (`/View_RTSP/ViewModels/`)
**目的**: MVVMパターンのViewModelクラス
**パターン**: `ObservableObject` を継承した `partial class`。1 ViewModel = 1 ファイル
**例**: `MainWindowViewModel.cs`（レイアウト管理・設定永続化）、`StreamPaneViewModel.cs`（ペインごとの接続・PTZ・統計）

### ビュー (`/View_RTSP/Views/`)
**目的**: WPFユーザーコントロール（XAMLとコードビハインドのペア）
**パターン**: UserControlとして定義。コードビハインドはUIイベント処理の最小限に留める
**例**: `StreamPaneView.xaml`、`ConnectionSettingsView.xaml`、`PtzControlView.xaml`

### サービス (`/View_RTSP/Services/`)
**目的**: ビジネスロジックと外部ライブラリ連携
**パターン**: インターフェース（`I*.cs`）と実装クラスのペア。外部依存はアダプターで抽象化
**例**: `IRtspStreamService.cs` + `RtspStreamService.cs`、`IOnvifPtzService.cs` + `OnvifPtzService.cs`

### ONVIFアダプター (`/View_RTSP/Services/Onvif/`)
**名前空間**: `View_RTSP.Services.OnvifAdapters`
**目的**: Onvif.Core ライブラリのラッパー。インターフェース定義とアダプター実装を格納
**パターン**: `IOnvif*Client` インターフェースと `*Adapter` / `*AdapterImpl` 実装クラス。`OnvifResponseParseErrorDetector` でXML応答エラーを共通検出
**例**: `IOnvifClientFactory.cs`、`OnvifClientFactoryAdapter.cs`（StripScheme回避策を含む）

### コンバーター (`/View_RTSP/Converters/`)
**目的**: WPF IValueConverter 実装（XAMLバインディング用の値変換）
**パターン**: 1コンバーター = 1ファイル。命名は `{SourceType}To{TargetType}Converter`
**例**: `ConnectionStateToColorConverter.cs`、`ErrorMessageToVisibilityConverter.cs`

### テーマ (`/View_RTSP/Themes/`)
**目的**: XAMLリソースディクショナリ（ダークテーマの色・タイポグラフィ・コントロールスタイル・アニメーション）
**パターン**: 関心事ごとに分割したリソースディクショナリ。`App.xaml` でマージ
**例**: `Colors.xaml`、`Typography.xaml`、`Controls.xaml`、`Animations.xaml`、`Icons.xaml`

## 命名規則

- **ファイル名**: PascalCase（例: `MainWindow.xaml`、`StreamPaneViewModel.cs`）
- **名前空間**: `View_RTSP` をルートとし、サブディレクトリに対応（例: `View_RTSP.ViewModels`、`View_RTSP.Services.OnvifAdapters`）
- **クラス名**: PascalCase
- **インターフェース名**: `I` プレフィックス + PascalCase（例: `IRtspStreamService`）
- **プライベートフィールド**: `_camelCase`（アンダースコアプレフィックス）
- **ObservableProperty**: `_camelCase` のprivateフィールドに `[ObservableProperty]` を付与すると、PascalCaseの公開プロパティが自動生成される

## WPFファイルペアの原則

XAMLファイルは必ずコードビハインドとペアを成す：
```
StreamPaneView.xaml       <- UI定義（レイアウト、バインディング）
StreamPaneView.xaml.cs    <- コードビハインド（UIイベント処理の最小限）
```

コードビハインドはUIイベント処理の最小限に留め、ロジックはViewModelやサービスに委譲する。

## コード組織の原則

- **MVVM分離**: View → ViewModel → Service の一方向依存。ViewModelはViewを参照しない
- **インターフェース駆動**: サービスはインターフェース経由で注入。外部ライブラリはアダプターで抽象化
- **UIスレッド安全性**: バックグラウンドスレッドからのUI更新は `Dispatcher.Invoke` を使用
- **コンポジションルート**: `App.OnStartup` でサービスとViewModelを組み立て、`MainWindow.DataContext` に設定

---
_updated_at: 2026-03-15_
_パターンを記録するものであり、ディレクトリツリーの網羅的なリストではない。新しいファイルが既存パターンに従う場合、このファイルの更新は不要_
