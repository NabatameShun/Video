# Requirements Document

## Introduction

本ドキュメントは、View_RTSP アプリケーションにおけるローカル録画機能の要件を定義する。各ストリームペインで受信中のRTSPストリームをMP4ファイルとしてローカルフォルダに保存する機能を対象とする。

## Project Description (Input)
録画機能。各画面に接続している分を録画する。録画ファイルはローカルフォルダにMP4で保存。

## Requirements

### Requirement 1: 録画の開始と停止

**Objective:** 監視オペレーターとして、各ストリームペインの映像を任意のタイミングで録画開始・停止したい。録画した映像を後から確認できるようにするため。

#### Acceptance Criteria
1. When ユーザーがストリームペインの録画開始ボタンをクリックする, the Recording Service shall 該当ペインのRTSPストリームをMP4形式でローカルファイルへの書き込みを開始する
2. When ユーザーがストリームペインの録画停止ボタンをクリックする, the Recording Service shall 録画を終了し、MP4ファイルを正常にクローズする
3. While RTSPストリームが未接続の状態である, the Recording Service shall 録画開始ボタンを無効化する
4. While 録画中である, the Recording Service shall 録画停止ボタンを有効化し、録画開始ボタンを無効化する
5. The Recording Service shall 各ストリームペインで独立して録画の開始・停止を制御できる

### Requirement 2: 録画ファイルの保存

**Objective:** 監視オペレーターとして、録画ファイルが整理された形でローカルフォルダに保存されるようにしたい。後から録画を検索・再生しやすくするため。

#### Acceptance Criteria
1. The Recording Service shall 録画ファイルをMP4コンテナ形式（H.264映像）で保存する
2. The Recording Service shall 録画ファイル名に録画開始日時を含める（例: `20260315_143000.mp4`）
3. The Recording Service shall 録画ファイルをユーザーが指定した保存先フォルダに格納する
4. When 保存先フォルダが存在しない場合, the Recording Service shall フォルダを自動作成する

### Requirement 3: 録画状態の表示

**Objective:** 監視オペレーターとして、各ペインの録画状態をリアルタイムで把握したい。録画の実行状況を一目で確認できるようにするため。

#### Acceptance Criteria
1. While 録画中である, the View_RTSP shall ペイン上に録画中であることを視覚的に示すインジケーターを表示する
2. While 録画中である, the View_RTSP shall 録画経過時間を表示する
3. When 録画が正常に停止される, the View_RTSP shall 録画インジケーターを非表示にする

### Requirement 4: 録画保存先の設定

**Objective:** 監視オペレーターとして、録画ファイルの保存先フォルダを設定で変更したい。ディスク容量やファイル管理の都合に合わせて保存場所を選択できるようにするため。

#### Acceptance Criteria
1. The View_RTSP shall 録画ファイルの保存先フォルダをユーザーが設定できるUIを提供する
2. The View_RTSP shall 保存先フォルダのデフォルト値を設定する（例: `%USERPROFILE%/Videos/RtspViewer`）
3. When アプリケーションが終了する, the View_RTSP shall 録画保存先フォルダ設定を永続化する
4. When アプリケーションが起動する, the View_RTSP shall 前回の録画保存先フォルダ設定を復元する

### Requirement 5: 録画中のエラーハンドリング

**Objective:** 監視オペレーターとして、録画中に問題が発生した場合に適切に通知を受けたい。録画データの損失を最小限に抑えるため。

#### Acceptance Criteria
1. If 録画中にRTSP接続が切断される, the Recording Service shall 録画を自動的に停止し、それまでの録画データを含むMP4ファイルを正常にクローズする
2. If 録画中にディスク書き込みエラーが発生する, the Recording Service shall 録画を停止し、ユーザーにエラーメッセージを表示する
3. If 保存先フォルダへの書き込み権限がない場合, the Recording Service shall 録画開始時にエラーメッセージを表示し、録画を開始しない
4. When RTSP再接続が成功する, the Recording Service shall 自動的には録画を再開せず、ユーザーの明示的な操作を待つ
