# Research & Design Decisions

---
**Purpose**: ローカル録画機能のディスカバリーで得た調査結果・設計判断の根拠を記録する。
**Usage**: design.md の補足資料。詳細な調査ログ・比較・代替案をここに集約する。
---

## Summary
- **Feature**: `local-recording`
- **Discovery Scope**: Extension（既存 RtspStreamService の拡張 + 新規 RecordingService）
- **Key Findings**:
  - Sdcb.FFmpeg 7.0 は `FormatContext.AllocOutput` / `IOContext.OpenWrite` / `InterleavedWritePacket` による MP4 リミュクスを完全サポートしており、再エンコード不要で H.264 パケットを直接 MP4 コンテナに書き込める
  - クラッシュ耐性には fragmented MP4（`movflags: empty_moov+frag_keyframe`）を採用し、moov atom 未書き込みによるファイル破損リスクを排除する
  - パケットインターセプトはデリゲートコールバック方式で RtspStreamService のデコードループに最小限の変更で統合可能

## Research Log

### Sdcb.FFmpeg MP4 リミュクス API
- **Context**: 既存プロジェクトで使用中の Sdcb.FFmpeg 7.0 で MP4 muxing が可能か調査
- **Sources Consulted**:
  - [sdcb/ffmpeg-muxing-video-demo](https://github.com/sdcb/ffmpeg-muxing-video-demo) - 公式デモリポジトリ
  - [sdcb/Sdcb.FFmpeg](https://github.com/sdcb/Sdcb.FFmpeg) - ライブラリ本体
  - [Sdcb.FFmpeg.Tests/Examples.cs](https://github.com/sdcb/Sdcb.FFmpeg/blob/release/4.4.3/src/Sdcb.FFmpeg.Tests/Examples.cs) - テスト例
- **Findings**:
  - `FormatContext.AllocOutput(formatName: "mp4")` で出力コンテキストを確保
  - `fc.NewStream()` でビデオストリームを作成し、`Codecpar.CopyFrom()` でソースストリームのコーデックパラメータをコピー
  - `IOContext.OpenWrite(path)` でファイル I/O を開き、`fc.Pb = io` で紐付け
  - `fc.WriteHeader()` → `fc.InterleavedWritePacket(packet)` → `fc.WriteTrailer()` の順で書き込み
  - `packet.RescaleTimestamp(srcTimeBase, dstTimeBase)` でタイムスタンプを変換
  - リミュクスの場合、デコード・エンコードは不要。パケットをそのまま書き込める
- **Implications**: 再エンコード不要のため CPU 負荷が極めて低い。既存のデコードループ内でパケットをコピーして録画サービスに渡す方式が適切

### moov atom とクラッシュ耐性
- **Context**: 通常の MP4 は `WriteTrailer()` 呼び出し時に moov atom を書き込むため、クラッシュ時にファイルが再生不能になるリスクがある
- **Sources Consulted**:
  - [FFmpeg Formats Documentation](https://ffmpeg.org/ffmpeg-formats.html) - movflags オプション
  - [EaseUS moov atom guide](https://www.easeus.com/data-recovery-solution/moov-atom-not-found.html)
- **Findings**:
  - **通常 MP4**: moov atom はファイル末尾に書き込まれる。`WriteTrailer()` 未呼び出しでファイルが破損する
  - **Fragmented MP4** (`movflags: empty_moov+frag_keyframe`): 各キーフレームで独立したフラグメントを生成。moov atom は空で開始時に書き込まれ、各フラグメントが自己完結。クラッシュ時は最後のフラグメントのみ損失
  - **faststart** (`movflags: faststart`): moov atom をファイル先頭に移動するが、WriteTrailer 時の二重書き込みが必要で、fragmented モードとは併用不可
  - fragmented MP4 は一部の古いプレーヤーで非対応だが、VLC / Windows Media Player / 主要ブラウザは対応済み
- **Implications**: 監視用途ではクラッシュ耐性を優先し fragmented MP4 を採用。正常停止時は `WriteTrailer()` を呼び出してファイルを正しく終端する

### パケットインターセプト方式の比較
- **Context**: RtspStreamService のデコードループからパケットを録画サービスに渡す方式を検討
- **Findings**:
  - **Option A: イベント方式** - `PacketReceived` イベントを追加し、サブスクライバがパケットを受け取る
    - 利点: 疎結合、複数サブスクライバ対応
    - 欠点: パケットの寿命管理が複雑（イベントハンドラ実行後に Unref される）、パフォーマンスオーバーヘッド
  - **Option B: デリゲートコールバック方式** - `Action<Packet>?` コールバックを RtspStreamService に設定
    - 利点: シンプル、パケット寿命が明確（コールバック内でコピー）、1:1 の関係に適合
    - 欠点: 単一コールバックのみ
  - **Option C: Producer-Consumer キュー** - `Channel<PacketData>` でパケットデータを非同期キューに投入
    - 利点: スレッド安全、バックプレッシャー制御
    - 欠点: 複雑度が高い、パケットコピーのメモリアロケーション
- **Selected**: Option B（デリゲートコールバック方式）。録画は 1 ペインにつき 1 録画のみであり、1:1 関係が自然。コールバック内でパケットデータを即座にコピーし、録画スレッドに渡す

### PTS/DTS タイムスタンプ変換
- **Context**: RTSP ストリームのタイムベースと MP4 出力のタイムベースが異なるため変換が必要
- **Findings**:
  - RTSP H.264 ストリームの典型的なタイムベース: 1/90000（90kHz クロック）
  - MP4 コンテナのデフォルトタイムベース: ストリーム作成時に設定（通常はソースと同じタイムベースを使用）
  - `packet.RescaleTimestamp(srcTimeBase, dstTimeBase)` で変換可能
  - 録画開始時の最初のパケットの PTS を基準点（0）としてオフセットする必要がある
- **Implications**: 出力ストリームのタイムベースをソースストリームと同一に設定し、PTS オフセットのみ調整する方式が最もシンプル

## Architecture Pattern Evaluation

| Option | Description | Strengths | Risks / Limitations | Notes |
|--------|-------------|-----------|---------------------|-------|
| Hybrid Service | 新規 IRecordingService + RtspStreamService にパケットコールバック追加 | 関心の分離が明確、既存コード変更が最小限 | コールバックのスレッド安全性に注意 | 推奨 |
| 統合方式 | RtspStreamService 内に録画ロジックを組み込む | 追加サービス不要 | SRP 違反、RtspStreamService の肥大化 | 却下 |
| メディエータ方式 | パケットルーターサービスを介在 | 高い拡張性 | 過剰設計、現時点では不要な複雑度 | 却下 |

## Design Decisions

### Decision: Fragmented MP4 によるクラッシュ耐性
- **Context**: 録画中にアプリケーションクラッシュやプロセス強制終了が発生した場合、録画データを可能な限り保護する必要がある（要件 5.1）
- **Alternatives Considered**:
  1. 通常 MP4 + WriteTrailer — クラッシュ時にファイル全損
  2. Fragmented MP4 — 最後のフラグメントのみ損失
  3. 定期的な moov atom 更新 — 実装複雑、FFmpeg API で直接サポートされない
- **Selected Approach**: Fragmented MP4（`empty_moov+frag_keyframe`）
- **Rationale**: 監視用途ではデータ保護が最優先。fragmented MP4 は FFmpeg の標準 movflags で設定可能で実装が簡素
- **Trade-offs**: 古いプレーヤーで再生できない可能性があるが、主要プレーヤーは対応済み
- **Follow-up**: 正常停止時は WriteTrailer を確実に呼び出し、ファイルを適切に終端する

### Decision: デリゲートコールバック方式によるパケットインターセプト
- **Context**: RtspStreamService のデコードループ内でパケットを録画サービスに渡す仕組みが必要
- **Alternatives Considered**:
  1. イベント方式 — パケット寿命管理が複雑
  2. デリゲートコールバック — シンプルで明確
  3. Channel ベース Producer-Consumer — 過剰な複雑度
- **Selected Approach**: `Action<Packet, AVRational>?` コールバックプロパティを IRtspStreamService に追加
- **Rationale**: 1 ペインにつき 1 録画の 1:1 関係であり、コールバックが最適。パケットの寿命はコールバック実行中のみ有効であることを契約として明確化
- **Trade-offs**: 複数サブスクライバは不可だが、現要件では不要
- **Follow-up**: コールバック内でのパケットデータコピーは録画サービス側の責務

### Decision: 録画状態マシン設計
- **Context**: 録画の開始・停止・エラー時の状態遷移を明確に定義する必要がある
- **Selected Approach**: 3 状態の状態マシン（Idle → Recording → Stopping → Idle）
- **Rationale**: シンプルで網羅的。Stopping 状態を設けることで WriteTrailer の非同期完了を安全に待機できる

## Risks & Mitigations
- **パケットコールバック内のブロッキング** — コールバックはデコードスレッド上で実行されるため、録画サービスはパケットデータを即座にコピーしてバッファリングし、実際の I/O は録画専用スレッドで行う
- **ディスク I/O ボトルネック** — リミュクス（再エンコードなし）のため書き込みデータ量は RTSP 受信量と同程度。一般的な監視カメラ（2-8 Mbps）では SSD/HDD ともに問題なし
- **スレッド安全性** — 録画状態の変更は lock で保護。パケットコールバックはデコードスレッドから呼ばれ、録画 I/O は別スレッドで実行

## References
- [sdcb/ffmpeg-muxing-video-demo](https://github.com/sdcb/ffmpeg-muxing-video-demo) — Sdcb.FFmpeg MP4 muxing 公式デモ
- [sdcb/Sdcb.FFmpeg](https://github.com/sdcb/Sdcb.FFmpeg) — ライブラリ本体リポジトリ
- [FFmpeg Formats Documentation](https://ffmpeg.org/ffmpeg-formats.html) — movflags 等の出力オプション仕様
- [FFmpeg Bitstream Filters Documentation](https://ffmpeg.org/ffmpeg-bitstream-filters.html) — h264_mp4toannexb 等
