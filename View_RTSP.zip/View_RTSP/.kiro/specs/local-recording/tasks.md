# Implementation Plan

- [x] 1. 録画ドメインモデルと設定モデルの拡張
- [x] 1.1 (P) 録画状態・エラー種別のドメインモデルを追加する
  - 録画状態を表す列挙型（Idle / Recording / Stopping）を定義する
  - 録画エラー種別の列挙型（DiskWriteError / PermissionDenied / DirectoryCreationFailed）を定義する
  - 録画エラーイベント引数クラスを定義する（エラー種別とメッセージを保持）
  - _Requirements: 1.1, 1.2, 5.1, 5.2, 5.3_

- [x] 1.2 (P) AppSettings に録画保存先フォルダフィールドを追加する
  - AppSettings レコードに録画保存先フォルダパスフィールドを追加する
  - デフォルト値として `%USERPROFILE%/Videos/RtspViewer` を設定する
  - AppSettingsDto にも対応するフィールドを追加し、既存 JSON との後方互換性を確保する（null 時はデフォルト値にフォールバック）
  - _Requirements: 4.2, 4.3, 4.4_

- [x] 2. RtspStreamService にパケットコールバック機構を追加する
  - IRtspStreamService インターフェースにパケット受信コールバックプロパティを追加する（パケット、タイムベース、コーデックパラメータを受け取るデリゲート）
  - RtspStreamService のデコードループ内でパケット読み取り後にコールバックを呼び出す
  - コールバックが null の場合はスキップし、パフォーマンスへの影響を排除する
  - コールバック内の例外がデコードループをクラッシュさせないよう try-catch でラップする
  - _Requirements: 1.1_
  - _Contracts: IRtspStreamService (拡張)_

- [x] 3. RecordingService の実装
- [x] 3.1 録画サービスのインターフェースと基本構造を実装する
  - IRecordingService インターフェースを定義する（Start / Stop / WritePacket / State / イベント）
  - RecordingService クラスの骨格を作成し、状態マシン（Idle → Recording → Stopping → Idle）を実装する
  - 状態遷移を lock で保護し、スレッドセーフな状態管理を実現する
  - StateChanged イベントと RecordingError イベントを実装する
  - IDisposable パターンでリソース解放を実装する
  - _Requirements: 1.1, 1.2, 1.5_
  - _Contracts: IRecordingService_

- [x] 3.2 MP4 リミュクスによる録画開始処理を実装する
  - Start メソッドで出力フォルダの存在確認・自動作成を行う
  - テストファイル書き込みによる書き込み権限チェックを実施する
  - 録画開始日時をローカル時刻でファイル名に含める（yyyyMMdd_HHmmss 形式）
  - FormatContext / IOContext / MediaStream を使用して MP4 出力コンテキストを構築する
  - Fragmented MP4（empty_moov + frag_keyframe）でヘッダーを書き込む
  - ソースストリームのコーデックパラメータをコピーしてビデオストリームを作成する
  - 権限エラーやフォルダ作成失敗時に RecordingError イベントを発行して録画を拒否する
  - _Requirements: 1.1, 2.1, 2.2, 2.3, 2.4, 5.3_

- [x] 3.3 パケット書き込みと録画停止処理を実装する
  - WritePacket メソッドで録画状態を確認し、Recording 状態でのみパケットを処理する
  - パケットデータをコピーし、PTS/DTS オフセットを調整して出力コンテキストに書き込む
  - 録画開始時の最初のパケットの PTS を基準点としてオフセットする
  - Stop メソッドで Stopping 状態に遷移し、WriteTrailer でファイルを正常に終端する
  - IOContext と FormatContext を適切に解放する
  - ディスク書き込みエラー発生時に録画を停止し RecordingError イベントを発行する
  - _Requirements: 1.2, 2.1, 5.1, 5.2_

- [x] 4. StreamPaneViewModel に録画機能を統合する
- [x] 4.1 録画コマンドと状態プロパティを追加する
  - ToggleRecording コマンドを実装し、録画の開始・停止をトグルする
  - CanToggleRecording で RTSP 接続状態と録画状態に基づく有効/無効制御を実装する
  - RTSP 未接続時に録画ボタンを無効化する
  - 録画中は停止ボタンを有効化し、開始ボタンを無効化する
  - IsRecording プロパティで録画状態を UI に公開する
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_
  - _Contracts: StreamPaneViewModel (拡張)_

- [x] 4.2 録画経過時間の表示とイベントハンドリングを実装する
  - DispatcherTimer（1 秒間隔）で録画経過時間を更新する
  - RecordingElapsedTime プロパティで経過時間文字列（HH:mm:ss 形式）を UI に公開する
  - RecordingService の StateChanged / RecordingError イベントをサブスクライブする
  - エラーイベント受信時に ErrorMessage プロパティへエラーメッセージを反映する
  - _Requirements: 3.2, 5.2_

- [x] 4.3 RTSP 切断時の自動録画停止とコールバック管理を実装する
  - RTSP 接続確立後にパケットコールバックを設定する
  - RTSP 切断検知時に録画を自動停止し、それまでのデータを含む MP4 を正常にクローズする
  - RTSP 切断時にパケットコールバックを解除する
  - RTSP 再接続成功時に自動的には録画を再開せず、ユーザーの明示的な操作を待つ
  - _Requirements: 5.1, 5.4_

- [x] 5. StreamPaneView に録画 UI を追加する
- [x] 5.1 録画ボタンと録画インジケーターを実装する
  - 録画開始/停止のトグルボタンを追加し、ToggleRecordingCommand にバインドする
  - IsRecording プロパティに応じてボタンのアイコンやスタイルを切り替える
  - 録画中に赤丸インジケーターを表示する（BooleanToVisibilityConverter でバインド）
  - 録画経過時間をインジケーター付近に表示する
  - RTSP 未接続時は録画ボタンを無効化状態で表示する
  - _Requirements: 1.3, 1.4, 3.1, 3.2, 3.3_

- [x] 5.2 (P) 録画保存先フォルダの設定 UI を実装する
  - フォルダ選択ボタン付きテキストボックスを接続設定エリアに追加する
  - RecordingFolderPath プロパティにバインドする
  - フォルダ選択ダイアログでユーザーが保存先を変更できるようにする
  - _Requirements: 4.1_

- [x] 6. DI 構成と録画保存先設定の永続化を統合する
- [x] 6.1 App.OnStartup で RecordingService の DI 組み立てを追加する
  - ペインごとに独立した RecordingService インスタンスを生成する
  - StreamPaneViewModel に RecordingService を注入する
  - アプリケーション終了時に RecordingService を Dispose する
  - _Requirements: 1.5_

- [x] 6.2 録画保存先フォルダ設定の永続化・復元を実装する
  - アプリケーション終了時に RecordingFolderPath を AppSettings 経由で JSON に保存する
  - アプリケーション起動時に前回の RecordingFolderPath を復元し、ViewModel に反映する
  - 設定が存在しない場合はデフォルト値にフォールバックする
  - _Requirements: 4.3, 4.4_

- [x] 7. 結合テストとエンドツーエンド検証
- [x] 7.1 RecordingService の状態マシンとバリデーションをテストする
  - 状態マシン遷移（Idle → Recording → Stopping → Idle）の正常系テスト
  - Start 時の無効パス・書き込み権限なしのバリデーションテスト
  - ファイル名生成ロジックの日時フォーマットテスト
  - CanToggleRecording の条件テスト（接続状態 x 録画状態の組み合わせ）
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 2.2, 5.3_

- [x] 7.2 MP4 録画フローとエラーハンドリングの結合テスト
  - パケットコールバック経由で録画した MP4 ファイルが有効な MP4 として再生可能であることを検証する
  - RTSP 切断時に自動停止し、それまでの録画が保存されることを検証する
  - ディスク書き込みエラー時に録画が停止しエラーメッセージが表示されることを検証する
  - RecordingFolderPath の永続化・復元が正しく機能することを検証する
  - _Requirements: 2.1, 4.3, 4.4, 5.1, 5.2_
