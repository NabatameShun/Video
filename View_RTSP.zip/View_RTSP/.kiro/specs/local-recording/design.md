# Technical Design: local-recording

## Overview

**Purpose**: 本機能は、各ストリームペインで受信中の RTSP ストリームを MP4 ファイルとしてローカルフォルダに保存する録画機能を提供する。

**Users**: 監視オペレーターが、任意のタイミングで録画を開始・停止し、録画ファイルを後から確認・検索できるようにする。

**Impact**: 既存の RtspStreamService にパケットコールバック機構を追加し、新規 RecordingService で MP4 リミュクスを実行する。StreamPaneViewModel に録画コマンドと状態表示を追加し、SettingsService / AppSettings に録画保存先フォルダの永続化を追加する。

### Goals
- RTSP H.264 パケットを再エンコードなしで MP4 コンテナにリミュクスし、CPU 負荷を最小化する
- ペインごとに独立した録画の開始・停止を実現する
- Fragmented MP4 によりクラッシュ時のデータ損失を最小化する
- 既存の MVVM / サービスパターンに準拠した設計

### Non-Goals
- 音声トラックの録画（RTSP ストリームのビデオトラックのみ対象）
- 録画ファイルの再生機能（外部プレーヤーでの再生を前提）
- 録画ファイルの自動削除・ディスク容量管理
- 複数カメラの同時録画を跨いだ同期

## Architecture

### Existing Architecture Analysis

現在のアーキテクチャは WPF MVVM 構成で、以下のパターンが確立されている:

- **サービス層**: `IRtspStreamService` / `RtspStreamService` がデコードループを管理。パケット読み取り → デコード → フレーム変換 → レンダラーへの描画をシングルスレッドで実行
- **ViewModel 層**: `StreamPaneViewModel` がペインごとの接続・PTZ・統計を管理。`[ObservableProperty]` と `[RelayCommand]` で XAML バインディングを提供
- **設定永続化**: `ISettingsService` / `SettingsService` が `AppSettings` を JSON ファイルに保存。`AppSettings` は `record` 型で不変
- **DI**: `App.OnStartup` でサービスを手動組み立て

録画機能は以下の統合ポイントに接続する:
- `RtspStreamService.RunDecodeLoopSync` 内の `ReadPackets` ループでパケットをインターセプト
- `StreamPaneViewModel` に録画コマンドと状態プロパティを追加
- `AppSettings` に録画保存先フォルダフィールドを追加

### Architecture Pattern & Boundary Map

```mermaid
graph TB
    subgraph UI Layer
        SPV[StreamPaneView]
    end

    subgraph ViewModel Layer
        SPVM[StreamPaneViewModel]
    end

    subgraph Service Layer
        RSS[RtspStreamService]
        RS[RecordingService]
        SS[SettingsService]
    end

    subgraph External
        RTSP[RTSP Camera]
        FS[File System]
    end

    SPV --> SPVM
    SPVM --> RSS
    SPVM --> RS
    SPVM --> SS
    RSS -->|Packet Callback| RS
    RSS --> RTSP
    RS --> FS
```

**Architecture Integration**:
- Selected pattern: 既存 MVVM + サービス層パターンの拡張。新規 `IRecordingService` を追加し、`RtspStreamService` にパケットコールバック機構を追加
- Domain/feature boundaries: 録画ロジックは `RecordingService` に集約。RtspStreamService はパケット配信のみ担当し、録画の知識を持たない
- Existing patterns preserved: インターフェース駆動の DI、`readonly record struct` によるデータモデル、`ObservableObject` / `[ObservableProperty]` による ViewModel
- New components rationale: `IRecordingService` はファイル I/O と FFmpeg muxing を RtspStreamService から分離するために必要
- Steering compliance: サービスは `IDisposable` を実装しリソース解放を明示化。UI スレッド安全性は `Dispatcher.Invoke` を使用

### Technology Stack

| Layer | Choice / Version | Role in Feature | Notes |
|-------|------------------|-----------------|-------|
| Service | Sdcb.FFmpeg 7.0 | MP4 リミュクス（FormatContext, IOContext, Packet） | 既存依存。新規ライブラリ追加なし |
| Service | .NET 10 System.IO | ファイル書き込み、ディレクトリ作成 | 標準ライブラリ |
| ViewModel | CommunityToolkit.Mvvm 8.4 | 録画コマンド・状態プロパティのバインディング | 既存依存 |
| UI | WPF UserControl | 録画ボタン・インジケーター | 既存 StreamPaneView の拡張 |
| Data | SettingsService (JSON) | 録画保存先フォルダの永続化 | 既存パターン拡張 |

## System Flows

### 録画開始〜停止フロー

```mermaid
sequenceDiagram
    participant User
    participant SPVM as StreamPaneViewModel
    participant RS as RecordingService
    participant RSS as RtspStreamService
    participant FS as File System

    User->>SPVM: ToggleRecordingCommand
    SPVM->>RS: StartAsync(outputPath, codecpar, timeBase)
    RS->>FS: IOContext.OpenWrite(path)
    RS->>RS: FormatContext.WriteHeader()
    RS-->>SPVM: State = Recording

    loop Packet Reception
        RSS->>RSS: ReadPackets loop
        RSS->>RS: OnPacketReceived(packet, timeBase)
        RS->>RS: Copy packet data
        RS->>FS: InterleavedWritePacket
    end

    User->>SPVM: ToggleRecordingCommand
    SPVM->>RS: StopAsync()
    RS->>RS: State = Stopping
    RS->>FS: WriteTrailer()
    RS->>FS: Close IOContext
    RS-->>SPVM: State = Idle
```

### 録画状態マシン

```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> Recording : StartAsync
    Recording --> Stopping : StopAsync / RTSP Disconnect / Disk Error
    Stopping --> Idle : Finalization Complete
```

Key Decisions:
- `Stopping` 状態を設けて `WriteTrailer()` の完了を安全に待機する。この間は新たな `StartAsync` を受け付けない
- RTSP 切断時は自動的に `Stopping` に遷移し、それまでのデータを含む MP4 を正常にクローズする（5.1）
- RTSP 再接続成功時に録画は自動再開しない（5.4）

## Requirements Traceability

| Requirement | Summary | Components | Interfaces | Flows |
|-------------|---------|------------|------------|-------|
| 1.1 | 録画開始ボタンで MP4 書き込み開始 | RecordingService, StreamPaneViewModel | IRecordingService.StartAsync | 録画開始フロー |
| 1.2 | 録画停止ボタンで MP4 正常クローズ | RecordingService, StreamPaneViewModel | IRecordingService.StopAsync | 録画停止フロー |
| 1.3 | RTSP 未接続時は録画ボタン無効 | StreamPaneViewModel | CanStartRecording | - |
| 1.4 | 録画中は停止ボタン有効、開始ボタン無効 | StreamPaneViewModel | IsRecording, CanStartRecording | - |
| 1.5 | ペインごとに独立した録画制御 | RecordingService (per-pane instance) | - | - |
| 2.1 | MP4 コンテナ形式で H.264 保存 | RecordingService | FormatContext, Codecpar | Packet Write |
| 2.2 | 録画開始日時を含むファイル名 | RecordingService | GenerateFileName | - |
| 2.3 | ユーザー指定フォルダに保存 | RecordingService, SettingsService | RecordingFolderPath | - |
| 2.4 | 保存先フォルダ自動作成 | RecordingService | EnsureDirectoryExists | - |
| 3.1 | 録画中インジケーター表示 | StreamPaneView, StreamPaneViewModel | IsRecording | - |
| 3.2 | 録画経過時間表示 | StreamPaneViewModel | RecordingElapsedTime | - |
| 3.3 | 録画停止時にインジケーター非表示 | StreamPaneView, StreamPaneViewModel | IsRecording | - |
| 4.1 | 保存先フォルダ設定 UI | StreamPaneView or SettingsView | RecordingFolderPath | - |
| 4.2 | デフォルト保存先 | AppSettings, SettingsService | Default RecordingFolderPath | - |
| 4.3 | 終了時に保存先設定永続化 | SettingsService, MainWindowViewModel | AppSettings.RecordingFolderPath | - |
| 4.4 | 起動時に保存先設定復元 | SettingsService, MainWindowViewModel | AppSettings.RecordingFolderPath | - |
| 5.1 | RTSP 切断時に自動停止・MP4 クローズ | RecordingService, StreamPaneViewModel | OnRtspDisconnected | 状態マシン |
| 5.2 | ディスク書き込みエラー時に停止・通知 | RecordingService, StreamPaneViewModel | RecordingError event | エラーフロー |
| 5.3 | 書き込み権限エラー時に録画拒否 | RecordingService | ValidateOutputPath | - |
| 5.4 | RTSP 再接続時に自動録画再開しない | StreamPaneViewModel | OnStateChanged | - |

## Components and Interfaces

| Component | Domain/Layer | Intent | Req Coverage | Key Dependencies | Contracts |
|-----------|------------|--------|--------------|------------------|-----------|
| IRecordingService / RecordingService | Service | MP4 リミュクスによるパケット録画 | 1.1, 1.2, 1.5, 2.1-2.4, 5.1-5.3 | Sdcb.FFmpeg (P0), File System (P0) | Service, State, Event |
| IRtspStreamService (拡張) | Service | パケットコールバック機構の追加 | 1.1 | - | Service |
| StreamPaneViewModel (拡張) | ViewModel | 録画コマンド・状態・経過時間表示 | 1.1-1.5, 3.1-3.3, 5.1, 5.2, 5.4 | IRecordingService (P0), IRtspStreamService (P0) | State |
| AppSettings / SettingsModels (拡張) | Model | 録画保存先フォルダの追加 | 4.1-4.4 | - | - |
| StreamPaneView (拡張) | UI | 録画ボタン・インジケーター・経過時間 | 3.1-3.3, 4.1 | StreamPaneViewModel (P0) | - |

### Service Layer

#### IRecordingService / RecordingService

| Field | Detail |
|-------|--------|
| Intent | RTSP H.264 パケットを MP4 コンテナにリミュクスしてファイルに書き込む |
| Requirements | 1.1, 1.2, 1.5, 2.1, 2.2, 2.3, 2.4, 5.1, 5.2, 5.3 |

**Responsibilities & Constraints**
- MP4 出力コンテキストの作成・管理・破棄
- パケットの PTS/DTS オフセット調整と書き込み
- 録画状態マシン（Idle / Recording / Stopping）の管理
- 出力パスのバリデーション（ディレクトリ存在確認・書き込み権限チェック）
- Fragmented MP4 フォーマットによるクラッシュ耐性の確保
- 1 インスタンス = 1 ペインの録画。ペインごとに独立したインスタンスを DI で組み立てる

**Dependencies**
- External: Sdcb.FFmpeg 7.0 — FormatContext, IOContext, Packet, MediaStream (P0)
- External: System.IO — ファイル・ディレクトリ操作 (P0)
- Inbound: StreamPaneViewModel — 録画開始・停止の指示 (P0)
- Inbound: RtspStreamService — パケットコールバック経由のパケット受信 (P0)

**Contracts**: Service [x] / API [ ] / Event [x] / Batch [ ] / State [x]

##### Service Interface

```csharp
/// <summary>
/// 録画状態を表す列挙型
/// </summary>
public enum RecordingState
{
    Idle,
    Recording,
    Stopping
}

/// <summary>
/// 録画エラーイベント引数
/// </summary>
public sealed class RecordingErrorEventArgs : EventArgs
{
    public string Message { get; }
    public RecordingErrorKind Kind { get; }
    public RecordingErrorEventArgs(RecordingErrorKind kind, string message) { Kind = kind; Message = message; }
}

/// <summary>
/// 録画エラー種別
/// </summary>
public enum RecordingErrorKind
{
    DiskWriteError,
    PermissionDenied,
    DirectoryCreationFailed
}

/// <summary>
/// RTSP ストリームの録画サービスインターフェース
/// </summary>
public interface IRecordingService : IDisposable
{
    /// <summary>現在の録画状態</summary>
    RecordingState State { get; }

    /// <summary>録画開始日時（UTC）。Idle 状態では null</summary>
    DateTime? RecordingStartedAtUtc { get; }

    /// <summary>録画エラー発生時に発行されるイベント</summary>
    event EventHandler<RecordingErrorEventArgs> RecordingError;

    /// <summary>録画状態が変化したときに発行されるイベント</summary>
    event EventHandler<RecordingState> StateChanged;

    /// <summary>
    /// 録画を開始する。
    /// </summary>
    /// <param name="outputFolderPath">録画ファイルの保存先フォルダパス</param>
    /// <param name="sourceCodecpar">ソースストリームのコーデックパラメータ（Codecpar のコピー用）</param>
    /// <param name="sourceTimeBase">ソースストリームのタイムベース</param>
    /// <returns>開始に成功した場合 true</returns>
    /// <remarks>
    /// Preconditions: State == Idle, outputFolderPath が書き込み可能
    /// Postconditions: State == Recording, MP4 ファイルが作成されヘッダーが書き込まれる
    /// </remarks>
    bool Start(string outputFolderPath, CodecParameters sourceCodecpar, AVRational sourceTimeBase);

    /// <summary>
    /// 録画を停止し、MP4 ファイルを正常にクローズする。
    /// </summary>
    /// <remarks>
    /// Preconditions: State == Recording
    /// Postconditions: State == Idle, WriteTrailer 完了、リソース解放
    /// </remarks>
    void Stop();

    /// <summary>
    /// パケットを録画ファイルに書き込む。RtspStreamService のコールバックから呼ばれる。
    /// </summary>
    /// <param name="packet">書き込むパケット（コールバック内でのみ有効）</param>
    /// <param name="sourceTimeBase">ソースストリームのタイムベース</param>
    /// <remarks>
    /// Preconditions: State == Recording
    /// Invariants: パケットデータはこのメソッド内でコピーされる（呼び出し元のパケットを保持しない）
    /// </remarks>
    void WritePacket(Packet packet, AVRational sourceTimeBase);
}
```

- Preconditions: `Start` は `State == Idle` のときのみ呼び出し可能。出力フォルダへの書き込み権限が必要
- Postconditions: `Stop` 完了後は `State == Idle` に復帰し、MP4 ファイルは再生可能な状態で閉じられる
- Invariants: 録画中のパケット書き込みはスレッドセーフ。`WritePacket` はデコードスレッドから呼ばれ、内部で lock を使用

##### Event Contract
- Published events:
  - `RecordingError`: ディスク書き込みエラーまたは権限エラー発生時
  - `StateChanged`: 録画状態が遷移したとき（Idle → Recording → Stopping → Idle）
- Ordering / delivery guarantees: イベントは録画スレッドまたはデコードスレッドから発行される。UI 更新はハンドラ側で Dispatcher にディスパッチする

##### State Management
- State model: `RecordingState` 列挙型（Idle / Recording / Stopping）
- Persistence: 状態はメモリのみ（永続化不要）
- Concurrency strategy: `_stateLock` (object) で状態遷移を保護。`WritePacket` は `lock` 内で `State == Recording` を確認してから書き込み

**Implementation Notes**
- Integration: `RtspStreamService` のパケットコールバックから `WritePacket` が呼ばれる。コールバック内でパケットデータを `Packet.Clone()` または手動バッファコピーで複製し、出力コンテキストに書き込む
- Validation: `Start` 時に出力フォルダの存在確認・作成、テストファイル書き込みによる権限チェックを実施（5.3）
- Risks: デコードスレッド上での `WritePacket` 呼び出しが I/O ブロッキングとなる可能性がある。Fragmented MP4 の `InterleavedWritePacket` は通常高速だが、ディスク I/O 遅延が大きい場合はフレームドロップにつながる可能性がある。初期実装ではデコードスレッド上で直接書き込み、問題が発生した場合にバッファリング方式に移行する

#### IRtspStreamService (拡張)

| Field | Detail |
|-------|--------|
| Intent | パケットコールバック機構を追加し、録画サービスがパケットを受信できるようにする |
| Requirements | 1.1 |

**Contracts**: Service [x]

##### Service Interface (追加分)

```csharp
public interface IRtspStreamService : IDisposable
{
    // ... 既存メンバー ...

    /// <summary>
    /// パケット受信時に呼ばれるコールバック。
    /// デコードスレッドから呼ばれるため、ハンドラは高速に完了する必要がある。
    /// パケットはコールバック実行中のみ有効。保持する場合はコピーすること。
    /// </summary>
    /// <remarks>
    /// 第1引数: 受信パケット（コールバック内でのみ有効）
    /// 第2引数: ソースストリームのタイムベース
    /// 第3引数: ソースストリームのコーデックパラメータ（録画開始時のコピー用）
    /// </remarks>
    Action<Packet, AVRational, CodecParameters>? PacketReceived { get; set; }
}
```

**Implementation Notes**
- Integration: `RunDecodeLoopSync` 内の `foreach (var packet in formatContext.ReadPackets(...))` ループ内で、`codecContext.SendPacket(packet)` の直前に `PacketReceived?.Invoke(packet, stream.TimeBase, stream.Codecpar!)` を呼び出す
- Validation: コールバックが null の場合はスキップ（オーバーヘッドなし）
- Risks: コールバック内の例外がデコードループをクラッシュさせないよう、try-catch でラップする

### ViewModel Layer

#### StreamPaneViewModel (拡張)

| Field | Detail |
|-------|--------|
| Intent | 録画の開始・停止コマンド、録画状態・経過時間の表示を管理する |
| Requirements | 1.1, 1.2, 1.3, 1.4, 1.5, 3.1, 3.2, 3.3, 5.1, 5.2, 5.4 |

**Responsibilities & Constraints**
- 録画開始・停止の `[RelayCommand]` を提供
- `IsRecording` / `RecordingElapsedTime` プロパティで UI バインディングを提供
- RTSP 接続状態に応じた録画ボタンの有効/無効制御
- RTSP 切断イベント検知時の自動録画停止
- 録画エラーイベントの受信と `ErrorMessage` への反映
- パケットコールバックの接続・解除

**Dependencies**
- Outbound: IRecordingService — 録画の開始・停止・パケット書き込み (P0)
- Outbound: IRtspStreamService — パケットコールバック設定 (P0)
- Outbound: ISettingsService — 録画保存先フォルダの取得 (P1)

**Contracts**: State [x]

##### State Management

追加する `[ObservableProperty]` フィールド:

```csharp
/// <summary>録画中かどうか</summary>
[ObservableProperty]
private bool _isRecording;

/// <summary>録画経過時間の表示文字列（例: "00:05:23"）</summary>
[ObservableProperty]
private string _recordingElapsedTime = string.Empty;

/// <summary>録画保存先フォルダパス</summary>
[ObservableProperty]
private string _recordingFolderPath = string.Empty;
```

追加するコマンド:

```csharp
/// <summary>
/// 録画の開始・停止をトグルするコマンド。
/// CanExecute: RTSP 接続中かつ録画状態が Idle または Recording のとき
/// </summary>
[RelayCommand(CanExecute = nameof(CanToggleRecording))]
private void ToggleRecording();

private bool CanToggleRecording()
    => ConnectionState == ConnectionState.Connected
    && (_recordingService.State == RecordingState.Idle
        || _recordingService.State == RecordingState.Recording);
```

- Persistence: `RecordingFolderPath` は `AppSettings` 経由で永続化
- Concurrency: 録画経過時間の更新は `DispatcherTimer`（1 秒間隔）で UI スレッドから実行

**Implementation Notes**
- Integration: コンストラクタで `IRecordingService` を受け取り、`RecordingError` イベントと `StateChanged` イベントをサブスクライブ。`OnStateChanged` ハンドラ内で RTSP 切断検知時に `_recordingService.Stop()` を呼び出す
- Validation: `ToggleRecording` 実行前に `ConnectionState == Connected` を確認（1.3）
- Risks: パケットコールバックの設定タイミング。RTSP 接続確立後にコールバックを設定し、切断時に解除する

### Model Layer

#### AppSettings / SettingsModels (拡張)

| Field | Detail |
|-------|--------|
| Intent | 録画保存先フォルダパスを AppSettings に追加する |
| Requirements | 4.1, 4.2, 4.3, 4.4 |

追加するフィールド:

```csharp
/// <summary>
/// アプリケーション全体の設定を保持するレコード（拡張）
/// </summary>
public record AppSettings(
    StreamPaneSettings Pane1,
    StreamPaneSettings Pane2,
    DualPaneLayout Layout,
    string RecordingFolderPath  // 新規追加
)
{
    public static AppSettings Default => new(
        Pane1: StreamPaneSettings.Default,
        Pane2: StreamPaneSettings.Default,
        Layout: DualPaneLayout.Horizontal,
        RecordingFolderPath: Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),
            "RtspViewer")
    );
}
```

- デフォルト値は `%USERPROFILE%/Videos/RtspViewer`（4.2）
- `record` 型の不変性を維持。`with` 式で新しいインスタンスを生成する

**Implementation Notes**
- Integration: `SettingsService` の `AppSettingsDto` にも `RecordingFolderPath` フィールドを追加。既存 JSON ファイルとの後方互換性のため、`RecordingFolderPath` が null の場合はデフォルト値にフォールバック
- Risks: 既存の `settings.json` に `RecordingFolderPath` が存在しない場合のデシリアライズ。`JsonSerializer` はデフォルトで欠損フィールドを null/default にするため問題なし

### UI Layer

#### StreamPaneView (拡張) — Summary

録画ボタン（トグル式）と録画インジケーター（赤丸 + 経過時間）を既存の StreamPaneView に追加する。

- 録画ボタン: `ToggleRecordingCommand` にバインド。`IsRecording` プロパティで表示切り替え（開始/停止アイコン）
- 録画インジケーター: `IsRecording == true` 時に赤丸アイコンと `RecordingElapsedTime` を表示。`BooleanToVisibilityConverter` でバインド
- 保存先フォルダ設定: 接続設定エリアにフォルダ選択ボタン付きテキストボックスを追加。`RecordingFolderPath` にバインド
- RTSP 未接続時は録画ボタンを無効化（`CanToggleRecording` で制御）

## Data Models

### Domain Model

新規追加するドメインモデル:

```csharp
/// <summary>録画状態を表す列挙型</summary>
public enum RecordingState { Idle, Recording, Stopping }

/// <summary>録画エラー種別</summary>
public enum RecordingErrorKind { DiskWriteError, PermissionDenied, DirectoryCreationFailed }

/// <summary>録画エラーイベント引数</summary>
public sealed class RecordingErrorEventArgs : EventArgs
{
    public RecordingErrorKind Kind { get; }
    public string Message { get; }
    public RecordingErrorEventArgs(RecordingErrorKind kind, string message)
    {
        Kind = kind;
        Message = message;
    }
}
```

### Logical Data Model

**AppSettings の拡張**:
- `RecordingFolderPath: string` — 全ペイン共通の録画保存先フォルダパス
- デフォルト: `%USERPROFILE%/Videos/RtspViewer`
- JSON シリアライズ時のキー: `recordingFolderPath`（camelCase）

**録画ファイル命名規則**:
- フォーマット: `{yyyyMMdd_HHmmss}.mp4`
- 例: `20260315_143000.mp4`
- タイムスタンプはローカル時刻を使用（ファイルエクスプローラーでの視認性を優先）

## Error Handling

### Error Strategy

| Error Category | Trigger | Response | Requirement |
|---------------|---------|----------|-------------|
| 書き込み権限エラー | `Start` 時にフォルダへの書き込みテストが失敗 | 録画を開始せず `RecordingError` イベントを発行 | 5.3 |
| ディスク書き込みエラー | `WritePacket` / `WriteTrailer` で IOException | 録画を停止し `RecordingError` イベントを発行 | 5.2 |
| RTSP 切断 | `StateChanged` で `Disconnected` を受信 | 録画を自動停止、WriteTrailer で MP4 を正常クローズ | 5.1 |
| フォルダ作成失敗 | `EnsureDirectoryExists` で例外 | 録画を開始せず `RecordingError` イベントを発行 | 2.4 |
| パケットコールバック例外 | `WritePacket` 内での想定外例外 | 例外をキャッチしログ出力。デコードループを停止させない | - |

### Monitoring
- 録画の開始・停止・エラーは `Trace.WriteLine` でアプリケーションログに記録
- 録画ファイルパスとサイズをログに出力

## Testing Strategy

### Unit Tests
- `RecordingService` 状態マシン遷移テスト（Idle → Recording → Stopping → Idle）
- `RecordingService.Start` のバリデーション（無効なパス、書き込み権限なし）
- ファイル名生成ロジック（日時フォーマット）
- `StreamPaneViewModel.CanToggleRecording` の条件テスト
- `AppSettings` のデフォルト値・シリアライズ後方互換性テスト

### Integration Tests
- MP4 ファイル書き込み・読み取り検証（fragmented MP4 が有効な MP4 ファイルであること）
- パケットコールバック経由の録画フロー（RtspStreamService → RecordingService）
- SettingsService による RecordingFolderPath の永続化・復元
- RTSP 切断時の自動録画停止と MP4 クローズ

### E2E/UI Tests
- 録画ボタンのクリックで録画開始・停止が切り替わること
- 録画中に赤インジケーターと経過時間が表示されること
- RTSP 未接続時に録画ボタンが無効であること

## Performance & Scalability

- **CPU 負荷**: リミュクス方式のため再エンコードなし。パケットのメモリコピー + ファイル I/O のみで CPU 使用率への影響は最小
- **メモリ**: パケットバッファは 1 フレーム分のみ。H.264 の典型的なパケットサイズ（数 KB〜数百 KB）のため問題なし
- **ディスク I/O**: 監視カメラの一般的なビットレート（2-8 Mbps）ではデスクトップ HDD/SSD ともに十分な書き込み速度
- **Target**: 2 ペイン同時録画で CPU 使用率増加 5% 未満、メモリ増加 50MB 未満
