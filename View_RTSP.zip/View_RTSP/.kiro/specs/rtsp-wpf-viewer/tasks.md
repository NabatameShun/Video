# 実装タスク一覧
## RTSPビューワー WPFアプリケーション

---

## タスク

- [x] 1. プロジェクト基盤・NuGet パッケージのセットアップ
- [x] 1.1 NuGet パッケージの追加と csproj 設定
  - Sdcb.FFmpeg、Sdcb.FFmpeg.runtime.windows-x64、CommunityToolkit.Mvvm、Onvif.Core の 4 パッケージを追加する
  - アンセーフコードを許可する設定（AllowUnsafeBlocks）を csproj に追加する
  - Nullable 参照型と ImplicitUsings の有効化を確認する
  - ターゲットフレームワークが net10.0-windows であることを確認する
  - _Requirements: 4.1, 9.1_

- [x] 1.2 (P) ドメインモデル・列挙型・共有データ構造の定義
  - 接続状態を表す列挙型（Disconnected / Connecting / Connected / Error）を定義する
  - RTSP 接続オプション（URL・認証情報・トランスポート・低遅延フラグ）を保持する不変レコードを定義する
  - ストリーム状態変化イベントの引数（状態・エラー情報）を定義する
  - エラー種別（接続タイムアウト / 認証失敗 / ネットワーク不達 / デコードエラー / 不明）を網羅する列挙型を定義する
  - エラー詳細（種別・メッセージ・FFmpeg エラーコード）を保持するレコードを定義する
  - 接続統計情報（フレームレート・受信フレーム数・稼働時間）を保持するレコードを定義する
  - ONVIF 接続オプション（エンドポイント URL・ユーザー名・パスワード・プロファイルトークン）を定義する
  - PTZ 方向を表す列挙型（8 方向）を定義する
  - デュアルペインのレイアウト種別（水平 / 垂直）を表す列挙型を定義する
  - _Requirements: 1.4, 1.5, 1.7, 3.4, 5.3, 6.3, 7.1, 8.4, 9.3_

- [x] 1.3 (P) 設定データモデルとサービスインターフェースの定義
  - アプリ全体の設定（2 ペイン設定・レイアウト）を保持するレコードを定義する
  - 各ペインの設定（RTSP URL・認証情報・トランスポート・ONVIF 設定）を保持するレコードを定義する
  - RTSP ストリームサービスのインターフェース（ConnectAsync / Disconnect / StateChanged / StatsUpdated）を定義する
  - 映像フレーム描画サービスのインターフェース（RenderFrame / Clear / BitmapUpdated）を定義する
  - ONVIF PTZ サービスのインターフェース（GetPtzCapabilitiesAsync / StartMoveAsync / StopMoveAsync / ZoomAsync）を定義する
  - 設定永続化サービスのインターフェース（Load / Save）を定義する
  - _Requirements: 1.2, 1.6, 4.6, 5.1, 7.1, 7.3, 7.4, 9.3_

---

- [x] 2. 設定永続化サービスの実装
  - %AppData%\RtspViewer フォルダへ JSON ファイルとして接続設定を保存・読み込みする機能を実装する
  - パスワードは Windows DPAPI（ProtectedData）で暗号化し Base64 エンコードで保存する
  - 設定ファイルが存在しない場合はデフォルト値を返し、例外をスローしない
  - 設定ファイルが破損している場合はデフォルト値へフォールバックしログに記録する
  - RTSP URL・レイアウト・ONVIF エンドポイント等の全設定項目を往復変換できることを確認する
  - _Requirements: 4.6, 5.1, 5.4, 9.3_

---

- [x] 3. 映像フレーム描画サービスの実装
  - WritableBitmap を所有し、映像解像度が変わった場合のみ再生成するロジックを実装する
  - デコードスレッドから BGRA フレームデータを受け取り、UI スレッドの Dispatcher 経由で WritableBitmap へ書き込む
  - ピン留めしたバイト配列バックバッファを再利用して GC アロケーションを最小化する
  - UI スレッドが描画に追いつかない場合は古いフレームをスキップし最新フレームのみ描画する
  - Clear() 呼び出しでビットマップをプレースホルダー状態にリセットできるようにする
  - _Requirements: 2.1, 2.3, 6.2, 6.4, 9.5, 9.7_

---

- [x] 4. RTSP ストリームサービス（FFmpeg デコードエンジン）の実装
- [x] 4.1 FFmpeg 初期化と RTSP 接続確立
  - Sdcb.FFmpeg を使用して RTSP URL へ接続を開き、AVFormatContext を取得する
  - 低遅延 FFmpeg オプション（rtsp_transport、fflags=nobuffer、flags=low_delay、max_delay=0、analyzeduration=0、probesize=32）を適用する
  - TCP / UDP トランスポートをユーザー設定に応じて切り替えられるようにする
  - 認証情報が指定されている場合は URL または FFmpeg オプション経由で認証を試みる
  - 接続結果（成功 / タイムアウト / 認証失敗 / ネットワーク不達）を状態変化イベントとして通知する
  - _Requirements: 1.2, 1.3, 1.5, 5.2, 5.5, 9.1, 9.2, 9.3, 9.4_

- [x] 4.2 H.264 デコードループの実装
  - H.264 ビデオストリームを avcodec で検出しデコーダーを開く
  - 専用バックグラウンドスレッドで av_read_frame / avcodec_send_packet / avcodec_receive_frame のループを実行する
  - デコードしたフレームを sws_scale で YUV420P から BGRA へ変換し VideoFrameRenderer へ渡す
  - フレームレートを直近 5 秒の平均で算出し 1 秒ごとに統計情報イベントを発行する
  - _Requirements: 2.4, 6.1, 6.2, 9.2, 9.6, 9.7_

- [x] 4.3 エラー検出・自動再試行・リソース解放
  - デコードループでエラーを検出した場合に最大 3 回（500ms 待機）の自動再接続を試みる
  - 再試行上限到達後は切断状態に遷移し、ユーザーへ状況を通知する状態変化イベントを発行する
  - IDisposable パターンで AVFormatContext / AVCodecContext / AVFrame / SwsContext 等の全ネイティブリソースを確実に解放する
  - Disconnect() をどの状態からでも安全に呼び出せる冪等な実装にする
  - _Requirements: 3.1, 3.3, 3.5, 9.8, 9.9_

---

- [x] 5. ONVIF PTZ サービスの実装
- [x] 5.1 ONVIF 接続と PTZ 対応能力の確認
  - Onvif.Core の Camera クラスを使用して ONVIF デバイスへ接続する
  - GetCapabilities を呼び出してカメラの PTZ 対応可否を確認し、結果をキャッシュする
  - ProfileToken が未指定の場合は GetProfiles() で最初のプロファイルを自動選択してキャッシュする
  - 接続タイムアウトを 3 秒以内に設定し、失敗時は例外をスローせず false を返す
  - _Requirements: 7.1, 7.6_

- [x] 5.2 PTZ コマンド送信（ContinuousMove / Stop / Zoom）
  - StartMoveAsync で ContinuousMove コマンドを WS-Security UsernameToken 認証付きで送信する
  - StopMoveAsync で Stop コマンドを送信し、カメラの動きを止める
  - ZoomAsync でズームイン / ズームアウトコマンドを送信する
  - 各コマンドは独立したタスクで実行し、RTSP デコードスレッドに影響しない
  - コマンド失敗時は例外をキャッチして呼び出し元へエラーを伝達し、ストリーム表示は継続させる
  - _Requirements: 7.2, 7.3, 7.4, 7.7, 7.8_

---

- [x] 6. ViewModel 層の実装
- [x] 6.1 StreamPaneViewModel の状態管理と接続コマンド
  - CommunityToolkit.Mvvm の ObservableProperty を活用して接続状態・ステータスメッセージ・エラーメッセージ・統計情報をバインド可能プロパティとして実装する
  - RTSP URL のフォーマットバリデーション（rtsp:// スキームチェック）を ConnectCommand 実行前に行い、不正な場合はエラーメッセージを表示して接続を試みない
  - ConnectCommand / DisconnectCommand を IRelayCommand として実装し、接続状態に応じた有効/無効制御を行う
  - バックグラウンドスレッドからの状態変化・統計情報イベントを UI スレッドへ安全にディスパッチする
  - 認証情報（ユーザー名・パスワード）を ViewModel から接続オプションへ組み立てるロジックを実装する
  - _Requirements: 1.1, 1.2, 1.4, 1.5, 1.6, 1.7, 5.2, 5.3, 5.5, 6.3_

- [x] 6.2 StreamPaneViewModel の PTZ 連携と映像フレーム受信
  - StartMoveCommand / StopMoveCommand / ZoomCommand を IRelayCommand として実装する
  - ONVIF 接続確認後に PTZ 有効フラグを設定し、非対応カメラの場合は PTZ UI を無効化する
  - VideoFrameRenderer の BitmapUpdated イベントを受け取り、VideoFrame バインドプロパティを更新する
  - PTZ コマンド失敗時はエラーメッセージを表示しつつ RTSP ストリーム表示を継続する
  - 接続設定を SettingsService から読み込み、ViewModel プロパティへ反映するロジックを実装する
  - _Requirements: 2.1, 3.2, 6.3, 7.2, 7.3, 7.4, 7.6, 7.8, 8.2, 8.7, 8.8_

- [x] 6.3 MainWindowViewModel の実装
  - StreamPaneViewModel を 2 インスタンス所有・管理する
  - 左右分割 / 上下分割レイアウトを切り替える ToggleLayoutCommand を実装する
  - アプリ終了時（OnClosing）に両ペインを切断してから設定を保存する
  - 起動時に SettingsService から設定を読み込んで各 StreamPaneViewModel へ反映する
  - _Requirements: 4.3, 4.6, 8.1, 8.4_

---

- [x] 7. ダークテーマ・UIリソースの実装
- [x] 7.1 (P) カラーパレットとグローバルスタイルリソースの定義
  - ダークグレー / チャコール系のカラーパレットを ResourceDictionary として定義する
  - Segoe UI フォントファミリーをアプリ全体のデフォルトフォントとして設定する
  - ベクター XAML（Path / Geometry）で PTZ ・接続ボタン用のスケーラブルアイコンを定義する
  - App.xaml で ResourceDictionary をマージしてアプリ全体にテーマを適用する
  - _Requirements: 10.1, 10.7_

- [x] 7.2 (P) カスタムコントロールスタイルとアニメーション効果の実装
  - ボタン・テキストボックス・PasswordBox・パネル等のカスタム ControlTemplate / Style を定義する
  - ホバー時のハイライト・フェードインなどのアニメーション効果を Storyboard / Trigger で実装する
  - 映像表示ペインの境界にアクセントカラーのボーダーまたはシャドウ効果を適用する
  - 接続状態（接続中 / 受信中 / 切断 / エラー）をカラーインジケーター（緑 / 青 / グレー / 赤）で表示する IValueConverter を実装する
  - _Requirements: 10.2, 10.3, 10.4, 10.5_

---

- [x] 8. View 層の XAML 実装
- [x] 8.1 StreamPaneView の実装
  - RTSP URL 入力テキストフィールド・ユーザー名フィールド・パスワードフィールド（PasswordBox）・接続/切断ボタンを配置する
  - パスワードは PasswordBox で入力し、PasswordChanged イベントをコードビハインドで捕捉して ViewModel へ安全に渡す
  - ViewBox で映像表示エリアをラップし、ウィンドウリサイズ時にアスペクト比を維持したままリサイズされるようにする
  - Image コントロールの Source を ViewModel の VideoFrame（WritableBitmap）にバインドする
  - 未接続時はプレースホルダーテキストをオーバーレイ表示し、接続中はステータスインジケーターを表示する
  - カラーインジケーターと統計情報（フレームレート・接続状態）を表示するステータスバー領域を実装する
  - _Requirements: 1.1, 1.7, 2.2, 2.3, 2.5, 5.1, 5.4, 6.3, 10.3_

- [x] 8.2 (P) PtzControlView の実装
  - 8 方向ボタン（上下左右 + 斜め）とズームイン / アウトボタンを Grid で方向キー配置する
  - PreviewMouseDown / PreviewMouseUp イベントで StartMoveCommand / StopMoveCommand を送信する
  - ベクターアイコンを使用してコンパクトなアイコンベース UI を実現する
  - IsPtzEnabled バインドでコントロール全体の有効/無効を制御し、非対応カメラ時はグレーアウトする
  - _Requirements: 7.2, 7.3, 7.4, 7.6, 10.6_

- [x] 8.3 DualPaneLayout と MainWindow の実装
  - Grid の ColumnDefinitions / RowDefinitions をレイアウトプロパティに応じて動的に切り替えるコンテナを実装する
  - GridSplitter を配置し、ユーザーが境界をドラッグしてペインの比率を調整できるようにする
  - 各セルに StreamPaneView を配置し、それぞれ独立した ViewModel インスタンスにバインドする
  - MainWindow でウィンドウ最大化 / 最小化 / 通常サイズの操作をサポートし、Closing イベントで MainWindowViewModel の終了処理を呼び出す
  - 1280x720 〜 1920x1080 以上の解像度で最適表示されるレスポンシブレイアウトを実装する
  - _Requirements: 4.3, 4.4, 8.1, 8.4, 8.5, 10.8_

- [x] 8.4 (P) ConnectionSettingsView（ONVIF 設定パネル）の実装
  - ONVIF エンドポイント URL・ユーザー名・パスワード・プロファイルトークンを入力するフィールドを配置する
  - 入力値を StreamPaneViewModel の ONVIF 設定プロパティへバインドする
  - パスワードフィールドは PasswordBox でマスク表示する
  - _Requirements: 7.5, 5.4_

---

- [x] 9. グローバル例外ハンドリングとアプリケーション基盤の実装
  - App.xaml.cs に DispatcherUnhandledException ハンドラを登録し、未処理例外をキャッチしてユーザーへダイアログで通知する
  - 未処理例外発生時にアプリケーションをクラッシュさせず、継続または終了を選択できるようにする
  - 起動時に FFmpeg ネイティブ DLL の存在チェックを行い、欠如している場合は早期に明確なエラーメッセージを表示して終了する
  - アプリ起動後は接続操作が行われるまで最小限のリソース消費状態で待機する（RTSP サービスを起動しない）
  - _Requirements: 3.5, 4.2, 4.5_

---

- [x] 10. デュアルストリーム独立動作の結合確認
  - 2 つの StreamPaneViewModel インスタンスがそれぞれ独立した RtspStreamService インスタンスを持ち、独立したデコードスレッドで動作することを確認する
  - 一方のペインでストリームが切断されたとき、もう一方のペインの映像表示が継続されることを確認する
  - 各ペインが独立した接続・切断操作をサポートし、ステータスが個別に表示されることを確認する
  - デュアルストリーム接続中にレイアウト切り替え（水平 / 垂直）を行っても両方のストリームが継続して表示されることを確認する
  - _Requirements: 8.2, 8.3, 8.6, 8.7, 8.8_

---

- [x] 11. ユニットテストの実装
- [x] 11.1 (P) ViewModel ユニットテスト
  - RTSP URL バリデーション（正常 URL / 不正スキーム / 空文字）の判定ロジックをテストする
  - IRtspStreamService のモックを使用して StreamPaneViewModel の状態遷移（ConnectCommand → Connecting → Connected / Error）を検証する
  - DisconnectCommand 実行後に ConnectionState が Disconnected へ遷移することを確認する
  - PTZ 有効フラグが PTZ 対応能力確認の結果に応じて正しく切り替わることを確認する
  - _Requirements: 1.4, 1.6, 1.7, 7.6_

- [x] 11.2 (P) 設定サービスユニットテスト
  - 設定ファイル不存在時にデフォルト値が返され例外が発生しないことを確認する
  - Save → Load の往復変換で URL・レイアウト・トランスポート設定が保持されることを確認する
  - パスワードの暗号化・復号ラウンドトリップが正しく機能することを確認する
  - 設定ファイルが破損している場合にデフォルト値へフォールバックすることを確認する
  - _Requirements: 4.6, 5.4_

---

- [x] 12. 統合テストとパフォーマンス確認

- [x] 12.1 RTSP ストリーム接続・デコードの統合テスト
  - ローカル RTSP テストサーバー（ffmpeg -re コマンド等）への接続・H.264 フレーム受信を確認する
  - TCP / UDP トランスポート切り替えが正常に動作することを確認する
  - 接続失敗・認証失敗時に正しいエラー種別が通知されることを確認する
  - 自動再試行が最大 3 回実行され、上限到達後に切断状態へ遷移することを確認する
  - _Requirements: 1.3, 1.5, 3.1, 5.2, 5.3, 9.1, 9.2, 9.8_

- [x] 12.2 (P) ONVIF PTZ 統合テスト
  - ONVIF テストサーバーへの接続と PTZ 対応能力確認が正常に動作することを確認する
  - ContinuousMove / Stop / Zoom コマンドが WS-Security 認証付きで正しく送信されることを確認する
  - ONVIF コマンド失敗時に RTSP ストリームが継続表示されることを確認する
  - _Requirements: 7.1, 7.3, 7.4, 7.7, 7.8_

- [x] 12.3 パフォーマンス計測
  - エンドツーエンド遅延（フレームタイムスタンプと WPF 描画完了のデルタ）を計測し 500ms 以内を確認する
  - デュアルストリーム（1080p × 2）接続時の CPU 使用率が目標値以下であることを確認する
  - 接続・切断を繰り返した後のメモリ変化を確認し FFmpeg リソースのリークがないことを検証する
  - 映像表示中の UI 操作レスポンスタイムが 100ms 以内であることを確認する
  - _Requirements: 6.1, 6.2, 8.3, 9.7, 9.9_

- [ ]* 12.4 E2E / UI テスト（デファース可）
  - RTSP URL 入力 → 接続 → 映像表示 → 切断の完全フローを UI Automation で確認する
  - ウィンドウリサイズ時に映像のアスペクト比が維持されることを確認する
  - アプリ再起動後に前回の RTSP URL が復元されることを確認する
  - _Requirements: 1.1, 1.2, 1.6, 2.3, 4.6_
