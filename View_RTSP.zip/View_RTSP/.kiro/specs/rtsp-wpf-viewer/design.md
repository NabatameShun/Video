# 技術設計書
## RTSPビューワー WPFアプリケーション

---

## 概要

本フィーチャーは、WPF（Windows Presentation Foundation）アプリケーションとして、RTSPプロトコル経由でネットワークカメラや映像サーバーの映像をリアルタイム表示する機能を提供する。Sdcb.FFmpeg を使用した低遅延デコード、ONVIF PTZ リモート制御、デュアルストリーム同時表示、スタイリッシュなダークテーマ UI を包含する。

対象ユーザーは監視カメラ映像をモニタリングするオペレーターおよび VMS システム管理者である。本アプリケーションは VMSエコシステムの映像表示コンポーネントとして、既存の映像サーバーインフラとネットワーク経由で連携する。

現在のコードベースは .NET 10 WPF シングルウィンドウ構成のスキャフォールド段階にあり、本設計に基づく MVVM 分割 ViewModel 構成・サービス層・リソースディレクトリを新規追加する。

---

### ゴール

- H.264 エンコードの RTSP ストリームを 500ms 以内（ネットワーク遅延除く）の低遅延で表示する
- デュアルストリームの独立した同時受信・表示を実現し、一方の障害が他方に影響しないことを保証する
- ONVIF Profile S PTZ 制御（パン・チルト・ズーム）を WS-Security 認証経由で提供する
- 認証情報を含む接続設定を永続化し、アプリケーション再起動後に復元する
- ダークテーマ・アニメーション効果を備えたプロフェッショナル UI を実現する

### 非ゴール

- H.265（HEVC）・VP9 等の H.264 以外のコーデック対応
- 録画・スナップショット保存機能
- 3 ストリーム以上の同時表示
- モバイル・クロスプラットフォーム対応
- ONVIF Profile G（録画）・Profile T（高度映像）への対応
- NVR・VMS サーバー機能（本アプリはクライアントのみ）

---

## 要件トレーサビリティ

| 要件 | 概要 | 担当コンポーネント | インターフェース | フロー |
|------|------|------------------|----------------|-------|
| 1.1 | URL 入力フィールド表示 | StreamPaneView | — | — |
| 1.2 | 接続ボタンで RTSP 接続開始 | StreamPaneViewModel, RtspStreamService | IRtspStreamService.ConnectAsync | 接続フロー |
| 1.3 | 接続成功後に映像受信・表示開始 | RtspStreamService, VideoFrameRenderer | IVideoFrameRenderer.RenderFrame | デコードフロー |
| 1.4 | 不正 URL のバリデーションとエラー表示 | StreamPaneViewModel | — | エラーフロー |
| 1.5 | 接続失敗時エラーメッセージ | StreamPaneViewModel, RtspStreamService | IRtspStreamService.ConnectAsync | エラーフロー |
| 1.6 | 切断ボタンで接続切断 | StreamPaneViewModel, RtspStreamService | IRtspStreamService.Disconnect | — |
| 1.7 | 接続中ステータス表示 | StreamPaneViewModel | ConnectionState | — |
| 2.1 | リアルタイムフレーム表示 | VideoFrameRenderer | IVideoFrameRenderer.RenderFrame | デコードフロー |
| 2.2 | 映像表示領域がメインエリアを占有 | StreamPaneView（XAML レイアウト） | — | — |
| 2.3 | ウィンドウリサイズ時のアスペクト比維持 | StreamPaneView（ViewBox） | — | — |
| 2.4 | H.264 ストリーム表示 | RtspStreamService（avcodec） | — | デコードフロー |
| 2.5 | 未接続時プレースホルダー表示 | StreamPaneView | ConnectionState | — |
| 3.1 | 予期せぬ切断の通知 | RtspStreamService, StreamPaneViewModel | StreamStateChangedEvent | エラーフロー |
| 3.2 | 切断後に未接続状態へ遷移 | StreamPaneViewModel | ConnectionState | エラーフロー |
| 3.3 | ネットワークエラー通知 | RtspStreamService, StreamPaneViewModel | StreamStateChangedEvent | エラーフロー |
| 3.4 | エラー種別を含む詳細エラーメッセージ | StreamPaneViewModel | RtspError | エラーフロー |
| 3.5 | エラー時のアプリクラッシュ防止 | App.xaml.cs（グローバル例外ハンドラ） | — | — |
| 4.1 | Windows 10以降での動作 | View_RTSP.csproj（TargetFramework） | — | — |
| 4.2 | 起動時の最小リソース消費 | RtspStreamService（未接続時は非起動） | — | — |
| 4.3 | ウィンドウ閉じる時に適切な切断・終了 | MainWindowViewModel | IApplicationLifetime.Shutdown | — |
| 4.4 | ウィンドウ操作サポート | MainWindow.xaml（標準 WPF） | — | — |
| 4.5 | 未処理例外のユーザー通知 | App.xaml.cs | — | エラーフロー |
| 4.6 | RTSP URL の永続化 | SettingsService | ISettingsService | — |
| 5.1 | ユーザー名・パスワード入力フィールド | StreamPaneView | — | — |
| 5.2 | 認証情報を用いた接続 | RtspStreamService | IRtspStreamService.ConnectAsync | 接続フロー |
| 5.3 | 認証失敗エラーメッセージ | StreamPaneViewModel | RtspError | エラーフロー |
| 5.4 | パスワードのマスク表示 | StreamPaneView（PasswordBox） | — | — |
| 5.5 | 認証なし接続サポート | RtspStreamService | IRtspStreamService.ConnectAsync | 接続フロー |
| 6.1 | 映像遅延 2秒以内（目標） | RtspStreamService（FFmpeg オプション） | — | デコードフロー |
| 6.2 | UIスレッドをブロックしない非同期処理 | RtspStreamService（専用スレッド） | — | デコードフロー |
| 6.3 | 接続状態・フレームレート表示 | StreamPaneViewModel | ConnectionStats | — |
| 6.4 | フレームレート低下時の継続表示 | VideoFrameRenderer（フレームスキップ許容） | — | デコードフロー |
| 7.1 | ONVIF Profile S PTZ サポート | OnvifPtzService | IOnvifPtzService | — |
| 7.2 | PTZ 方向・ズームボタン UI | PtzControlView | — | — |
| 7.3 | ContinuousMove / Stop コマンド | OnvifPtzService | IOnvifPtzService.StartMove, StopMove | PTZ フロー |
| 7.4 | ズーム制御コマンド | OnvifPtzService | IOnvifPtzService.ZoomAsync | PTZ フロー |
| 7.5 | ONVIF エンドポイント設定 | ConnectionSettingsView, SettingsService | — | — |
| 7.6 | PTZ 非対応カメラでの UI 無効化 | OnvifPtzService, StreamPaneViewModel | IOnvifPtzService.GetCapabilitiesAsync | — |
| 7.7 | WS-Security UsernameToken 認証 | OnvifPtzService（Onvif.Core） | — | — |
| 7.8 | PTZ エラー時の RTSP 継続表示 | StreamPaneViewModel | — | エラーフロー |
| 8.1 | 2ペイン並列表示 | MainWindow.xaml, DualPaneLayout | — | — |
| 8.2 | 各ペインの独立 URL・認証情報設定 | StreamPaneViewModel x2 | — | — |
| 8.3 | 両ストリームの独立受信・表示 | RtspStreamService（独立スレッド）x2 | — | デコードフロー |
| 8.4 | 左右・上下分割レイアウト選択 | MainWindowViewModel, DualPaneLayout | — | — |
| 8.5 | リサイズ時の均等アスペクト比維持 | DualPaneLayout（ViewBox） | — | — |
| 8.6 | 片方切断時の独立エラー表示 | StreamPaneViewModel（独立インスタンス） | — | エラーフロー |
| 8.7 | 各ペインの独立接続・切断操作 | StreamPaneViewModel x2 | — | — |
| 8.8 | 各ペインの個別ステータス表示 | StreamPaneViewModel x2 | ConnectionStats | — |
| 9.1 | FFmpeg.AutoGen による RTSP デコード | RtspStreamService | — | デコードフロー |
| 9.2 | avformat / avcodec 直接利用 | RtspStreamService | — | デコードフロー |
| 9.3 | TCP / UDP トランスポート選択 | RtspStreamService, SettingsService | RtspConnectionOptions | — |
| 9.4 | 低遅延 FFmpeg オプション適用 | RtspStreamService | — | デコードフロー |
| 9.5 | WritableBitmap への直接描画 | VideoFrameRenderer | IVideoFrameRenderer.RenderFrame | デコードフロー |
| 9.6 | 専用バックグラウンドスレッドでデコード | RtspStreamService | — | デコードフロー |
| 9.7 | E2E 遅延 500ms 以内 | RtspStreamService + VideoFrameRenderer | — | デコードフロー |
| 9.8 | デコードエラー時の自動再試行と通知 | RtspStreamService | StreamStateChangedEvent | エラーフロー |
| 9.9 | 終了時の FFmpeg リソース解放 | RtspStreamService（IDisposable） | — | — |
| 10.1 | ダークテーマ配色 | App.xaml（ResourceDictionary） | — | — |
| 10.2 | カスタム ControlTemplate/Style | Themes/Controls.xaml | — | — |
| 10.3 | 接続状態カラーインジケーター | StreamPaneView（State → Brush バインド） | ConnectionState | — |
| 10.4 | UI アニメーション効果 | Themes/Animations.xaml | — | — |
| 10.5 | ペイン境界のアクセントカラー | Themes/Controls.xaml | — | — |
| 10.6 | PTZ コントロールのアイコンベース UI | PtzControlView | — | — |
| 10.7 | Segoe UI フォント・ベクターアイコン | App.xaml（ResourceDictionary） | — | — |
| 10.8 | 1280x720 〜 1920x1080+ レスポンシブ | MainWindow.xaml（Grid・ViewBox） | — | — |

---

## アーキテクチャ

### アーキテクチャパターンとバウンダリマップ

**採用パターン**: MVVM（分割 ViewModel）+ Service Layer

- 選択根拠: 要件 8 のデュアルストリーム独立動作に対し、`StreamPaneViewModel` を 2 インスタンス化することで状態・スレッドを完全分離できる。steering の MVVM 方針に準拠。
- 既存パターンの維持: XAML + コードビハインド（最小）・ViewModel / Services ディレクトリパターン
- Steering 準拠: `View_RTSP.ViewModels`・`View_RTSP.Services` 名前空間を steering の構造定義に従い追加

```mermaid
graph TB
    subgraph UI Layer
        MainWindow[MainWindow]
        DualPane[DualPaneLayout]
        StreamPaneView1[StreamPaneView 1]
        StreamPaneView2[StreamPaneView 2]
        PtzView1[PtzControlView 1]
        PtzView2[PtzControlView 2]
        ConnSettings[ConnectionSettingsView]
    end

    subgraph ViewModel Layer
        MainVM[MainWindowViewModel]
        PaneVM1[StreamPaneViewModel 1]
        PaneVM2[StreamPaneViewModel 2]
    end

    subgraph Service Layer
        RtspSvc1[RtspStreamService 1]
        RtspSvc2[RtspStreamService 2]
        OnvifSvc[OnvifPtzService]
        SettingsSvc[SettingsService]
        FrameRenderer1[VideoFrameRenderer 1]
        FrameRenderer2[VideoFrameRenderer 2]
    end

    subgraph External
        FFmpegLib[FFmpeg Native DLLs]
        OnvifLib[Onvif.Core 3.0]
        AppData[AppData JSON]
        Camera1[RTSP Camera 1]
        Camera2[RTSP Camera 2]
    end

    MainWindow --> MainVM
    MainWindow --> DualPane
    DualPane --> StreamPaneView1
    DualPane --> StreamPaneView2
    StreamPaneView1 --> PtzView1
    StreamPaneView2 --> PtzView2
    StreamPaneView1 --> ConnSettings

    MainVM --> PaneVM1
    MainVM --> PaneVM2
    MainVM --> SettingsSvc

    PaneVM1 --> RtspSvc1
    PaneVM1 --> OnvifSvc
    PaneVM2 --> RtspSvc2
    PaneVM2 --> OnvifSvc

    RtspSvc1 --> FrameRenderer1
    RtspSvc2 --> FrameRenderer2
    RtspSvc1 --> FFmpegLib
    RtspSvc2 --> FFmpegLib
    OnvifSvc --> OnvifLib
    SettingsSvc --> AppData

    FFmpegLib --> Camera1
    FFmpegLib --> Camera2
    OnvifLib --> Camera1
    OnvifLib --> Camera2
```

### 技術スタック

| レイヤー | 選択・バージョン | フィーチャーにおける役割 | 備考 |
|---------|---------------|----------------------|------|
| UI / View | WPF (.NET 10), XAML | ダークテーマ・デュアルペイン・PTZ UI | CustomControlTemplate, ViewBox, ResourceDictionary |
| ViewModel | C# 13, INotifyPropertyChanged | 状態管理・コマンド・データバインディング | CommunityToolkit.Mvvm 8.x で [ObservableProperty] 活用 |
| デコードエンジン | Sdcb.FFmpeg 6.x（+ Sdcb.FFmpeg.AutoGen） | RTSP 受信・H.264 デコード | 同一エコシステム、managed wrapper 中心で unsafe 最小化 |
| FFmpeg ランタイム | Sdcb.FFmpeg.runtime.windows-x64（FFmpeg 7.x） | ネイティブ DLL 提供 | 同一エコシステム、NuGet で自動配置 |
| ONVIF クライアント | Onvif.Core 3.0.0 | PTZ ContinuousMove/Stop/Zoom | WS-Security UsernameToken 内包 |
| 設定永続化 | System.Text.Json (.NET 10 組込) | 接続設定の JSON シリアライズ | %AppData%\RtspViewer\settings.json |
| パスワード保護 | System.Security.Cryptography.ProtectedData | DPAPI によるパスワード暗号化 | Windows 専用, ユーザーキー暗号化 |
| アイコン | ベクター XAML (Path/Geometry) | PTZ・接続ボタンのスケーラブルアイコン | 外部依存なし |

---

## システムフロー

### 接続フロー（RTSP 接続確立）

```mermaid
sequenceDiagram
    participant User
    participant PaneVM as StreamPaneViewModel
    participant Svc as RtspStreamService
    participant FFmpeg as FFmpeg Native

    User->>PaneVM: ConnectCommand（URL, 認証情報）
    PaneVM->>PaneVM: ValidateUrl()
    alt URL 不正
        PaneVM-->>User: エラーメッセージ表示（1.4）
    else URL 正常
        PaneVM->>PaneVM: State = Connecting（1.7）
        PaneVM->>Svc: ConnectAsync(RtspConnectionOptions)
        Svc->>FFmpeg: avformat_open_input(url, options)
        alt 接続失敗
            FFmpeg-->>Svc: エラーコード
            Svc-->>PaneVM: StreamStateChangedEvent(Error, RtspError)
            PaneVM-->>User: エラーメッセージ（1.5, 3.4）
            PaneVM->>PaneVM: State = Disconnected
        else 接続成功
            FFmpeg-->>Svc: AVFormatContext
            Svc->>FFmpeg: avformat_find_stream_info
            Svc->>FFmpeg: avcodec_open2（H.264 デコーダー）
            Svc-->>PaneVM: StreamStateChangedEvent(Connected)
            PaneVM->>PaneVM: State = Connected（1.3）
            Svc->>Svc: DecodeLoop開始（専用スレッド）
        end
    end
```

### デコードフロー（フレーム受信・描画）

```mermaid
sequenceDiagram
    participant DecodeThread as デコードスレッド
    participant Svc as RtspStreamService
    participant FFmpeg as FFmpeg Native
    participant Renderer as VideoFrameRenderer
    participant WPF as WPF UIスレッド

    loop デコードループ（接続中）
        DecodeThread->>FFmpeg: av_read_frame(AVPacket)
        alt EOF / エラー
            FFmpeg-->>DecodeThread: エラーコード
            DecodeThread->>Svc: OnDecodeError → 再試行 or 切断通知（9.8）
        else パケット受信
            FFmpeg-->>DecodeThread: AVPacket
            DecodeThread->>FFmpeg: avcodec_send_packet
            DecodeThread->>FFmpeg: avcodec_receive_frame(AVFrame)
            DecodeThread->>FFmpeg: sws_scale（YUV→BGRA 変換）
            DecodeThread->>Renderer: EnqueueFrame(frameBytes, width, height)
            Renderer->>WPF: Dispatcher.BeginInvoke（WritableBitmap 更新）
            WPF->>WPF: Lock → WritePixels → AddDirtyRect → Unlock（9.5）
        end
    end
```

### PTZ 制御フロー

```mermaid
sequenceDiagram
    participant User
    participant PtzView as PtzControlView
    participant PaneVM as StreamPaneViewModel
    participant OnvifSvc as OnvifPtzService
    participant Camera as IPカメラ

    User->>PtzView: 方向ボタン押下
    PtzView->>PaneVM: StartMoveCommand(Direction)
    PaneVM->>OnvifSvc: StartMoveAsync(profileToken, direction, speed)
    OnvifSvc->>Camera: SOAP ContinuousMove（WS-Security付き）（7.3）
    alt コマンド失敗
        Camera-->>OnvifSvc: SOAP Fault
        OnvifSvc-->>PaneVM: OnvifError
        PaneVM-->>User: エラー通知（RTSPは継続）（7.8）
    else コマンド成功
        Camera-->>OnvifSvc: OK
    end

    User->>PtzView: ボタン離す
    PtzView->>PaneVM: StopMoveCommand
    PaneVM->>OnvifSvc: StopMoveAsync(profileToken)
    OnvifSvc->>Camera: SOAP Stop
```

### エラー・切断フロー

```mermaid
stateDiagram-v2
    [*] --> Disconnected
    Disconnected --> Connecting: ConnectCommand
    Connecting --> Connected: 接続成功（1.3）
    Connecting --> Disconnected: 接続失敗（1.5）
    Connected --> Receiving: フレーム受信開始
    Receiving --> Reconnecting: 予期せぬ切断（3.1）
    Reconnecting --> Receiving: 再試行成功（9.8）
    Reconnecting --> Disconnected: 再試行上限到達
    Connected --> Disconnected: DisconnectCommand（1.6）
    Receiving --> Disconnected: DisconnectCommand（1.6）
```

---

## コンポーネントとインターフェース

### コンポーネントサマリー

| コンポーネント | ドメイン/レイヤー | 意図 | 要件カバレッジ | 主要依存 | 契約 |
|-------------|----------------|------|--------------|---------|------|
| MainWindowViewModel | ViewModel | アプリ全体状態・レイアウト管理 | 4.3, 8.1, 8.4 | StreamPaneViewModel, SettingsService | State |
| StreamPaneViewModel | ViewModel | 単一ストリームペインの状態・コマンド | 1.x, 2.x, 3.x, 5.x, 6.x, 7.x, 8.x | RtspStreamService, OnvifPtzService | State, Event |
| RtspStreamService | Service | FFmpeg による RTSP 受信・デコード | 1.2, 1.3, 2.4, 6.x, 9.x | FFmpeg Native DLLs | Service |
| VideoFrameRenderer | Service | WritableBitmap へのフレーム描画 | 2.1, 9.5, 9.7 | WPF Dispatcher | Service |
| OnvifPtzService | Service | ONVIF PTZ コマンド送信 | 7.x | Onvif.Core 3.0.0 | Service |
| SettingsService | Service | 接続設定の永続化・復元 | 4.6, 5.x, 9.3 | System.Text.Json, ProtectedData | Service |
| MainWindow | View | ウィンドウルート・レイアウト | 4.3, 4.4, 8.1, 8.4 | MainWindowViewModel | — |
| StreamPaneView | View | ストリームペイン UI（URL入力・映像表示） | 1.1, 2.x, 5.x, 10.x | StreamPaneViewModel | — |
| PtzControlView | View | PTZ 操作 UI | 7.2, 10.6 | StreamPaneViewModel | — |
| DualPaneLayout | View | 左右/上下分割レイアウトコンテナ | 8.1, 8.4, 8.5 | MainWindowViewModel | — |
| App.xaml / App.xaml.cs | Infrastructure | グローバル例外ハンドラ・テーマリソース | 3.5, 4.5, 10.1 | — | — |

---

### Service Layer

#### RtspStreamService

| フィールド | 詳細 |
|---------|------|
| Intent | Sdcb.FFmpeg を使用した RTSP ストリームの受信・H.264 デコード・フレーム配信 |
| Requirements | 1.2, 1.3, 1.5, 1.6, 2.4, 3.1, 3.3, 6.1, 6.2, 9.1–9.9 |

**責務と制約**
- avformat_open_input による RTSP 接続確立（低遅延オプション付き）
- avcodec による H.264 ビデオフレームのデコード（avcodec_send_packet / avcodec_receive_frame）
- sws_scale による YUV420P → BGRA 変換
- 専用バックグラウンドスレッドでデコードループを実行し、UIスレッドを一切ブロックしない
- IDisposable パターンで AVFormatContext / AVCodecContext / AVFrame 等のネイティブリソースを確実に解放
- デコードエラー時は最大 3 回の自動再試行を行い、上限到達後に StreamStateChangedEvent を発行

**依存関係**
- Outbound: Sdcb.FFmpeg（FormatContext, CodecContext, VideoFrame, SWScale）— RTSP 受信・デコード（P0）
- Outbound: VideoFrameRenderer — デコード済みフレームの描画依頼（P0）
- Inbound: StreamPaneViewModel — 接続・切断コマンドの受信（P0）

**契約**: Service [x] / Event [x]

##### Service Interface

```csharp
// View_RTSP.Services
interface IRtspStreamService : IDisposable
{
    ConnectionState State { get; }
    event EventHandler<StreamStateChangedEventArgs> StateChanged;
    event EventHandler<ConnectionStats> StatsUpdated;

    Task ConnectAsync(RtspConnectionOptions options, CancellationToken cancellationToken = default);
    void Disconnect();
}

readonly record struct RtspConnectionOptions(
    string Url,
    string? Username,
    string? Password,
    RtspTransport Transport,     // TCP | UDP
    bool LowLatencyMode          // fflags=nobuffer, flags=low_delay
);

enum RtspTransport { Tcp, Udp }

readonly record struct ConnectionStats(
    double FrameRate,
    long ReceivedFrames,
    TimeSpan Uptime
);
```

- 事前条件: `options.Url` は `rtsp://` スキームで始まる有効な URI
- 事後条件: ConnectAsync 完了後、State は Connected または Disconnected（エラー時）に遷移
- 不変条件: Disconnect() はどの状態からも安全に呼び出し可能（冪等）

##### Event Contract

- 発行イベント: `StateChanged(StreamStateChangedEventArgs { State, Error? })`
- 発行イベント: `StatsUpdated(ConnectionStats)` — 1秒ごとに更新
- 発行保証: StateChanged は必ず UI スレッドへのディスパッチが完了する前に発行（バックグラウンドスレッドから）
- 順序保証: Connected → Receiving → Disconnected の順序で発行

**実装ノート**
- `Sdcb.FFmpeg.Formats.FormatContext.OpenInputUrl()` で RTSP 接続を確立
- 低遅延 AVOption: `rtsp_transport=tcp`（または udp）, `fflags=nobuffer`, `flags=low_delay`, `max_delay=0`, `analyzeduration=0`, `probesize=32`
- フレーム変換: `Sdcb.FFmpeg.Swscales.VideoFrameConverter` で YUV420P → BGRA 変換（WritableBitmap の Pbgra32 フォーマットに対応）
- ネイティブ DLL は `Sdcb.FFmpeg.runtime.windows-x64` NuGet パッケージが `runtimes/win-x64/native/` に自動配置。`FFmpegLoader` で明示ロード不要（同一エコシステムのため互換保証）
- `csproj` に `<AllowUnsafeBlocks>true</AllowUnsafeBlocks>` を追加（Sdcb.FFmpeg.AutoGen の一部 API が unsafe を使用）
- リスク: ネイティブ DLL が存在しない場合に DllNotFoundException — 起動時チェックで早期フェイル

---

#### VideoFrameRenderer

| フィールド | 詳細 |
|---------|------|
| Intent | デコード済み BGRA フレームを WritableBitmap へ描画し、WPF Image コントロールを更新する |
| Requirements | 2.1, 2.3, 6.4, 9.5, 9.7 |

**責務と制約**
- `WritableBitmap` を所有し、解像度変更時に再生成する
- フレームデータをバックグラウンドスレッドから受信し、`Dispatcher.BeginInvoke` 経由で WritableBitmap を更新
- GC 負荷低減のため、ピン留めした `byte[]` バックバッファを再利用する
- 描画が UIスレッドの処理能力を超える場合は最新フレームのみを描画し、古いフレームをスキップする

**依存関係**
- Inbound: RtspStreamService — フレームデータ（P0）
- Outbound: WPF Dispatcher — UI スレッドへのフレーム書き込み（P0）

**契約**: Service [x] / State [x]

##### Service Interface

```csharp
// View_RTSP.Services
interface IVideoFrameRenderer
{
    WriteableBitmap? CurrentBitmap { get; }
    event EventHandler<WriteableBitmap> BitmapUpdated;

    void RenderFrame(ReadOnlySpan<byte> bgraData, int width, int height);
    void Clear();
}
```

- 事前条件: `bgraData.Length == width * height * 4`（BGRA 各 1 バイト）
- 事後条件: `BitmapUpdated` イベントが UIスレッドで発行される
- 不変条件: `Clear()` はいつでも呼び出し可能で、プレースホルダー状態に戻る

**実装ノート**
- `Dispatcher.BeginInvoke(DispatcherPriority.Render, ...)` を使用（Invoke より低ブロッキング）
- フレームスキップ判定: キュー内に未処理フレームが存在する場合は最新のみ保持
- リスク: 高解像度（1080p）では BGRA バッファが 8MB/フレームになる — ピン留め再利用で軽減

---

#### OnvifPtzService

| フィールド | 詳細 |
|---------|------|
| Intent | Onvif.Core 3.0.0 を使用した ONVIF Profile S PTZ コマンドの送信と機能確認 |
| Requirements | 7.1–7.8 |

**責務と制約**
- GetCapabilities でカメラの PTZ 対応可否を確認し、結果をキャッシュする
- ContinuousMove / Stop / Zoom コマンドを WS-Security UsernameToken 認証付きで送信
- 各コマンドは独立したタスクで実行し、RTSP デコードスレッドに影響しない
- コマンド失敗時は例外をキャッチして StreamPaneViewModel へ通知し、ストリーム表示は継続する

**依存関係**
- Outbound: Onvif.Core 3.0.0（Camera クラス）— SOAP PTZ コマンド送信（P0）
- Inbound: StreamPaneViewModel — PTZ コマンドの受信（P0）

**契約**: Service [x]

##### Service Interface

```csharp
// View_RTSP.Services
interface IOnvifPtzService
{
    Task<bool> GetPtzCapabilitiesAsync(OnvifConnectionOptions options, CancellationToken ct = default);

    Task StartMoveAsync(
        OnvifConnectionOptions options,
        PtzDirection direction,
        float speed,
        CancellationToken ct = default);

    Task StopMoveAsync(OnvifConnectionOptions options, CancellationToken ct = default);

    Task ZoomAsync(
        OnvifConnectionOptions options,
        float zoomSpeed,
        CancellationToken ct = default);
}

readonly record struct OnvifConnectionOptions(
    string EndpointUrl,
    string Username,
    string Password,
    string? ProfileToken   // null の場合は GetProfiles() で最初のプロファイルを自動選択
);

enum PtzDirection { Up, Down, Left, Right, UpLeft, UpRight, DownLeft, DownRight }
```

- 事前条件: `options.EndpointUrl` は有効な HTTP/HTTPS URI
- 事後条件: GetPtzCapabilitiesAsync は PTZ 対応時 true を返す（カメラ応答タイムアウト 3 秒）
- 不変条件: すべてのメソッドは例外をスローせず、失敗時は `false` 返却または内部エラーイベントで通知

**実装ノート**
- Onvif.Core の `Camera` クラスでインスタンスを生成し、`MoveAsync` / `StopAsync` を呼び出す
- WS-Security は Onvif.Core 内部で自動付与
- **ProfileToken の取得フロー**: `OnvifConnectionOptions.ProfileToken` が null の場合、接続確立後に `GetProfiles()` を呼び出して最初のプロファイルを自動選択しキャッシュする。ユーザーは `ConnectionSettingsView` でプロファイルトークンを手動上書きすることも可能（省略時は自動取得）
- リスク: カメラベンダーごとの SOAP 実装差異 — GetCapabilities の応答を防御的にパース

---

#### SettingsService

| フィールド | 詳細 |
|---------|------|
| Intent | 接続設定（URL・認証情報・レイアウト）の JSON 永続化と DPAPI パスワード暗号化 |
| Requirements | 4.6, 5.1–5.5, 9.3 |

**責務と制約**
- `%AppData%\RtspViewer\settings.json` へ `AppSettings` を JSON シリアライズして保存
- パスワードは `ProtectedData.Protect()` で DPAPI 暗号化し、Base64 でシリアライズする
- アプリ起動時に設定ファイルが存在しない場合はデフォルト値を返す（例外をスローしない）
- 設定ファイルが破損している場合はデフォルト値へフォールバックし、ログに記録する

**依存関係**
- Outbound: System.Text.Json — JSON シリアライズ（P0）
- Outbound: System.Security.Cryptography.ProtectedData — パスワード暗号化（P1）
- Inbound: MainWindowViewModel — 起動・終了時の設定 Load/Save（P0）

**契約**: Service [x] / State [x]

##### Service Interface

```csharp
// View_RTSP.Services
interface ISettingsService
{
    AppSettings Load();
    void Save(AppSettings settings);
}

record AppSettings(
    StreamPaneSettings Pane1,
    StreamPaneSettings Pane2,
    DualPaneLayout Layout,
    string DpiAwareness
);

record StreamPaneSettings(
    string RtspUrl,
    string? Username,
    string? EncryptedPassword,   // DPAPI Base64
    RtspTransport Transport,
    string? OnvifEndpointUrl,
    string? OnvifUsername,
    string? OnvifEncryptedPassword
);

enum DualPaneLayout { Horizontal, Vertical }
```

**実装ノート**
- 暗号化スコープ: `DataProtectionScope.CurrentUser`（ユーザープロファイルキー）
- リスク: 異なる Windows ユーザーでは復号不可 — アプリドキュメントに記載

---

### ViewModel Layer

#### StreamPaneViewModel

| フィールド | 詳細 |
|---------|------|
| Intent | 単一映像ペインの接続・切断・PTZ・ステータス表示の状態管理とコマンドバインディング |
| Requirements | 1.x, 2.x, 3.x, 5.x, 6.x, 7.x, 8.x |

**責務と制約**
- `RtspStreamService` および `OnvifPtzService` を所有し、ライフサイクルを管理する
- `INotifyPropertyChanged` を実装し、バインド可能なプロパティを公開する
- コマンド（ConnectCommand, DisconnectCommand, StartMoveCommand, StopMoveCommand, ZoomCommand）を ICommand として公開
- バックグラウンドスレッドからのイベント受信時は `Dispatcher.Invoke` で UI スレッドに安全にディスパッチする
- 接続状態に応じて PTZ UI の有効・無効を制御する（IsPtzEnabled プロパティ）

**依存関係**
- Outbound: IRtspStreamService — 接続管理（P0）
- Outbound: IOnvifPtzService — PTZ コマンド（P1）
- Inbound: StreamPaneView — データバインディング（P0）

**契約**: State [x] / Event [x]

##### State Management

```csharp
// View_RTSP.ViewModels
// 公開バインド可能プロパティ（INotifyPropertyChanged）
record struct StreamPaneState
{
    ConnectionState ConnectionState;  // Disconnected | Connecting | Connected | Error
    string StatusMessage;
    string? ErrorMessage;
    bool IsPtzEnabled;
    bool IsPtzSupported;
    ConnectionStats Stats;            // FrameRate, ReceivedFrames, Uptime
    WriteableBitmap? VideoFrame;      // VideoFrameRenderer から更新
}

enum ConnectionState { Disconnected, Connecting, Connected, Error }
```

- 状態モデル: ConnectionState の遷移は「接続フロー」の状態図に従う
- 永続化: 接続設定は SettingsService 経由で保存（アプリ終了時）
- 並行制御: コマンドハンドラは CancellationTokenSource で取り消し可能

#### MainWindowViewModel

**実装ノート（サマリーのみ）**
- `StreamPaneViewModel Pane1` と `Pane2` を所有
- `DualPaneLayout` プロパティで左右/上下分割を切り替え（ToggleLayoutCommand）
- アプリ終了時（`OnClosing`）に Pane1.Disconnect() と Pane2.Disconnect() を実行後、SettingsService.Save() を呼び出す（4.3）

---

### View Layer

#### StreamPaneView（実装ノート）

- `Image` コントロールの `Source` を `StreamPaneViewModel.VideoFrame`（WriteableBitmap）にバインド
- `ViewBox` で映像エリアをラップし、アスペクト比を維持したリサイズを実現（2.3）
- URL 入力は `TextBox`、パスワードは `PasswordBox`。`PasswordBox.Password` は DependencyProperty ではないため、コードビハインドで `PasswordChanged` イベントを捕捉し `ViewModel.SetPassword(SecureString)` を呼び出す方式を採用（平文 string への変換は接続直前のみ、使用後即 `string.Empty` で上書き）（5.4）
- 接続状態インジケーターは `ConnectionState → Brush` のバリューコンバーターで色を制御（10.3）
- 未接続時は `TextBlock`「未接続」をオーバーレイ表示（2.5）

#### PtzControlView（実装ノート）

- 8方向 + ズームイン/アウトのボタンを Grid で方向キー配置（10.6）
- `PreviewMouseDown` / `PreviewMouseUp` で StartMoveCommand / StopMoveCommand をトリガー
- `IsPtzEnabled` バインドで全体を IsEnabled 制御（7.6）

#### DualPaneLayout（実装ノート）

- `Grid` の `ColumnDefinitions` / `RowDefinitions` を `DualPaneLayout` プロパティで動的切り替え
- 各セルに `StreamPaneView` を配置し、`GridSplitter` で境界をドラッグ調整可能にする（8.5）

---

## データモデル

### ドメインモデル

```mermaid
classDiagram
    class AppSettings {
        +StreamPaneSettings Pane1
        +StreamPaneSettings Pane2
        +DualPaneLayout Layout
    }
    class StreamPaneSettings {
        +string RtspUrl
        +string Username
        +string EncryptedPassword
        +RtspTransport Transport
        +string OnvifEndpointUrl
        +string OnvifUsername
        +string OnvifEncryptedPassword
    }
    class RtspConnectionOptions {
        +string Url
        +string Username
        +string Password
        +RtspTransport Transport
        +bool LowLatencyMode
    }
    class StreamStateChangedEventArgs {
        +ConnectionState State
        +RtspError? Error
    }
    class RtspError {
        +RtspErrorKind Kind
        +string Message
        +int? FfmpegErrorCode
    }
    class ConnectionStats {
        +double FrameRate
        +long ReceivedFrames
        +TimeSpan Uptime
    }

    AppSettings "1" *-- "2" StreamPaneSettings
    StreamPaneSettings --> RtspConnectionOptions : 変換
    RtspConnectionOptions --> StreamStateChangedEventArgs : 接続結果
    StreamStateChangedEventArgs --> RtspError
    RtspStreamService --> ConnectionStats : 発行
```

### ドメインルールと不変条件

- `RtspConnectionOptions.Url` は `rtsp://` で始まる必要がある（接続前に ViewModel でバリデーション）
- `EncryptedPassword` は DPAPI で暗号化済みの Base64 文字列または null
- `ConnectionStats.FrameRate` は直近 5 秒のフレーム数を平均して算出
- `RtspErrorKind` は `ConnectionTimeout | AuthenticationFailed | NetworkUnreachable | DecodeError | UnknownError` を網羅

### 設定ファイル構造（論理データモデル）

```json
{
  "pane1": {
    "rtspUrl": "rtsp://192.168.1.100/stream1",
    "username": "admin",
    "encryptedPassword": "<DPAPI-Base64>",
    "transport": "Tcp",
    "onvifEndpointUrl": "http://192.168.1.100/onvif/device_service",
    "onvifUsername": "admin",
    "onvifEncryptedPassword": "<DPAPI-Base64>"
  },
  "pane2": { "...": "..." },
  "layout": "Horizontal"
}
```

---

## エラーハンドリング

### エラー戦略

ユーザー向けエラーはすべて `StreamPaneViewModel.ErrorMessage` 経由でビューに表示する。エラーはアプリクラッシュを引き起こさず、ConnectionState を適切な状態へ遷移させる。

### エラー分類と対応

| エラー種別 | 発生箇所 | 対応 | ユーザー通知 |
|---------|---------|------|------------|
| URL フォーマット不正 | StreamPaneViewModel.ValidateUrl | 接続試みず、State = Disconnected | 「URLフォーマットが正しくありません」（1.4） |
| 接続タイムアウト | RtspStreamService（avformat_open_input） | StateChanged(Error, ConnectionTimeout) | 「接続タイムアウト: サーバーに到達できません」（3.4） |
| 認証失敗 | RtspStreamService（HTTP 401相当） | StateChanged(Error, AuthenticationFailed) | 「認証失敗: ユーザー名またはパスワードを確認してください」（5.3） |
| ネットワーク不達 | RtspStreamService | StateChanged(Error, NetworkUnreachable) | 「ネットワークエラー: 接続が失われました」（3.3） |
| 予期せぬ切断 | RtspStreamService（DecodeLoop） | 最大3回再試行 → StateChanged(Disconnected) | 「ストリームが切断されました。再接続できませんでした」（3.1, 9.8） |
| FFmpeg デコードエラー | RtspStreamService | 自動再試行 → 失敗時に通知 | 「デコードエラーが発生しました。再試行中...」（9.8） |
| ONVIF コマンド失敗 | OnvifPtzService | 例外キャッチ → StateChanged（RTSP継続） | 「PTZコマンドに失敗しました: [詳細]」（7.8） |
| 設定ファイル破損 | SettingsService.Load | デフォルト値へフォールバック | なし（ログ記録のみ） |
| 未処理例外 | App.xaml.cs（DispatcherUnhandledException） | ダイアログ表示後に継続または終了 | 「予期しないエラーが発生しました」（4.5） |

### エラーフロー（複合ケース）

```mermaid
flowchart TD
    A[DecodeLoop エラー検出] --> B{エラー種別判定}
    B -->|デコードエラー| C{再試行回数 3未満?}
    C -->|Yes| D[500ms 待機後に再接続]
    D --> A
    C -->|No| E[StateChanged Disconnected]
    B -->|ネットワーク切断| E
    E --> F[StreamPaneViewModel: ErrorMessage 更新]
    F --> G[UI: エラー通知表示 + 再接続ボタン有効化]
```

### モニタリング

- FFmpeg エラーコードは `av_strerror` で文字列化しログ記録（Debug ビルド: Trace.WriteLine）
- 接続・切断・エラーイベントは `ConnectionStats` に記録（将来的なログ出力の拡張ポイント）
- グローバル例外ハンドラ（`Application.DispatcherUnhandledException`）で未処理例外をキャプチャ

---

## テスト戦略

### ユニットテスト

- `StreamPaneViewModel.ValidateUrl()`: 正常 URL / 不正スキーム / 空文字 の判定（1.4）
- `SettingsService.Load()`: 設定ファイル不存在時のデフォルト値返却（4.6）
- `SettingsService.Save()` → `Load()` のラウンドトリップ（URL・レイアウト保持）
- `RtspConnectionOptions` バリデーション: Transport 値の範囲チェック
- `StreamPaneViewModel` 状態遷移: ConnectCommand → Connecting → Connected / Error の遷移確認（モック IRtspStreamService）

### 統合テスト

- `RtspStreamService.ConnectAsync()`: ローカル RTSP テストサーバー（ffmpeg -re コマンド）への接続・フレーム受信確認（9.1, 9.2）
- `OnvifPtzService.GetPtzCapabilitiesAsync()`: ONVIF テストサーバーへの能力確認（7.6）
- `SettingsService`: パスワード暗号化・復号のラウンドトリップ（5.4）
- デュアルストリーム独立動作: 2つの RtspStreamService インスタンスが独立してデコードすることの確認（8.3）

### E2E / UI テスト

- RTSP URL 入力 → 接続 → 映像表示 → 切断の完全フロー（UI Automation / Appium for WPF）
- ウィンドウリサイズ時の映像アスペクト比維持確認（2.3）
- 片方ペインの切断がもう一方に影響しないことの確認（8.6）
- アプリ再起動後の URL 永続化確認（4.6）

### パフォーマンステスト

- エンドツーエンド遅延計測: フレームタイムスタンプとWPF描画完了のデルタ（目標 500ms, 要件 9.7）
- CPU 使用率: デュアルストリーム（1080p x 2）接続時の CPU 使用率（目標 50% 以下）
- メモリリーク確認: 接続・切断を 100 回繰り返した後の RSS 変化（FFmpeg リソース解放の確認、9.9）
- UIスレッドフリーズ確認: 映像表示中の UI 操作（ボタンクリック）に対するレスポンスタイム（目標 100ms 以内）

---

## セキュリティ考慮事項

- **パスワードマスク**: PasswordBox コントロールを使用し、プレーンテキストでメモリに長期保持しない（5.4）
- **DPAPI 暗号化**: 保存パスワードは `ProtectedData.Protect(DataProtectionScope.CurrentUser)` で暗号化（5.x）
- **RTSP URL のログ記録除外**: 認証情報付き URL（`rtsp://user:pass@host`）をログに出力しない
- **WS-Security**: Onvif.Core がナンス・タイムスタンプ付きの UsernameToken を自動生成（7.7）
- **入力バリデーション**: RTSP URL は Uri クラスでパース検証後に FFmpeg へ渡す（1.4）

---

## パフォーマンスと拡張性

- **低遅延目標**: FFmpeg オプション（fflags=nobuffer, flags=low_delay, max_delay=0）で E2E 500ms 以内（9.7）
- **GC 圧力削減**: BGRA バックバッファをピン留め byte[] で再利用し、フレームごとの GC アロケーションを排除
- **Dispatcher スロットリング**: 映像フレームは `Dispatcher.BeginInvoke(DispatcherPriority.Render)` を使用し、UI スレッドのキューを詰まらせない
- **スレッド分離**: 各ストリームが専用デコードスレッドを持ち、CPU コアを最大活用（8.3）
- **解像度スケーラビリティ**: WritableBitmap は解像度変更時のみ再生成し、通常フレームでは WritePixels のみ実行

---

## 参照資料

- [Sdcb.FFmpeg NuGet Gallery](https://www.nuget.org/packages/Sdcb.FFmpeg/) — バインディングバージョン確認
- [Sdcb.FFmpeg.runtime.windows-x64 NuGet](https://www.nuget.org/packages/Sdcb.FFmpeg.runtime.windows-x64/) — ネイティブ DLL（同一エコシステム）
- [GitHub - sdcb/Sdcb.FFmpeg](https://github.com/sdcb/Sdcb.FFmpeg) — API サンプル・Wiki
- [Onvif.Core NuGet (3.0.0)](https://www.nuget.org/packages/Onvif.Core) — ONVIF クライアント
- [GitHub - Jazea/Onvif.Core](https://github.com/Jazea/Onvif.Core) — PTZ MoveAsync リファレンス
- [ONVIF PTZ Service Specification v2.6](https://www.onvif.org/specs/srv/ptz/ONVIF-PTZ-Service-Spec-v260.pdf) — ContinuousMove WSDL 定義
- [Microsoft Learn - MVVM Multithreading](https://learn.microsoft.com/en-us/archive/msdn-magazine/2014/april/mvvm-multithreading-and-dispatching-in-mvvm-applications) — Dispatcher パターン
- 詳細な調査ログ・設計判断の根拠 → `research.md`
