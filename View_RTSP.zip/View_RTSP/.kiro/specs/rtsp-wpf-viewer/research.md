# リサーチ・設計決定ドキュメント

---
**目的**: 技術設計を裏付けるディスカバリー調査・アーキテクチャ検討・根拠を記録する。

---

## サマリー
- **フィーチャー**: `rtsp-wpf-viewer`
- **ディスカバリースコープ**: 新規フィーチャー（Complex Integration）
- **主要調査結果**:
  - FFmpeg.AutoGen 8.0 は .NET 10 + WPF と互換性があり、avformat / avcodec 直接呼出しによる低遅延デコードが可能
  - ONVIF PTZ 制御には `Onvif.Core` 3.0.0（NuGet）または `SharpOnvif` が利用可能で、WS-Security UsernameToken に対応
  - WPF における WritableBitmap の Lock/WritePixels/Unlock パターンが GC 負荷を抑えた高効率フレーム描画の最適解

---

## リサーチログ

### FFmpeg.AutoGen バージョンと .NET 10 互換性

- **Context**: 要件 9 で FFmpeg.AutoGen を使用した低遅延 RTSP デコードが指定されている。最新バージョンと .NET 10 との互換性を確認する必要がある。
- **Sources Consulted**:
  - [FFmpeg.AutoGen NuGet Gallery (8.0.0)](https://www.nuget.org/packages/FFmpeg.AutoGen/)
  - [GitHub - Ruslan-B/FFmpeg.AutoGen](https://github.com/Ruslan-B/FFmpeg.AutoGen)
- **Findings**:
  - FFmpeg.AutoGen 8.0.0 が最新安定版（FFmpeg 6.x/7.x バインディング）
  - .NET 6+ をターゲットとしており、.NET 10 では問題なく動作する
  - unsafe コードブロックが必要（`<AllowUnsafeBlocks>true</AllowUnsafeBlocks>` を csproj に追加）
  - Windows 向け FFmpeg ネイティブバイナリは別途配布が必要（`Sdcb.FFmpeg.runtime.windows-x64` 等）
  - avformat_open_input / avcodec_decode_video2 等の低レベル API が直接利用可能
- **Implications**:
  - デコードスレッドは専用バックグラウンドスレッドで動作させ、UIスレッドと完全分離する
  - ネイティブ DLL（avcodec, avformat, avutil 等）はアプリケーション出力ディレクトリに配置する必要がある

### 低遅延 RTSP フラグ設定

- **Context**: 要件 9.7 でエンドツーエンド遅延 500ms 以内が目標とされている。FFmpeg オプションによる低遅延設定を調査した。
- **Sources Consulted**:
  - [FFmpeg.AutoGen issues #99 - max delay reached RTSP](https://github.com/Ruslan-B/FFmpeg.AutoGen/issues/99)
  - [OpenCV Forum - RTSP ffmpeg set flags](https://forum.opencv.org/t/rtsp-ffmpeg-set-flags/14382)
- **Findings**:
  - `rtsp_transport=tcp` または `udp` をオプションで選択可能
  - `fflags=nobuffer` でデマルチプレクサのバッファリングを無効化
  - `flags=low_delay` でデコーダーの遅延低減モードを有効化
  - `max_delay=0` で最大遅延を 0 に設定
  - `analyzeduration=0` と `probesize=32` で開始時のストリーム解析時間を短縮
  - AVDictionary を使用して avformat_open_input に渡す
- **Implications**:
  - RtspStreamService がこれらのオプション定数を保持し、接続時に適用する
  - トランスポート選択（TCP/UDP）はユーザー設定として公開する（要件 9.3）

### WPF WritableBitmap フレーム描画パターン

- **Context**: 要件 9.5 で WritableBitmap への直接書き込みによる高効率描画が指定されている。
- **Sources Consulted**:
  - [A Beginner's Guide to FFmpeg.AutoGen (GitHub Gist)](https://gist.github.com/nidbCN/be6753d09ac2cbd504c92e2954eca554)
  - [Microsoft WPF Multithreading and Dispatching](https://learn.microsoft.com/en-us/archive/msdn-magazine/2014/april/mvvm-multithreading-and-dispatching-in-mvvm-applications)
- **Findings**:
  - WritableBitmap はスレッドアフィニティを持ち、UIスレッドでのみ直接操作可能
  - `Dispatcher.Invoke` 経由で `Lock()` → `WritePixels()` または `AddDirtyRect()` → `Unlock()` のシーケンスが必要
  - sws_scale で AVFrame のピクセルフォーマットを BGR24 または BGRA に変換後、WritePixels でコピー
  - フレームコピーのコスト削減のため、固定サイズのピン留めバイト配列をバックバッファとして保持する
- **Implications**:
  - VideoFrameRenderer コンポーネントが WritableBitmap を所有し、Dispatcher 経由で描画を行う
  - デコードスレッドと UI スレッド間の同期には ConcurrentQueue またはチャンネルを使用する

### ONVIF PTZ 制御ライブラリ選定

- **Context**: 要件 7 で ONVIF Profile S PTZ 制御が必要とされており、WS-Security UsernameToken 認証が必要。
- **Sources Consulted**:
  - [Onvif.Core NuGet 3.0.0](https://www.nuget.org/packages/Onvif.Core)
  - [GitHub - Jazea/Onvif.Core](https://github.com/Jazea/Onvif.Core)
  - [GitHub - jimm98y/SharpOnvif](https://github.com/jimm98y/SharpOnvif)
- **Findings**:
  - `Onvif.Core` 3.0.0（Jazea）: 軽量 ONVIF Discovery・Client ライブラリ、MoveAsync 等の高レベル API あり
  - `SharpOnvif`: Profile S/G/T 全対応、クライアント・サーバー両実装、より完全な SOAP / WS-Security 対応
  - どちらも WS-Security UsernameToken 認証に対応（SOAP ヘッダーに埋め込み）
  - PTZ ContinuousMove / Stop / Zoom コマンドをサポート
  - PTZ 対応可否は GetCapabilities または GetServices レスポンスで判断可能
- **Implications**:
  - `Onvif.Core` 3.0.0 を採用（軽量・NuGet 安定版・必要機能を充足）
  - PTZ 非対応の場合は GetCapabilities の PTZ プロパティ存在確認で判定し、UIを無効化する

### MVVM Community Toolkit と WPF スレッドモデル

- **Context**: WPF MVVM パターンにおける INotifyPropertyChanged の実装と非同期処理の整合性確認。
- **Sources Consulted**:
  - [Microsoft Learn - MVVM Multithreading and Dispatching](https://learn.microsoft.com/en-us/archive/msdn-magazine/2014/april/mvvm-multithreading-and-dispatching-in-mvvm-applications)
  - [WPF Multithreading UI Dispatcher in MVVM 2026](https://copyprogramming.com/howto/wpf-multithreading-ui-dispatcher-in-mvvm)
- **Findings**:
  - WPF は PropertyChanged イベントをメインスレッドへ自動ディスパッチしない（他の XAML フレームワークと異なる）
  - バックグラウンドスレッドからの PropertyChanged は Dispatcher.Invoke/BeginInvoke が必要
  - CommunityToolkit.Mvvm 8.x は [ObservableProperty] 属性で MVVM ボイラープレートを自動生成可能
  - デュアルストリームは各ストリームが独立した ViewModel インスタンスを持つことでスレッド安全性を確保
- **Implications**:
  - StreamPaneViewModel を独立した単位として設計し、独立したスレッドで動作させる
  - フレーム描画は Dispatcher 経由で行い、PropertyChanged もディスパッチ経由とする

---

## アーキテクチャパターン評価

| オプション | 説明 | 強み | リスク・制約 | 備考 |
|----------|------|------|-------------|------|
| MVVM（単一 VM） | MainWindowViewModel のみ | シンプル、ファイル数少 | 複数ストリームで VM が肥大化 | デュアルストリーム要件には不適 |
| MVVM（分割 VM） | MainWindowViewModel + StreamPaneViewModel x2 | 独立性・テスタビリティ高 | ファイル数増加 | **採用**。要件 8 と整合 |
| Hexagonal | Port/Adapter でストリーム処理を分離 | 高テスタビリティ | WPF 向けの over-engineering | 今回のスコープには不要 |
| コードビハインドのみ | XAML + code-behind で全実装 | 最速の初期実装 | テスト不可、ロジック混在 | ステアリング規約に反する |

---

## 設計決定

### 決定: FFmpeg.AutoGen vs LibVLCSharp

- **Context**: 要件 9 で FFmpeg.AutoGen が明示指定されているが、他候補との比較を記録する。
- **Alternatives Considered**:
  1. `LibVLCSharp.WPF` — VideoLAN の高レベルラッパー、設定容易、低遅延制御が限定的
  2. `FFmpeg.AutoGen 8.0` — 低レベル API 直接呼出し、完全な遅延制御が可能
  3. `Sdcb.FFmpeg` — CppSharp 生成の別バインディング、より新しいが成熟度が低い
- **Selected Approach**: FFmpeg.AutoGen 8.0 を採用し、avformat / avcodec を直接使用
- **Rationale**: 要件 9 で明示されており、avformat オプションによる完全な低遅延制御が可能
- **Trade-offs**: unsafe コードが必要・ネイティブ DLL 配布が必要 vs 500ms 遅延目標の達成
- **Follow-up**: ネイティブ DLL の配布方法（NuGet ランタイムパッケージ vs 手動コピー）を実装時に確認

### 決定: 独立ストリームスレッドモデル

- **Context**: 要件 8 でデュアルストリームの独立動作（一方の障害が他方に影響しない）が必要。
- **Alternatives Considered**:
  1. 共有スレッドプールで両ストリームを処理 — 実装シンプルだが相互影響リスクあり
  2. 各ストリームに専用デコードスレッドを割り当て — 完全分離、スレッド数が増加
- **Selected Approach**: 各 StreamPaneViewModel に対し独立した専用デコードスレッドを起動
- **Rationale**: 要件 8.3「一方の遅延やエラーが他方に影響しない」を確実に達成するため
- **Trade-offs**: CPU 使用スレッド数が 2 倍になるが、監視用途では許容範囲
- **Follow-up**: CancellationToken を用いた適切なスレッド終了処理を実装時に確認

### 決定: 設定永続化方式

- **Context**: 要件 4.6 で RTSP URL の永続化が必要。要件 5 で認証情報も扱う。
- **Alternatives Considered**:
  1. JSON ファイル（AppData フォルダ）— シンプル、可読性高い
  2. Windows Registry — WPF アプリ標準だが可搬性が低い
  3. SQLite — 過剰
- **Selected Approach**: JSON ファイルを `%AppData%\RtspViewer\settings.json` に保存
- **Rationale**: シンプルかつポータブル、パスワードは Windows DPAPI で暗号化
- **Trade-offs**: ファイルアクセス競合は起動・終了時のみなので問題なし
- **Follow-up**: DPAPI（System.Security.Cryptography.ProtectedData）の利用可能性を確認

---

## リスクと軽減策

- **FFmpeg ネイティブ DLL 配布**: NuGet の `Sdcb.FFmpeg.runtime.windows-x64` パッケージでランタイムを自動配置するか、手動コピーでの対応が必要 — 実装初期に配布方式を確定する
- **WritableBitmap スレッド競合**: Dispatcher.Invoke のフレームレートへの影響（過剰な Invoke でUIスレッド飽和） — BeginInvoke + フレームスキップ判定でスロットリング
- **ONVIF 互換性**: カメラベンダーごとに PTZ SOAP 実装が微妙に異なる — GetCapabilities で事前確認し、エラー時は PTZ UI を無効化（要件 7.6）
- **デュアルストリームの CPU/メモリ負荷**: 2 ストリーム同時デコードで CPU 使用率が高くなる可能性 — 接続前にリソース状況を確認する UI ガイダンスを検討

---

## 参照資料

- [FFmpeg.AutoGen NuGet Gallery (8.0.0)](https://www.nuget.org/packages/FFmpeg.AutoGen/) — バージョン・依存関係の確認
- [GitHub - Ruslan-B/FFmpeg.AutoGen](https://github.com/Ruslan-B/FFmpeg.AutoGen) — サンプル・バインディング詳細
- [Onvif.Core NuGet (3.0.0)](https://www.nuget.org/packages/Onvif.Core) — ONVIF クライアントライブラリ
- [GitHub - Jazea/Onvif.Core](https://github.com/Jazea/Onvif.Core) — PTZ API リファレンス
- [GitHub - jimm98y/SharpOnvif](https://github.com/jimm98y/SharpOnvif) — 代替 ONVIF 実装
- [ONVIF PTZ Service Specification v2.6](https://www.onvif.org/specs/srv/ptz/ONVIF-PTZ-Service-Spec-v260.pdf) — ContinuousMove/Stop WSDL 定義
- [Microsoft Learn - MVVM Multithreading and Dispatching](https://learn.microsoft.com/en-us/archive/msdn-magazine/2014/april/mvvm-multithreading-and-dispatching-in-mvvm-applications) — WPF スレッドモデル
- [WPF Multithreading UI Dispatcher in MVVM 2026](https://copyprogramming.com/howto/wpf-multithreading-ui-dispatcher-in-mvvm) — Dispatcher パターン最新情報
