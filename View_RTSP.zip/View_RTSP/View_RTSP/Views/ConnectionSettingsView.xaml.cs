// ConnectionSettingsView のコードビハインド
// タスク 8.4: ONVIF PasswordBox の PasswordChanged イベントを処理
// Requirements: 7.5, 5.4

using System.Windows;
using System.Windows.Controls;
using View_RTSP.ViewModels;

namespace View_RTSP.Views;

/// <summary>
/// ONVIF 接続設定パネルのコードビハインド。
/// ONVIF PasswordBox の PasswordChanged イベントを処理し、ViewModel へパスワードを渡す。
/// </summary>
public partial class ConnectionSettingsView : UserControl
{
    // ─── コンストラクター ─────────────────────────────────────────

    /// <summary>
    /// ConnectionSettingsView を初期化する。
    /// </summary>
    public ConnectionSettingsView()
    {
        InitializeComponent();
    }

    // ─── プライベートヘルパー ─────────────────────────────────────

    /// <summary>
    /// DataContext を StreamPaneViewModel として取得する。
    /// </summary>
    private StreamPaneViewModel? ViewModel => DataContext as StreamPaneViewModel;

    // ─── PasswordBox イベントハンドラー ───────────────────────────

    /// <summary>
    /// ONVIF PasswordBox のパスワード変更イベントを処理する。
    /// PasswordBox.Password は DependencyProperty ではないため、PasswordChanged イベントで
    /// コードビハインドから ViewModel へパスワードを渡す（要件 5.4）。
    /// </summary>
    private void OnvifPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (sender is PasswordBox passwordBox && ViewModel is not null)
        {
            ViewModel.OnvifPassword = passwordBox.Password;
        }
    }

    // ─── PTZ 確認ボタン ───────────────────────────────────────────

    /// <summary>
    /// PTZ 確認ボタンのクリックイベントを処理する。
    /// RTSP 接続状態に関わらず手動で PTZ 能力を確認できる。
    /// </summary>
    private async void CheckPtzButton_Click(object sender, RoutedEventArgs e)
    {
        if (ViewModel is null)
        {
            MessageBox.Show(
                "ViewModel が見つかりません。DataContext が正しく設定されていません。",
                "ONVIF PTZ 確認",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        await ViewModel.CheckPtzCapabilitiesAsync();
    }

    // ─── DataContext 変更時のパスワード初期化 ─────────────────────

    /// <summary>
    /// DataContext が変更された時に ONVIF パスワードフィールドを同期する。
    /// </summary>
    protected override void OnPropertyChanged(
        System.Windows.DependencyPropertyChangedEventArgs e)
    {
        base.OnPropertyChanged(e);

        if (e.Property == DataContextProperty)
        {
            if (OnvifPasswordBox is not null)
            {
                OnvifPasswordBox.Password = string.Empty;
            }

            if (ViewModel is not null && OnvifPasswordBox is not null)
            {
                OnvifPasswordBox.Password = ViewModel.OnvifPassword;
            }
        }
    }
}
