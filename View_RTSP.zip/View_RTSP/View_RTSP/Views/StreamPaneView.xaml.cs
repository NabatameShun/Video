// StreamPaneView のコードビハインド
// タスク 8.1: PasswordBox バインディングと接続/切断ボタンのイベント処理
// PasswordBox.Password は DependencyProperty ではないため、PasswordChanged イベントを
// コードビハインドで捕捉して ViewModel へ安全に渡す（設計書 StreamPaneView 実装ノート準拠）

using System.Windows;
using System.Windows.Controls;
using View_RTSP.ViewModels;

namespace View_RTSP.Views;

/// <summary>
/// StreamPaneView のコードビハインド。
/// PasswordBox の PasswordChanged イベントを処理し、ViewModel へパスワードを渡す。
/// </summary>
public partial class StreamPaneView : UserControl
{
    // ─── コンストラクター ─────────────────────────────────────────

    /// <summary>
    /// StreamPaneView を初期化する。
    /// </summary>
    public StreamPaneView()
    {
        InitializeComponent();
    }

    // ─── プライベートヘルパー ─────────────────────────────────────

    /// <summary>
    /// DataContext を StreamPaneViewModel として取得する。
    /// </summary>
    private StreamPaneViewModel? ViewModel => DataContext as StreamPaneViewModel;

    // ─── PasswordBox イベントハンドラー ───────────────────────────

    /// <summary>
    /// RTSP PasswordBox のパスワード変更イベントを処理する。
    /// PasswordBox.Password は DependencyProperty ではないため、PasswordChanged イベントで
    /// コードビハインドから ViewModel へパスワードを渡す方式を採用している（要件 5.4）。
    /// </summary>
    private void RtspPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (sender is PasswordBox passwordBox && ViewModel is not null)
        {
            // PasswordBox からプレーンテキストパスワードを取得して ViewModel へ設定する
            // セキュリティ考慮: 接続直前のみ使用し、接続後はクリアされる
            ViewModel.Password = passwordBox.Password;
        }
    }

    // ─── 接続/切断ボタンイベントハンドラー ───────────────────────

    /// <summary>
    /// 接続ボタンのクリックイベントを処理する。
    /// </summary>
    private async void ConnectButton_Click(object sender, RoutedEventArgs e)
    {
        if (ViewModel is not null)
        {
            // 接続中は UI を更新するため非同期で実行
            await ViewModel.ConnectAsync();
        }
    }

    /// <summary>
    /// 切断ボタンのクリックイベントを処理する。
    /// </summary>
    private void DisconnectButton_Click(object sender, RoutedEventArgs e)
    {
        ViewModel?.Disconnect();
    }

    // ─── 録画保存先フォルダ選択ハンドラー ─────────────────────────

    /// <summary>
    /// フォルダ選択ダイアログを表示し、録画保存先フォルダを選択する（要件 4.1）。
    /// </summary>
    private void BrowseFolderButton_Click(object sender, RoutedEventArgs e)
    {
        if (ViewModel is null) return;

        var dialog = new Microsoft.Win32.OpenFolderDialog
        {
            Title = "録画保存先フォルダを選択",
            Multiselect = false,
        };

        // 現在のフォルダパスが有効なら初期ディレクトリに設定
        if (!string.IsNullOrWhiteSpace(ViewModel.RecordingFolderPath)
            && System.IO.Directory.Exists(ViewModel.RecordingFolderPath))
        {
            dialog.InitialDirectory = ViewModel.RecordingFolderPath;
        }

        if (dialog.ShowDialog() == true)
        {
            ViewModel.RecordingFolderPath = dialog.FolderName;
        }
    }

    // ─── DataContext 変更時のパスワード初期化 ─────────────────────

    /// <summary>
    /// DataContext が変更された時にパスワードフィールドを同期する。
    /// </summary>
    protected override void OnPropertyChanged(
        System.Windows.DependencyPropertyChangedEventArgs e)
    {
        base.OnPropertyChanged(e);

        if (e.Property == DataContextProperty)
        {
            // DataContext が新しい ViewModel になった場合、PasswordBox をクリアする
            // （セキュリティ: 古いパスワードが残らないようにする）
            if (RtspPasswordBox is not null)
            {
                RtspPasswordBox.Password = string.Empty;
            }

            // 新しい ViewModel のパスワードで PasswordBox を初期化する
            if (ViewModel is not null && RtspPasswordBox is not null)
            {
                RtspPasswordBox.Password = ViewModel.Password;
            }
        }
    }
}
