// PtzControlView のコードビハインド
// タスク 8.2: PreviewMouseDown / PreviewMouseUp イベントで PTZ コマンドを ViewModel へ送信
// Requirements: 7.2, 7.3, 7.4, 7.6, 10.6

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using View_RTSP.Models;
using View_RTSP.ViewModels;

namespace View_RTSP.Views;

/// <summary>
/// PTZ コントロールビューのコードビハインド。
/// PreviewMouseDown で移動開始、PreviewMouseUp で移動停止のコマンドを ViewModel へ送信する。
/// </summary>
public partial class PtzControlView : UserControl
{
    // ─── コンストラクター ─────────────────────────────────────────

    /// <summary>
    /// PtzControlView を初期化する。
    /// </summary>
    public PtzControlView()
    {
        InitializeComponent();
    }

    // ─── プライベートヘルパー ─────────────────────────────────────

    /// <summary>
    /// DataContext を StreamPaneViewModel として取得する。
    /// </summary>
    private StreamPaneViewModel? ViewModel => DataContext as StreamPaneViewModel;

    // ─── 方向ボタン イベントハンドラー ───────────────────────────

    /// <summary>
    /// PTZ 方向ボタンの PreviewMouseDown イベントを処理する。
    /// ボタンの Tag プロパティから方向を取得して StartMoveAsync を呼び出す。
    /// </summary>
    private async void PtzButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (sender is Button button
            && button.Tag is string directionStr
            && Enum.TryParse<PtzDirection>(directionStr, out var direction)
            && ViewModel is not null)
        {
            await ViewModel.StartMoveAsync(direction);
        }
    }

    /// <summary>
    /// PTZ 方向ボタンの PreviewMouseUp イベントを処理する。
    /// カメラの移動を停止する。
    /// </summary>
    private async void PtzButton_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (ViewModel is not null)
        {
            await ViewModel.StopMoveAsync();
        }
    }

    /// <summary>
    /// 停止ボタン（中央）のクリックイベントを処理する。
    /// </summary>
    private async void PtzStopButton_Click(object sender, RoutedEventArgs e)
    {
        if (ViewModel is not null)
        {
            await ViewModel.StopMoveAsync();
        }
    }

    // ─── ズームボタン イベントハンドラー ─────────────────────────

    /// <summary>
    /// ズームインボタンの PreviewMouseDown イベントを処理する。
    /// </summary>
    private async void ZoomInButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (ViewModel is not null)
        {
            // 正の速度でズームイン
            await ViewModel.ZoomAsync(0.5f);
        }
    }

    /// <summary>
    /// ズームアウトボタンの PreviewMouseDown イベントを処理する。
    /// </summary>
    private async void ZoomOutButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (ViewModel is not null)
        {
            // 負の速度でズームアウト
            await ViewModel.ZoomAsync(-0.5f);
        }
    }

    /// <summary>
    /// ズームボタンの PreviewMouseUp イベントを処理する。
    /// ズーム動作を停止する。
    /// </summary>
    private async void ZoomButton_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (ViewModel is not null)
        {
            await ViewModel.StopMoveAsync();
        }
    }
}
