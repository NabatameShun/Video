// MainWindowViewModel の実装
// 3ペイン・4タブレイアウト対応
// Requirements: 4.3, 4.6, 8.1, 8.4

using CommunityToolkit.Mvvm.ComponentModel;
using View_RTSP.Models;
using View_RTSP.Services;

namespace View_RTSP.ViewModels;

/// <summary>
/// アプリケーション全体の状態・タブ管理を担う ViewModel。
/// <para>
/// 3つの <see cref="StreamPaneViewModel"/> を所有・管理し、
/// タブ切り替えと起動時設定読み込み・終了時設定保存を処理する。
/// </para>
/// </summary>
public partial class MainWindowViewModel : ObservableObject
{
    // ─── 依存サービス ─────────────────────────────────────────────
    private readonly ISettingsService _settingsService;

    // ─── バインド可能プロパティ ───────────────────────────────────

    /// <summary>ペイン1の ViewModel</summary>
    public StreamPaneViewModel Pane1 { get; }

    /// <summary>ペイン2の ViewModel</summary>
    public StreamPaneViewModel Pane2 { get; }

    /// <summary>ペイン3の ViewModel</summary>
    public StreamPaneViewModel Pane3 { get; }

    /// <summary>選択中のタブインデックス（0=カメラ1, 1=カメラ2, 2=カメラ3, 3=全カメラ）</summary>
    [ObservableProperty]
    private int _selectedTabIndex = 3;

    /// <summary>録画ファイルの保存先フォルダパス</summary>
    private string _recordingFolderPath = AppSettings.Default.RecordingFolderPath;

    // ─── コンストラクター ─────────────────────────────────────────

    /// <summary>
    /// 依存オブジェクトを受け取るコンストラクター。
    /// </summary>
    /// <param name="pane1">ペイン 1 の ViewModel</param>
    /// <param name="pane2">ペイン 2 の ViewModel</param>
    /// <param name="pane3">ペイン 3 の ViewModel</param>
    /// <param name="settingsService">設定永続化サービス</param>
    public MainWindowViewModel(
        StreamPaneViewModel pane1,
        StreamPaneViewModel pane2,
        StreamPaneViewModel pane3,
        ISettingsService settingsService)
    {
        Pane1 = pane1;
        Pane2 = pane2;
        Pane3 = pane3;
        _settingsService = settingsService;
    }

    // ─── 起動時設定読み込み ───────────────────────────────────────

    /// <summary>
    /// SettingsService から設定を読み込んで各 StreamPaneViewModel へ反映する。
    /// Requirements: 8.4（起動時設定読み込み）, 4.6（RTSP URL の永続化）
    /// </summary>
    public void LoadSettings()
    {
        var settings = _settingsService.Load();

        SelectedTabIndex = settings.SelectedTabIndex;
        _recordingFolderPath = settings.RecordingFolderPath;

        // 各ペインへ設定を反映（パスワードは暗号化済みのため null として渡す）
        Pane1.LoadSettings(settings.Pane1, decryptedPassword: null, decryptedOnvifPassword: null);
        Pane2.LoadSettings(settings.Pane2, decryptedPassword: null, decryptedOnvifPassword: null);
        Pane3.LoadSettings(settings.Pane3, decryptedPassword: null, decryptedOnvifPassword: null);

        // 録画保存先フォルダパスを各ペインの ViewModel に反映（Requirements: 4.4）
        Pane1.RecordingFolderPath = settings.RecordingFolderPath;
        Pane2.RecordingFolderPath = settings.RecordingFolderPath;
        Pane3.RecordingFolderPath = settings.RecordingFolderPath;
    }

    // ─── アプリ終了処理 ───────────────────────────────────────────

    /// <summary>
    /// ウィンドウ閉じる時の処理。
    /// 全ペインを切断してから設定を保存する。
    /// Requirements: 4.3（ウィンドウ閉じる時の切断・終了処理）, 4.6
    /// </summary>
    public void OnClosing()
    {
        // 全ペインを切断（Requirements: 4.3）
        Pane1.Disconnect();
        Pane2.Disconnect();
        Pane3.Disconnect();

        // 現在の設定を保存（Requirements: 4.6）
        var settings = BuildCurrentSettings();
        _settingsService.Save(settings);
    }

    // ─── プライベートヘルパー ─────────────────────────────────────

    /// <summary>
    /// 現在の ViewModel 状態から保存用の AppSettings を構築する。
    /// RecordingFolderPath は Pane1 の値を使用する（UI で変更された最新値を保存するため）。
    /// </summary>
    private AppSettings BuildCurrentSettings()
    {
        // Pane1 の RecordingFolderPath を優先的に使用（UI 変更を反映）
        var recordingFolderPath = !string.IsNullOrWhiteSpace(Pane1.RecordingFolderPath)
            ? Pane1.RecordingFolderPath
            : _recordingFolderPath;

        return new AppSettings(
            Pane1: Pane1.BuildSettings(),
            Pane2: Pane2.BuildSettings(),
            Pane3: Pane3.BuildSettings(),
            SelectedTabIndex: SelectedTabIndex,
            RecordingFolderPath: recordingFolderPath);
    }
}
