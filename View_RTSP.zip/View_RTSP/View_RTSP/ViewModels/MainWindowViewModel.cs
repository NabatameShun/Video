// MainWindowViewModel の実装
// タスク 6.3 に対応
// Requirements: 4.3, 4.6, 8.1, 8.4

using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using View_RTSP.Models;
using View_RTSP.Services;

namespace View_RTSP.ViewModels;

/// <summary>
/// アプリケーション全体の状態・レイアウト管理を担う ViewModel。
/// <para>
/// デュアルストリーム構成の 2 つの <see cref="StreamPaneViewModel"/> を所有・管理し、
/// レイアウト切り替えと起動時設定読み込み・終了時設定保存を処理する。
/// </para>
/// </summary>
public partial class MainWindowViewModel : ObservableObject
{
    // ─── 依存サービス ─────────────────────────────────────────────
    private readonly ISettingsService _settingsService;

    // ─── バインド可能プロパティ ───────────────────────────────────

    /// <summary>左（または上）ペインの ViewModel</summary>
    public StreamPaneViewModel Pane1 { get; }

    /// <summary>右（または下）ペインの ViewModel</summary>
    public StreamPaneViewModel Pane2 { get; }

    /// <summary>デュアルペインのレイアウト種別（Horizontal / Vertical）</summary>
    [ObservableProperty]
    private DualPaneLayout _layout = DualPaneLayout.Horizontal;

    // ─── コンストラクター ─────────────────────────────────────────

    /// <summary>
    /// 依存オブジェクトを受け取るコンストラクター。
    /// </summary>
    /// <param name="pane1">ペイン 1 の ViewModel</param>
    /// <param name="pane2">ペイン 2 の ViewModel</param>
    /// <param name="settingsService">設定永続化サービス</param>
    public MainWindowViewModel(
        StreamPaneViewModel pane1,
        StreamPaneViewModel pane2,
        ISettingsService settingsService)
    {
        Pane1 = pane1;
        Pane2 = pane2;
        _settingsService = settingsService;
    }

    // ─── レイアウト切り替えコマンド ───────────────────────────────

    /// <summary>
    /// 左右分割 / 上下分割レイアウトを切り替える。
    /// Requirements: 8.4（左右・上下分割レイアウト選択）
    /// </summary>
    [RelayCommand]
    public void ToggleLayout()
    {
        Layout = Layout == DualPaneLayout.Horizontal
            ? DualPaneLayout.Vertical
            : DualPaneLayout.Horizontal;
    }

    // ─── 起動時設定読み込み ───────────────────────────────────────

    /// <summary>
    /// SettingsService から設定を読み込んで各 StreamPaneViewModel へ反映する。
    /// Requirements: 8.4（起動時設定読み込み）, 4.6（RTSP URL の永続化）
    /// </summary>
    public void LoadSettings()
    {
        var settings = _settingsService.Load();

        Layout = settings.Layout;

        // 各ペインへ設定を反映（パスワードは暗号化済みのため null として渡す）
        Pane1.LoadSettings(settings.Pane1, decryptedPassword: null, decryptedOnvifPassword: null);
        Pane2.LoadSettings(settings.Pane2, decryptedPassword: null, decryptedOnvifPassword: null);
    }

    // ─── アプリ終了処理 ───────────────────────────────────────────

    /// <summary>
    /// ウィンドウ閉じる時の処理。
    /// 両ペインを切断してから設定を保存する。
    /// Requirements: 4.3（ウィンドウ閉じる時の切断・終了処理）, 4.6
    /// </summary>
    public void OnClosing()
    {
        // 両ペインを切断（Requirements: 4.3）
        Pane1.Disconnect();
        Pane2.Disconnect();

        // 現在の設定を保存（Requirements: 4.6）
        var settings = BuildCurrentSettings();
        _settingsService.Save(settings);
    }

    // ─── プライベートヘルパー ─────────────────────────────────────

    /// <summary>
    /// 現在の ViewModel 状態から保存用の AppSettings を構築する。
    /// </summary>
    private AppSettings BuildCurrentSettings()
    {
        return new AppSettings(
            Pane1: Pane1.BuildSettings(),
            Pane2: Pane2.BuildSettings(),
            Layout: Layout);
    }
}
