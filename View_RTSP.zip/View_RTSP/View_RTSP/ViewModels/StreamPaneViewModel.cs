// StreamPaneViewModel の実装
// タスク 6.1, 6.2 に対応
// Requirements: 1.1, 1.2, 1.4, 1.5, 1.6, 1.7, 2.1, 3.2, 5.2, 5.3, 5.5, 6.3,
//               7.2, 7.3, 7.4, 7.6, 7.8, 8.2, 8.7, 8.8

using System.Windows.Media.Imaging;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using View_RTSP.Models;
using View_RTSP.Services;

namespace View_RTSP.ViewModels;

/// <summary>
/// 単一映像ペインの接続・切断・PTZ・ステータス表示を管理する ViewModel。
/// <para>
/// デュアルストリーム構成の各ペインに 1 インスタンス作成される。
/// バックグラウンドスレッドからのイベントは Dispatcher 経由で UI スレッドにディスパッチする。
/// </para>
/// </summary>
public partial class StreamPaneViewModel : ObservableObject
{
    // ─── 定数 ────────────────────────────────────────────────────
    private const float DefaultPtzSpeed = 0.5f;

    // ─── 依存サービス ─────────────────────────────────────────────
    private readonly IRtspStreamService _rtspService;
    private readonly IVideoFrameRenderer _renderer;
    private readonly IOnvifPtzService _onvifService;
    private readonly ISettingsService _settingsService;

    // ─── バインド可能プロパティ ───────────────────────────────────

    /// <summary>RTSP ストリーム URL</summary>
    [ObservableProperty]
    private string _rtspUrl = string.Empty;

    /// <summary>RTSP 認証ユーザー名</summary>
    [ObservableProperty]
    private string _username = string.Empty;

    /// <summary>RTSP 認証パスワード（コードビハインドから設定）</summary>
    [ObservableProperty]
    private string _password = string.Empty;

    /// <summary>現在の接続状態</summary>
    [ObservableProperty]
    private ConnectionState _connectionState = ConnectionState.Disconnected;

    /// <summary>ステータスメッセージ</summary>
    [ObservableProperty]
    private string _statusMessage = "未接続";

    /// <summary>エラーメッセージ（エラー時のみ設定）</summary>
    [ObservableProperty]
    private string? _errorMessage;

    /// <summary>接続統計情報（フレームレート・受信フレーム数・稼働時間）</summary>
    [ObservableProperty]
    private ConnectionStats _stats;

    /// <summary>映像フレーム（WritableBitmap）</summary>
    [ObservableProperty]
    private WriteableBitmap? _videoFrame;

    /// <summary>PTZ が有効かどうか（ONVIF 対応かつ ONVIF 設定済み）</summary>
    [ObservableProperty]
    private bool _isPtzEnabled;

    /// <summary>ONVIF エンドポイント URL</summary>
    [ObservableProperty]
    private string _onvifEndpointUrl = string.Empty;

    /// <summary>ONVIF 認証ユーザー名</summary>
    [ObservableProperty]
    private string _onvifUsername = string.Empty;

    /// <summary>ONVIF 認証パスワード</summary>
    [ObservableProperty]
    private string _onvifPassword = string.Empty;

    /// <summary>RTSP トランスポートプロトコル</summary>
    [ObservableProperty]
    private RtspTransport _transport = RtspTransport.Tcp;

    // ─── コンストラクター ─────────────────────────────────────────

    /// <summary>
    /// 依存サービスを受け取るコンストラクター。
    /// </summary>
    public StreamPaneViewModel(
        IRtspStreamService rtspService,
        IVideoFrameRenderer renderer,
        IOnvifPtzService onvifService,
        ISettingsService settingsService)
    {
        _rtspService = rtspService;
        _renderer = renderer;
        _onvifService = onvifService;
        _settingsService = settingsService;

        // サービスイベントをサブスクライブ
        _rtspService.StateChanged += OnStateChanged;
        _rtspService.StatsUpdated += OnStatsUpdated;
        _renderer.BitmapUpdated += OnBitmapUpdated;
    }

    // ─── プロパティ変更フック ─────────────────────────────────────

    // ─── URL バリデーション ───────────────────────────────────────

    /// <summary>
    /// RTSP URL のフォーマットを検証する。
    /// rtsp:// スキームで始まっている場合のみ有効と判定する。
    /// </summary>
    /// <returns>URL が有効な場合は true</returns>
    public bool IsUrlValid()
    {
        if (string.IsNullOrWhiteSpace(RtspUrl))
            return false;

        return RtspUrl.StartsWith("rtsp://", StringComparison.OrdinalIgnoreCase);
    }

    // ─── 接続コマンド ─────────────────────────────────────────────

    /// <summary>
    /// RTSP ストリームへ接続する。
    /// URL バリデーションが失敗した場合はエラーメッセージを設定して接続を試みない。
    /// </summary>
    public async Task ConnectAsync(CancellationToken cancellationToken = default)
    {
        // URL バリデーション（Requirements: 1.4）
        if (!IsUrlValid())
        {
            ErrorMessage = "URLフォーマットが正しくありません。rtsp:// で始まる URL を入力してください。";
            return;
        }

        ErrorMessage = null;
        StatusMessage = "接続中...";
        ConnectionState = ConnectionState.Connecting;

        // 認証情報を接続オプションへ組み立て（Requirements: 5.2, 5.5）
        var options = BuildConnectionOptions();

        await _rtspService.ConnectAsync(options, cancellationToken);
    }

    /// <summary>
    /// RTSP ストリームを切断する。
    /// </summary>
    public void Disconnect()
    {
        _rtspService.Disconnect();
    }

    // ─── PTZ コマンド ─────────────────────────────────────────────

    /// <summary>
    /// 指定した方向への連続移動を開始する。
    /// IsPtzEnabled が false の場合は何もしない。
    /// </summary>
    /// <param name="direction">移動方向</param>
    /// <param name="cancellationToken">キャンセルトークン</param>
    public async Task StartMoveAsync(PtzDirection direction, CancellationToken cancellationToken = default)
    {
        if (!IsPtzEnabled)
            return;

        try
        {
            var options = BuildOnvifOptions();
            await _onvifService.StartMoveAsync(options, direction, DefaultPtzSpeed, cancellationToken);
        }
        catch (Exception ex)
        {
            // PTZ エラー時はエラーメッセージを表示しつつ RTSP 表示を継続（Requirements: 7.8）
            ErrorMessage = $"PTZコマンドに失敗しました: {ex.Message}";
        }
    }

    /// <summary>
    /// カメラの移動を停止する。
    /// </summary>
    /// <param name="cancellationToken">キャンセルトークン</param>
    public async Task StopMoveAsync(CancellationToken cancellationToken = default)
    {
        if (!IsPtzEnabled)
            return;

        try
        {
            var options = BuildOnvifOptions();
            await _onvifService.StopMoveAsync(options, cancellationToken);
        }
        catch (Exception ex)
        {
            ErrorMessage = $"PTZ 停止コマンドに失敗しました: {ex.Message}";
        }
    }

    /// <summary>
    /// ズームコマンドを送信する。
    /// </summary>
    /// <param name="zoomSpeed">ズーム速度（正値: ズームイン、負値: ズームアウト）</param>
    /// <param name="cancellationToken">キャンセルトークン</param>
    public async Task ZoomAsync(float zoomSpeed, CancellationToken cancellationToken = default)
    {
        if (!IsPtzEnabled)
            return;

        try
        {
            var options = BuildOnvifOptions();
            await _onvifService.ZoomAsync(options, zoomSpeed, cancellationToken);
        }
        catch (Exception ex)
        {
            ErrorMessage = $"PTZ ズームコマンドに失敗しました: {ex.Message}";
        }
    }

    // ─── PTZ 対応能力確認 ─────────────────────────────────────────

    /// <summary>
    /// ONVIF カメラの PTZ 対応能力を確認し、IsPtzEnabled フラグを更新する。
    /// 結果は必ず UI スレッドへディスパッチする。
    /// </summary>
    /// <param name="cancellationToken">キャンセルトークン</param>
    public async Task CheckPtzCapabilitiesAsync(CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(OnvifEndpointUrl))
        {
            DispatchToUiThread(() =>
            {
                IsPtzEnabled = false;
                ErrorMessage = "ONVIF エンドポイント URL が入力されていません。";
            });
            return;
        }

        try
        {
            var options = BuildOnvifOptions();
            var isSupported = await _onvifService.GetPtzCapabilitiesAsync(options, cancellationToken);
            // await 後はスレッドプールスレッドになる可能性があるため UI スレッドへディスパッチ
            DispatchToUiThread(() =>
            {
                IsPtzEnabled = isSupported;
                if (!isSupported)
                    ErrorMessage = "ONVIF: PTZ 非対応（GetCapabilities で PTZ アドレスが見つかりませんでした）";
            });
        }
        catch (OperationCanceledException)
        {
            DispatchToUiThread(() =>
            {
                IsPtzEnabled = false;
                ErrorMessage = "ONVIF: 接続タイムアウト（3秒以内に応答がありませんでした）";
            });
        }
        catch (Exception ex)
        {
            // 実際の例外メッセージをそのまま表示して原因を特定できるようにする
            var inner = ex.InnerException?.Message ?? string.Empty;
            var detail = string.IsNullOrEmpty(inner) ? ex.Message : $"{ex.Message} → {inner}";
            DispatchToUiThread(() =>
            {
                IsPtzEnabled = false;
                ErrorMessage = $"ONVIF エラー: {detail}";
            });
        }
    }

    // ─── 設定読み込み ─────────────────────────────────────────────

    /// <summary>
    /// ペイン設定をプロパティへ反映する。
    /// </summary>
    /// <param name="settings">ペイン設定</param>
    /// <param name="decryptedPassword">復号済み RTSP パスワード</param>
    /// <param name="decryptedOnvifPassword">復号済み ONVIF パスワード</param>
    public void LoadSettings(
        StreamPaneSettings settings,
        string? decryptedPassword,
        string? decryptedOnvifPassword)
    {
        RtspUrl = settings.RtspUrl;
        Username = settings.Username ?? string.Empty;
        Password = decryptedPassword ?? string.Empty;
        Transport = settings.Transport;
        OnvifEndpointUrl = settings.OnvifEndpointUrl ?? string.Empty;
        OnvifUsername = settings.OnvifUsername ?? string.Empty;
        OnvifPassword = decryptedOnvifPassword ?? string.Empty;
    }

    /// <summary>
    /// 現在のプロパティから保存用のペイン設定を構築する。
    /// </summary>
    /// <param name="encryptPassword">パスワード暗号化関数</param>
    /// <returns>保存用ペイン設定</returns>
    public StreamPaneSettings BuildSettings(Func<string, string>? encryptPassword = null)
    {
        string? encryptedPassword = null;
        if (!string.IsNullOrEmpty(Password) && encryptPassword != null)
            encryptedPassword = encryptPassword(Password);

        string? encryptedOnvifPassword = null;
        if (!string.IsNullOrEmpty(OnvifPassword) && encryptPassword != null)
            encryptedOnvifPassword = encryptPassword(OnvifPassword);

        return new StreamPaneSettings(
            RtspUrl: RtspUrl,
            Username: string.IsNullOrEmpty(Username) ? null : Username,
            EncryptedPassword: encryptedPassword,
            Transport: Transport,
            OnvifEndpointUrl: string.IsNullOrEmpty(OnvifEndpointUrl) ? null : OnvifEndpointUrl,
            OnvifUsername: string.IsNullOrEmpty(OnvifUsername) ? null : OnvifUsername,
            OnvifEncryptedPassword: encryptedOnvifPassword);
    }

    // ─── プライベートヘルパー ─────────────────────────────────────

    /// <summary>
    /// 現在のプロパティから RTSP 接続オプションを構築する。
    /// </summary>
    private RtspConnectionOptions BuildConnectionOptions()
    {
        // 空の認証情報は null として扱う（Requirements: 5.5）
        string? username = string.IsNullOrEmpty(Username) ? null : Username;
        string? password = string.IsNullOrEmpty(Password) ? null : Password;

        return new RtspConnectionOptions(
            Url: RtspUrl,
            Username: username,
            Password: password,
            Transport: Transport,
            LowLatencyMode: true);
    }

    /// <summary>
    /// 現在のプロパティから ONVIF 接続オプションを構築する。
    /// </summary>
    private OnvifConnectionOptions BuildOnvifOptions()
    {
        return new OnvifConnectionOptions(
            EndpointUrl: OnvifEndpointUrl,
            Username: OnvifUsername,
            Password: OnvifPassword,
            ProfileToken: null);
    }

    // ─── イベントハンドラー ───────────────────────────────────────

    /// <summary>
    /// RTSP サービスの状態変化イベントを処理する。
    /// バックグラウンドスレッドから発行される場合があるため、UI スレッドへディスパッチする。
    /// </summary>
    private void OnStateChanged(object? sender, StreamStateChangedEventArgs e)
    {
        // UI スレッドへ安全にディスパッチ（Requirements: 6.3）
        DispatchToUiThread(() =>
        {
            ConnectionState = e.State;

            switch (e.State)
            {
                case ConnectionState.Connected:
                    StatusMessage = "接続済み";
                    ErrorMessage = null;
                    // RTSP 接続確立後に PTZ 対応能力を確認する（Requirements: 7.6）
                    _ = CheckPtzCapabilitiesAsync();
                    break;

                case ConnectionState.Connecting:
                    StatusMessage = "接続中...";
                    ErrorMessage = null;
                    break;

                case ConnectionState.Disconnected:
                    StatusMessage = "未接続";
                    IsPtzEnabled = false;
                    break;

                case ConnectionState.Error:
                    StatusMessage = "エラー";
                    if (e.Error.HasValue)
                        ErrorMessage = e.Error.Value.Message;
                    break;
            }
        });
    }

    /// <summary>
    /// 統計情報更新イベントを処理する。
    /// </summary>
    private void OnStatsUpdated(object? sender, ConnectionStats stats)
    {
        // UI スレッドへ安全にディスパッチ
        DispatchToUiThread(() =>
        {
            Stats = stats;
        });
    }

    /// <summary>
    /// ビットマップ更新イベントを処理する。
    /// </summary>
    private void OnBitmapUpdated(object? sender, WriteableBitmap bitmap)
    {
        // BitmapUpdated は IVideoFrameRenderer の実装が UI スレッドで発行する
        VideoFrame = bitmap;
    }

    /// <summary>
    /// UI スレッドへアクションをディスパッチする。
    /// テスト環境では Dispatcher が利用できないため、直接実行する。
    /// </summary>
    private static void DispatchToUiThread(Action action)
    {
        var dispatcher = System.Windows.Application.Current?.Dispatcher;
        if (dispatcher != null && !dispatcher.CheckAccess())
        {
            dispatcher.Invoke(action);
        }
        else
        {
            action();
        }
    }
}
