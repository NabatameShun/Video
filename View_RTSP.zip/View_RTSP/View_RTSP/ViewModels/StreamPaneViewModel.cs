// StreamPaneViewModel の実裁E
// タスク 6.1, 6.2 に対忁E
// Requirements: 1.1, 1.2, 1.4, 1.5, 1.6, 1.7, 2.1, 3.2, 5.2, 5.3, 5.5, 6.3,
//               7.2, 7.3, 7.4, 7.6, 7.8, 8.2, 8.7, 8.8

using System.Diagnostics;
using System.Windows.Media.Imaging;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Sdcb.FFmpeg.Codecs;
using Sdcb.FFmpeg.Raw;
using View_RTSP.Models;
using View_RTSP.Services;

namespace View_RTSP.ViewModels;

/// <summary>
/// 単一映像�Eインの接続�E刁E�E��E�・PTZ・スチE�E�Eタス表示を管琁E�E��E�めEViewModel、E
/// <para>
/// チE�E��E�アルストリーム構�Eの吁E�E�Eインに 1 インスタンス作�Eされる、E
/// バックグラウンドスレチE�E��E�からのイベント�E Dispatcher 経由で UI スレチE�E��E�にチE�E��E�スパッチする、E
/// </para>
/// </summary>
public partial class StreamPaneViewModel : ObservableObject
{
    // ─── 定数 ────────────────────────────────────────────────────
    private const float DefaultPtzSpeed = 0.5f;

    // ─── 依存サービス ─────────────────────────────────────────────
    private readonly IRtspStreamService _rtspService;
    private readonly IVideoFrameRenderer _renderer;
    private readonly IOnvifPtzService _onvifService;
    private readonly ISettingsService _settingsService;
    private readonly IRecordingService? _recordingService;

    // ─── 録画コールバック用フィールチE────────────────────────────
    private CodecParameters? _lastCodecpar;
    private AVRational _lastTimeBase;

    // ─── バインド可能プロパティ ───────────────────────────────────

    /// <summary>RTSP ストリーム URL</summary>
    [ObservableProperty]
    private string _rtspUrl = string.Empty;

    /// <summary>RTSP 認証ユーザー吁E/summary>
    [ObservableProperty]
    private string _username = string.Empty;

    /// <summary>RTSP 認証パスワード（コードビハインドから設定！E/summary>
    [ObservableProperty]
    private string _password = string.Empty;

    /// <summary>現在の接続状慁E/summary>
    [ObservableProperty]
    private ConnectionState _connectionState = ConnectionState.Disconnected;

    /// <summary>スチE�E�EタスメチE�E��E�ージ</summary>
    [ObservableProperty]
    private string _statusMessage = "未接続";

    /// <summary>エラーメチE�E��E�ージ�E�E�E�エラー時�Eみ設定！E/summary>
    [ObservableProperty]
    private string? _errorMessage;

    /// <summary>接続統計情報�E�E�E�フレームレート�E受信フレーム数・稼働時間！E/summary>
    [ObservableProperty]
    private ConnectionStats _stats;

    /// <summary>映像フレーム�E�E�E�EritableBitmap�E�E�E�E/summary>
    [ObservableProperty]
    private WriteableBitmap? _videoFrame;

    /// <summary>
    /// 録画ファイル名に使用するカメララベル（例: "cam1", "cam2"）。
    /// App.xaml.cs でペイン生成時に設定する。
    /// </summary>
    public string CameraLabel { get; set; } = string.Empty;

    /// <summary>デジタルズームレベル（1.0 = 等倍、最大 5.0）</summary>
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(IsZoomed))]
    private double _zoomLevel = 1.0;

    /// <summary>ズーム中かどうか（スライダー表示切替に使用）</summary>
    public bool IsZoomed => _zoomLevel > 1.0;

    /// <summary>十字線（クロスヘア）オーバーレイの表示/非表示</summary>
    [ObservableProperty]
    private bool _showCrosshair = false;

    /// <summary>十字線の表示/非表示をトグルするコマンド。</summary>
    [RelayCommand]
    public void ToggleCrosshair() => ShowCrosshair = !ShowCrosshair;

    /// <summary>PTZ が有効かどぁE�E��E��E�E�E�ENVIF 対応かつ ONVIF 設定済み�E�E�E�E/summary>
    [ObservableProperty]
    private bool _isPtzEnabled;

    /// <summary>ONVIF エンド�EインチEURL</summary>
    [ObservableProperty]
    private string _onvifEndpointUrl = string.Empty;

    /// <summary>ONVIF 認証ユーザー吁E/summary>
    [ObservableProperty]
    private string _onvifUsername = string.Empty;

    /// <summary>ONVIF 認証パスワーチE/summary>
    [ObservableProperty]
    private string _onvifPassword = string.Empty;

    /// <summary>ONVIF プロファイルトークン（省略時は自動取得）</summary>
    [ObservableProperty]
    private string _onvifProfileToken = string.Empty;

    /// <summary>RTSP トランスポ�Eト�Eロトコル</summary>
    [ObservableProperty]
    private RtspTransport _transport = RtspTransport.Tcp;

    // ─── 録画関連プロパティ ─────────────────────────────────────

    /// <summary>録画中かどぁE��</summary>
    [ObservableProperty]
    private bool _isRecording;

    /// <summary>録画経過時間の表示斁E���E�E�侁E "00:05:23"�E�E/summary>
    [ObservableProperty]
    private string _recordingElapsedTime = string.Empty;

    /// <summary>録画保存�Eフォルダパス</summary>
    [ObservableProperty]
    private string _recordingFolderPath = string.Empty;

    // ─── コンストラクター ─────────────────────────────────────────

    /// <summary>
    /// 依存サービスを受け取るコンストラクター�E�後方互換�E�、E
    /// </summary>
    public StreamPaneViewModel(
        IRtspStreamService rtspService,
        IVideoFrameRenderer renderer,
        IOnvifPtzService onvifService,
        ISettingsService settingsService)
        : this(rtspService, renderer, onvifService, settingsService, recordingService: null)
    {
    }

    /// <summary>
    /// 録画サービスを含む依存サービスを受け取るコンストラクター、E
    /// </summary>
    public StreamPaneViewModel(
        IRtspStreamService rtspService,
        IVideoFrameRenderer renderer,
        IOnvifPtzService onvifService,
        ISettingsService settingsService,
        IRecordingService? recordingService)
    {
        _rtspService = rtspService;
        _renderer = renderer;
        _onvifService = onvifService;
        _settingsService = settingsService;
        _recordingService = recordingService;

        // サービスイベントをサブスクライチE
        _rtspService.StateChanged += OnStateChanged;
        _rtspService.StatsUpdated += OnStatsUpdated;
        _renderer.BitmapUpdated += OnBitmapUpdated;

        // 録画サービスイベントをサブスクライチE
        if (_recordingService is not null)
        {
            _recordingService.StateChanged += OnRecordingStateChanged;
            _recordingService.RecordingError += OnRecordingError;
        }
    }

    // ─── プロパティ変更フック ─────────────────────────────────────

    // ─── URL バリチE�E�Eション ───────────────────────────────────────

    /// <summary>
    /// RTSP URL のフォーマットを検証する、E
    /// rtsp:// スキームで始まってぁE�E��E�場合�Eみ有効と判定する、E
    /// </summary>
    /// <returns>URL が有効な場合�E true</returns>
    public bool IsUrlValid()
    {
        if (string.IsNullOrWhiteSpace(RtspUrl))
            return false;

        return RtspUrl.StartsWith("rtsp://", StringComparison.OrdinalIgnoreCase);
    }

    // ─── 接続コマンチE─────────────────────────────────────────────

    /// <summary>
    /// RTSP ストリームへ接続する、E
    /// URL バリチE�E�Eションが失敗した場合�EエラーメチE�E��E�ージを設定して接続を試みなぁE�E��E�E
    /// </summary>
    public async Task ConnectAsync(CancellationToken cancellationToken = default)
    {
        // URL バリチE�E�Eション�E�E�E�Eequirements: 1.4�E�E�E�E
        if (!IsUrlValid())
        {
            ErrorMessage = "Invalid URL. Use rtsp://...";
            return;
        }

        ErrorMessage = null;
        StatusMessage = "接続中...";
        ConnectionState = ConnectionState.Connecting;

        // 認証惁E�E��E�を接続オプションへ絁E�E��E�立て�E�E�E�Eequirements: 5.2, 5.5�E�E�E�E
        var options = BuildConnectionOptions();

        await _rtspService.ConnectAsync(options, cancellationToken);
    }

    /// <summary>
    /// RTSP ストリームを�E断する、E
    /// </summary>
    public void Disconnect()
    {
        _rtspService.Disconnect();
    }

    // ─── 録画コマンチE─────────────────────────────────────────────

    /// <summary>
    /// 録画の開始�E停止をトグルするコマンド、E
    /// </summary>
    [RelayCommand(CanExecute = nameof(CanToggleRecording))]
    public void ToggleRecording()
    {
        if (_recordingService is null) return;

        if (_recordingService.State == RecordingState.Idle)
        {
            // 録画開姁E パケチE��コールバックで取得しぁEcodecpar と timeBase を使用
            var folderPath = string.IsNullOrWhiteSpace(RecordingFolderPath)
                ? AppSettings.Default.RecordingFolderPath
                : RecordingFolderPath;

            _recordingService.Start(folderPath, _lastCodecpar!, _lastTimeBase,
                string.IsNullOrEmpty(CameraLabel) ? null : CameraLabel);
        }
        else if (_recordingService.State == RecordingState.Recording)
        {
            _recordingService.Stop();
        }
    }

    /// <summary>
    /// 録画ボタンの有効/無効を判定する、E
    /// RTSP 接続中かつ録画状態が Idle また�E Recording のとき有効、E
    /// </summary>
    public bool CanToggleRecording()
        => _recordingService is not null
        && (_recordingService.State == RecordingState.Idle
            || _recordingService.State == RecordingState.Recording)
        && (ConnectionState == ConnectionState.Connected
            // 録画中は一時�E断�E�Eonnecting = 再接続中�E�でも停止操作を許可する
            || (ConnectionState == ConnectionState.Connecting
                && _recordingService.State == RecordingState.Recording));

    // ─── スナップショットコマンド ─────────────────────────────────

    /// <summary>
    /// 現在の映像フレームをPNG画像として保存するコマンド。
    /// </summary>
    [RelayCommand(CanExecute = nameof(CanSaveSnapshot))]
    public void SaveSnapshot()
    {
        if (VideoFrame is null) return;

        var folderPath = string.IsNullOrWhiteSpace(RecordingFolderPath)
            ? Environment.GetFolderPath(Environment.SpecialFolder.MyPictures)
            : RecordingFolderPath;

        try
        {
            if (!System.IO.Directory.Exists(folderPath))
                System.IO.Directory.CreateDirectory(folderPath);

            var fileName = $"snapshot_{DateTime.Now:yyyyMMdd_HHmmss}.png";
            var outputPath = System.IO.Path.Combine(folderPath, fileName);

            var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
            encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(VideoFrame));

            using var stream = System.IO.File.OpenWrite(outputPath);
            encoder.Save(stream);

            Trace.WriteLine($"[Snapshot] Saved: {outputPath}");
            ErrorMessage = $"スナップショット保存: {fileName}";
        }
        catch (Exception ex)
        {
            Trace.WriteLine($"[Snapshot] Failed: {ex.Message}");
            ErrorMessage = $"スナップショット保存失敗: {ex.Message}";
        }
    }

    /// <summary>接続済みかつフレームが存在するときのみ有効。</summary>
    public bool CanSaveSnapshot()
        => ConnectionState == ConnectionState.Connected && VideoFrame is not null;

    // ─── PTZ コマンチE─────────────────────────────────────────────

    /// <summary>
    /// 持E�E��E�した方向への連続移動を開始する、E
    /// IsPtzEnabled ぁEfalse の場合�E何もしなぁE�E��E�E
    /// </summary>
    /// <param name="direction">移動方吁E/param>
    /// <param name="cancellationToken">キャンセルト�Eクン</param>
    public async Task StartMoveAsync(PtzDirection direction, CancellationToken cancellationToken = default)
    {
        if (!IsPtzEnabled)
            return;

        try
        {
            var options = BuildOnvifOptions();
            await _onvifService.StartMoveAsync(options, direction, DefaultPtzSpeed, cancellationToken);
        }
        catch (Exception ex) when (IsIgnorablePtzException(ex))
        {
            // Ignore response XML parse errors; command likely applied.
        }
        catch (Exception ex)
        {
            ErrorMessage = $"PTZ command failed: {ex.Message}";
        }
    }

    /// <summary>
    /// カメラの移動を停止する、E
    /// </summary>
    /// <param name="cancellationToken">キャンセルト�Eクン</param>
    public async Task StopMoveAsync(CancellationToken cancellationToken = default)
    {
        if (!IsPtzEnabled)
            return;

        try
        {
            var options = BuildOnvifOptions();
            await _onvifService.StopMoveAsync(options, cancellationToken);
        }
        catch (Exception ex) when (IsIgnorablePtzException(ex))
        {
            // Ignore response XML parse errors; command likely applied.
        }
        catch (Exception ex)
        {
            ErrorMessage = $"PTZ stop command failed: {ex.Message}";
        }
    }

    // PTZ home
    public async Task GoHomeAsync(CancellationToken cancellationToken = default)
    {
        if (!IsPtzEnabled)
            return;

        try
        {
            var options = BuildOnvifOptions();
            await _onvifService.GoHomeAsync(options, cancellationToken);
        }
        catch (Exception ex) when (IsIgnorablePtzException(ex))
        {
            // Ignore response XML parse errors; command likely applied.
        }
        catch (Exception ex)
        {
            ErrorMessage = $"PTZ home command failed: {ex.Message}";
        }
    }

    // PTZ zoom
    public async Task ZoomAsync(float zoomSpeed, CancellationToken cancellationToken = default)
    {
        if (!IsPtzEnabled)
            return;

        try
        {
            var options = BuildOnvifOptions();
            await _onvifService.ZoomAsync(options, zoomSpeed, cancellationToken);
        }
        catch (Exception ex) when (IsIgnorablePtzException(ex))
        {
            // Ignore response XML parse errors; command likely applied.
        }
        catch (Exception ex)
        {
            ErrorMessage = $"PTZ zoom command failed: {ex.Message}";
        }
    }

    // ─── PTZ 対応�E力確誁E─────────────────────────────────────────

    /// <summary>
    /// ONVIF カメラの PTZ 対応�E力を確認し、IsPtzEnabled フラグを更新する、E
    /// 結果は忁E�E��E� UI スレチE�E��E�へチE�E��E�スパッチする、E
    /// </summary>
    /// <param name="cancellationToken">キャンセルト�Eクン</param>
    public async Task CheckPtzCapabilitiesAsync(CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(OnvifEndpointUrl))
        {
            DispatchToUiThread(() =>
            {
                IsPtzEnabled = false;
            });
            return;
        }

        try
        {
            var options = BuildOnvifOptions();
            var isSupported = await _onvifService.GetPtzCapabilitiesAsync(options, cancellationToken);
            // await 後�EスレチE�E��E�プ�EルスレチE�E��E�になる可能性があるためEUI スレチE�E��E�へチE�E��E�スパッチE
            DispatchToUiThread(() =>
            {
                IsPtzEnabled = isSupported;
                if (!isSupported)
                    ErrorMessage = "ONVIF: このカメラは PTZ に対応していません。";
            });
        }
        catch (OperationCanceledException)
        {
            DispatchToUiThread(() =>
            {
                IsPtzEnabled = false;
                ErrorMessage = "ONVIF: 接続タイムアウトしました（3秒）。エンドポイント URL を確認してください。";
            });
        }
        catch (Exception ex)
        {
            // 実際の例外メチE�E��E�ージをそのまま表示して原因を特定できるようにする
            var inner = ex.InnerException?.Message ?? string.Empty;
            var detail = string.IsNullOrEmpty(inner) ? ex.Message : $"{ex.Message} ↁE{inner}";
            DispatchToUiThread(() =>
            {
                IsPtzEnabled = false;
                ErrorMessage = $"ONVIF エラー: {detail}";
            });
        }
    }

    // ─── 設定読み込み ─────────────────────────────────────────────

    /// <summary>
    /// ペイン設定をプロパティへ反映する、E
    /// </summary>
    /// <param name="settings">ペイン設宁E/param>
    /// <param name="decryptedPassword">復号済み RTSP パスワーチE/param>
    /// <param name="decryptedOnvifPassword">復号済み ONVIF パスワーチE/param>
    public void LoadSettings(
        StreamPaneSettings settings,
        string? decryptedPassword,
        string? decryptedOnvifPassword)
    {
        RtspUrl = settings.RtspUrl;
        Username = settings.Username ?? string.Empty;
        Password = decryptedPassword ?? string.Empty;
        Transport = settings.Transport == RtspTransport.Udp ? RtspTransport.Tcp : settings.Transport;
        OnvifEndpointUrl = settings.OnvifEndpointUrl ?? string.Empty;
        OnvifUsername = settings.OnvifUsername ?? string.Empty;
        OnvifPassword = decryptedOnvifPassword ?? string.Empty;
    }

    /// <summary>
    /// 現在のプロパティから保存用のペイン設定を構築する、E
    /// </summary>
    /// <param name="encryptPassword">パスワード暗号化関数</param>
    /// <returns>保存用ペイン設宁E/returns>
    public StreamPaneSettings BuildSettings(Func<string, string>? encryptPassword = null)
    {
        string? encryptedPassword = null;
        if (!string.IsNullOrEmpty(Password) && encryptPassword != null)
            encryptedPassword = encryptPassword(Password);

        string? encryptedOnvifPassword = null;
        if (!string.IsNullOrEmpty(OnvifPassword) && encryptPassword != null)
            encryptedOnvifPassword = encryptPassword(OnvifPassword);

        return new StreamPaneSettings(
            RtspUrl: RtspUrl,
            Username: string.IsNullOrEmpty(Username) ? null : Username,
            EncryptedPassword: encryptedPassword,
            Transport: Transport,
            OnvifEndpointUrl: string.IsNullOrEmpty(OnvifEndpointUrl) ? null : OnvifEndpointUrl,
            OnvifUsername: string.IsNullOrEmpty(OnvifUsername) ? null : OnvifUsername,
            OnvifEncryptedPassword: encryptedOnvifPassword);
    }

    // ─── プライベ�Eト�Eルパ�E ─────────────────────────────────────

    /// <summary>
    /// 現在のプロパティから RTSP 接続オプションを構築する、E
    /// </summary>
    private RtspConnectionOptions BuildConnectionOptions()
    {
        // 空の認証惁E�E��E�は null として扱ぁE�E��E�Eequirements: 5.5�E�E�E�E
        string? username = string.IsNullOrEmpty(Username) ? null : Username;
        string? password = string.IsNullOrEmpty(Password) ? null : Password;

        return new RtspConnectionOptions(
            Url: RtspUrl,
            Username: username,
            Password: password,
            Transport: Transport,
            LowLatencyMode: false);
    }

    /// <summary>
    /// 現在のプロパティから ONVIF 接続オプションを構築する、E
    /// </summary>
    private OnvifConnectionOptions BuildOnvifOptions()
    {
        return new OnvifConnectionOptions(
            EndpointUrl: OnvifEndpointUrl,
            Username: OnvifUsername,
            Password: OnvifPassword,
            ProfileToken: string.IsNullOrWhiteSpace(OnvifProfileToken) ? null : OnvifProfileToken);
    }

    // ─── イベントハンドラー ───────────────────────────────────────

    /// <summary>
    /// RTSP サービスの状態変化イベントを処琁E�E��E�る、E
    /// バックグラウンドスレチE�E��E�から発行される場合があるため、UI スレチE�E��E�へチE�E��E�スパッチする、E
    /// </summary>
    private void OnStateChanged(object? sender, StreamStateChangedEventArgs e)
    {
        // UI スレチE��へ安�EにチE��スパッチE��Eequirements: 6.3�E�E
        DispatchToUiThread(() =>
        {
            ConnectionState = e.State;

            switch (e.State)
            {
                case ConnectionState.Connected:
                    StatusMessage = "接続済み";
                    ErrorMessage = null;
                    // RTSP 接続確立後にパケチE��コールバックを設宁E
                    SetupPacketCallback();
                    // RTSP 接続確立後に PTZ 対応�E力を確認する！Eequirements: 7.6�E�E
                    _ = CheckPtzCapabilitiesAsync();
                    ToggleRecordingCommand.NotifyCanExecuteChanged();
                    SaveSnapshotCommand.NotifyCanExecuteChanged();
                    break;

                case ConnectionState.Connecting:
                    StatusMessage = "接続中...";
                    ErrorMessage = null;
                    // 再接続中も録画停止ボタンの状態を更新
                    ToggleRecordingCommand.NotifyCanExecuteChanged();
                    SaveSnapshotCommand.NotifyCanExecuteChanged();
                    break;

                case ConnectionState.Disconnected:
                    StatusMessage = "未接続";
                    IsPtzEnabled = false;
                    VideoFrame = null;
                    ZoomLevel = 1.0;
                    // RTSP 最終切断時に録画を自動停止（Requirements: 5.1）
                    // Disconnected はリトライ上限到達 or 手動切断でのみ発行される
                    if (_recordingService is not null && _recordingService.State == RecordingState.Recording)
                    {
                        _recordingService.Stop();
                    }
                    ClearPacketCallback();
                    ToggleRecordingCommand.NotifyCanExecuteChanged();
                    SaveSnapshotCommand.NotifyCanExecuteChanged();
                    break;

                case ConnectionState.Error:
                    StatusMessage = "エラー";
                    if (e.Error.HasValue)
                        ErrorMessage = e.Error.Value.Message;
                    break;
            }
        });
    }

    /// <summary>
    /// 統計情報更新イベントを処琁E�E��E�る、E
    /// </summary>
    private void OnStatsUpdated(object? sender, ConnectionStats stats)
    {
        // UI スレチE�E��E�へ安�EにチE�E��E�スパッチE
        DispatchToUiThread(() =>
        {
            Stats = stats;
        });
    }

    /// <summary>
    /// ビット�EチE�E�E更新イベントを処琁E�E��E�る、E
    /// </summary>
    private void OnBitmapUpdated(object? sender, WriteableBitmap bitmap)
    {
        // BitmapUpdated は IVideoFrameRenderer の実裁E�E��E� UI スレチE�E��E�で発行すめE
        var isFirst = VideoFrame is null;
        VideoFrame = bitmap;
        // 最初のフレーム受信時にスナップショットコマンドを有効化
        if (isFirst)
            SaveSnapshotCommand.NotifyCanExecuteChanged();
    }

    // ─── 録画イベントハンドラー ─────────────────────────────────────

    /// <summary>
    /// 録画状態変化イベントを処琁E��る、E
    /// </summary>
    private void OnRecordingStateChanged(object? sender, RecordingState state)
    {
        DispatchToUiThread(() =>
        {
            IsRecording = state == RecordingState.Recording;

            if (state == RecordingState.Idle)
            {
                RecordingElapsedTime = string.Empty;
            }

            ToggleRecordingCommand.NotifyCanExecuteChanged();
        });
    }

    /// <summary>
    /// 録画エラーイベントを処琁E��る、E
    /// </summary>
    private void OnRecordingError(object? sender, RecordingErrorEventArgs e)
    {
        DispatchToUiThread(() =>
        {
            ErrorMessage = e.Message;
        });
    }

    // ─── パケチE��コールバック管琁E─────────────────────────────────

    /// <summary>
    /// RTSP 接続確立後にパケチE��コールバックを設定する、E
    /// </summary>
    private void SetupPacketCallback()
    {
        _rtspService.PacketReceived = (packet, timeBase, codecpar) =>
        {
            // 最新の codecpar と timeBase を保持�E�録画開始時に使用�E�E
            _lastCodecpar = codecpar;
            _lastTimeBase = timeBase;

            // 録画中の場合�EパケチE��を書き込む
            _recordingService?.WritePacket(packet, timeBase);
        };
    }

    /// <summary>
    /// RTSP 刁E��時にパケチE��コールバックを解除する、E
    /// </summary>
    private void ClearPacketCallback()
    {
        _rtspService.PacketReceived = null;
        _lastCodecpar = null;
    }

    /// <summary>
    /// UI スレチE��へアクションをディスパッチする、E
    /// チE��ト環墁E��は Dispatcher が利用できなぁE��め、直接実行する、E
    /// </summary>
    private static void DispatchToUiThread(Action action)
    {
        var dispatcher = System.Windows.Application.Current?.Dispatcher;
        if (dispatcher != null && !dispatcher.CheckAccess())
        {
            dispatcher.Invoke(action);
        }
        else
        {
            action();
        }
    }

    private static bool IsIgnorablePtzException(Exception ex)
    {
        var stack = new Stack<Exception>();
        stack.Push(ex);

        while (stack.Count > 0)
        {
            var current = stack.Pop();

            if (current is AggregateException aggregate)
            {
                foreach (var inner in aggregate.InnerExceptions)
                    stack.Push(inner);
            }

            if (current.InnerException is not null)
                stack.Push(current.InnerException);

            if (current is System.Xml.XmlException)
                return true;

            if (current is System.ServiceModel.CommunicationException
                || current is System.ServiceModel.ProtocolException)
            {
                if (LooksLikeXmlParseMessage(current.Message))
                    return true;
            }

            if (LooksLikeXmlParseMessage(current.Message))
                return true;
        }

        return false;
    }

    private static bool LooksLikeXmlParseMessage(string? message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return false;

        return message.Contains("XML", StringComparison.OrdinalIgnoreCase)
            || message.Contains("�E�l�E�b�E�g�E��E��E�[�E�N�E��E��E��E��E�M�E��E��E��E� XML", StringComparison.Ordinal)
            || message.Contains("�E��E�M�E��E��E��E� XML", StringComparison.Ordinal);
    }
}














