// MainWindow コードビハインド
// タスク 8.3: Closing イベントで MainWindowViewModel.OnClosing() を呼び出す
// Requirements: 4.3, 4.4, 8.1, 8.4, 8.5

using System.ComponentModel;
using System.Windows;
using View_RTSP.ViewModels;

namespace View_RTSP;

/// <summary>
/// メインウィンドウのコードビハインド。
/// Closing イベントで MainWindowViewModel の終了処理を呼び出す。
/// </summary>
public partial class MainWindow : Window
{
    // ─── コンストラクター ─────────────────────────────────────────

    /// <summary>
    /// MainWindow を初期化する。
    /// </summary>
    public MainWindow()
    {
        InitializeComponent();
    }

    // ─── プライベートヘルパー ─────────────────────────────────────

    /// <summary>
    /// DataContext を MainWindowViewModel として取得する。
    /// </summary>
    private MainWindowViewModel? ViewModel => DataContext as MainWindowViewModel;

    // ─── ウィンドウイベントハンドラー ─────────────────────────────

    /// <summary>
    /// ウィンドウ閉じるイベントを処理する。
    /// MainWindowViewModel.OnClosing() を呼び出して両ペインを切断し設定を保存する。
    /// Requirements: 4.3（ウィンドウ閉じる時の切断・終了処理）
    /// </summary>
    private void Window_Closing(object sender, CancelEventArgs e)
    {
        ViewModel?.OnClosing();
    }

    // ─── ツールバーボタンイベントハンドラー ─────────────────────

    /// <summary>
    /// レイアウト切り替えボタンのクリックイベントを処理する。
    /// Requirements: 8.4（左右・上下分割レイアウト選択）
    /// </summary>
    private void ToggleLayoutButton_Click(object sender, RoutedEventArgs e)
    {
        ViewModel?.ToggleLayout();
    }
}
