// MainWindow コードビハインド
// 3ペイン・4タブレイアウト対応
// Requirements: 4.3, 8.1

using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using View_RTSP.ViewModels;

namespace View_RTSP;

/// <summary>
/// メインウィンドウのコードビハインド。
/// Closing イベントで MainWindowViewModel の終了処理を呼び出す。
/// タブ切替の RadioButton クリックイベントを処理する。
/// </summary>
public partial class MainWindow : Window
{
    // ─── コンストラクター ─────────────────────────────────────────

    /// <summary>
    /// MainWindow を初期化する。
    /// </summary>
    public MainWindow()
    {
        InitializeComponent();
    }

    // ─── プライベートヘルパー ─────────────────────────────────────

    /// <summary>
    /// DataContext を MainWindowViewModel として取得する。
    /// </summary>
    private MainWindowViewModel? ViewModel => DataContext as MainWindowViewModel;

    // ─── ウィンドウイベントハンドラー ─────────────────────────────

    /// <summary>
    /// ウィンドウ閉じるイベントを処理する。
    /// MainWindowViewModel.OnClosing() を呼び出して全ペインを切断し設定を保存する。
    /// Requirements: 4.3（ウィンドウ閉じる時の切断・終了処理）
    /// </summary>
    private void Window_Closing(object sender, CancelEventArgs e)
    {
        ViewModel?.OnClosing();
    }

    // ─── タブ切替イベントハンドラー ─────────────────────────────

    /// <summary>
    /// タブ切替 RadioButton のクリックイベントを処理する。
    /// Tag に設定されたインデックス値を ViewModel の SelectedTabIndex に反映する。
    /// </summary>
    private void TabButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is RadioButton rb && rb.Tag is string tag && int.TryParse(tag, out var index))
            if (ViewModel is not null)
                ViewModel.SelectedTabIndex = index;
    }
}
