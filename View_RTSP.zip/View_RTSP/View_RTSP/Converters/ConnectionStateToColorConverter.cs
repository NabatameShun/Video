// タスク 7.2: 接続状態をカラーインジケーター（Brush）に変換する IValueConverter
// 接続中=緑、受信中=青、切断=グレー、エラー=赤

using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using View_RTSP.Models;

namespace View_RTSP.Converters;

/// <summary>
/// <see cref="ConnectionState"/> を UI カラーインジケーター用の <see cref="SolidColorBrush"/> に変換する。
/// <list type="bullet">
///   <item><see cref="ConnectionState.Connected"/> → 緑（#4CAF50）</item>
///   <item><see cref="ConnectionState.Connecting"/> → 青（#0078D4）</item>
///   <item><see cref="ConnectionState.Disconnected"/> → グレー（#888888）</item>
///   <item><see cref="ConnectionState.Error"/> → 赤（#F44336）</item>
/// </list>
/// </summary>
[ValueConversion(typeof(ConnectionState), typeof(SolidColorBrush))]
public sealed class ConnectionStateToColorConverter : IValueConverter
{
    // ─── カラー定数 ────────────────────────────────────────────────────

    /// <summary>接続済み状態のカラー（緑）</summary>
    private static readonly Color ConnectedColor = Color.FromRgb(0x4C, 0xAF, 0x50);

    /// <summary>接続中状態のカラー（Windows アクセントブルー）</summary>
    private static readonly Color ConnectingColor = Color.FromRgb(0x00, 0x78, 0xD4);

    /// <summary>切断状態のカラー（グレー）</summary>
    private static readonly Color DisconnectedColor = Color.FromRgb(0x88, 0x88, 0x88);

    /// <summary>エラー状態のカラー（赤）</summary>
    private static readonly Color ErrorColor = Color.FromRgb(0xF4, 0x43, 0x36);

    // ─── ブラシキャッシュ（Freeze して UI スレッド間で共有可能にする） ──

    private static readonly SolidColorBrush ConnectedBrush = CreateFrozenBrush(ConnectedColor);
    private static readonly SolidColorBrush ConnectingBrush = CreateFrozenBrush(ConnectingColor);
    private static readonly SolidColorBrush DisconnectedBrush = CreateFrozenBrush(DisconnectedColor);
    private static readonly SolidColorBrush ErrorBrush = CreateFrozenBrush(ErrorColor);

    // ─── IValueConverter 実装 ──────────────────────────────────────────

    /// <summary>
    /// <see cref="ConnectionState"/> を対応する <see cref="SolidColorBrush"/> に変換する。
    /// </summary>
    /// <param name="value">変換元の <see cref="ConnectionState"/> 値</param>
    /// <param name="targetType">変換先の型（<see cref="Brush"/> 系を想定）</param>
    /// <param name="parameter">未使用</param>
    /// <param name="culture">未使用</param>
    /// <returns>状態に対応する <see cref="SolidColorBrush"/></returns>
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is ConnectionState state)
        {
            return state switch
            {
                ConnectionState.Connected => ConnectedBrush,
                ConnectionState.Connecting => ConnectingBrush,
                ConnectionState.Disconnected => DisconnectedBrush,
                ConnectionState.Error => ErrorBrush,
                _ => DisconnectedBrush
            };
        }

        // null または予期しない型の場合はグレーを返す
        return DisconnectedBrush;
    }

    /// <summary>
    /// 逆変換はサポートしない（一方向バインディング専用）。
    /// </summary>
    /// <exception cref="NotSupportedException">常にスローされる</exception>
    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        throw new NotSupportedException(
            $"{nameof(ConnectionStateToColorConverter)} は一方向変換専用です。ConvertBack は使用できません。");
    }

    // ─── プライベートヘルパー ──────────────────────────────────────────

    /// <summary>
    /// 指定カラーで Freeze 済みの <see cref="SolidColorBrush"/> を生成する。
    /// </summary>
    private static SolidColorBrush CreateFrozenBrush(Color color)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        return brush;
    }
}
