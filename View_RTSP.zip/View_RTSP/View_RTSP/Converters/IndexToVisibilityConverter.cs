// タブインデックスに基づく Visibility 変換コンバーター
// 選択中のタブインデックスと対象インデックスが一致する場合に Visible を返す

using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace View_RTSP.Converters;

/// <summary>
/// 選択中のタブインデックスと ConverterParameter のインデックスを比較し、
/// 一致すれば Visible、不一致なら Collapsed を返すコンバーター。
/// </summary>
public sealed class IndexToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is int selectedIndex && parameter is string paramStr && int.TryParse(paramStr, out var targetIndex))
            return selectedIndex == targetIndex ? Visibility.Visible : Visibility.Collapsed;
        return Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
