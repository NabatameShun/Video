// ErrorMessage（string?）が非空の場合に Visible、空または null の場合に Collapsed を返すコンバーター

using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace View_RTSP.Converters;

/// <summary>
/// エラーメッセージ文字列を <see cref="Visibility"/> に変換する。
/// 非空文字列 → Visible、null または空文字列 → Collapsed。
/// </summary>
[ValueConversion(typeof(string), typeof(Visibility))]
public sealed class ErrorMessageToVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return value is string message && !string.IsNullOrWhiteSpace(message)
            ? Visibility.Visible
            : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        throw new NotSupportedException();
    }
}
