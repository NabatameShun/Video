// タブインデックスに基づく Boolean 変換コンバーター
// RadioButton の IsChecked バインディングに使用

using System;
using System.Globalization;
using System.Windows.Data;

namespace View_RTSP.Converters;

/// <summary>
/// 選択中のタブインデックスと ConverterParameter のインデックスを比較し、
/// 一致すれば true、不一致なら false を返すコンバーター。
/// </summary>
public sealed class IndexToBoolConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is int selectedIndex && parameter is string paramStr && int.TryParse(paramStr, out var targetIndex))
            return selectedIndex == targetIndex;
        return false;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
