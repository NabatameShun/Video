// タスク 9: グローバル例外ハンドリングサービスの実装
// Requirements: 3.5, 4.5（エラー時のアプリクラッシュ防止・未処理例外のユーザー通知）

namespace View_RTSP.Services;

/// <summary>
/// アプリケーション全体の未処理例外ハンドリングを担うサービス。
/// <para>
/// DispatcherUnhandledException ハンドラーのロジックをテスト可能な形で分離する。
/// 致命的例外（OutOfMemoryException、InsufficientExecutionStackException 等）は
/// アプリケーションの終了を推奨し、通常の例外は継続を許容する。
/// </para>
/// </summary>
public sealed class ApplicationErrorHandler : IApplicationErrorHandler
{
    // 致命的例外の型一覧（継続不可能なシステムレベルの例外）
    private static readonly Type[] FatalExceptionTypes =
    [
        typeof(OutOfMemoryException),
        typeof(InsufficientExecutionStackException),
        typeof(AccessViolationException),
    ];

    /// <inheritdoc/>
    public string FormatUserMessage(Exception exception)
    {
        ArgumentNullException.ThrowIfNull(exception);

        return
            $"予期しないエラーが発生しました。\n\n" +
            $"エラー内容: {exception.Message}\n\n" +
            "「はい」を選択するとアプリケーションを継続します。\n" +
            "「いいえ」を選択するとアプリケーションを終了します。";
    }

    /// <inheritdoc/>
    public bool ShouldTerminate(Exception exception)
    {
        ArgumentNullException.ThrowIfNull(exception);

        var exceptionType = exception.GetType();

        foreach (var fatalType in FatalExceptionTypes)
        {
            if (fatalType.IsAssignableFrom(exceptionType))
                return true;
        }

        return false;
    }
}
