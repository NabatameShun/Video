// Onvif.Core の静的 OnvifClientFactory をラップするアダプター
// タスク 5.1, 5.2: 本番環境で使用する IOnvifClientFactory の実装

using Onvif.Core.Client;
using Onvif.Core.Client.Common;
using Onvif.Core.Client.Device;
using OnvifMediaClientType = Onvif.Core.Client.Media.MediaClient;
using OnvifPtzClientType = Onvif.Core.Client.Ptz.PTZClient;

namespace View_RTSP.Services.OnvifAdapters;

internal static class OnvifResponseParseErrorDetector
{
    public static bool IsResponseParseError(Exception ex)
    {
        if (IsLikelyXmlParseMessage(ex.Message))
            return true;

        for (Exception? current = ex; current is not null; current = current.InnerException)
        {
            if (current is System.Xml.XmlException || current is InvalidOperationException)
                return true;

            if (current is AggregateException aggregate)
            {
                foreach (var inner in aggregate.InnerExceptions)
                {
                    if (IsResponseParseError(inner))
                        return true;
                }
            }

            if (current is System.ServiceModel.CommunicationException
                || current is System.ServiceModel.ProtocolException)
            {
                if (IsLikelyXmlParseMessage(current.Message))
                    return true;
            }
        }

        return false;
    }

    private static bool IsLikelyXmlParseMessage(string? message)
    {
        if (string.IsNullOrWhiteSpace(message))
            return false;

        return message.Contains("XML", StringComparison.OrdinalIgnoreCase)
            || message.Contains("受信した", StringComparison.Ordinal)
            || message.Contains("ネットワークから受信", StringComparison.Ordinal);
    }
}

/// <summary>
/// Onvif.Core の静的 OnvifClientFactory を IOnvifClientFactory にアダプトする実装。
/// 本番コードはこのクラスを使用し、テストコードはモックに差し替える。
/// </summary>
public sealed class OnvifClientFactoryAdapter : IOnvifClientFactory
{
    /// <inheritdoc/>
    public async Task<IOnvifDeviceClient> CreateDeviceClientAsync(
        string host, string username, string password)
    {
        // 空文字列は null に変換する（認証不要デバイスで WS-Security ヘッダーを省略するため）
        var user = string.IsNullOrEmpty(username) ? null : username;
        var pass = string.IsNullOrEmpty(password) ? null : password;
        var client = await OnvifClientFactory.CreateDeviceClientAsync(StripScheme(host), user, pass);
        return new OnvifDeviceClientAdapter(client);
    }

    /// <inheritdoc/>
    public async Task<IOnvifMediaClient> CreateMediaClientAsync(
        string host, string username, string password)
    {
        var user = string.IsNullOrEmpty(username) ? null : username;
        var pass = string.IsNullOrEmpty(password) ? null : password;
        var client = await OnvifClientFactory.CreateMediaClientAsync(StripScheme(host), user, pass);
        return new OnvifMediaClientAdapterImpl(client);
    }

    /// <inheritdoc/>
    public async Task<IOnvifPtzClient> CreatePtzClientAsync(
        string host, string username, string password)
    {
        var user = string.IsNullOrEmpty(username) ? null : username;
        var pass = string.IsNullOrEmpty(password) ? null : password;
        var client = await OnvifClientFactory.CreatePTZClientAsync(StripScheme(host), user, pass);
        return new OnvifPtzClientAdapterImpl(client);
    }

    /// <summary>
    /// Onvif.Core は内部で http:// を付加するため、ユーザー入力から http:// / https:// を除去する。
    /// </summary>
    private static string StripScheme(string url)
    {
        if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
            return url[7..];
        if (url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            return url[8..];
        return url;
    }
}

/// <summary>
/// DeviceClient を IOnvifDeviceClient にアダプトする内部実装
/// </summary>
internal sealed class OnvifDeviceClientAdapter : IOnvifDeviceClient
{
    private readonly DeviceClient _inner;

    public OnvifDeviceClientAdapter(DeviceClient inner)
    {
        _inner = inner;
    }

    /// <inheritdoc/>
    public async Task<OnvifCapabilitiesResult> GetCapabilitiesAsync(CancellationToken ct = default)
    {
        try
        {
            // All カテゴリで取得して PTZ・Media の XAddr も得る
            var response = await _inner.GetCapabilitiesAsync(
                new[] { CapabilityCategory.All });

            // PTZ.XAddr が非空であれば PTZ サポートあり（ONVIF 仕様）
            var hasPtz = response?.Capabilities?.PTZ?.XAddr is { Length: > 0 };

            return new OnvifCapabilitiesResult
            {
                HasPtz = hasPtz,
                PtzXAddr = response?.Capabilities?.PTZ?.XAddr,
                MediaXAddr = response?.Capabilities?.Media?.XAddr,
            };
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // 一部の ONVIF デバイス（仮想カメラ等）は GetCapabilities レスポンスに
            // 非標準 XML を返すことがある。PTZ 非対応と判定する。
            return new OnvifCapabilitiesResult { HasPtz = false };
        }
    }
}

/// <summary>
/// MediaClient を IOnvifMediaClient にアダプトする内部実装
/// </summary>
internal sealed class OnvifMediaClientAdapterImpl : IOnvifMediaClient
{
    private readonly OnvifMediaClientType _inner;

    public OnvifMediaClientAdapterImpl(OnvifMediaClientType inner)
    {
        _inner = inner;
    }

    /// <inheritdoc/>
    public async Task<OnvifProfileInfo[]> GetProfilesAsync(CancellationToken ct = default)
    {
        try
        {
            var response = await _inner.GetProfilesAsync();

            if (response?.Profiles is null || response.Profiles.Length == 0)
                return Array.Empty<OnvifProfileInfo>();

            return response.Profiles
                .Where(p => p?.token is not null)
                .Select(p => new OnvifProfileInfo
                {
                    Token = p.token,
                    Name = p.Name ?? string.Empty
                })
                .ToArray();
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // 一部の ONVIF デバイス（仮想カメラ等）は GetProfiles レスポンスに
            // 非標準 XML を返すことがある。空配列を返す。
            return Array.Empty<OnvifProfileInfo>();
        }
    }
}

/// <summary>
/// PTZClient を IOnvifPtzClient にアダプトする内部実装
/// </summary>
internal sealed class OnvifPtzClientAdapterImpl : IOnvifPtzClient
{
    private readonly OnvifPtzClientType _inner;

    public OnvifPtzClientAdapterImpl(OnvifPtzClientType inner)
    {
        _inner = inner;
    }

    /// <inheritdoc/>
    public async Task ContinuousMoveAsync(
        string profileToken,
        float panSpeed,
        float tiltSpeed,
        float zoomSpeed,
        CancellationToken ct = default)
    {
        try
        {
            var velocity = new PTZSpeed
            {
                PanTilt = new Vector2D { x = panSpeed, y = tiltSpeed },
                Zoom = new Vector1D { x = zoomSpeed }
            };

            await _inner.ContinuousMoveAsync(profileToken, velocity, null);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // 一部の ONVIF デバイス（仮想カメラ等）は ContinuousMove レスポンスに
            // 非標準 XML を返すことがある。コマンド自体は送信済みのため無視する。
        }
    }

    /// <inheritdoc/>
    public async Task StopAsync(string profileToken, CancellationToken ct = default)
    {
        try
        {
            // PanTilt と Zoom の両方を停止する
            await _inner.StopAsync(profileToken, PanTilt: true, Zoom: true);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // 一部の ONVIF デバイス（仮想カメラ等）は Stop レスポンスに
            // 非標準 XML を返すことがある。コマンド自体は送信済みのため無視する。
        }
    }

    /// <inheritdoc/>
    public async Task GoToHomeAsync(string profileToken, CancellationToken ct = default)
    {
        try
        {
            await _inner.GotoHomePositionAsync(profileToken, null);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // 一部の ONVIF デバイス（仮想カメラ等）はレスポンスに
            // 非標準 XML を返すことがある。コマンド自体は送信済みのため無視する。
        }
    }
}
