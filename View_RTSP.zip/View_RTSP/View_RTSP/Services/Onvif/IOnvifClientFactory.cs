// ONVIF クライアントファクトリのインターフェース
// OnvifClientFactory（静的クラス）のラッパー。テスト可能性のために抽象化する。
// タスク 5.1, 5.2: OnvifPtzService の依存性注入用インターフェース

namespace View_RTSP.Services.OnvifAdapters;

/// <summary>
/// ONVIF クライアントを生成するファクトリのインターフェース。
/// Onvif.Core の静的 OnvifClientFactory をラップして DI・テストを可能にする。
/// </summary>
public interface IOnvifClientFactory
{
    /// <summary>
    /// ONVIF デバイスクライアントを非同期で生成する。
    /// </summary>
    /// <param name="host">デバイスエンドポイント URL またはホスト名</param>
    /// <param name="username">認証ユーザー名</param>
    /// <param name="password">認証パスワード</param>
    Task<IOnvifDeviceClient> CreateDeviceClientAsync(
        string host, string username, string password);

    /// <summary>
    /// ONVIF メディアクライアントを非同期で生成する。
    /// </summary>
    Task<IOnvifMediaClient> CreateMediaClientAsync(
        string host, string username, string password);

    /// <summary>
    /// ONVIF PTZ クライアントを非同期で生成する。
    /// </summary>
    Task<IOnvifPtzClient> CreatePtzClientAsync(
        string host, string username, string password);
}

/// <summary>
/// GetCapabilities の結果を保持する値オブジェクト
/// </summary>
public sealed class OnvifCapabilitiesResult
{
    /// <summary>カメラが PTZ をサポートしている場合は true</summary>
    public bool HasPtz { get; init; }

    /// <summary>PTZ サービスの XAddr（例: http://192.168.1.10/onvif/ptz_service）</summary>
    public string? PtzXAddr { get; init; }

    /// <summary>メディアサービスの XAddr（例: http://192.168.1.10/onvif/media_service）</summary>
    public string? MediaXAddr { get; init; }
}

/// <summary>
/// ONVIF プロファイル情報を保持する値オブジェクト
/// </summary>
public sealed class OnvifProfileInfo
{
    /// <summary>プロファイルトークン</summary>
    public required string Token { get; init; }

    /// <summary>プロファイル名</summary>
    public required string Name { get; init; }
}
