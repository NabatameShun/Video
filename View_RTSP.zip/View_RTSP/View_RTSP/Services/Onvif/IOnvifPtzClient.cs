// ONVIF PTZ クライアントのインターフェース
// Onvif.Core の PTZClient をラップして DI・テストを可能にする。
// タスク 5.2: ContinuousMove / Stop / Zoom コマンドを送信する

namespace View_RTSP.Services.OnvifAdapters;

/// <summary>
/// ONVIF PTZ サービスのクライアントインターフェース。
/// ContinuousMove / Stop / Zoom などの PTZ コマンドを抽象化する。
/// </summary>
public interface IOnvifPtzClient
{
    /// <summary>
    /// 指定したプロファイルに対して ContinuousMove コマンドを送信する。
    /// </summary>
    /// <param name="profileToken">対象プロファイルのトークン</param>
    /// <param name="panSpeed">パン速度（-1.0 〜 1.0）</param>
    /// <param name="tiltSpeed">チルト速度（-1.0 〜 1.0）</param>
    /// <param name="zoomSpeed">ズーム速度（-1.0 〜 1.0）</param>
    /// <param name="ct">キャンセルトークン</param>
    Task ContinuousMoveAsync(
        string profileToken,
        float panSpeed,
        float tiltSpeed,
        float zoomSpeed,
        CancellationToken ct = default);

    /// <summary>
    /// 指定したプロファイルに対して Stop コマンドを送信し、カメラの動きを止める。
    /// </summary>
    /// <param name="profileToken">対象プロファイルのトークン</param>
    /// <param name="ct">キャンセルトークン</param>
    Task StopAsync(string profileToken, CancellationToken ct = default);
}
