// ONVIF メディアクライアントのインターフェース
// Onvif.Core の MediaClient をラップして DI・テストを可能にする。
// タスク 5.1: GetProfiles でプロファイルトークンを自動取得する

namespace View_RTSP.Services.OnvifAdapters;

/// <summary>
/// ONVIF メディアサービスのクライアントインターフェース。
/// GetProfiles などメディアプロファイル操作を抽象化する。
/// </summary>
public interface IOnvifMediaClient
{
    /// <summary>
    /// デバイスのメディアプロファイル一覧を取得する。
    /// </summary>
    /// <param name="ct">キャンセルトークン</param>
    /// <returns>プロファイル情報の配列</returns>
    Task<OnvifProfileInfo[]> GetProfilesAsync(CancellationToken ct = default);
}
