// ONVIF デバイスクライアントのインターフェース
// Onvif.Core の DeviceClient をラップして DI・テストを可能にする。
// タスク 5.1: GetCapabilities で PTZ 対応能力を確認する

namespace View_RTSP.Services.OnvifAdapters;

/// <summary>
/// ONVIF デバイスサービスのクライアントインターフェース。
/// GetCapabilities など基本デバイス操作を抽象化する。
/// </summary>
public interface IOnvifDeviceClient
{
    /// <summary>
    /// デバイスの能力情報（PTZ 対応可否を含む）を取得する。
    /// </summary>
    /// <param name="ct">キャンセルトークン</param>
    /// <returns>能力情報の結果オブジェクト</returns>
    Task<OnvifCapabilitiesResult> GetCapabilitiesAsync(CancellationToken ct = default);
}
