// 録画サービスの実装
// タスク 3.1, 3.2, 3.3: 状態管理・シンク、MP4 リミューダックス、パケット書き込み
// Requirements: 1.1, 1.2, 1.5, 2.1, 2.2, 2.3, 2.4, 5.1, 5.2, 5.3

using System;
using System.IO;
using System.Linq;
using Sdcb.FFmpeg.Codecs;
using Sdcb.FFmpeg.Formats;
using Sdcb.FFmpeg.Raw;
using Sdcb.FFmpeg.Utils;
using View_RTSP.Models;

namespace View_RTSP.Services;

/// <summary>
/// RTSP H.264 パケットを MP4 コンテナにリミューダックスしてファイルに書き込む録画サービス。
/// ペイン毎に独立したインスタンスとして使用する。
/// </summary>
public sealed class RecordingService : IRecordingService
{
    private readonly object _stateLock = new();
    private RecordingState _state = RecordingState.Idle;
    private bool _disposed;

    // 録画中のみ有効なフィールド
    private FormatContext? _outputFormatContext;
    private IOContext? _outputIoContext;
    private AVRational _outputTimeBase;
    private string? _tempFilePath;   // 録画中の一時ファイル（fragmented MP4）
    private string? _finalFilePath;  // 停止後のリミューダックス先ファイル

    // タイムスタンプ補正・継続接続時の前フレーム間隔を自動補正。
    private long _ptsOffset = long.MinValue;
    private long _dtsOffset = long.MinValue;
    private long _continuationOffset;       // 複数接続毎との間隔オフセット。(ソースタイムベース)
    private long _prevRawDts = long.MinValue; // 前回パケットの前 DTS。(前フレーム用)
    private long _lastAdjustedDts;           // 最後に調整込みの DTS。(連続性確認用)

    /// <inheritdoc/>
    public RecordingState State => _state;

    /// <inheritdoc/>
    public DateTime? RecordingStartedAtUtc { get; private set; }

    /// <inheritdoc/>
    public event EventHandler<RecordingErrorEventArgs>? RecordingError;

    /// <inheritdoc/>
    public event EventHandler<RecordingState>? StateChanged;

    /// <summary>
    /// 録画ファイル名を生成する。ローカル時刻の yyyyMMdd_HHmmss 形式。
    /// </summary>
    public static string GenerateFileName(DateTime localTime) => GenerateFileName(localTime, null);

    /// <summary>
    /// カメラ名付きの録画ファイル名を生成する。形式: {cameraName}_{yyyyMMdd_HHmmss}.mp4
    /// </summary>
    public static string GenerateFileName(DateTime localTime, string? cameraName)
    {
        var prefix = string.IsNullOrWhiteSpace(cameraName) ? "" : $"{SanitizeForFileName(cameraName)}_";
        return $"{prefix}{localTime:yyyyMMdd_HHmmss}.mp4";
    }

    /// <summary>
    /// ファイル名に使用できない文字をアンダースコアに置換する。
    /// </summary>
    private static string SanitizeForFileName(string name)
    {
        var invalid = System.IO.Path.GetInvalidFileNameChars();
        return string.Concat(name.Select(c => Array.IndexOf(invalid, c) >= 0 ? '_' : c));
    }

    /// <inheritdoc/>
    public bool Start(string outputFolderPath, CodecParameters sourceCodecpar, AVRational sourceTimeBase, string? cameraName = null)
    {
        if (_disposed) return false;

        lock (_stateLock)
        {
            if (_state != RecordingState.Idle)
            {
                AppLogger.Warn($"[RecordingService] Start rejected: current state is {_state}");
                return false;
            }

            // パスのバリデーション
            if (string.IsNullOrWhiteSpace(outputFolderPath))
            {
                RaiseRecordingError(RecordingErrorKind.PermissionDenied, "録画保存先フォルダパスが指定されていません。");
                return false;
            }

            // フォルダの存在確認・作成
            try
            {
                if (!Directory.Exists(outputFolderPath))
                {
                    Directory.CreateDirectory(outputFolderPath);
                    AppLogger.Info($"[RecordingService] Created output directory: {outputFolderPath}");
                }
            }
            catch (Exception ex)
            {
                AppLogger.Error($"[RecordingService] Failed to create directory: {ex.Message}");
                RaiseRecordingError(RecordingErrorKind.DirectoryCreationFailed,
                    $"録画保存先フォルダの作成に失敗しました: {ex.Message}");
                return false;
            }

            // 書き込み権限チェック・テストファイル書き込み
            try
            {
                var testFile = Path.Combine(outputFolderPath, $".write_test_{Guid.NewGuid():N}");
                File.WriteAllText(testFile, "test");
                File.Delete(testFile);
            }
            catch (Exception ex)
            {
                AppLogger.Error($"[RecordingService] Write permission check failed: {ex.Message}");
                RaiseRecordingError(RecordingErrorKind.PermissionDenied,
                    $"録画保存先フォルダへの書き込み権限がありません: {ex.Message}");
                return false;
            }

            // sourceCodecpar の null チェック
            if (sourceCodecpar is null)
            {
                RaiseRecordingError(RecordingErrorKind.DiskWriteError, "ソースコーデックパラメータが指定されていません");
                return false;
            }

            // MP4 出力コンテキストの構成
            // 録画中: 一時ファイル(.tmp.mp4)へ fragmented MP4 で書き込み → クラッシュ耐性
            // 停止時: リミューダックスで通常 MP4(.mp4)へ変換 → WMP でシーク可能
            var fileName = GenerateFileName(DateTime.Now, cameraName);
            _finalFilePath = Path.Combine(outputFolderPath, fileName);
            _tempFilePath = Path.ChangeExtension(_finalFilePath, ".tmp.mp4");

            try
            {
                _outputFormatContext = FormatContext.AllocOutput(formatName: "mp4");
                _outputIoContext = IOContext.Open(_tempFilePath, AVIO_FLAG.Write, null);
                _outputFormatContext.Pb = _outputIoContext;

                // ビデオストリームを追加し、ソースのコーデックパラメータをコピー
                var outStream = _outputFormatContext.NewStream(null);
                outStream.Codecpar!.CopyFrom(sourceCodecpar);
                outStream.TimeBase = sourceTimeBase;
                _outputTimeBase = outStream.TimeBase;

                // fragmented MP4 (frag_keyframe のみ):
                //   - WriteHeader 時に moov ボックスをコーデック情報付きでファイル先頭に書く
                //   - Iフレームごとに moof+mdat フラグメントを逐次書き込む
                //   - 強制終了時: moov は既に書かれており、最後のフラグメントまで再生可能
                //   - empty_moov は使わない: moov が空だと OpenInputUrl 時にコーデック情報が
                //     読めず、停止後のリミューダックスが失敗する
                using var muxerOptions = new MediaDictionary { ["movflags"] = "frag_keyframe" };
                _outputFormatContext.WriteHeader(muxerOptions);

                _ptsOffset = long.MinValue;
                _dtsOffset = long.MinValue;
                _continuationOffset = 0;
                _prevRawDts = long.MinValue;
                _lastAdjustedDts = -1;

                RecordingStartedAtUtc = DateTime.UtcNow;
                _state = RecordingState.Recording;
                RaiseStateChanged(RecordingState.Recording);

                AppLogger.Info($"[RecordingService] Recording started: {_tempFilePath}");
                return true;
            }
            catch (Exception ex)
            {
                AppLogger.Error($"[RecordingService] Failed to start recording: {ex.Message}");
                CleanupOutputContext();
                RaiseRecordingError(RecordingErrorKind.DiskWriteError,
                    $"録画の開始に失敗しました: {ex.Message}");
                return false;
            }
        }
    }

    /// <inheritdoc/>
    public void WritePacket(Packet packet, AVRational sourceTimeBase)
    {
        if (_disposed) return;

        lock (_stateLock)
        {
            if (_state != RecordingState.Recording || _outputFormatContext is null)
                return;

            try
            {
                using var clonedPacket = packet.Clone();
                clonedPacket.StreamIndex = 0;

                // 最初のパケットの PTS/DTS をオフセットとして設定
                if (_ptsOffset == long.MinValue)
                {
                    _ptsOffset = clonedPacket.Pts != ffmpeg.AV_NOPTS_VALUE ? clonedPacket.Pts : 0;
                    _dtsOffset = clonedPacket.Dts != ffmpeg.AV_NOPTS_VALUE ? clonedPacket.Dts : 0;
                }

                long rawDts = clonedPacket.Dts != ffmpeg.AV_NOPTS_VALUE
                    ? clonedPacket.Dts
                    : clonedPacket.Pts;

                if (rawDts != ffmpeg.AV_NOPTS_VALUE)
                {
                    long adjustedDts = (rawDts - _dtsOffset) + _continuationOffset;
                    if (adjustedDts <= _lastAdjustedDts)
                    {
                        _continuationOffset += (_lastAdjustedDts - adjustedDts) + 1;
                        adjustedDts = (rawDts - _dtsOffset) + _continuationOffset;
                    }

                    _lastAdjustedDts = adjustedDts;
                    _prevRawDts = rawDts;
                    clonedPacket.Dts = adjustedDts;
                }

                if (clonedPacket.Pts != ffmpeg.AV_NOPTS_VALUE)
                {
                    long adjustedPts = (clonedPacket.Pts - _ptsOffset) + _continuationOffset;
                    // PTS は DTS 以上でなければならない
                    if (adjustedPts < clonedPacket.Dts)
                        adjustedPts = clonedPacket.Dts;
                    clonedPacket.Pts = adjustedPts;
                }

                clonedPacket.RescaleTimestamp(sourceTimeBase, _outputTimeBase);

                _outputFormatContext.InterleavedWritePacket(clonedPacket);
            }
            catch (Exception ex)
            {
                AppLogger.Error($"[RecordingService] Write packet error: {ex.Message}");
                StopWithError(RecordingErrorKind.DiskWriteError,
                    $"録画中にディスク書き込みエラーが発生しました: {ex.Message}");
            }
        }
    }

    /// <inheritdoc/>
    public void Stop()
    {
        if (_disposed) return;

        string? tempPath;
        string? finalPath;

        lock (_stateLock)
        {
            if (_state != RecordingState.Recording)
                return;

            _state = RecordingState.Stopping;
            RaiseStateChanged(RecordingState.Stopping);

            try
            {
                _outputFormatContext?.WriteTrailer();
                AppLogger.Debug("[RecordingService] WriteTrailer completed");
            }
            catch (Exception ex)
            {
                AppLogger.Warn($"[RecordingService] WriteTrailer error: {ex.Message}");
            }

            tempPath = _tempFilePath;
            finalPath = _finalFilePath;

            CleanupOutputContext();

            RecordingStartedAtUtc = null;
            _state = RecordingState.Idle;
            RaiseStateChanged(RecordingState.Idle);

            AppLogger.Info("[RecordingService] Recording stopped");
        }

        // ロック外でリミューダックス（再エンコードなしの高速コピー）
        // 通常停止時のみ実行: fragmented → シーク可能な通常 MP4 へ変換
        if (tempPath != null && finalPath != null)
            Task.Run(() => RemuxAndCleanup(tempPath, finalPath));
    }

    /// <summary>
    /// エラー発生時に録画を停止する補助メソッド。lock 外から呼び出す。
    /// </summary>
    private void StopWithError(RecordingErrorKind kind, string message)
    {
        _state = RecordingState.Stopping;
        RaiseStateChanged(RecordingState.Stopping);

        try
        {
            _outputFormatContext?.WriteTrailer();
        }
        catch (Exception ex)
        {
            AppLogger.Warn($"[RecordingService] WriteTrailer error during error stop: {ex.Message}");
        }

        CleanupOutputContext();

        RecordingStartedAtUtc = null;
        _state = RecordingState.Idle;
        RaiseStateChanged(RecordingState.Idle);
        RaiseRecordingError(kind, message);
    }

    /// <summary>
    /// 出力コンテキストのリソースを解放する。
    /// </summary>
    private void CleanupOutputContext()
    {
        try { _outputFormatContext?.Dispose(); } catch { }
        try { _outputIoContext?.Dispose(); } catch { }
        _outputFormatContext = null;
        _outputIoContext = null;
        _tempFilePath = null;
        _finalFilePath = null;
        _ptsOffset = long.MinValue;
        _dtsOffset = long.MinValue;
        _continuationOffset = 0;
        _prevRawDts = long.MinValue;
        _lastAdjustedDts = -1;
    }

    /// <summary>
    /// 一時 fragmented MP4 を通常 MP4 へリミューダックスしてシーク可能にする。
    /// 再エンコードなし（ストリームコピー）のため高速。
    /// リミューダックス先は別の一時ファイルに書き出し、成功後にアトミックに置き換える。
    /// 失敗時は元の fragmented MP4 を最終ファイル名に変更して必ず再生可能な状態にする。
    /// </summary>
    private void RemuxAndCleanup(string tempPath, string finalPath)
    {
        // リミューダックス出力先は別の一時ファイルに書く
        // → 失敗時に部分書き込みの finalPath が残る問題を防ぐ
        var remuxTemp = finalPath + ".remux";
        try
        {
            RemuxToSeekableMp4(tempPath, remuxTemp);

            // 成功: アトミックに置き換え
            if (File.Exists(finalPath))
                File.Delete(finalPath);
            File.Move(remuxTemp, finalPath);
            File.Delete(tempPath);
            AppLogger.Info($"[RecordingService] Remux completed: {finalPath}");
        }
        catch (Exception ex)
        {
            AppLogger.Error($"[RecordingService] Remux failed: {ex.Message}");

            // 部分的なリミューダックス出力を必ず削除
            try { if (File.Exists(remuxTemp)) File.Delete(remuxTemp); } catch { }

            // フォールバック: 元の fragmented MP4 を最終ファイル名に変更
            // finalPath が存在しても上書きして確実に有効なファイルを残す
            try
            {
                if (File.Exists(finalPath))
                    File.Delete(finalPath);
                if (File.Exists(tempPath))
                    File.Move(tempPath, finalPath);
            }
            catch (Exception moveEx)
            {
                AppLogger.Warn($"[RecordingService] Fallback rename failed: {moveEx.Message}");
            }

            var inner = ex.InnerException is not null ? $" → {ex.InnerException.Message}" : "";
            RaiseRecordingError(RecordingErrorKind.DiskWriteError,
                $"シーク最適化失敗 [{ex.GetType().Name}]{inner}: {ex.Message}");
        }
    }

    /// <summary>
    /// fragmented MP4 を通常 MP4 へコピーリミューダックスして WMP でシーク可能にする。
    /// moov は末尾に書かれるが、WMP は末尾 moov の標準 MP4 でもシーク可能。
    /// faststart（moov を先頭へ移動）は出力ファイルへのシークが必要なため使用しない。
    /// IOContext の解放順序を明示して FormatContext → IOContext の順に解放する。
    /// </summary>
    private static void RemuxToSeekableMp4(string inputPath, string outputPath)
    {
        using var inputCtx = FormatContext.OpenInputUrl(inputPath, null, null);
        var inStream = inputCtx.Streams[0];

        // outputCtx より先に outputIo が解放されないよう try/finally で順序を制御
        var outputIo = IOContext.Open(outputPath, AVIO_FLAG.Write, null);
        var outputCtx = FormatContext.AllocOutput(formatName: "mp4");
        try
        {
            outputCtx.Pb = outputIo;

            var outStream = outputCtx.NewStream(null);
            outStream.Codecpar!.CopyFrom(inStream.Codecpar!);
            outStream.TimeBase = inStream.TimeBase;

            // movflags なし → 通常 MP4（moov at end）
            // WriteTrailer で完全な moov が書かれてシークインデックスが完成する
            outputCtx.WriteHeader(null);

            foreach (var packet in inputCtx.ReadPackets(0))
            {
                packet.RescaleTimestamp(inStream.TimeBase, outStream.TimeBase);
                outputCtx.InterleavedWritePacket(packet);
            }

            outputCtx.WriteTrailer();
        }
        finally
        {
            // FormatContext を先に解放してから IOContext を解放する
            outputCtx.Dispose();
            outputIo.Dispose();
        }
    }

    /// <summary>
    /// 起動時クリーンアップ: 前回クラッシュ時に残った一時ファイルをバックグラウンドで処理する。
    /// <list type="bullet">
    ///   <item>*.mp4.remux → 削除（リミューダックス途中の中途半端なファイル）</item>
    ///   <item>*.tmp.mp4  → リミューダックスして通常 MP4 へ変換（シーク可能にする）</item>
    /// </list>
    /// </summary>
    public static Task CleanupOrphanedFilesAsync(IEnumerable<string> folderPaths)
    {
        return Task.Run(() =>
        {
            var uniqueFolders = folderPaths
                .Where(p => !string.IsNullOrWhiteSpace(p))
                .Select(p => p.Trim())
                .Where(Directory.Exists)
                .Distinct(StringComparer.OrdinalIgnoreCase);

            foreach (var folder in uniqueFolders)
            {
                // リミューダックス途中で残った部分ファイルを削除
                foreach (var remuxFile in Directory.GetFiles(folder, "*.mp4.remux"))
                {
                    try
                    {
                        File.Delete(remuxFile);
                        AppLogger.Info($"[RecordingService] Deleted orphaned remux temp: {remuxFile}");
                    }
                    catch (Exception ex)
                    {
                        AppLogger.Warn($"[RecordingService] Failed to delete {remuxFile}: {ex.Message}");
                    }
                }

                // クラッシュで残った fragmented MP4 をリミューダックス
                foreach (var tmpFile in Directory.GetFiles(folder, "*.tmp.mp4"))
                {
                    if (!tmpFile.EndsWith(".tmp.mp4", StringComparison.OrdinalIgnoreCase))
                        continue;

                    var finalPath = tmpFile[..^".tmp.mp4".Length] + ".mp4";

                    // 既に最終ファイルが存在する場合は孤立 tmp を削除してスキップ
                    if (File.Exists(finalPath))
                    {
                        try { File.Delete(tmpFile); } catch { }
                        continue;
                    }

                    var remuxTemp = finalPath + ".remux";
                    try
                    {
                        RemuxToSeekableMp4(tmpFile, remuxTemp);
                        if (File.Exists(finalPath)) File.Delete(finalPath);
                        File.Move(remuxTemp, finalPath);
                        File.Delete(tmpFile);
                        AppLogger.Info($"[RecordingService] Crash recovery completed: {finalPath}");
                    }
                    catch (Exception ex)
                    {
                        AppLogger.Warn($"[RecordingService] Crash recovery failed for {tmpFile}: {ex.Message}");
                        try { if (File.Exists(remuxTemp)) File.Delete(remuxTemp); } catch { }
                        // .tmp.mp4 はそのまま残す（ユーザーが手動で確認できる）
                    }
                }
            }
        });
    }

    private void RaiseStateChanged(RecordingState state)
    {
        StateChanged?.Invoke(this, state);
    }

    private void RaiseRecordingError(RecordingErrorKind kind, string message)
    {
        RecordingError?.Invoke(this, new RecordingErrorEventArgs(kind, message));
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;

        lock (_stateLock)
        {
            if (_state == RecordingState.Recording)
            {
                try
                {
                    _outputFormatContext?.WriteTrailer();
                }
                catch { }
            }

            CleanupOutputContext();
            RecordingStartedAtUtc = null;
            _state = RecordingState.Idle;
        }
    }
}
