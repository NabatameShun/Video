// 映像フレーム描画サービスのインターフェース
// タスク 1.3: IVideoFrameRenderer 定義

using System.Windows.Media.Imaging;

namespace View_RTSP.Services;

/// <summary>
/// デコード済み映像フレームを WritableBitmap に描画するサービスのインターフェース
/// </summary>
public interface IVideoFrameRenderer
{
    /// <summary>現在の WritableBitmap（未初期化の場合は null）</summary>
    WriteableBitmap? CurrentBitmap { get; }

    /// <summary>
    /// WritableBitmap が更新されたときに発行されるイベント。
    /// UI スレッドで発行される。
    /// </summary>
    event EventHandler<WriteableBitmap> BitmapUpdated;

    /// <summary>
    /// BGRA フォーマットのフレームデータを描画する。
    /// バックグラウンドスレッドから呼び出し可能。
    /// </summary>
    /// <param name="bgraData">BGRA ピクセルデータ（長さ = width * height * 4）</param>
    /// <param name="width">フレーム幅（ピクセル）</param>
    /// <param name="height">フレーム高さ（ピクセル）</param>
    void RenderFrame(ReadOnlySpan<byte> bgraData, int width, int height);

    /// <summary>
    /// ビットマップをプレースホルダー状態にリセットする。いつでも呼び出し可能。
    /// </summary>
    void Clear();
}
