// ONVIF PTZ サービスの実装
// タスク 5.1: ONVIF 接続と PTZ 対応能力の確認
// タスク 5.2: PTZ コマンド送信（ContinuousMove / Stop / Zoom）
// Requirements: 7.1, 7.2, 7.3, 7.4, 7.6, 7.7, 7.8

using View_RTSP.Models;
using View_RTSP.Services.OnvifAdapters;

namespace View_RTSP.Services;

/// <summary>
/// ONVIF Profile S PTZ コマンドの送信と機能確認を担うサービス実装。
///
/// 設計方針:
/// - Onvif.Core の静的 OnvifClientFactory は IOnvifClientFactory でラップして DI/テストを可能にする
/// - PTZ 対応能力の確認結果とプロファイルトークンをキャッシュし、再接続コストを低減する
/// - GetCapabilities の XAddr を Media/PTZ クライアント生成に使用し、非標準エンドポイントへも対応する
/// - すべてのコマンドは独立したタスクで実行し、RTSP デコードスレッドに影響しない
/// - GetPtzCapabilitiesAsync は OperationCanceledException・XML パースエラーのみ false を返す
///   → 認証エラー（FaultException・MessageSecurityException）は呼び出し元へ伝播してユーザーに通知
/// - StartMoveAsync / StopMoveAsync / ZoomAsync は応答 XML パース失敗を除き例外を呼び出し元に伝播する
/// </summary>
public sealed class OnvifPtzService : IOnvifPtzService, IDisposable
{
    // ─── フィールド ─────────────────────────────────────────────────────

    private readonly IOnvifClientFactory _clientFactory;

    // プロファイルトークン・XAddr のキャッシュ（エンドポイント URL をキーとする）
    // 値: (token, isPtzSupported, ptzXAddr, mediaXAddr)
    private readonly Dictionary<string, (string token, bool isPtzSupported, string ptzXAddr, string mediaXAddr)>
        _profileTokenCache = new();

    // キャッシュの排他制御（非同期処理の競合を防ぐ）
    private readonly SemaphoreSlim _cacheLock = new(1, 1);

    private bool _disposed;

    // ─── コンストラクタ ───────────────────────────────────────────────

    /// <summary>
    /// コンストラクタ（本番用）。OnvifClientFactoryAdapter を使用する
    /// </summary>
    public OnvifPtzService()
        : this(new OnvifClientFactoryAdapter())
    {
    }

    /// <summary>
    /// コンストラクタ（DI / テスト用）。ファクトリを外部から注入する
    /// </summary>
    /// <param name="clientFactory">ONVIF クライアントファクトリ</param>
    public OnvifPtzService(IOnvifClientFactory clientFactory)
    {
        _clientFactory = clientFactory ?? throw new ArgumentNullException(nameof(clientFactory));
    }

    // ─── IOnvifPtzService 実装 ────────────────────────────────────────

    /// <inheritdoc/>
    /// <remarks>
    /// タスク 5.1 対応
    /// - GetCapabilities で PTZ 対応可否・XAddr を確認しキャッシュ
    /// - ProfileToken が未指定の場合は GetProfiles() で最初のプロファイルを自動選択
    /// - タイムアウト・XML パースエラー時は false を返す
    /// - 認証エラー（FaultException・MessageSecurityException）は例外をスローして呼び出し元に通知
    /// </remarks>
    public async Task<bool> GetPtzCapabilitiesAsync(
        OnvifConnectionOptions options,
        CancellationToken ct = default)
    {
        // タイムアウト 3 秒（要件 7.6）
        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeoutCts.CancelAfter(TimeSpan.FromSeconds(3));
        var linkedCt = timeoutCts.Token;

        try
        {
            var deviceClient = await _clientFactory.CreateDeviceClientAsync(
                options.EndpointUrl,
                options.Username,
                options.Password);

            var capabilities = await deviceClient.GetCapabilitiesAsync(linkedCt);

            if (!capabilities.HasPtz)
            {
                await UpdateCacheAsync(options.EndpointUrl, string.Empty, false,
                    string.Empty, string.Empty);
                return false;
            }

            // GetCapabilities の XAddr を使用。取得できない場合はデバイス URL でフォールバック
            var ptzXAddr = !string.IsNullOrEmpty(capabilities.PtzXAddr)
                ? capabilities.PtzXAddr
                : options.EndpointUrl;
            var mediaXAddr = !string.IsNullOrEmpty(capabilities.MediaXAddr)
                ? capabilities.MediaXAddr
                : options.EndpointUrl;

            var profileToken = await ResolveProfileTokenAsync(options, mediaXAddr, linkedCt);

            await UpdateCacheAsync(options.EndpointUrl, profileToken, true, ptzXAddr, mediaXAddr);
            return true;
        }
        catch (OperationCanceledException)
        {
            // タイムアウトまたはキャンセル → false として返す
            return false;
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // 非標準 XML レスポンス → PTZ 非対応と判定
            return false;
        }
        catch (System.ServiceModel.FaultException)
        {
            // SOAP Fault（認証失敗: FailedAuthentication / NotAuthorized など）
            // 呼び出し元へ伝播してユーザーにエラーを通知する
            throw;
        }
        catch (System.ServiceModel.Security.MessageSecurityException)
        {
            // WS-Security トークン検証失敗（認証エラー）
            // 呼び出し元へ伝播してユーザーにエラーを通知する
            throw;
        }
        // その他の例外（ネットワーク障害など）は呼び出し元へ伝播する
    }

    /// <inheritdoc/>
    /// <remarks>
    /// タスク 5.2 対応
    /// - ContinuousMove コマンドを WS-Security UsernameToken 認証付きで送信
    /// - キャッシュした PTZ XAddr を使用して正しいエンドポイントへ接続
    /// </remarks>
    public async Task StartMoveAsync(
        OnvifConnectionOptions options,
        PtzDirection direction,
        float speed,
        CancellationToken ct = default)
    {
        var (panSpeed, tiltSpeed) = CalculatePanTiltSpeed(direction, speed);
        var (profileToken, ptzXAddr) = await GetEffectiveProfileTokenAsync(options, ct);

        var ptzClient = await _clientFactory.CreatePtzClientAsync(
            ptzXAddr,
            options.Username,
            options.Password);

        // ContinuousMove コマンド; レスポンス XML パース失敗は無視
        try
        {
            await ptzClient.ContinuousMoveAsync(profileToken, panSpeed, tiltSpeed, 0f, ct);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // レスポンス XML パースエラーはコマンド送信済みのため無視
        }
    }

    /// <inheritdoc/>
    /// <remarks>
    /// タスク 5.2 対応
    /// - Stop コマンドを送信してカメラの動きを止める
    /// </remarks>
    public async Task StopMoveAsync(
        OnvifConnectionOptions options,
        CancellationToken ct = default)
    {
        var (profileToken, ptzXAddr) = await GetEffectiveProfileTokenAsync(options, ct);

        var ptzClient = await _clientFactory.CreatePtzClientAsync(
            ptzXAddr,
            options.Username,
            options.Password);

        // Stop コマンド; レスポンス XML パース失敗は無視
        try
        {
            await ptzClient.StopAsync(profileToken, ct);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // レスポンス XML パースエラーは無視
        }
    }

    /// <inheritdoc/>
    public async Task GoHomeAsync(
        OnvifConnectionOptions options,
        CancellationToken ct = default)
    {
        var (profileToken, ptzXAddr) = await GetEffectiveProfileTokenAsync(options, ct);

        var ptzClient = await _clientFactory.CreatePtzClientAsync(
            ptzXAddr,
            options.Username,
            options.Password);

        try
        {
            await ptzClient.GoToHomeAsync(profileToken, ct);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // レスポンス XML パースエラーは無視
        }
    }

    /// <inheritdoc/>
    public async Task ZoomAsync(
        OnvifConnectionOptions options,
        float zoomSpeed,
        CancellationToken ct = default)
    {
        var (profileToken, ptzXAddr) = await GetEffectiveProfileTokenAsync(options, ct);

        var ptzClient = await _clientFactory.CreatePtzClientAsync(
            ptzXAddr,
            options.Username,
            options.Password);

        // Zoom with ContinuousMove; レスポンス XML パース失敗は無視
        try
        {
            await ptzClient.ContinuousMoveAsync(profileToken, 0f, 0f, zoomSpeed, ct);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // レスポンス XML パースエラーは無視
        }
    }

    // ─── プライベートメソッド ─────────────────────────────────────────

    /// <summary>
    /// 方向の列挙型からパン・チルト速度成分を算出する。
    /// </summary>
    private static (float pan, float tilt) CalculatePanTiltSpeed(PtzDirection direction, float speed)
    {
        // 斜め方向は 1/√2 ≒ 0.707 でスケールして合成速度が speed を超えないようにする
        const float DiagonalFactor = 0.707f;

        return direction switch
        {
            PtzDirection.Up => (0f, speed),
            PtzDirection.Down => (0f, -speed),
            PtzDirection.Left => (-speed, 0f),
            PtzDirection.Right => (speed, 0f),
            PtzDirection.UpLeft => (-speed * DiagonalFactor, speed * DiagonalFactor),
            PtzDirection.UpRight => (speed * DiagonalFactor, speed * DiagonalFactor),
            PtzDirection.DownLeft => (-speed * DiagonalFactor, -speed * DiagonalFactor),
            PtzDirection.DownRight => (speed * DiagonalFactor, -speed * DiagonalFactor),
            _ => (0f, 0f)
        };
    }

    /// <summary>
    /// 有効なプロファイルトークンと PTZ XAddr を解決する。
    /// - 明示指定済みの場合はそのまま返す
    /// - キャッシュがあればキャッシュから返す
    /// - なければ GetProfiles() で自動取得する
    /// </summary>
    private async Task<(string token, string ptzXAddr)> GetEffectiveProfileTokenAsync(
        OnvifConnectionOptions options,
        CancellationToken ct)
    {
        // 明示的なトークンが指定されている場合はキャッシュを使わず、
        // PTZ XAddr はキャッシュから取得（なければデバイス URL にフォールバック）
        if (!string.IsNullOrEmpty(options.ProfileToken))
        {
            var cachedPtzXAddr = await TryGetCachedPtzXAddrAsync(options.EndpointUrl, ct);
            return (options.ProfileToken, cachedPtzXAddr ?? options.EndpointUrl);
        }

        // キャッシュを確認する
        await _cacheLock.WaitAsync(ct);
        try
        {
            if (_profileTokenCache.TryGetValue(options.EndpointUrl, out var cached)
                && !string.IsNullOrEmpty(cached.token))
            {
                var ptzAddr = !string.IsNullOrEmpty(cached.ptzXAddr)
                    ? cached.ptzXAddr
                    : options.EndpointUrl;
                return (cached.token, ptzAddr);
            }
        }
        finally
        {
            _cacheLock.Release();
        }

        // キャッシュになければ GetProfiles() で取得する（Media XAddr 不明なのでデバイス URL 使用）
        var profileToken = await ResolveProfileTokenAsync(options, options.EndpointUrl, ct);
        return (profileToken, options.EndpointUrl);
    }

    /// <summary>
    /// キャッシュから PTZ XAddr だけを取得する。
    /// </summary>
    private async Task<string?> TryGetCachedPtzXAddrAsync(string endpointUrl, CancellationToken ct)
    {
        await _cacheLock.WaitAsync(ct);
        try
        {
            if (_profileTokenCache.TryGetValue(endpointUrl, out var cached)
                && !string.IsNullOrEmpty(cached.ptzXAddr))
                return cached.ptzXAddr;
            return null;
        }
        finally
        {
            _cacheLock.Release();
        }
    }

    /// <summary>
    /// GetProfiles() を呼び出してプロファイルトークンを取得する。
    /// ProfileToken が指定済みの場合はそのまま返す。
    /// </summary>
    /// <param name="options">接続オプション</param>
    /// <param name="mediaXAddr">メディアサービスのエンドポイント URL</param>
    /// <param name="ct">キャンセルトークン</param>
    private async Task<string> ResolveProfileTokenAsync(
        OnvifConnectionOptions options,
        string mediaXAddr,
        CancellationToken ct)
    {
        if (!string.IsNullOrEmpty(options.ProfileToken))
            return options.ProfileToken;

        var mediaClient = await _clientFactory.CreateMediaClientAsync(
            mediaXAddr,
            options.Username,
            options.Password);

        var profiles = await mediaClient.GetProfilesAsync(ct);

        if (profiles.Length == 0)
            throw new InvalidOperationException(
                $"ONVIF プロファイルが見つかりません: '{mediaXAddr}'");

        return profiles[0].Token;
    }

    /// <summary>
    /// プロファイルトークン・XAddr・PTZ サポート状態をキャッシュに保存する。
    /// </summary>
    private async Task UpdateCacheAsync(
        string endpointUrl,
        string token,
        bool isPtzSupported,
        string ptzXAddr,
        string mediaXAddr)
    {
        await _cacheLock.WaitAsync();
        try
        {
            _profileTokenCache[endpointUrl] = (token, isPtzSupported, ptzXAddr, mediaXAddr);
        }
        finally
        {
            _cacheLock.Release();
        }
    }

    /// <inheritdoc/>
    public void Dispose()
    {
        if (_disposed)
            return;

        _cacheLock.Dispose();
        _disposed = true;
    }
}
