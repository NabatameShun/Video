// ONVIF PTZ サービスの実装
// タスク 5.1: ONVIF 接続と PTZ 対応能力の確認
// タスク 5.2: PTZ コマンド送信（ContinuousMove / Stop / Zoom）
// Requirements: 7.1, 7.2, 7.3, 7.4, 7.6, 7.7, 7.8

using View_RTSP.Models;
using View_RTSP.Services.OnvifAdapters;

namespace View_RTSP.Services;

/// <summary>
/// ONVIF Profile S PTZ コマンドの送信と機能確認を担うサービス実装。
///
/// 設計方針:
/// - Onvif.Core の静的 OnvifClientFactory は IOnvifClientFactory でラップして DI/テストを可能にする
/// - PTZ 対応能力の確認結果とプロファイルトークンをキャッシュし、再接続コストを低減する
/// - すべてのコマンドは独立したタスクで実行し、RTSP デコードスレッドに影響しない
/// - GetPtzCapabilitiesAsync は例外をスローせず false を返す（要件 7.6）
/// - StartMoveAsync / StopMoveAsync / ZoomAsync は応答 XML パース失敗を除き例外を呼び出し元に伝播する（要件 7.8）
/// </summary>
public sealed class OnvifPtzService : IOnvifPtzService, IDisposable
{
    // ─── フィールド ───────────────────────────────────────────────────

    private readonly IOnvifClientFactory _clientFactory;

    // プロファイルトークンのキャッシュ（エンドポイントURLをキーとする）
    // 値: (token, isPtzSupported)
    private readonly Dictionary<string, (string token, bool isPtzSupported)> _profileTokenCache = new();

    // キャッシュの排他制御（非同期処理間の競合を防ぐ）
    private readonly SemaphoreSlim _cacheLock = new(1, 1);

    private bool _disposed;

    // ─── コンストラクタ ───────────────────────────────────────────────

    /// <summary>
    /// コンストラクタ（本番用）: OnvifClientFactoryAdapter を使用する
    /// </summary>
    public OnvifPtzService()
        : this(new OnvifClientFactoryAdapter())
    {
    }

    /// <summary>
    /// コンストラクタ（DI / テスト用）: ファクトリを外部から注入する
    /// </summary>
    /// <param name="clientFactory">ONVIF クライアントファクトリ</param>
    public OnvifPtzService(IOnvifClientFactory clientFactory)
    {
        _clientFactory = clientFactory ?? throw new ArgumentNullException(nameof(clientFactory));
    }

    // ─── IOnvifPtzService 実装 ────────────────────────────────────────

    /// <inheritdoc/>
    /// <remarks>
    /// タスク 5.1 対応:
    /// - GetCapabilities で PTZ 対応可否を確認し結果をキャッシュ
    /// - ProfileToken が未指定の場合は GetProfiles() で最初のプロファイルを自動選択
    /// - 接続失敗・タイムアウト時は例外をスローせず false を返す
    /// </remarks>
    public async Task<bool> GetPtzCapabilitiesAsync(
        OnvifConnectionOptions options,
        CancellationToken ct = default)
    {
        try
        {
            // タイムアウト 3 秒（要件 7.6）
            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeoutCts.CancelAfter(TimeSpan.FromSeconds(3));
            var linkedCt = timeoutCts.Token;

            // デバイスクライアントを生成して PTZ 能力を確認する
            var deviceClient = await _clientFactory.CreateDeviceClientAsync(
                options.EndpointUrl,
                options.Username,
                options.Password);

            var capabilities = await deviceClient.GetCapabilitiesAsync(linkedCt);

            if (!capabilities.HasPtz)
            {
                await UpdateCacheAsync(options.EndpointUrl, string.Empty, false);
                return false;
            }

            // プロファイルトークンを決定する
            var profileToken = await ResolveProfileTokenAsync(options, linkedCt);

            await UpdateCacheAsync(options.EndpointUrl, profileToken, true);
            return true;
        }
        catch (OperationCanceledException)
        {
            // タイムアウト・キャンセルは false として返す
            return false;
        }
        // その他の例外（接続エラー・認証失敗・SOAP エラー等）は呼び出し元へ伝播させて
        // ユーザーに原因を通知できるようにする
    }

    /// <inheritdoc/>
    /// <remarks>
    /// タスク 5.2 対応:
    /// - ContinuousMove コマンドを WS-Security UsernameToken 認証付きで送信
    /// - 独立したタスクで実行してデコードスレッドに影響しない
    /// - コマンド失敗時は例外を呼び出し元へ伝達（ストリーム表示は ViewModel 側で継続）
    /// </remarks>
    public async Task StartMoveAsync(
        OnvifConnectionOptions options,
        PtzDirection direction,
        float speed,
        CancellationToken ct = default)
    {
        var (panSpeed, tiltSpeed) = CalculatePanTiltSpeed(direction, speed);
        var profileToken = await GetEffectiveProfileTokenAsync(options, ct);

        var ptzClient = await _clientFactory.CreatePtzClientAsync(
            options.EndpointUrl,
            options.Username,
            options.Password);

        // ContinuousMove コマンドを送信（例外は呼び出し元に伝播する）
        try
        {
            await ptzClient.ContinuousMoveAsync(profileToken, panSpeed, tiltSpeed, 0f, ct);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // 応答 XML のパース失敗はコマンド送信済みとみなし無視する
        }
    }

    /// <inheritdoc/>
    /// <remarks>
    /// タスク 5.2 対応:
    /// - Stop コマンドを送信してカメラの動きを止める
    /// - コマンド失敗時は例外を呼び出し元へ伝達
    /// </remarks>
    public async Task StopMoveAsync(
        OnvifConnectionOptions options,
        CancellationToken ct = default)
    {
        var profileToken = await GetEffectiveProfileTokenAsync(options, ct);

        var ptzClient = await _clientFactory.CreatePtzClientAsync(
            options.EndpointUrl,
            options.Username,
            options.Password);

        // Stop コマンドを送信（例外は呼び出し元に伝播する）
        try
        {
            await ptzClient.StopAsync(profileToken, ct);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // 応答 XML のパース失敗はコマンド送信済みとみなし無視する
        }
    }

    /// <inheritdoc/>
    /// <remarks>
    /// タスク 5.2 対応:
    /// - ズームイン（正値）/ ズームアウト（負値）コマンドを送信
    /// - パン・チルトは 0（ズームのみ）
    /// - コマンド失敗時は例外を呼び出し元へ伝達
    /// </remarks>
    public async Task ZoomAsync(
        OnvifConnectionOptions options,
        float zoomSpeed,
        CancellationToken ct = default)
    {
        var profileToken = await GetEffectiveProfileTokenAsync(options, ct);

        var ptzClient = await _clientFactory.CreatePtzClientAsync(
            options.EndpointUrl,
            options.Username,
            options.Password);

        // ズームのみ（パン・チルトは 0）の ContinuousMove コマンドを送信
        try
        {
            await ptzClient.ContinuousMoveAsync(profileToken, 0f, 0f, zoomSpeed, ct);
        }
        catch (Exception ex) when (OnvifResponseParseErrorDetector.IsResponseParseError(ex))
        {
            // 応答 XML のパース失敗はコマンド送信済みとみなし無視する
        }
    }

    // ─── プライベートメソッド ─────────────────────────────────────────

    /// <summary>
    /// 方向列挙型からパン・チルト速度成分を算出する。
    /// </summary>
    /// <param name="direction">移動方向</param>
    /// <param name="speed">基本速度（0.0 〜 1.0）</param>
    /// <returns>(panSpeed, tiltSpeed) タプル</returns>
    private static (float pan, float tilt) CalculatePanTiltSpeed(PtzDirection direction, float speed)
    {
        // 斜め方向は 1/√2 ≈ 0.707 でスケールして合成速度が speed を超えないようにする
        const float DiagonalFactor = 0.707f;

        return direction switch
        {
            PtzDirection.Up => (0f, speed),
            PtzDirection.Down => (0f, -speed),
            PtzDirection.Left => (-speed, 0f),
            PtzDirection.Right => (speed, 0f),
            PtzDirection.UpLeft => (-speed * DiagonalFactor, speed * DiagonalFactor),
            PtzDirection.UpRight => (speed * DiagonalFactor, speed * DiagonalFactor),
            PtzDirection.DownLeft => (-speed * DiagonalFactor, -speed * DiagonalFactor),
            PtzDirection.DownRight => (speed * DiagonalFactor, -speed * DiagonalFactor),
            _ => (0f, 0f)
        };
    }

    /// <summary>
    /// オプションのプロファイルトークンを解決する。
    /// - 指定済みの場合はそのまま返す
    /// - null の場合はキャッシュを確認し、なければ GetProfiles() で自動取得する
    /// </summary>
    private async Task<string> GetEffectiveProfileTokenAsync(
        OnvifConnectionOptions options,
        CancellationToken ct)
    {
        // 明示的にトークンが指定されている場合はそのまま使用
        if (!string.IsNullOrEmpty(options.ProfileToken))
            return options.ProfileToken;

        // キャッシュを確認する
        await _cacheLock.WaitAsync(ct);
        try
        {
            if (_profileTokenCache.TryGetValue(options.EndpointUrl, out var cached)
                && !string.IsNullOrEmpty(cached.token))
            {
                return cached.token;
            }
        }
        finally
        {
            _cacheLock.Release();
        }

        // キャッシュになければ GetProfiles() で取得する
        return await ResolveProfileTokenAsync(options, ct);
    }

    /// <summary>
    /// GetProfiles() を呼び出してプロファイルトークンを取得する。
    /// ProfileToken が指定済みの場合はそのまま返す。
    /// </summary>
    private async Task<string> ResolveProfileTokenAsync(
        OnvifConnectionOptions options,
        CancellationToken ct)
    {
        if (!string.IsNullOrEmpty(options.ProfileToken))
            return options.ProfileToken;

        var mediaClient = await _clientFactory.CreateMediaClientAsync(
            options.EndpointUrl,
            options.Username,
            options.Password);

        var profiles = await mediaClient.GetProfilesAsync(ct);

        // 最初のプロファイルのトークンを使用する（ONVIF 仕様: 少なくとも 1 つのプロファイルが存在）
        if (profiles.Length == 0)
            throw new InvalidOperationException(
                $"ONVIF デバイス '{options.EndpointUrl}' にプロファイルが見つかりませんでした。");

        return profiles[0].Token;
    }

    /// <summary>
    /// プロファイルトークンと PTZ サポート状態をキャッシュに保存する。
    /// </summary>
    private async Task UpdateCacheAsync(string endpointUrl, string token, bool isPtzSupported)
    {
        await _cacheLock.WaitAsync();
        try
        {
            _profileTokenCache[endpointUrl] = (token, isPtzSupported);
        }
        finally
        {
            _cacheLock.Release();
        }
    }

    /// <inheritdoc/>
    public void Dispose()
    {
        if (_disposed)
            return;

        _cacheLock.Dispose();
        _disposed = true;
    }
}
