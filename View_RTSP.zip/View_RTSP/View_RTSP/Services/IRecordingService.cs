// 録画サービスのインターフェース
// タスク 3.1: IRecordingService 定義
// Requirements: 1.1, 1.2, 1.5, 2.1, 5.1, 5.2, 5.3

using Sdcb.FFmpeg.Codecs;
using Sdcb.FFmpeg.Raw;
using View_RTSP.Models;

namespace View_RTSP.Services;

/// <summary>
/// RTSP ストリームの録画サービスインターフェース。
/// ペインごとに独立したインスタンスとして DI で組み立てる。
/// </summary>
public interface IRecordingService : IDisposable
{
    /// <summary>現在の録画状態</summary>
    RecordingState State { get; }

    /// <summary>録画開始日時（UTC）。Idle 状態では null</summary>
    DateTime? RecordingStartedAtUtc { get; }

    /// <summary>録画エラー発生時に発行されるイベント</summary>
    event EventHandler<RecordingErrorEventArgs> RecordingError;

    /// <summary>録画状態が変化したときに発行されるイベント</summary>
    event EventHandler<RecordingState> StateChanged;

    /// <summary>
    /// 録画を開始する。
    /// </summary>
    /// <param name="outputFolderPath">録画ファイルの保存先フォルダパス</param>
    /// <param name="sourceCodecpar">ソースストリームのコーデックパラメータ</param>
    /// <param name="sourceTimeBase">ソースストリームのタイムベース</param>
    /// <param name="cameraName">ファイル名に付与するカメラ名（省略可）</param>
    /// <returns>開始に成功した場合 true</returns>
    bool Start(string outputFolderPath, CodecParameters sourceCodecpar, AVRational sourceTimeBase, string? cameraName = null);

    /// <summary>
    /// 録画を停止し、MP4 ファイルを正常にクローズする。
    /// </summary>
    void Stop();

    /// <summary>
    /// パケットを録画ファイルに書き込む。RtspStreamService のコールバックから呼ばれる。
    /// </summary>
    /// <param name="packet">書き込むパケット（コールバック内でのみ有効）</param>
    /// <param name="sourceTimeBase">ソースストリームのタイムベース</param>
    void WritePacket(Packet packet, AVRational sourceTimeBase);
}
