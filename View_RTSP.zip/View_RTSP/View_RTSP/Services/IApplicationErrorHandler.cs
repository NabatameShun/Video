// タスク 9: グローバル例外ハンドリングサービスのインターフェース定義
// Requirements: 3.5, 4.5（エラー時のアプリクラッシュ防止・未処理例外のユーザー通知）

namespace View_RTSP.Services;

/// <summary>
/// アプリケーション全体の未処理例外ハンドリングを担うサービスのインターフェース。
/// DispatcherUnhandledException ハンドラーから呼び出し、ユーザーへの通知メッセージ生成および
/// 致命的例外の判定ロジックをテスト可能な形で分離する。
/// </summary>
public interface IApplicationErrorHandler
{
    /// <summary>
    /// 例外をユーザー向けのダイアログメッセージ文字列にフォーマットする。
    /// </summary>
    /// <param name="exception">発生した例外</param>
    /// <returns>ユーザーへ表示するメッセージ</returns>
    string FormatUserMessage(Exception exception);

    /// <summary>
    /// 例外の種別に基づき、アプリケーションを終了すべきかどうかを判定する。
    /// OutOfMemoryException や InsufficientExecutionStackException のような
    /// 致命的例外の場合は true を返す。
    /// </summary>
    /// <param name="exception">発生した例外</param>
    /// <returns>終了すべき場合 true、継続可能な場合 false</returns>
    bool ShouldTerminate(Exception exception);
}
