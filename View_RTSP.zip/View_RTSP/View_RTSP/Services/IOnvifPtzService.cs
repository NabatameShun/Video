// ONVIF PTZ サービスのインターフェース
// タスク 1.3: IOnvifPtzService 定義

using View_RTSP.Models;

namespace View_RTSP.Services;

/// <summary>
/// ONVIF Profile S PTZ コマンドの送信・能力確認サービスのインターフェース
/// </summary>
public interface IOnvifPtzService
{
    /// <summary>
    /// カメラの PTZ 対応能力を確認する。
    /// タイムアウト（3 秒）または接続失敗時は例外をスローせず false を返す。
    /// </summary>
    /// <param name="options">ONVIF 接続オプション</param>
    /// <param name="ct">キャンセルトークン</param>
    /// <returns>PTZ が対応している場合は true</returns>
    Task<bool> GetPtzCapabilitiesAsync(OnvifConnectionOptions options, CancellationToken ct = default);

    /// <summary>
    /// 指定した方向への連続移動（ContinuousMove）を開始する。
    /// </summary>
    /// <param name="options">ONVIF 接続オプション</param>
    /// <param name="direction">移動方向</param>
    /// <param name="speed">移動速度（0.0 〜 1.0）</param>
    /// <param name="ct">キャンセルトークン</param>
    Task StartMoveAsync(
        OnvifConnectionOptions options,
        PtzDirection direction,
        float speed,
        CancellationToken ct = default);

    /// <summary>
    /// カメラの移動を停止する（Stop コマンド）。
    /// </summary>
    /// <param name="options">ONVIF 接続オプション</param>
    /// <param name="ct">キャンセルトークン</param>
    Task StopMoveAsync(OnvifConnectionOptions options, CancellationToken ct = default);

    /// <summary>
    /// ズームイン / アウトコマンドを送信する。
    /// </summary>
    /// <param name="options">ONVIF 接続オプション</param>
    /// <param name="zoomSpeed">ズーム速度（正値: ズームイン、負値: ズームアウト）</param>
    /// <param name="ct">キャンセルトークン</param>
    Task ZoomAsync(
        OnvifConnectionOptions options,
        float zoomSpeed,
        CancellationToken ct = default);
}
