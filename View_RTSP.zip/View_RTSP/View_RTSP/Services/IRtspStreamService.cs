// RTSP ストリームサービスのインターフェース
// タスク 1.3: IRtspStreamService 定義

using View_RTSP.Models;

namespace View_RTSP.Services;

/// <summary>
/// RTSP ストリームの接続・デコード・フレーム配信サービスのインターフェース
/// </summary>
public interface IRtspStreamService : IDisposable
{
    /// <summary>現在の接続状態</summary>
    ConnectionState State { get; }

    /// <summary>
    /// 接続状態が変化したときに発行されるイベント。
    /// バックグラウンドスレッドから発行される場合があるため、
    /// ハンドラ内で UI 操作を行う場合は Dispatcher 経由でディスパッチすること。
    /// </summary>
    event EventHandler<StreamStateChangedEventArgs> StateChanged;

    /// <summary>
    /// 接続統計情報が更新されたときに発行されるイベント（1 秒ごと）。
    /// バックグラウンドスレッドから発行される場合がある。
    /// </summary>
    event EventHandler<ConnectionStats> StatsUpdated;

    /// <summary>
    /// 指定した接続オプションで RTSP ストリームへの接続を開始する。
    /// </summary>
    /// <param name="options">RTSP 接続オプション</param>
    /// <param name="cancellationToken">キャンセルトークン</param>
    Task ConnectAsync(RtspConnectionOptions options, CancellationToken cancellationToken = default);

    /// <summary>
    /// RTSP ストリームを切断する。どの状態からでも安全に呼び出せる（冪等）。
    /// </summary>
    void Disconnect();
}
