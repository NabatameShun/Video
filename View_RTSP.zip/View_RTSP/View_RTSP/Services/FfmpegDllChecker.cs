// タスク 9: FFmpeg ネイティブ DLL 存在チェックサービスの実装
// Requirements: 4.2（起動時の FFmpeg DLL 存在チェックと早期フェイル）

using System.IO;

namespace View_RTSP.Services;

/// <summary>
/// FFmpeg ネイティブ DLL の存在確認を行うサービス。
/// <para>
/// Sdcb.FFmpeg.runtime.windows-x64 パッケージが提供する DLL
/// （avcodec-*.dll、avformat-*.dll、avutil-*.dll、swscale-*.dll）が
/// アプリケーションディレクトリに存在するかどうかを検査する。
/// </para>
/// </summary>
public sealed class FfmpegDllChecker : IFfmpegDllChecker
{
    // すべての必須 DLL パターン（GetMissingDlls で使用）
    private static readonly string[] RequiredDllPatterns =
    [
        "avcodec-*.dll",
        "avformat-*.dll",
        "avutil-*.dll",
        "swscale-*.dll",
    ];

    // FFmpeg が利用可能かどうかを判定するコア DLL パターン（いずれか 1 つ以上の存在で OK）
    private static readonly string[] CoreDllPatterns =
    [
        "avcodec-*.dll",
        "avformat-*.dll",
    ];

    private readonly string _searchDirectory;

    /// <summary>
    /// デフォルトコンストラクター。アプリケーション実行ディレクトリで DLL を検索する。
    /// </summary>
    public FfmpegDllChecker()
        : this(AppContext.BaseDirectory)
    {
    }

    /// <summary>
    /// テスト用コンストラクター。検索ディレクトリを指定する。
    /// </summary>
    /// <param name="searchDirectory">DLL を検索するディレクトリパス</param>
    public FfmpegDllChecker(string searchDirectory)
    {
        _searchDirectory = searchDirectory;
    }

    /// <inheritdoc/>
    public bool CheckDllsExist()
    {
        // コア DLL（avcodec または avformat）のいずれか 1 つ以上が存在すれば OK とみなす
        foreach (var pattern in CoreDllPatterns)
        {
            var matches = Directory.GetFiles(_searchDirectory, pattern, SearchOption.TopDirectoryOnly);
            if (matches.Length > 0)
                return true;
        }

        return false;
    }

    /// <inheritdoc/>
    public IReadOnlyList<string> GetMissingDlls()
    {
        var missing = new List<string>();

        foreach (var pattern in RequiredDllPatterns)
        {
            var matches = Directory.GetFiles(_searchDirectory, pattern, SearchOption.TopDirectoryOnly);
            if (matches.Length == 0)
            {
                missing.Add(pattern);
            }
        }

        return missing.AsReadOnly();
    }

    /// <inheritdoc/>
    public string GetErrorMessage()
    {
        var missing = GetMissingDlls();

        if (missing.Count == 0)
            return string.Empty;

        var missingList = string.Join("\n  - ", missing);

        return
            $"FFmpeg ネイティブ DLL が見つかりません。\n\n" +
            $"以下の DLL パターンが存在しません:\n  - {missingList}\n\n" +
            "アプリケーションを実行するには、Sdcb.FFmpeg.runtime.windows-x64 パッケージの\n" +
            "ネイティブ DLL がアプリケーションディレクトリに配置されている必要があります。\n\n" +
            $"検索ディレクトリ: {_searchDirectory}";
    }
}
