// 設定永続化サービスのインターフェース
// タスク 1.3: ISettingsService 定義

using View_RTSP.Models;

namespace View_RTSP.Services;

/// <summary>
/// 接続設定の永続化・読み込みサービスのインターフェース
/// </summary>
public interface ISettingsService
{
    /// <summary>
    /// 設定ファイルから <see cref="AppSettings"/> を読み込む。
    /// ファイルが存在しない場合はデフォルト値を返す。
    /// ファイルが破損している場合はデフォルト値にフォールバックする。
    /// </summary>
    /// <returns>読み込んだ設定またはデフォルト設定</returns>
    AppSettings Load();

    /// <summary>
    /// <see cref="AppSettings"/> を設定ファイルに保存する。
    /// </summary>
    /// <param name="settings">保存する設定</param>
    void Save(AppSettings settings);
}
