// タスク 9: FFmpeg ネイティブ DLL 存在チェックサービスのインターフェース定義
// Requirements: 4.2（起動時の FFmpeg DLL 存在チェックと早期フェイル）

namespace View_RTSP.Services;

/// <summary>
/// FFmpeg ネイティブ DLL の存在確認を行うサービスのインターフェース。
/// アプリ起動時に avcodec / avformat 等の必須 DLL が存在するかどうかを検査し、
/// 欠如している場合は早期に明確なエラーメッセージを提供する。
/// </summary>
public interface IFfmpegDllChecker
{
    /// <summary>
    /// 必要な FFmpeg ネイティブ DLL がすべて存在するかどうかを確認する。
    /// </summary>
    /// <returns>すべての必須 DLL が存在する場合 true、1 つでも欠如している場合 false</returns>
    bool CheckDllsExist();

    /// <summary>
    /// 存在しない DLL パターン名のリストを返す。
    /// </summary>
    /// <returns>欠如している DLL のパターン名一覧</returns>
    IReadOnlyList<string> GetMissingDlls();

    /// <summary>
    /// DLL 欠如時のユーザー向けエラーメッセージを生成する。
    /// </summary>
    /// <returns>FFmpeg DLL の欠如を説明するメッセージ</returns>
    string GetErrorMessage();
}
