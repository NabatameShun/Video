// タイムスタンプ付きファイルトレースリスナー

using System.Diagnostics;
using System.IO;
using System.Text;

namespace View_RTSP.Services;

/// <summary>
/// 各ログ行に "yyyy-MM-dd HH:mm:ss.fff" タイムスタンプを付与してファイルへ書き込む
/// TraceListener 実装。スレッドセーフ（lock で保護）。
/// </summary>
public sealed class TimestampedFileTraceListener : TraceListener
{
    private readonly StreamWriter _writer;
    private readonly object _lock = new();

    /// <summary>
    /// 指定パスにログファイルを開く（追記モード、UTF-8 BOM なし）。
    /// </summary>
    public TimestampedFileTraceListener(string filePath)
        : base(filePath)
    {
        var dir = Path.GetDirectoryName(filePath);
        if (!string.IsNullOrEmpty(dir))
            Directory.CreateDirectory(dir);

        _writer = new StreamWriter(filePath, append: true, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false))
        {
            AutoFlush = true
        };
    }

    public override void Write(string? message)
    {
        // WriteLine から呼ばれる場合のみ使用するため、ここでは何もしない
        // （WriteLine で改行込みの完全な行を書く）
    }

    public override void WriteLine(string? message)
    {
        if (message is null)
            return;

        lock (_lock)
        {
            _writer.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} {message}");
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
            _writer.Dispose();
        base.Dispose(disposing);
    }
}
