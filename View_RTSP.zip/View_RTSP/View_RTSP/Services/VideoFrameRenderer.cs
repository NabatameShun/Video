// 映像フレーム描画サービスの実装
// タスク 3: VideoFrameRenderer
// Requirements: 2.1, 2.3, 6.2, 6.4, 9.5, 9.7

using System.Runtime.InteropServices;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace View_RTSP.Services;

/// <summary>
/// デコード済み BGRA フレームを WritableBitmap に描画するサービス。
/// <para>
/// - WritableBitmap を所有し、解像度変更時のみ再生成する（GC 負荷軽減）。
/// - バックグラウンドスレッドからフレームデータを受け取り、Dispatcher 経由で UI スレッドへ書き込む。
/// - ピン留めした byte[] バックバッファを再利用し、フレームごとの GC アロケーションを最小化する。
/// - UI スレッドが描画に追いつかない場合は古いフレームをスキップし、最新フレームのみ描画する。
/// </para>
/// </summary>
public sealed class VideoFrameRenderer : IVideoFrameRenderer, IDisposable
{
    // ─── フィールド ─────────────────────────────────────────────

    private readonly Dispatcher _dispatcher;

    /// <summary>現在の WritableBitmap（未初期化の場合は null）</summary>
    private WriteableBitmap? _bitmap;

    /// <summary>ピン留めされたバックバッファ（GC 移動防止・再利用）</summary>
    private byte[]? _backBuffer;

    /// <summary>バックバッファのピン留めハンドル</summary>
    private GCHandle _backBufferHandle;

    /// <summary>現在の映像幅（ピクセル）</summary>
    private int _currentWidth;

    /// <summary>現在の映像高さ（ピクセル）</summary>
    private int _currentHeight;

    /// <summary>フレームスキップ用: Dispatcher キューに未処理フレームがあるかどうか</summary>
    private volatile int _pendingFrames;

    /// <summary>最新フレームデータ（スキップ判定時に保持）</summary>
    private byte[]? _latestFrameData;

    /// <summary>最新フレームのロック用オブジェクト</summary>
    private readonly object _latestFrameLock = new();

    /// <summary>最新フレームの幅</summary>
    private int _latestFrameWidth;

    /// <summary>最新フレームの高さ</summary>
    private int _latestFrameHeight;

    private bool _disposed;

    // ─── コンストラクタ ─────────────────────────────────────────

    /// <summary>
    /// VideoFrameRenderer のインスタンスを生成する。
    /// </summary>
    /// <param name="dispatcher">UI スレッドの Dispatcher</param>
    public VideoFrameRenderer(Dispatcher dispatcher)
    {
        _dispatcher = dispatcher ?? throw new ArgumentNullException(nameof(dispatcher));
    }

    // ─── IVideoFrameRenderer ───────────────────────────────────

    /// <inheritdoc />
    public WriteableBitmap? CurrentBitmap => _bitmap;

    /// <inheritdoc />
    public event EventHandler<WriteableBitmap>? BitmapUpdated;

    /// <summary>
    /// BGRA フォーマットのフレームデータを描画する。
    /// バックグラウンドスレッドから呼び出し可能。
    /// </summary>
    /// <param name="bgraData">BGRA ピクセルデータ（長さ = width * height * 4）</param>
    /// <param name="width">フレーム幅（ピクセル）</param>
    /// <param name="height">フレーム高さ（ピクセル）</param>
    /// <exception cref="ObjectDisposedException">Dispose 済みの場合</exception>
    /// <exception cref="ArgumentException">bgraData の長さが不正な場合</exception>
    public void RenderFrame(ReadOnlySpan<byte> bgraData, int width, int height)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        int expectedLength = width * height * 4;
        if (bgraData.Length != expectedLength)
        {
            throw new ArgumentException(
                $"bgraData の長さが不正です。期待値: {expectedLength}, 実際: {bgraData.Length}",
                nameof(bgraData));
        }

        // 最新フレームデータをコピーして保持（スパンはスタック上にあるため非同期処理のためにコピーが必要）
        var frameDataCopy = new byte[bgraData.Length];
        bgraData.CopyTo(frameDataCopy);

        // 最新フレームを更新（古いフレームは上書き）
        lock (_latestFrameLock)
        {
            _latestFrameData = frameDataCopy;
            _latestFrameWidth = width;
            _latestFrameHeight = height;
        }

        // フレームスキップ判定: Dispatcher キューに未処理フレームがある場合はスキップ
        // Interlocked.Increment で アトミックに _pendingFrames を増加させ、
        // すでに 1 件以上 pending がある場合は BeginInvoke を重複発行しない
        int currentPending = Interlocked.Increment(ref _pendingFrames);
        if (currentPending > 1)
        {
            // 未処理フレームがある場合はスキップ（最新フレームデータは上で保存済み）
            return;
        }

        // UI スレッドへ非同期ディスパッチ（DispatcherPriority.Render でレンダリング優先度）
        _dispatcher.BeginInvoke(DispatcherPriority.Render, () =>
        {
            try
            {
                // 最新フレームデータを取得
                byte[]? frameData;
                int frameWidth, frameHeight;
                lock (_latestFrameLock)
                {
                    frameData = _latestFrameData;
                    frameWidth = _latestFrameWidth;
                    frameHeight = _latestFrameHeight;
                }

                if (frameData is null || _disposed)
                    return;

                // WritableBitmap を解像度変更時のみ再生成
                EnsureBitmap(frameWidth, frameHeight);

                // ピン留めバックバッファへフレームデータをコピー
                WriteFrameToBackBuffer(frameData, frameWidth, frameHeight);

                // BitmapUpdated イベントを発行（UI スレッドで）
                BitmapUpdated?.Invoke(this, _bitmap!);
            }
            finally
            {
                // pending カウントをリセット（次のフレームを受け付けるため 0 に戻す）
                Interlocked.Exchange(ref _pendingFrames, 0);
            }
        });
    }

    /// <summary>
    /// ビットマップをプレースホルダー状態にリセットする。いつでも呼び出し可能。
    /// </summary>
    public void Clear()
    {
        if (_disposed)
            return;

        _dispatcher.BeginInvoke(DispatcherPriority.Render, () =>
        {
            if (_disposed)
                return;

            // バックバッファのピン留めを解除
            ReleaseBackBuffer();

            _bitmap = null;
            _currentWidth = 0;
            _currentHeight = 0;

            lock (_latestFrameLock)
            {
                _latestFrameData = null;
            }
        });
    }

    // ─── プライベートメソッド ──────────────────────────────────

    /// <summary>
    /// 解像度が変わった場合のみ WritableBitmap を再生成する。
    /// UI スレッドで呼び出すこと。
    /// </summary>
    private void EnsureBitmap(int width, int height)
    {
        if (_bitmap is not null && _currentWidth == width && _currentHeight == height)
            return;

        // 既存のバックバッファを解放
        ReleaseBackBuffer();

        // 新しいバックバッファを確保してピン留め
        int bufferSize = width * height * 4;
        _backBuffer = new byte[bufferSize];
        _backBufferHandle = GCHandle.Alloc(_backBuffer, GCHandleType.Pinned);

        // ピン留めされたバッファのアドレスで WritableBitmap を作成
        // PixelFormats.Pbgra32 は BGRA 各 8bit（FFmpeg の BGRA 出力と対応）
        _bitmap = new WriteableBitmap(
            width,
            height,
            dpiX: 96,
            dpiY: 96,
            PixelFormats.Pbgra32,
            palette: null);

        _currentWidth = width;
        _currentHeight = height;
    }

    /// <summary>
    /// フレームデータをバックバッファ経由で WritableBitmap に書き込む。
    /// UI スレッドで呼び出すこと。
    /// </summary>
    private void WriteFrameToBackBuffer(byte[] frameData, int width, int height)
    {
        if (_bitmap is null || _backBuffer is null)
            return;

        // フレームデータをバックバッファにコピー
        Buffer.BlockCopy(frameData, 0, _backBuffer, 0, frameData.Length);

        // WritableBitmap にロックして書き込む
        _bitmap.Lock();
        try
        {
            int stride = width * 4; // BGRA: 4 bytes per pixel
            _bitmap.WritePixels(
                new System.Windows.Int32Rect(0, 0, width, height),
                _backBuffer,
                stride,
                offset: 0);
        }
        finally
        {
            _bitmap.Unlock();
        }
    }

    /// <summary>
    /// バックバッファのピン留めを解除してメモリを解放する。
    /// </summary>
    private void ReleaseBackBuffer()
    {
        if (_backBufferHandle.IsAllocated)
        {
            _backBufferHandle.Free();
        }
        _backBuffer = null;
    }

    // ─── IDisposable ────────────────────────────────────────────

    /// <summary>
    /// リソースを解放する。
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
            return;

        _disposed = true;

        // ピン留めバックバッファを解放
        ReleaseBackBuffer();

        _bitmap = null;
        lock (_latestFrameLock)
        {
            _latestFrameData = null;
        }
    }
}
