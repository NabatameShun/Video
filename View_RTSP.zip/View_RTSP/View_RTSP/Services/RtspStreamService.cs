using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Sdcb.FFmpeg.Codecs;
using Sdcb.FFmpeg.Common;
using Sdcb.FFmpeg.Formats;
using Sdcb.FFmpeg.Raw;
using Sdcb.FFmpeg.Swscales;
using Sdcb.FFmpeg.Utils;
using View_RTSP.Models;

namespace View_RTSP.Services;

public sealed class RtspStreamService : IRtspStreamService, IDisposable
{
    private const int MaxRetryCount = 10;
    private const int InitialRetryDelayMs = 1000;
    private const int MaxRetryDelayMs = 30000;
    private const int FrameRateWindowSeconds = 5;
    private const int StatsUpdateIntervalMs = 1000;
    /// <summary>安定受信と判断するまでの秒数。この間フレームを受信し続けれ�EリトライカウンタをリセチE��する、E/summary>
    private const int StableStreamThresholdSeconds = 30;
    /// <summary>安定受信後�E再接続で「接続中」表示に刁E��替えるまでの連続失敗回数、E/summary>
    private const int SilentRetryThreshold = 3;

    private readonly IVideoFrameRenderer _renderer;
    private volatile ConnectionState _state = ConnectionState.Disconnected;
    private CancellationTokenSource? _decodeCts;
    private Task? _decodeTask;
    private DateTime _connectedAt;
    private long _receivedFrames;
    private DateTime _lastFrameAt;
    private readonly TimeSpan _stallTimeout = TimeSpan.FromSeconds(60);
    private readonly AVIOInterruptCB_callback _interruptCallback;
    private readonly ConcurrentQueue<DateTime> _frameTimestamps = new();
    private readonly object _stateLock = new();
    private volatile bool _hasReceivedFrame;
    private DateTime _lastInterruptLogAt = DateTime.MinValue;
    private volatile bool _disposed;

    public ConnectionState State => _state;

    public event EventHandler<StreamStateChangedEventArgs>? StateChanged;
    public event EventHandler<ConnectionStats>? StatsUpdated;
    public event EventHandler<StreamInfo>? StreamInfoReady;

    /// <inheritdoc/>
    public Action<Packet, AVRational, CodecParameters>? PacketReceived { get; set; }

    public RtspStreamService(IVideoFrameRenderer renderer)
    {
        _renderer = renderer ?? throw new ArgumentNullException(nameof(renderer));
        unsafe
        {
            _interruptCallback = InterruptCallback;
        }
        _lastFrameAt = DateTime.UtcNow;
    }

    public async Task ConnectAsync(RtspConnectionOptions options, CancellationToken cancellationToken = default)
    {
        if (_disposed)
            return;

        cancellationToken.ThrowIfCancellationRequested();

        AppLogger.Info($"[RtspStreamService] ConnectAsync url={options.Url} transport={options.Transport} lowLatency={options.LowLatencyMode}");

        Disconnect();

        _state = ConnectionState.Connecting;
        RaiseStateChanged(ConnectionState.Connecting);

        _decodeCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var token = _decodeCts.Token;

        _decodeTask = Task.Factory.StartNew(
            () => DecodeLoopWithRetryAsync(options, token),
            CancellationToken.None,
            TaskCreationOptions.LongRunning,
            TaskScheduler.Default).Unwrap();

        await Task.CompletedTask;
    }

    public void Disconnect()
    {
        if (_disposed)
            return;

        AppLogger.Info("[RtspStreamService] Disconnect called");

        lock (_stateLock)
        {
            try
            {
                _decodeCts?.Cancel();
            }
            catch (ObjectDisposedException)
            {
            }

            _decodeTask = null;

            try
            {
                _decodeCts?.Dispose();
            }
            catch (ObjectDisposedException)
            {
            }

            _decodeCts = null;
        }

        _renderer.Clear();

        if (_state != ConnectionState.Disconnected)
        {
            _state = ConnectionState.Disconnected;
            RaiseStateChanged(ConnectionState.Disconnected);
        }
    }

    private async Task DecodeLoopWithRetryAsync(RtspConnectionOptions options, CancellationToken token)
    {
        var retryCount = 0;

        while (!token.IsCancellationRequested)
        {
            var loopStartedAt = DateTime.UtcNow;

            try
            {
                await Task.Run(() => RunDecodeLoopSync(options, token), token);
            }
            catch (OperationCanceledException)
            {
                AppLogger.Info("[RtspStreamService] Decode loop canceled");
                break;
            }
            catch (Exception ex) when (!token.IsCancellationRequested)
            {
                // 安定受信してぁE��場合！EtableStreamThresholdSeconds 以上フレーム受信�E��EリトライカウンタをリセチE��
                var elapsed = DateTime.UtcNow - loopStartedAt;
                var wasStable = _hasReceivedFrame && elapsed.TotalSeconds >= StableStreamThresholdSeconds;
                if (wasStable)
                {
                    AppLogger.Info($"[RtspStreamService] Stream was stable for {elapsed.TotalSeconds:F0}s, resetting retry count");
                    retryCount = 0;
                }

                if (retryCount >= MaxRetryCount)
                {
                    AppLogger.Error($"[RtspStreamService] Max retries ({MaxRetryCount}) exhausted: {ex.Message}");
                    var errorKind = ClassifyException(ex);
                    var errorMsg = ex is RtspConnectionException rtspEx
                        ? rtspEx.Message
                        : ex.Message;
                    RaiseStateChanged(
                        ConnectionState.Disconnected,
                        new RtspError(errorKind, $"RTSP connection failed after {MaxRetryCount} retries: {errorMsg}", null));
                    _renderer.Clear();
                    return;
                }

                retryCount++;
                var delayMs = Math.Min(InitialRetryDelayMs * (1 << (retryCount - 1)), MaxRetryDelayMs);
                var kind = ClassifyException(ex);
                AppLogger.Warn($"[RtspStreamService] Retry {retryCount}/{MaxRetryCount} (delay={delayMs}ms): {ex.GetType().Name}: {ex.Message}");

                // 安定受信後�E最初�E数回�Eサイレントリトライ�E�EI に「接続中」を出さなぁE��E
                if (!wasStable || retryCount > SilentRetryThreshold)
                {
                    RaiseStateChanged(
                        ConnectionState.Connecting,
                        new RtspError(
                            kind,
                            $"再接続中 ({retryCount}/{MaxRetryCount}): {ex.Message}",
                            ex is RtspConnectionException r ? r.FfmpegErrorCode : null));
                }

                try
                {
                    await Task.Delay(delayMs, token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }

                continue;
            }

            // 正常終亁E��EeadPackets が�E然に完亁E��た場吁E= EOF�E�E
            // EOF も一時的な刁E��として再接続を試みめE
            if (!token.IsCancellationRequested)
            {
                var elapsed = DateTime.UtcNow - loopStartedAt;
                var wasStable = _hasReceivedFrame && elapsed.TotalSeconds >= StableStreamThresholdSeconds;
                if (wasStable)
                    retryCount = 0;

                retryCount++;
                if (retryCount > MaxRetryCount)
                    break;

                AppLogger.Info($"[RtspStreamService] Stream ended (EOF), reconnecting ({retryCount}/{MaxRetryCount})");

                // 安定受信後�Eサイレントリトライ
                if (!wasStable || retryCount > SilentRetryThreshold)
                {
                    RaiseStateChanged(ConnectionState.Connecting);
                }

                try
                {
                    await Task.Delay(InitialRetryDelayMs, token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }

                continue;
            }

            break;
        }

        if (!_disposed && _state != ConnectionState.Disconnected)
        {
            _state = ConnectionState.Disconnected;
            RaiseStateChanged(ConnectionState.Disconnected);
            _renderer.Clear();
        }
    }

    private unsafe void RunDecodeLoopSync(RtspConnectionOptions options, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        using var formatOptions = BuildFormatOptions(options);
        var rtspUrl = BuildRtspUrl(options);

        FormatContext? formatContext = null;
        try
        {
            try
            {
                formatContext = FormatContext.OpenInputUrl(rtspUrl, null, formatOptions);
                formatContext.InterruptCallback = new AVIOInterruptCB { callback = _interruptCallback, opaque = null };
                AppLogger.Info("[RtspStreamService] OpenInputUrl succeeded");
            }
            catch (FFmpegException ex)
            {
                var errorKind = ClassifyFfmpegErrorFromMessage(ex.Message);
                throw new RtspConnectionException(errorKind, ex.Message, null, ex);
            }

            formatContext.LoadStreamInfo();
            AppLogger.Info("[RtspStreamService] LoadStreamInfo succeeded");

            var videoStream = formatContext.FindBestStreamOrNull(AVMediaType.Video);
            if (!videoStream.HasValue)
            {
                throw new RtspConnectionException(RtspErrorKind.UnknownError, "No video stream found.", null);
            }

            var stream = videoStream.Value;

            using var codecContext = new CodecContext(Codec.FindDecoderById(stream.Codecpar!.CodecId));
            codecContext.FillParameters(stream.Codecpar);
            codecContext.Open();

            _connectedAt = DateTime.UtcNow;
            _lastFrameAt = DateTime.UtcNow;
            _hasReceivedFrame = false;
            Interlocked.Exchange(ref _receivedFrames, 0);
            _frameTimestamps.Clear();
            RaiseStateChanged(ConnectionState.Connected);

            // ストリーム惁E��を通知�E�解像度・コーチE��ク・ビットレート！E
            var codecName = FormatCodecName(Codec.FindDecoderById(stream.Codecpar!.CodecId).Name);
            var bitRate = stream.Codecpar!.BitRate > 0
                ? stream.Codecpar!.BitRate
                : formatContext.BitRate;
            var streamInfo = new StreamInfo(
                Width: stream.Codecpar!.Width,
                Height: stream.Codecpar!.Height,
                CodecName: codecName,
                BitRateBps: bitRate);
            StreamInfoReady?.Invoke(this, streamInfo);

            using var statsTimer = new Timer(OnStatsTimerTick, null, StatsUpdateIntervalMs, StatsUpdateIntervalMs);

            using var videoFrameConverter = new VideoFrameConverter();
            using var frame = new Frame();
            Frame? convertedFrame = null;
            var widthCache = 0;
            var heightCache = 0;

            try
            {
                foreach (var packet in formatContext.ReadPackets(stream.Index))
                {
                    token.ThrowIfCancellationRequested();

                    // パケチE��コールバック呼び出し（録画サービス用�E�E
                    try
                    {
                        PacketReceived?.Invoke(packet, stream.TimeBase, stream.Codecpar!);
                    }
                    catch (Exception ex)
                    {
                        AppLogger.Warn($"[RtspStreamService] PacketReceived callback error (ignored): {ex.Message}");
                    }

                    try
                    {
                        codecContext.SendPacket(packet);
                    }
                    catch (FFmpegException)
                    {
                        continue;
                    }

                    while (true)
                    {
                        CodecResult receiveResult;
                        try
                        {
                            receiveResult = codecContext.ReceiveFrame(frame);
                        }
                        catch (FFmpegException ex)
                        {
                            // Corrupted frame should not kill the stream; skip and continue.
                            AppLogger.Warn($"[RtspStreamService] Decode error (skipped): {ex.Message}");
                            break;
                        }

                        switch (receiveResult)
                        {
                            case CodecResult.EOF:
                                return;
                            case CodecResult.Again:
                                break;
                            default:
                            {
                                var width = frame.Width;
                                var height = frame.Height;

                                if (convertedFrame is null || width != widthCache || height != heightCache)
                                {
                                    convertedFrame?.Dispose();
                                    convertedFrame = Frame.CreateVideo(width, height, AVPixelFormat.Bgra);
                                    widthCache = width;
                                    heightCache = height;
                                }

                                videoFrameConverter.ConvertFrame(frame, convertedFrame);

                                var length = width * height * 4;
                                var bgraData = new ReadOnlySpan<byte>((void*)convertedFrame.Data[0], length);

                                _renderer.RenderFrame(bgraData, width, height);
                                Interlocked.Increment(ref _receivedFrames);
                                RecordFrameTimestamp();

                                goto frameReadCompleted;
                            }
                        }

                        break;
                    }

                    frameReadCompleted:;
                }

                // EOF: サーバ�EがセチE��ョンを終亁E��た、E
                // 例外にせず正常リターンし、DecodeLoopWithRetryAsync で自動�E接続を試みる、E
                AppLogger.Info("[RtspStreamService] ReadPackets completed (EOF)  Ewill attempt reconnection");
            }
            finally
            {
                convertedFrame?.Dispose();
            }
        }
        catch (RtspConnectionException)
        {
            throw;
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (FFmpegException ex)
        {
            var errorKind = ClassifyFfmpegErrorFromMessage(ex.Message);
            throw new RtspConnectionException(errorKind, ex.Message, null, ex);
        }
        catch (Exception ex)
        {
            throw new RtspConnectionException(RtspErrorKind.UnknownError, ex.Message, null, ex);
        }
        finally
        {
            formatContext?.Dispose();
            AppLogger.Debug("[RtspStreamService] Decode loop exited");
        }
    }

    private static MediaDictionary BuildFormatOptions(RtspConnectionOptions options)
    {
        var dict = new MediaDictionary();
        dict["rtsp_transport"] = options.Transport == RtspTransport.Tcp ? "tcp" : "udp";
        dict["user_agent"] = "View_RTSP";

        if (options.LowLatencyMode)
        {
            dict["fflags"] = "nobuffer";
            dict["flags"] = "low_delay";
            dict["max_delay"] = "0";
            dict["analyzeduration"] = "0";
            dict["probesize"] = "32";
        }
        else
        {
            // Favor stability over latency.
            dict["analyzeduration"] = "10000000";
            dict["probesize"] = "10000000";
        }


        // RTSP の一時的な遁E��で刁E��しなぁE��ぁE��イムアウト�E余裕をもたせる�E�E0秒！E
        dict["rw_timeout"] = "60000000";
        dict["stimeout"] = "60000000";

        // TCP 受信バッファを拡大�E�デフォルチE~64KB ↁE2MB�E�してジチE��ーを吸叁E
        dict["buffer_size"] = "2097152";

        // RTSP セチE��ョンの keepalive を維持すめE
        // FFmpeg は冁E��で GET_PARAMETER を定期送信するが、E
        // reorder_queue_size を設定することでパケチE��並べ替えバチE��ァも確俁E
        dict["reorder_queue_size"] = "500";

        return dict;
    }

    private static string BuildRtspUrl(RtspConnectionOptions options)
    {
        if (string.IsNullOrEmpty(options.Username))
            return options.Url;

        var uri = new Uri(options.Url);
        var userInfo = string.IsNullOrEmpty(options.Password)
            ? Uri.EscapeDataString(options.Username)
            : $"{Uri.EscapeDataString(options.Username)}:{Uri.EscapeDataString(options.Password ?? string.Empty)}";

        var port = uri.IsDefaultPort ? string.Empty : $":{uri.Port}";
        return $"{uri.Scheme}://{userInfo}@{uri.Host}{port}{uri.PathAndQuery}";
    }

    private void RecordFrameTimestamp()
    {
        var now = DateTime.UtcNow;
        _lastFrameAt = now;
        _hasReceivedFrame = true;
        _frameTimestamps.Enqueue(now);

        var cutoff = now.AddSeconds(-FrameRateWindowSeconds);
        while (_frameTimestamps.TryPeek(out var oldest) && oldest < cutoff)
        {
            _frameTimestamps.TryDequeue(out _);
        }
    }

    private double CalculateFrameRate()
    {
        // フレームが届いてぁE��ぁE��もタイマ�Eから呼ばれるため、E
        // ここでも古ぁE��イムスタンプを除去して正確な値を返す、E
        var now = DateTime.UtcNow;
        var cutoff = now.AddSeconds(-FrameRateWindowSeconds);
        while (_frameTimestamps.TryPeek(out var oldest) && oldest < cutoff)
            _frameTimestamps.TryDequeue(out _);

        int count = _frameTimestamps.Count;
        if (count < 2)
            return 0.0;

        // 実際に計測できた時間幁E��割ることで、E
        // 接続直後�Eウィンドウが埋まってぁE��ぁE��間も正確に計算する、E
        if (!_frameTimestamps.TryPeek(out var first))
            return 0.0;

        var actualWindowSeconds = (now - first).TotalSeconds;
        if (actualWindowSeconds < 0.1)
            return 0.0;

        return (count - 1) / actualWindowSeconds;
    }

    private void OnStatsTimerTick(object? state)
    {
        if (!_disposed && _state == ConnectionState.Connected)
        {
            var stats = new ConnectionStats(
                CalculateFrameRate(),
                Interlocked.Read(ref _receivedFrames),
                DateTime.UtcNow - _connectedAt);

            StatsUpdated?.Invoke(this, stats);
        }
    }

    private static string FormatCodecName(string ffmpegName) =>
        ffmpegName.ToUpperInvariant() switch
        {
            "H264" => "H.264",
            "HEVC" => "H.265",
            "MJPEG" => "MJPEG",
            "VP8"  => "VP8",
            "VP9"  => "VP9",
            "AV1"  => "AV1",
            var name => name
        };

    private static RtspErrorKind ClassifyFfmpegErrorFromMessage(string message)
    {
        if (string.IsNullOrEmpty(message))
            return RtspErrorKind.UnknownError;

        var lower = message.ToLowerInvariant();
        if (lower.Contains("401") || lower.Contains("unauthorized") || lower.Contains("forbidden") || lower.Contains("access denied") || lower.Contains("permission denied") || lower.Contains("authentication"))
            return RtspErrorKind.AuthenticationFailed;

        if (lower.Contains("timeout") || lower.Contains("timed out") || lower.Contains("etimedout"))
            return RtspErrorKind.ConnectionTimeout;

        if (lower.Contains("connection refused") || lower.Contains("network unreachable") || lower.Contains("host unreachable") || lower.Contains("no route to host") || lower.Contains("econnrefused") || lower.Contains("enetunreach") || lower.Contains("ehostunreach"))
            return RtspErrorKind.NetworkUnreachable;

        return RtspErrorKind.UnknownError;
    }

    private static RtspErrorKind ClassifyException(Exception ex)
    {
        return ex switch
        {
            RtspConnectionException rtspEx => rtspEx.ErrorKind,
            FFmpegException ffEx => ClassifyFfmpegErrorFromMessage(ffEx.Message),
            OperationCanceledException => RtspErrorKind.ConnectionTimeout,
            _ => RtspErrorKind.UnknownError
        };
    }

    private void RaiseStateChanged(ConnectionState state, RtspError? error = null)
    {
        _state = state;
        StateChanged?.Invoke(this, new StreamStateChangedEventArgs(state, error));
    }

    private unsafe int InterruptCallback(void* opaque)
    {
        if (_disposed)
            return 1;

        if (_decodeCts is not null && _decodeCts.IsCancellationRequested)
            return 1;

        if (_hasReceivedFrame && DateTime.UtcNow - _lastFrameAt > _stallTimeout)
        {
            var now = DateTime.UtcNow;
            if (now - _lastInterruptLogAt > TimeSpan.FromSeconds(1))
            {
                _lastInterruptLogAt = now;
                AppLogger.Warn("[RtspStreamService] InterruptCallback: stall detected");
            }
            return 1;
        }

        return 0;
    }

    public void Dispose()
    {
        if (_disposed)
            return;

        _disposed = true;

        try
        {
            _decodeCts?.Cancel();
        }
        catch (ObjectDisposedException)
        {
        }

        try
        {
            _decodeCts?.Dispose();
        }
        catch (ObjectDisposedException)
        {
        }

        _decodeCts = null;
        _decodeTask = null;
    }
}

