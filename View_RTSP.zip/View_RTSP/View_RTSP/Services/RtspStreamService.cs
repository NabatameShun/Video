// RTSP ストリームサービスの実装（FFmpeg デコードエンジン）
// タスク 4.1, 4.2, 4.3: FFmpeg 初期化・H.264 デコードループ・エラー検出・自動再試行・リソース解放
// Requirements: 1.2, 1.3, 1.5, 2.4, 3.1, 3.3, 5.2, 5.5, 6.1, 6.2, 9.1–9.9

using System.Collections.Concurrent;
using Sdcb.FFmpeg.Codecs;
using Sdcb.FFmpeg.Common;
using Sdcb.FFmpeg.Formats;
using Sdcb.FFmpeg.Raw;
using Sdcb.FFmpeg.Swscales;
using Sdcb.FFmpeg.Utils;
using View_RTSP.Models;

namespace View_RTSP.Services;

/// <summary>
/// Sdcb.FFmpeg を使用した RTSP ストリームの受信・H.264 デコード・フレーム配信サービス。
/// <para>
/// - avformat_open_input による RTSP 接続確立（低遅延オプション付き）
/// - avcodec による H.264 ビデオフレームのデコード（SendPacket / ReceiveFrame）
/// - sws_scale による YUV420P → BGRA 変換
/// - 専用バックグラウンドスレッドでデコードループを実行し、UI スレッドを一切ブロックしない
/// - IDisposable パターンで AVFormatContext / AVCodecContext / AVFrame 等のネイティブリソースを確実に解放
/// - デコードエラー時は最大 3 回の自動再試行を行い、上限到達後に StateChanged イベントを発行
/// </para>
/// </summary>
public sealed class RtspStreamService : IRtspStreamService
{
    // ─── 定数 ────────────────────────────────────────────────────

    /// <summary>自動再接続の最大試行回数</summary>
    private const int MaxRetryCount = 3;

    /// <summary>再接続待機時間（ミリ秒）</summary>
    private const int RetryDelayMs = 500;

    /// <summary>フレームレート算出ウィンドウ（秒）</summary>
    private const int FrameRateWindowSeconds = 5;

    /// <summary>統計情報更新間隔（ミリ秒）</summary>
    private const int StatsUpdateIntervalMs = 1000;

    // ─── フィールド ─────────────────────────────────────────────

    private readonly IVideoFrameRenderer _renderer;

    /// <summary>現在の接続状態</summary>
    private volatile ConnectionState _state = ConnectionState.Disconnected;

    /// <summary>デコードスレッドのキャンセルトークンソース</summary>
    private CancellationTokenSource? _decodeCts;

    /// <summary>デコードスレッドのタスク</summary>
    private Task? _decodeTask;

    /// <summary>接続開始日時（稼働時間算出用）</summary>
    private DateTime _connectedAt;

    /// <summary>受信フレーム数</summary>
    private long _receivedFrames;

    /// <summary>直近フレームタイムスタンプ（フレームレート算出用、直近 FrameRateWindowSeconds 秒のみ保持）</summary>
    private readonly ConcurrentQueue<DateTime> _frameTimestamps = new();

    /// <summary>状態変更ロック</summary>
    private readonly object _stateLock = new();

    /// <summary>Dispose 済みフラグ</summary>
    private volatile bool _disposed;

    // ─── コンストラクタ ─────────────────────────────────────────

    /// <summary>
    /// RtspStreamService のインスタンスを生成する。
    /// </summary>
    /// <param name="renderer">映像フレーム描画サービス</param>
    public RtspStreamService(IVideoFrameRenderer renderer)
    {
        _renderer = renderer ?? throw new ArgumentNullException(nameof(renderer));
    }

    // ─── IRtspStreamService ──────────────────────────────────────

    /// <inheritdoc />
    public ConnectionState State => _state;

    /// <inheritdoc />
    public event EventHandler<StreamStateChangedEventArgs>? StateChanged;

    /// <inheritdoc />
    public event EventHandler<ConnectionStats>? StatsUpdated;

    /// <inheritdoc />
    /// <summary>
    /// 指定した接続オプションで RTSP ストリームへの接続を開始する。
    /// バックグラウンドスレッドでデコードループを開始し、すぐに返る。
    /// 接続結果は StateChanged イベントで通知される。
    /// </summary>
    /// <param name="options">RTSP 接続オプション（URL・認証情報・トランスポート・低遅延設定）</param>
    /// <param name="cancellationToken">キャンセルトークン</param>
    public async Task ConnectAsync(RtspConnectionOptions options, CancellationToken cancellationToken = default)
    {
        if (_disposed)
            return;

        cancellationToken.ThrowIfCancellationRequested();

        // 既存の接続を切断
        Disconnect();

        _state = ConnectionState.Connecting;
        RaiseStateChanged(ConnectionState.Connecting);

        // デコードスレッド用のキャンセルトークンを作成
        _decodeCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var token = _decodeCts.Token;

        // バックグラウンドスレッドでデコードループを開始
        // TaskCreationOptions.LongRunning: 専用スレッドを使用し、スレッドプールを圧迫しない
        _decodeTask = Task.Factory.StartNew(
            () => DecodeLoopWithRetryAsync(options, token),
            CancellationToken.None,
            TaskCreationOptions.LongRunning,
            TaskScheduler.Default).Unwrap();

        await Task.CompletedTask;
    }

    /// <inheritdoc />
    /// <summary>
    /// RTSP ストリームを切断する。どの状態からでも安全に呼び出せる（冪等）。
    /// </summary>
    public void Disconnect()
    {
        if (_disposed)
            return;

        lock (_stateLock)
        {
            // キャンセルトークンをキャンセルしてデコードスレッドを停止
            try
            {
                _decodeCts?.Cancel();
            }
            catch (ObjectDisposedException)
            {
                // 既に Dispose 済みの場合は無視
            }

            _decodeTask = null;

            try
            {
                _decodeCts?.Dispose();
            }
            catch (ObjectDisposedException) { }

            _decodeCts = null;
        }

        // 映像フレームをクリア
        _renderer.Clear();

        // 状態が Disconnected 以外の場合のみ遷移
        if (_state != ConnectionState.Disconnected)
        {
            _state = ConnectionState.Disconnected;
            RaiseStateChanged(ConnectionState.Disconnected);
        }
    }

    // ─── デコードループ ──────────────────────────────────────────

    /// <summary>
    /// 自動再試行付きデコードループ。
    /// デコードエラー時は最大 MaxRetryCount 回再接続を試みる。
    /// Requirements: 9.8（デコードエラー時の自動再試行と通知）
    /// </summary>
    private async Task DecodeLoopWithRetryAsync(RtspConnectionOptions options, CancellationToken token)
    {
        int retryCount = 0;

        while (!token.IsCancellationRequested)
        {
            try
            {
                // FFmpeg 接続・デコードループを実行（専用スレッドで同期実行）
                await Task.Run(() => RunDecodeLoopSync(options, token), token);

                // 正常終了（キャンセルまたは EOF）
                break;
            }
            catch (OperationCanceledException)
            {
                // キャンセルによる終了（正常）
                break;
            }
            catch (RtspConnectionException rtspEx) when (retryCount < MaxRetryCount)
            {
                retryCount++;
                // 再試行通知（Connecting 状態に戻す）
                RaiseStateChanged(ConnectionState.Connecting,
                    new RtspError(
                        Kind: rtspEx.ErrorKind,
                        Message: $"デコードエラーが発生しました。再試行中... ({retryCount}/{MaxRetryCount}): {rtspEx.Message}",
                        FfmpegErrorCode: rtspEx.FfmpegErrorCode
                    ));

                // 再試行待機
                try
                {
                    await Task.Delay(RetryDelayMs, token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
            }
            catch (Exception ex) when (retryCount < MaxRetryCount)
            {
                retryCount++;
                var errorKind = ClassifyException(ex);

                RaiseStateChanged(ConnectionState.Connecting,
                    new RtspError(
                        Kind: errorKind,
                        Message: $"デコードエラーが発生しました。再試行中... ({retryCount}/{MaxRetryCount}): {ex.Message}",
                        FfmpegErrorCode: null
                    ));

                try
                {
                    await Task.Delay(RetryDelayMs, token);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
            }
            catch (RtspConnectionException rtspEx)
            {
                // 再試行上限到達: 切断状態に遷移
                // Requirements: 3.1（予期せぬ切断の通知）
                RaiseStateChanged(ConnectionState.Disconnected,
                    new RtspError(
                        Kind: rtspEx.ErrorKind,
                        Message: $"ストリームが切断されました。再接続できませんでした: {rtspEx.Message}",
                        FfmpegErrorCode: rtspEx.FfmpegErrorCode
                    ));
                _renderer.Clear();
                return;
            }
            catch (Exception ex)
            {
                // 再試行上限到達
                var errorKind = ClassifyException(ex);
                RaiseStateChanged(ConnectionState.Disconnected,
                    new RtspError(
                        Kind: errorKind,
                        Message: $"ストリームが切断されました。再接続できませんでした: {ex.Message}",
                        FfmpegErrorCode: null
                    ));
                _renderer.Clear();
                return;
            }
        }

        // キャンセルまたは正常完了後
        if (!_disposed && _state != ConnectionState.Disconnected)
        {
            _state = ConnectionState.Disconnected;
        }
    }

    /// <summary>
    /// FFmpeg を使用した同期デコードループ（専用バックグラウンドスレッドで実行）。
    /// タスク 4.1: FFmpeg 初期化と RTSP 接続確立
    /// タスク 4.2: H.264 デコードループ（av_read_frame / SendPacket / ReceiveFrame）
    /// </summary>
    private void RunDecodeLoopSync(RtspConnectionOptions options, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();

        // ─── タスク 4.1: FFmpeg 初期化と RTSP 接続確立 ───────────────

        // 低遅延 FFmpeg オプションを設定した MediaDictionary を構築
        using var formatOptions = BuildFormatOptions(options);

        // 認証情報付き RTSP URL を構築
        var rtspUrl = BuildRtspUrl(options);

        FormatContext? formatContext = null;
        try
        {
            // RTSP URL へ接続（FormatContext が接続タイムアウト等の例外をスロー）
            // Requirements: 9.1（Sdcb.FFmpeg による RTSP デコード）、9.2（avformat/avcodec 直接利用）
            try
            {
                formatContext = FormatContext.OpenInputUrl(rtspUrl, options: formatOptions);
            }
            catch (FFmpegException ex)
            {
                // FFmpeg エラーをメッセージから分類
                var errorKind = ClassifyFfmpegErrorFromMessage(ex.Message);
                throw new RtspConnectionException(errorKind, ex.Message, null, ex);
            }

            // ストリーム情報を読み込む（avformat_find_stream_info 相当）
            formatContext.LoadStreamInfo();

            // H.264 ビデオストリームを検出（FindBestStreamOrNull で安全に取得）
            // Requirements: 2.4（H.264 ストリーム表示）
            var videoStream = formatContext.FindBestStreamOrNull(AVMediaType.Video);
            if (!videoStream.HasValue)
            {
                throw new RtspConnectionException(
                    RtspErrorKind.UnknownError,
                    "ビデオストリームが見つかりませんでした。",
                    null);
            }

            var stream = videoStream.Value;

            // ─── タスク 4.2: H.264 デコーダーを開く ─────────────────────

            using var codecContext = new CodecContext(Codec.FindDecoderById(stream.Codecpar!.CodecId));
            codecContext.FillParameters(stream.Codecpar);
            codecContext.Open();

            // 接続成功を通知
            // Requirements: 1.3（接続成功後に映像受信・表示開始）
            _connectedAt = DateTime.UtcNow;
            Interlocked.Exchange(ref _receivedFrames, 0);
            _frameTimestamps.Clear();
            RaiseStateChanged(ConnectionState.Connected);

            // ─── 統計情報タイマー（1 秒ごとに StatsUpdated イベントを発行）───
            // Requirements: 6.3（フレームレート・接続状態表示）
            using var statsTimer = new System.Threading.Timer(
                OnStatsTimerTick,
                null,
                StatsUpdateIntervalMs,
                StatsUpdateIntervalMs);

            // ─── タスク 4.2: デコード + カラー変換コンテキスト ─────────────

            using var videoFrameConverter = new VideoFrameConverter();

            // デコード済みフレーム（YUV420P 等のコーデックネイティブ形式）
            using var decodedFrame = new Frame();

            // BGRA 変換先フレーム（サイズは最初のフレームで確定するため遅延初期化）
            Frame? bgraFrame = null;
            int lastWidth = 0, lastHeight = 0;

            try
            {
                // ─── タスク 4.2: デコードループ ─────────────────────────────
                // av_read_frame / avcodec_send_packet / avcodec_receive_frame ループ
                // Requirements: 9.6（専用バックグラウンドスレッドでデコード）

                foreach (var packet in formatContext.ReadPackets(stream.Index))
                {
                    token.ThrowIfCancellationRequested();

                    try
                    {
                        // パケットをデコーダーへ送信（avcodec_send_packet 相当）
                        codecContext.SendPacket(packet);
                    }
                    catch (FFmpegException)
                    {
                        // 単一パケットのエラーは無視して継続（デコードエラーは再試行で対応）
                        continue;
                    }

                    // デコードされたフレームを受信（avcodec_receive_frame 相当）
                    while (true)
                    {
                        CodecResult result;
                        try
                        {
                            result = codecContext.ReceiveFrame(decodedFrame);
                        }
                        catch (FFmpegException ex)
                        {
                            // デコードエラー: RtspConnectionException に変換して再スロー
                            throw new RtspConnectionException(
                                RtspErrorKind.DecodeError,
                                $"フレームデコードエラー: {ex.Message}",
                                null,
                                ex);
                        }

                        if (result == CodecResult.Again)
                            break; // もっとパケットが必要

                        if (result == CodecResult.EOF)
                            goto endOfStream;

                        // フレームサイズが変わった場合は BGRA フレームを再生成
                        int frameWidth = decodedFrame.Width;
                        int frameHeight = decodedFrame.Height;

                        if (bgraFrame is null || frameWidth != lastWidth || frameHeight != lastHeight)
                        {
                            bgraFrame?.Dispose();
                            bgraFrame = Frame.CreateVideo(frameWidth, frameHeight, AVPixelFormat.Bgra);
                            lastWidth = frameWidth;
                            lastHeight = frameHeight;
                        }

                        // タスク 4.2: YUV420P → BGRA 変換（sws_scale 相当）
                        // Requirements: 9.2（avformat/avcodec 直接利用）、9.7（E2E 遅延 500ms 以内）
                        videoFrameConverter.ConvertFrame(decodedFrame, bgraFrame);

                        // BGRA フレームデータを VideoFrameRenderer へ渡す
                        // Requirements: 6.2（UI スレッドをブロックしない非同期処理）
                        int bufferSize = frameWidth * frameHeight * 4; // BGRA: 4 bytes/pixel
                        unsafe
                        {
                            var span = new ReadOnlySpan<byte>(
                                (void*)bgraFrame.Data[0],
                                bufferSize);
                            _renderer.RenderFrame(span, frameWidth, frameHeight);
                        }

                        // フレーム統計を更新
                        Interlocked.Increment(ref _receivedFrames);
                        RecordFrameTimestamp();
                    }
                }

                endOfStream:;
            }
            finally
            {
                bgraFrame?.Dispose();
            }
        }
        catch (RtspConnectionException)
        {
            // そのまま上位へ再スロー
            throw;
        }
        catch (OperationCanceledException)
        {
            // キャンセルはそのまま再スロー
            throw;
        }
        catch (FFmpegException ex)
        {
            // FFmpeg エラーを分類して RtspConnectionException に変換
            var errorKind = ClassifyFfmpegErrorFromMessage(ex.Message);
            throw new RtspConnectionException(errorKind, ex.Message, null, ex);
        }
        catch (Exception ex)
        {
            throw new RtspConnectionException(RtspErrorKind.UnknownError, ex.Message, null, ex);
        }
        finally
        {
            formatContext?.Dispose();
        }
    }

    // ─── FFmpeg オプション構築 ───────────────────────────────────

    /// <summary>
    /// タスク 4.1: 低遅延 FFmpeg オプションを設定した MediaDictionary を構築する。
    /// Requirements: 9.4（低遅延 FFmpeg オプション適用）
    /// </summary>
    private static MediaDictionary BuildFormatOptions(RtspConnectionOptions options)
    {
        var dict = new MediaDictionary();

        // RTSP トランスポート設定（TCP / UDP）
        // Requirements: 9.3（TCP / UDP トランスポート選択）
        string transport = options.Transport == RtspTransport.Tcp ? "tcp" : "udp";
        dict["rtsp_transport"] = transport;

        if (options.LowLatencyMode)
        {
            // 低遅延 FFmpeg オプション
            // fflags=nobuffer: バッファリングを無効化して遅延を最小化
            // flags=low_delay: 低遅延デコードモード
            // max_delay=0: 最大遅延をゼロに設定
            // analyzeduration=0: ストリーム解析時間をゼロに設定
            // probesize=32: プローブサイズを最小化
            dict["fflags"] = "nobuffer";
            dict["flags"] = "low_delay";
            dict["max_delay"] = "0";
            dict["analyzeduration"] = "0";
            dict["probesize"] = "32";
        }

        return dict;
    }

    /// <summary>
    /// タスク 4.1: 認証情報を含む RTSP URL を構築する。
    /// 認証情報が指定されている場合は URL に埋め込む。
    /// Requirements: 5.2（認証情報を用いた接続）、5.5（認証なし接続サポート）
    /// </summary>
    private static string BuildRtspUrl(RtspConnectionOptions options)
    {
        if (string.IsNullOrEmpty(options.Username))
            return options.Url;

        // rtsp://username:password@host/path 形式に変換
        var uri = new Uri(options.Url);
        var userInfo = string.IsNullOrEmpty(options.Password)
            ? Uri.EscapeDataString(options.Username)
            : $"{Uri.EscapeDataString(options.Username)}:{Uri.EscapeDataString(options.Password ?? string.Empty)}";

        var port = uri.IsDefaultPort ? string.Empty : $":{uri.Port}";
        return $"{uri.Scheme}://{userInfo}@{uri.Host}{port}{uri.PathAndQuery}";
    }

    // ─── 統計情報 ────────────────────────────────────────────────

    /// <summary>
    /// タスク 4.2: フレームタイムスタンプを記録する（フレームレート算出用）。
    /// 直近 FrameRateWindowSeconds 秒のみ保持する。
    /// </summary>
    private void RecordFrameTimestamp()
    {
        var now = DateTime.UtcNow;
        _frameTimestamps.Enqueue(now);

        // 古いタイムスタンプを削除（FrameRateWindowSeconds 秒以上前）
        var cutoff = now.AddSeconds(-FrameRateWindowSeconds);
        while (_frameTimestamps.TryPeek(out var oldest) && oldest < cutoff)
        {
            _frameTimestamps.TryDequeue(out _);
        }
    }

    /// <summary>
    /// タスク 4.2: 直近 FrameRateWindowSeconds 秒の平均フレームレートを算出する。
    /// Requirements: 6.3（フレームレート算出）
    /// </summary>
    private double CalculateFrameRate()
    {
        int count = _frameTimestamps.Count;
        if (count < 2)
            return 0.0;

        return (double)count / FrameRateWindowSeconds;
    }

    /// <summary>
    /// 統計情報タイマーコールバック（1 秒ごとに StatsUpdated を発行）。
    /// Requirements: 6.3（接続状態・フレームレート表示）
    /// </summary>
    private void OnStatsTimerTick(object? state)
    {
        if (_disposed || _state != ConnectionState.Connected)
            return;

        var stats = new ConnectionStats(
            FrameRate: CalculateFrameRate(),
            ReceivedFrames: Interlocked.Read(ref _receivedFrames),
            Uptime: DateTime.UtcNow - _connectedAt
        );

        StatsUpdated?.Invoke(this, stats);
    }

    // ─── エラー分類 ──────────────────────────────────────────────

    /// <summary>
    /// タスク 4.1: FFmpeg エラーメッセージから RtspErrorKind を判定する。
    /// Requirements: 1.5（接続失敗時エラーメッセージ）、5.3（認証失敗エラーメッセージ）
    /// </summary>
    private static RtspErrorKind ClassifyFfmpegErrorFromMessage(string message)
    {
        if (string.IsNullOrEmpty(message))
            return RtspErrorKind.UnknownError;

        var lower = message.ToLowerInvariant();

        // 認証失敗の検出
        if (lower.Contains("401") ||
            lower.Contains("unauthorized") ||
            lower.Contains("forbidden") ||
            lower.Contains("access denied") ||
            lower.Contains("permission denied") ||
            lower.Contains("authentication"))
        {
            return RtspErrorKind.AuthenticationFailed;
        }

        // タイムアウトの検出
        if (lower.Contains("timeout") ||
            lower.Contains("timed out") ||
            lower.Contains("etimedout"))
        {
            return RtspErrorKind.ConnectionTimeout;
        }

        // ネットワーク不達の検出
        if (lower.Contains("connection refused") ||
            lower.Contains("network unreachable") ||
            lower.Contains("host unreachable") ||
            lower.Contains("no route to host") ||
            lower.Contains("econnrefused") ||
            lower.Contains("enetunreach") ||
            lower.Contains("ehostunreach"))
        {
            return RtspErrorKind.NetworkUnreachable;
        }

        return RtspErrorKind.UnknownError;
    }

    /// <summary>
    /// 例外の種類から RtspErrorKind を判定する。
    /// </summary>
    private static RtspErrorKind ClassifyException(Exception ex)
    {
        return ex switch
        {
            RtspConnectionException rtspEx => rtspEx.ErrorKind,
            FFmpegException ffEx => ClassifyFfmpegErrorFromMessage(ffEx.Message),
            OperationCanceledException => RtspErrorKind.ConnectionTimeout,
            _ => RtspErrorKind.UnknownError
        };
    }

    // ─── 状態管理 ────────────────────────────────────────────────

    /// <summary>
    /// StateChanged イベントを発行する（バックグラウンドスレッドから呼び出し可能）。
    /// Requirements: 3.1（予期せぬ切断の状態変化イベント通知）
    /// </summary>
    private void RaiseStateChanged(ConnectionState state, RtspError? error = null)
    {
        _state = state;
        StateChanged?.Invoke(this, new StreamStateChangedEventArgs(state, error));
    }

    // ─── IDisposable ────────────────────────────────────────────

    /// <summary>
    /// ネイティブリソースを解放する。
    /// タスク 4.3: IDisposable パターンで全ネイティブリソースを確実に解放する。
    /// Requirements: 9.9（終了時の FFmpeg リソース解放）
    /// </summary>
    public void Dispose()
    {
        if (_disposed)
            return;

        _disposed = true;

        try
        {
            _decodeCts?.Cancel();
        }
        catch (ObjectDisposedException) { }

        try
        {
            _decodeCts?.Dispose();
        }
        catch (ObjectDisposedException) { }

        _decodeCts = null;
        _decodeTask = null;
    }
}

// ─── 内部例外クラス ──────────────────────────────────────────────

/// <summary>
/// RTSP 接続・デコードエラーの内部例外クラス。
/// FFmpeg エラーをエラー種別付きで伝搬するために使用する。
/// </summary>
internal sealed class RtspConnectionException : Exception
{
    /// <summary>エラー種別</summary>
    public RtspErrorKind ErrorKind { get; }

    /// <summary>FFmpeg エラーコード（利用可能な場合のみ）</summary>
    public int? FfmpegErrorCode { get; }

    public RtspConnectionException(
        RtspErrorKind errorKind,
        string message,
        int? ffmpegErrorCode,
        Exception? innerException = null)
        : base(message, innerException)
    {
        ErrorKind = errorKind;
        FfmpegErrorCode = ffmpegErrorCode;
    }
}
