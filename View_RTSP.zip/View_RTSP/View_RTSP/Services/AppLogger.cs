// アプリケーションログユーティリティ

using System.Diagnostics;

namespace View_RTSP.Services;

/// <summary>
/// アプリケーション全体で使用するログ出力ユーティリティ。
/// Trace インフラ経由でログを書き込む（<see cref="TimestampedFileTraceListener"/> が
/// タイムスタンプを付与してファイルへ出力する）。
/// </summary>
public static class AppLogger
{
    /// <summary>通常の処理フローに関する情報ログ。</summary>
    public static void Info(string message) =>
        Trace.WriteLine($"[INFO ] {message}");

    /// <summary>予期しない状態だが継続可能な警告ログ。</summary>
    public static void Warn(string message) =>
        Trace.WriteLine($"[WARN ] {message}");

    /// <summary>エラーが発生したことを示すログ。</summary>
    public static void Error(string message) =>
        Trace.WriteLine($"[ERROR] {message}");

    /// <summary>詳細なデバッグ情報（開発時に有用）。</summary>
    public static void Debug(string message) =>
        Trace.WriteLine($"[DEBUG] {message}");
}
