// 設定永続化サービスの実装
// タスク 2: JSON ファイル保存・DPAPI パスワード暗号化・デフォルト値フォールバック
// Requirements: 4.6, 5.1, 5.4, 9.3

using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using View_RTSP.Models;

namespace View_RTSP.Services;

/// <summary>
/// 接続設定を %AppData%\RtspViewer\settings.json へ JSON 形式で永続化するサービス。
/// パスワードは Windows DPAPI（ProtectedData）で暗号化して Base64 エンコードで保存する。
/// </summary>
public sealed class SettingsService : ISettingsService
{
    private const string SettingsFileName = "settings.json";

    private readonly string _settingsDirectory;
    private readonly JsonSerializerOptions _jsonOptions;

    /// <summary>
    /// デフォルトコンストラクター。設定ディレクトリは %AppData%\RtspViewer を使用する。
    /// </summary>
    public SettingsService()
        : this(Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "RtspViewer"))
    {
    }

    /// <summary>
    /// テスト用コンストラクター。設定ディレクトリを指定できる。
    /// </summary>
    /// <param name="settingsDirectory">設定ファイルを保存するディレクトリパス</param>
    public SettingsService(string settingsDirectory)
    {
        _settingsDirectory = settingsDirectory;
        _jsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            Converters = { new JsonStringEnumConverter() }
        };
    }

    /// <inheritdoc/>
    public AppSettings Load()
    {
        var settingsPath = Path.Combine(_settingsDirectory, SettingsFileName);

        if (!File.Exists(settingsPath))
        {
            return AppSettings.Default;
        }

        try
        {
            var json = File.ReadAllText(settingsPath, Encoding.UTF8);
            var dto = JsonSerializer.Deserialize<AppSettingsDto>(json, _jsonOptions);

            if (dto is null)
            {
                Trace.WriteLine("[SettingsService] 設定ファイルのデシリアライズ結果が null でした。デフォルト値を使用します。");
                return AppSettings.Default;
            }

            return FromDto(dto);
        }
        catch (JsonException ex)
        {
            Trace.WriteLine($"[SettingsService] 設定ファイルが破損しています。デフォルト値にフォールバックします。詳細: {ex.Message}");
            return AppSettings.Default;
        }
        catch (Exception ex)
        {
            Trace.WriteLine($"[SettingsService] 設定ファイルの読み込みに失敗しました。デフォルト値にフォールバックします。詳細: {ex.Message}");
            return AppSettings.Default;
        }
    }

    /// <inheritdoc/>
    public void Save(AppSettings settings)
    {
        EnsureDirectoryExists();

        var dto = ToDto(settings);
        var json = JsonSerializer.Serialize(dto, _jsonOptions);
        var settingsPath = Path.Combine(_settingsDirectory, SettingsFileName);

        File.WriteAllText(settingsPath, json, Encoding.UTF8);
    }

    // ─── パスワード暗号化 / 復号 ──────────────────────────────────

    /// <summary>
    /// 平文パスワードを DPAPI（DataProtectionScope.CurrentUser）で暗号化し、
    /// Base64 文字列として返す。
    /// </summary>
    /// <param name="plainPassword">暗号化する平文パスワード</param>
    /// <returns>DPAPI 暗号化済み Base64 文字列</returns>
    public string EncryptPassword(string plainPassword)
    {
        var plainBytes = Encoding.UTF8.GetBytes(plainPassword);
        var encryptedBytes = ProtectedData.Protect(
            plainBytes,
            optionalEntropy: null,
            scope: DataProtectionScope.CurrentUser);
        return Convert.ToBase64String(encryptedBytes);
    }

    /// <summary>
    /// DPAPI 暗号化済み Base64 文字列を復号して平文パスワードを返す。
    /// </summary>
    /// <param name="encryptedBase64">暗号化された Base64 文字列</param>
    /// <returns>復号した平文パスワード</returns>
    public string DecryptPassword(string encryptedBase64)
    {
        var encryptedBytes = Convert.FromBase64String(encryptedBase64);
        var plainBytes = ProtectedData.Unprotect(
            encryptedBytes,
            optionalEntropy: null,
            scope: DataProtectionScope.CurrentUser);
        return Encoding.UTF8.GetString(plainBytes);
    }

    // ─── プライベートヘルパー ─────────────────────────────────────

    private void EnsureDirectoryExists()
    {
        if (!Directory.Exists(_settingsDirectory))
            Directory.CreateDirectory(_settingsDirectory);
    }

    /// <summary>AppSettings を JSON 転送用 DTO へ変換する</summary>
    private static AppSettingsDto ToDto(AppSettings settings) => new(
        Pane1: ToPaneDto(settings.Pane1),
        Pane2: ToPaneDto(settings.Pane2),
        Layout: settings.Layout
    );

    private static StreamPaneSettingsDto ToPaneDto(StreamPaneSettings pane) => new(
        RtspUrl: pane.RtspUrl,
        Username: pane.Username,
        EncryptedPassword: pane.EncryptedPassword,
        Transport: pane.Transport,
        OnvifEndpointUrl: pane.OnvifEndpointUrl,
        OnvifUsername: pane.OnvifUsername,
        OnvifEncryptedPassword: pane.OnvifEncryptedPassword
    );

    /// <summary>JSON 転送用 DTO を AppSettings へ変換する</summary>
    private static AppSettings FromDto(AppSettingsDto dto) => new(
        Pane1: FromPaneDto(dto.Pane1 ?? StreamPaneSettingsDto.Default),
        Pane2: FromPaneDto(dto.Pane2 ?? StreamPaneSettingsDto.Default),
        Layout: dto.Layout
    );

    private static StreamPaneSettings FromPaneDto(StreamPaneSettingsDto dto) => new(
        RtspUrl: dto.RtspUrl ?? string.Empty,
        Username: dto.Username,
        EncryptedPassword: dto.EncryptedPassword,
        Transport: dto.Transport,
        OnvifEndpointUrl: dto.OnvifEndpointUrl,
        OnvifUsername: dto.OnvifUsername,
        OnvifEncryptedPassword: dto.OnvifEncryptedPassword
    );
}

// ─── JSON DTO（内部使用）─────────────────────────────────────────

/// <summary>設定ファイルの JSON 構造（アプリ設定）</summary>
internal sealed record AppSettingsDto(
    StreamPaneSettingsDto? Pane1,
    StreamPaneSettingsDto? Pane2,
    DualPaneLayout Layout
);

/// <summary>設定ファイルの JSON 構造（ペイン設定）</summary>
internal sealed record StreamPaneSettingsDto(
    string? RtspUrl,
    string? Username,
    string? EncryptedPassword,
    RtspTransport Transport,
    string? OnvifEndpointUrl,
    string? OnvifUsername,
    string? OnvifEncryptedPassword
)
{
    /// <summary>デフォルトのペイン DTO</summary>
    public static StreamPaneSettingsDto Default => new(
        RtspUrl: string.Empty,
        Username: null,
        EncryptedPassword: null,
        Transport: RtspTransport.Tcp,
        OnvifEndpointUrl: null,
        OnvifUsername: null,
        OnvifEncryptedPassword: null
    );
}
