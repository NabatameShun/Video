// 設定データモデル
// タスク 1.3: アプリ設定・ペイン設定レコードの定義

namespace View_RTSP.Models;

/// <summary>
/// 各ペインの接続設定を保持するレコード
/// </summary>
/// <param name="RtspUrl">RTSP ストリーム URL</param>
/// <param name="Username">RTSP 認証ユーザー名</param>
/// <param name="EncryptedPassword">DPAPI で暗号化された RTSP パスワード（Base64）</param>
/// <param name="Transport">RTSP トランスポートプロトコル</param>
/// <param name="OnvifEndpointUrl">ONVIF デバイスサービスの URL</param>
/// <param name="OnvifUsername">ONVIF 認証ユーザー名</param>
/// <param name="OnvifEncryptedPassword">DPAPI で暗号化された ONVIF パスワード（Base64）</param>
public record StreamPaneSettings(
    string RtspUrl,
    string? Username,
    string? EncryptedPassword,
    RtspTransport Transport,
    string? OnvifEndpointUrl,
    string? OnvifUsername,
    string? OnvifEncryptedPassword
)
{
    /// <summary>デフォルトのペイン設定（空の URL、TCP トランスポート）</summary>
    public static StreamPaneSettings Default => new(
        RtspUrl: string.Empty,
        Username: null,
        EncryptedPassword: null,
        Transport: RtspTransport.Tcp,
        OnvifEndpointUrl: null,
        OnvifUsername: null,
        OnvifEncryptedPassword: null
    );
}

/// <summary>
/// アプリケーション全体の設定を保持するレコード
/// </summary>
/// <param name="Pane1">左（または上）ペインの設定</param>
/// <param name="Pane2">右（または下）ペインの設定</param>
/// <param name="Layout">デュアルペインのレイアウト種別</param>
public record AppSettings(
    StreamPaneSettings Pane1,
    StreamPaneSettings Pane2,
    DualPaneLayout Layout
)
{
    /// <summary>デフォルトのアプリ設定（空の設定・水平レイアウト）</summary>
    public static AppSettings Default => new(
        Pane1: StreamPaneSettings.Default,
        Pane2: StreamPaneSettings.Default,
        Layout: DualPaneLayout.Horizontal
    );
}
