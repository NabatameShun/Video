// ドメインモデル・列挙型・共有データ構造
// タスク 1.2: 接続状態・RTSP 接続オプション・エラー情報・統計情報・ONVIF 設定・PTZ 方向・レイアウト

namespace View_RTSP.Models;

// ─── 接続状態 ────────────────────────────────────────────────────

/// <summary>
/// RTSP ストリームの接続状態を表す列挙型
/// </summary>
public enum ConnectionState
{
    /// <summary>未接続</summary>
    Disconnected,
    /// <summary>接続中</summary>
    Connecting,
    /// <summary>接続済み（映像受信中）</summary>
    Connected,
    /// <summary>エラー発生</summary>
    Error
}

// ─── RTSP トランスポート ──────────────────────────────────────────

/// <summary>
/// RTSP トランスポートプロトコルを表す列挙型
/// </summary>
public enum RtspTransport
{
    /// <summary>TCP トランスポート（安定性優先）</summary>
    Tcp,
    /// <summary>UDP トランスポート（低遅延優先）</summary>
    Udp
}

// ─── エラー種別 ───────────────────────────────────────────────────

/// <summary>
/// RTSP 接続・デコードエラーの種別を表す列挙型
/// </summary>
public enum RtspErrorKind
{
    /// <summary>接続タイムアウト</summary>
    ConnectionTimeout,
    /// <summary>認証失敗（401 Unauthorized 相当）</summary>
    AuthenticationFailed,
    /// <summary>ネットワーク不達</summary>
    NetworkUnreachable,
    /// <summary>デコードエラー</summary>
    DecodeError,
    /// <summary>不明なエラー</summary>
    UnknownError
}

// ─── RTSP 接続オプション ──────────────────────────────────────────

/// <summary>
/// RTSP 接続に必要なオプションを保持する不変レコード
/// </summary>
/// <param name="Url">RTSP URL（rtsp:// スキームで始まる必要がある）</param>
/// <param name="Username">認証ユーザー名（認証不要の場合は null）</param>
/// <param name="Password">認証パスワード（認証不要の場合は null）</param>
/// <param name="Transport">トランスポートプロトコル（TCP / UDP）</param>
/// <param name="LowLatencyMode">低遅延モード（fflags=nobuffer, flags=low_delay を有効化）</param>
public readonly record struct RtspConnectionOptions(
    string Url,
    string? Username,
    string? Password,
    RtspTransport Transport,
    bool LowLatencyMode
);

// ─── エラー詳細 ───────────────────────────────────────────────────

/// <summary>
/// RTSP エラーの詳細情報を保持するレコード
/// </summary>
/// <param name="Kind">エラー種別</param>
/// <param name="Message">ユーザー向けエラーメッセージ</param>
/// <param name="FfmpegErrorCode">FFmpeg エラーコード（該当する場合）</param>
public readonly record struct RtspError(
    RtspErrorKind Kind,
    string Message,
    int? FfmpegErrorCode
);

// ─── ストリーム状態変化イベント引数 ──────────────────────────────

/// <summary>
/// RTSP ストリーム状態変化イベントの引数
/// </summary>
/// <param name="State">新しい接続状態</param>
/// <param name="Error">エラー情報（エラー状態の場合のみ設定）</param>
public sealed class StreamStateChangedEventArgs : EventArgs
{
    /// <summary>新しい接続状態</summary>
    public ConnectionState State { get; }

    /// <summary>エラー情報（エラー状態の場合のみ設定、それ以外は null）</summary>
    public RtspError? Error { get; }

    public StreamStateChangedEventArgs(ConnectionState state, RtspError? error = null)
    {
        State = state;
        Error = error;
    }
}

// ─── 接続統計情報 ─────────────────────────────────────────────────

/// <summary>
/// RTSP ストリームの接続統計情報を保持するレコード
/// </summary>
/// <param name="FrameRate">直近 5 秒の平均フレームレート（fps）</param>
/// <param name="ReceivedFrames">受信済みフレーム総数</param>
/// <param name="Uptime">接続継続時間</param>
public readonly record struct ConnectionStats(
    double FrameRate,
    long ReceivedFrames,
    TimeSpan Uptime
);

// ─── ONVIF 接続オプション ─────────────────────────────────────────

/// <summary>
/// ONVIF PTZ サービスへの接続オプションを保持するレコード
/// </summary>
/// <param name="EndpointUrl">ONVIF デバイスサービスのエンドポイント URL</param>
/// <param name="Username">認証ユーザー名</param>
/// <param name="Password">認証パスワード</param>
/// <param name="ProfileToken">
/// PTZ プロファイルトークン（null の場合は GetProfiles() で最初のプロファイルを自動選択）
/// </param>
public readonly record struct OnvifConnectionOptions(
    string EndpointUrl,
    string Username,
    string Password,
    string? ProfileToken
);

// ─── PTZ 方向 ─────────────────────────────────────────────────────

/// <summary>
/// PTZ カメラの移動方向を表す列挙型（8 方向）
/// </summary>
public enum PtzDirection
{
    /// <summary>上</summary>
    Up,
    /// <summary>下</summary>
    Down,
    /// <summary>左</summary>
    Left,
    /// <summary>右</summary>
    Right,
    /// <summary>左上</summary>
    UpLeft,
    /// <summary>右上</summary>
    UpRight,
    /// <summary>左下</summary>
    DownLeft,
    /// <summary>右下</summary>
    DownRight
}

// ─── 録画状態 ───────────────────────────────────────────────────

/// <summary>
/// 録画状態を表す列挙型
/// </summary>
public enum RecordingState
{
    /// <summary>録画停止中</summary>
    Idle,
    /// <summary>録画中</summary>
    Recording,
    /// <summary>録画停止処理中（WriteTrailer 完了待ち）</summary>
    Stopping
}

// ─── 録画エラー種別 ─────────────────────────────────────────────

/// <summary>
/// 録画エラーの種別を表す列挙型
/// </summary>
public enum RecordingErrorKind
{
    /// <summary>ディスク書き込みエラー</summary>
    DiskWriteError,
    /// <summary>書き込み権限エラー</summary>
    PermissionDenied,
    /// <summary>フォルダ作成失敗</summary>
    DirectoryCreationFailed
}

// ─── 録画エラーイベント引数 ─────────────────────────────────────

/// <summary>
/// 録画エラーイベントの引数
/// </summary>
public sealed class RecordingErrorEventArgs : EventArgs
{
    /// <summary>エラー種別</summary>
    public RecordingErrorKind Kind { get; }

    /// <summary>ユーザー向けエラーメッセージ</summary>
    public string Message { get; }

    public RecordingErrorEventArgs(RecordingErrorKind kind, string message)
    {
        Kind = kind;
        Message = message;
    }
}

// ─── デュアルペインレイアウト（後方互換用）──────────────────────────

/// <summary>
/// デュアルペインの分割方向を表す列挙型。
/// 3ペイン・タブレイアウトへの移行により廃止。設定ファイルの後方互換デシリアライズのために残す。
/// </summary>
[Obsolete("Use SelectedTabIndex instead")]
public enum DualPaneLayout
{
    /// <summary>水平分割（左右）</summary>
    Horizontal,
    /// <summary>垂直分割（上下）</summary>
    Vertical
}
