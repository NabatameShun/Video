// App.xaml.cs: アプリケーションエントリーポインチE
// タスク 8.3: MainWindowViewModel を絁E��立て、MainWindow の DataContext へ設定すめE
// タスク 9: グローバル例外ハンドリング・FFmpeg DLL チェチE��・最小起動リソース管琁E
// Requirements: 3.5, 4.2, 4.5

using System.Windows;
using System.Diagnostics;
using System.Windows.Threading;
using System.IO;
using System.Text;
using Sdcb.FFmpeg.Raw;
using Sdcb.FFmpeg.Utils;
using View_RTSP.Models;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP;

/// <summary>
/// アプリケーションのエントリーポイント、E
/// 依存サービスの絁E��立て、FFmpeg DLL チェチE��、MainWindowViewModel の DI 設定を行う、E
/// </summary>
public partial class App : Application
{
    // ─── サービスインスタンス ─────────────────────────────────────
    private readonly IApplicationErrorHandler _errorHandler = new ApplicationErrorHandler();
    private readonly IFfmpegDllChecker _dllChecker = new FfmpegDllChecker();

    // ─── アプリケーション起勁E─────────────────────────────────────

    /// <summary>
    /// アプリケーション起動時の処琁E��E
    /// FFmpeg DLL チェチE��を�E行実施し、依存サービスを絁E��立てて
    /// MainWindow の DataContext へ ViewModel を設定する、E
    /// </summary>
    private void OnStartup(object sender, StartupEventArgs e)
    {
        // グローバル例外ハンドラーを登録�E�Eequirements: 4.5�E�E
        DispatcherUnhandledException += App_DispatcherUnhandledException;

        // ─── FFmpeg DLL 存在チェチE���E�Eequirements: 4.2�E�──────────
        // 欠如してぁE��場合�E早期に明確なエラーメチE��ージを表示して終亁E��めE
        if (!_dllChecker.CheckDllsExist())
        {
            var errorMessage = _dllChecker.GetErrorMessage();
            MessageBox.Show(
                errorMessage,
                "起動エラー: FFmpeg DLL が見つかりません",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Shutdown(1);
            return;
        }

        // ─── ログ設定 ────────────────────────────────────────────
        // 実行ディレクトリ配下の log/ フォルダに日付ローテーションで出力
        var logDirectory = Path.Combine(AppContext.BaseDirectory, "log");
        var today = DateTime.Now.ToString("yyyyMMdd");

        // アプリログ: app_YYYYMMDD.log
        var appLogPath = Path.Combine(logDirectory, $"app_{today}.log");
        var appListener = new TimestampedFileTraceListener(appLogPath);
        Trace.Listeners.Add(appListener);
        Trace.AutoFlush = true;

        AppLogger.Info("=== アプリケーション起動 ===");
        AppLogger.Info($"実行ディレクトリ: {AppContext.BaseDirectory}");
        AppLogger.Info($"ログディレクトリ: {logDirectory}");

        // FFmpeg ログ: ffmpeg_YYYYMMDD.log（Warning 以上のみ出力）
        var ffmpegLogPath = Path.Combine(logDirectory, $"ffmpeg_{today}.log");
        Directory.CreateDirectory(logDirectory);
        var ffmpegLogWriter = new StreamWriter(ffmpegLogPath, append: true, new System.Text.UTF8Encoding(false))
        {
            AutoFlush = true
        };
        var ffmpegLock = new object();
        FFmpegLogger.LogLevel = LogLevel.Warning;
        FFmpegLogger.LogWriter = (level, message) =>
        {
            if (string.IsNullOrWhiteSpace(message))
                return;
            lock (ffmpegLock)
                ffmpegLogWriter.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [{level,-7}] {message.TrimEnd()}");
        };
// ─── 依存サービスの絁E��立て ─────────────────────────────
        // 注: RtspStreamService は吁E�Eインで接続操作が行われるまで RTSP 接続を開始しなぁE
        // �E�要件 4.2: 起動後�E接続操作まで最小リソース消費�E�E

        var settingsService = new SettingsService();
        var onvifService = new OnvifPtzService();

        // ペイン1 用サービス�E�接続前は征E��状態�Eみ、RTSP サービスは起動しなぁE��E
        var renderer1 = new VideoFrameRenderer(Current.Dispatcher);
        var rtspService1 = new RtspStreamService(renderer1);

        // ペイン2 用サービス�E�接続前は征E��状態�Eみ、RTSP サービスは起動しなぁE��E
        var renderer2 = new VideoFrameRenderer(Current.Dispatcher);
        var rtspService2 = new RtspStreamService(renderer2);

        // ペイン3 用サービス（接続前は静止状態のみ、RTSP サービスは起動しない）
        var renderer3 = new VideoFrameRenderer(Current.Dispatcher);
        var rtspService3 = new RtspStreamService(renderer3);

        // ─── 録画サービスの組み立て（ペインごとに独立インスタンス）────
        // Requirements: 1.5（ペインごとに独立した録画制御）

        var recordingService1 = new RecordingService();
        var recordingService2 = new RecordingService();
        var recordingService3 = new RecordingService();

        // アプリケーション終了時の後処理（ログ書き込みを最後に解放する）
        // 順序: RecordingService → FFmpegLogger停止 → ファイルライター解放
        Exit += (_, __) =>
        {
            AppLogger.Info("=== アプリケーション終了 ===");
            recordingService1.Dispose();
            recordingService2.Dispose();
            recordingService3.Dispose();
            // FFmpeg ログコールバックを先に無効化してから StreamWriter を閉じる
            FFmpegLogger.LogWriter = null;
            ffmpegLogWriter.Dispose();
            appListener.Dispose();
        };

        // ─── ViewModel の組み立て ───────────────────────────────

        var pane1Vm = new StreamPaneViewModel(rtspService1, renderer1, onvifService, settingsService, recordingService1) { CameraLabel = "cam1" };
        var pane2Vm = new StreamPaneViewModel(rtspService2, renderer2, onvifService, settingsService, recordingService2) { CameraLabel = "cam2" };
        var pane3Vm = new StreamPaneViewModel(rtspService3, renderer3, onvifService, settingsService, recordingService3) { CameraLabel = "cam3" };
        var mainVm = new MainWindowViewModel(pane1Vm, pane2Vm, pane3Vm, settingsService);

        // 起動時に設定を読み込む（Requirements: 4.6）
        mainVm.LoadSettings();

        // 自動接続: AutoConnect が有効なペインを起動直後に接続
        if (pane1Vm.AutoConnect && pane1Vm.IsUrlValid())
        {
            AppLogger.Info($"[cam1] AutoConnect: {pane1Vm.RtspUrl}");
            _ = pane1Vm.ConnectAsync();
        }
        if (pane2Vm.AutoConnect && pane2Vm.IsUrlValid())
        {
            AppLogger.Info($"[cam2] AutoConnect: {pane2Vm.RtspUrl}");
            _ = pane2Vm.ConnectAsync();
        }
        if (pane3Vm.AutoConnect && pane3Vm.IsUrlValid())
        {
            AppLogger.Info($"[cam3] AutoConnect: {pane3Vm.RtspUrl}");
            _ = pane3Vm.ConnectAsync();
        }

        // 前回クラッシュ時に残った一時録画ファイルをバックグラウンドで処理
        // .mp4.remux → 削除、.tmp.mp4 → リミューダックスして通常 MP4 へ変換
        _ = RecordingService.CleanupOrphanedFilesAsync(new[]
        {
            pane1Vm.RecordingFolderPath,
            pane2Vm.RecordingFolderPath,
            pane3Vm.RecordingFolderPath,
            AppSettings.Default.RecordingFolderPath,
        });

        // ─── MainWindow の設定 ───────────────────────────────────

        var mainWindow = new MainWindow
        {
            DataContext = mainVm
        };
        MainWindow = mainWindow;
        mainWindow.Show();
    }

    // ─── グローバル例外ハンドラー ─────────────────────────────────

    /// <summary>
    /// DispatcherUnhandledException ハンドラー、E
    /// 未処琁E��外をキャチE��してユーザーへダイアログで通知する�E�Eequirements: 4.5�E�、E
    /// アプリケーションをクラチE��ュさせず、継続また�E終亁E��選択できるようにする�E�Eequirements: 3.5�E�、E
    /// </summary>
    private void App_DispatcherUnhandledException(
        object sender,
        DispatcherUnhandledExceptionEventArgs e)
    {
        var exception = e.Exception;

        // 致命皁E��外�E場合�E強制終亁E��めE
        if (_errorHandler.ShouldTerminate(exception))
        {
            e.Handled = true;
            MessageBox.Show(
                $"致命皁E��エラーが発生したため、アプリケーションを終亁E��ます、En\n{exception.Message}",
                "致命皁E��ラー",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Shutdown(1);
            return;
        }

        // 通常の例外�Eユーザーに継続か終亁E��を選択させる
        var userMessage = _errorHandler.FormatUserMessage(exception);
        var result = MessageBox.Show(
            userMessage,
            "エラー",
            MessageBoxButton.YesNo,
            MessageBoxImage.Error);

        if (result == MessageBoxResult.Yes)
        {
            // 例外を処琁E��みとしてアプリケーションを継続すめE
            e.Handled = true;
        }
        else
        {
            // アプリケーションを終亁E��めE
            e.Handled = true;
            Shutdown(1);
        }
    }
}




