// App.xaml.cs: アプリケーションエントリーポイント
// タスク 8.3: MainWindowViewModel を組み立て、MainWindow の DataContext へ設定する
// タスク 9: グローバル例外ハンドリング・FFmpeg DLL チェック・最小起動リソース管理
// Requirements: 3.5, 4.2, 4.5

using System.Windows;
using System.Windows.Threading;
using View_RTSP.Services;
using View_RTSP.ViewModels;

namespace View_RTSP;

/// <summary>
/// アプリケーションのエントリーポイント。
/// 依存サービスの組み立て、FFmpeg DLL チェック、MainWindowViewModel の DI 設定を行う。
/// </summary>
public partial class App : Application
{
    // ─── サービスインスタンス ─────────────────────────────────────
    private readonly IApplicationErrorHandler _errorHandler = new ApplicationErrorHandler();
    private readonly IFfmpegDllChecker _dllChecker = new FfmpegDllChecker();

    // ─── アプリケーション起動 ─────────────────────────────────────

    /// <summary>
    /// アプリケーション起動時の処理。
    /// FFmpeg DLL チェックを先行実施し、依存サービスを組み立てて
    /// MainWindow の DataContext へ ViewModel を設定する。
    /// </summary>
    private void OnStartup(object sender, StartupEventArgs e)
    {
        // グローバル例外ハンドラーを登録（Requirements: 4.5）
        DispatcherUnhandledException += App_DispatcherUnhandledException;

        // ─── FFmpeg DLL 存在チェック（Requirements: 4.2）──────────
        // 欠如している場合は早期に明確なエラーメッセージを表示して終了する
        if (!_dllChecker.CheckDllsExist())
        {
            var errorMessage = _dllChecker.GetErrorMessage();
            MessageBox.Show(
                errorMessage,
                "起動エラー: FFmpeg DLL が見つかりません",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Shutdown(1);
            return;
        }

        // ─── 依存サービスの組み立て ─────────────────────────────
        // 注: RtspStreamService は各ペインで接続操作が行われるまで RTSP 接続を開始しない
        // （要件 4.2: 起動後は接続操作まで最小リソース消費）

        var settingsService = new SettingsService();
        var onvifService = new OnvifPtzService();

        // ペイン1 用サービス（接続前は待機状態のみ、RTSP サービスは起動しない）
        var renderer1 = new VideoFrameRenderer(Current.Dispatcher);
        var rtspService1 = new RtspStreamService(renderer1);

        // ペイン2 用サービス（接続前は待機状態のみ、RTSP サービスは起動しない）
        var renderer2 = new VideoFrameRenderer(Current.Dispatcher);
        var rtspService2 = new RtspStreamService(renderer2);

        // ─── ViewModel の組み立て ───────────────────────────────

        var pane1Vm = new StreamPaneViewModel(rtspService1, renderer1, onvifService, settingsService);
        var pane2Vm = new StreamPaneViewModel(rtspService2, renderer2, onvifService, settingsService);
        var mainVm = new MainWindowViewModel(pane1Vm, pane2Vm, settingsService);

        // 起動時に設定を読み込む（Requirements: 4.6）
        mainVm.LoadSettings();

        // ─── MainWindow の設定 ───────────────────────────────────

        var mainWindow = new MainWindow
        {
            DataContext = mainVm
        };
        MainWindow = mainWindow;
        mainWindow.Show();
    }

    // ─── グローバル例外ハンドラー ─────────────────────────────────

    /// <summary>
    /// DispatcherUnhandledException ハンドラー。
    /// 未処理例外をキャッチしてユーザーへダイアログで通知する（Requirements: 4.5）。
    /// アプリケーションをクラッシュさせず、継続または終了を選択できるようにする（Requirements: 3.5）。
    /// </summary>
    private void App_DispatcherUnhandledException(
        object sender,
        DispatcherUnhandledExceptionEventArgs e)
    {
        var exception = e.Exception;

        // 致命的例外の場合は強制終了する
        if (_errorHandler.ShouldTerminate(exception))
        {
            e.Handled = true;
            MessageBox.Show(
                $"致命的なエラーが発生したため、アプリケーションを終了します。\n\n{exception.Message}",
                "致命的エラー",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Shutdown(1);
            return;
        }

        // 通常の例外はユーザーに継続か終了かを選択させる
        var userMessage = _errorHandler.FormatUserMessage(exception);
        var result = MessageBox.Show(
            userMessage,
            "エラー",
            MessageBoxButton.YesNo,
            MessageBoxImage.Error);

        if (result == MessageBoxResult.Yes)
        {
            // 例外を処理済みとしてアプリケーションを継続する
            e.Handled = true;
        }
        else
        {
            // アプリケーションを終了する
            e.Handled = true;
            Shutdown(1);
        }
    }
}
