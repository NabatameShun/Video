using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using Sdcb.FFmpeg.Codecs;
using Sdcb.FFmpeg.Common;
using Sdcb.FFmpeg.Formats;
using Sdcb.FFmpeg.Raw;
using Sdcb.FFmpeg.Swscales;
using Sdcb.FFmpeg.Utils;
using View_RTSP.Models;

namespace View_RTSP.Services;

public sealed class RtspStreamService : IRtspStreamService, IDisposable
{
	private const int MaxRetryCount = 3;

	private const int RetryDelayMs = 500;

	private const int FrameRateWindowSeconds = 5;

	private const int StatsUpdateIntervalMs = 1000;

	private readonly IVideoFrameRenderer _renderer;

	private volatile ConnectionState _state = ConnectionState.Disconnected;

	private CancellationTokenSource? _decodeCts;

	private Task? _decodeTask;

	private DateTime _connectedAt;

	private long _receivedFrames;

	private readonly ConcurrentQueue<DateTime> _frameTimestamps = new ConcurrentQueue<DateTime>();

	private readonly object _stateLock = new object();

	private volatile bool _disposed;

	public ConnectionState State => _state;

	public event EventHandler<StreamStateChangedEventArgs>? StateChanged;

	public event EventHandler<ConnectionStats>? StatsUpdated;

	public RtspStreamService(IVideoFrameRenderer renderer)
	{
		_renderer = renderer ?? throw new ArgumentNullException("renderer");
	}

	public async Task ConnectAsync(RtspConnectionOptions options, CancellationToken cancellationToken = default(CancellationToken))
	{
		if (!_disposed)
		{
			cancellationToken.ThrowIfCancellationRequested();
			Disconnect();
			_state = ConnectionState.Connecting;
			RaiseStateChanged(ConnectionState.Connecting);
			_decodeCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
			CancellationToken token = _decodeCts.Token;
			_decodeTask = Task.Factory.StartNew(() => DecodeLoopWithRetryAsync(options, token), CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default).Unwrap();
			await Task.CompletedTask;
		}
	}

	public void Disconnect()
	{
		if (_disposed)
		{
			return;
		}
		lock (_stateLock)
		{
			try
			{
				_decodeCts?.Cancel();
			}
			catch (ObjectDisposedException)
			{
			}
			_decodeTask = null;
			try
			{
				_decodeCts?.Dispose();
			}
			catch (ObjectDisposedException)
			{
			}
			_decodeCts = null;
		}
		_renderer.Clear();
		if (_state != ConnectionState.Disconnected)
		{
			_state = ConnectionState.Disconnected;
			RaiseStateChanged(ConnectionState.Disconnected);
		}
	}

	private async Task DecodeLoopWithRetryAsync(RtspConnectionOptions options, CancellationToken token)
	{
		int retryCount = 0;
		while (!token.IsCancellationRequested)
		{
			try
			{
				await Task.Run(delegate
				{
					RunDecodeLoopSync(options, token);
				}, token);
			}
			catch (OperationCanceledException)
			{
			}
			catch (RtspConnectionException ex2) when (retryCount < 3)
			{
				retryCount++;
				RaiseStateChanged(ConnectionState.Connecting, new RtspError(ex2.ErrorKind, $"繝・さ繝ｼ繝峨お繝ｩ繝ｼ縺檎匱逕溘＠縺ｾ縺励◆縲ょ・隧ｦ陦御ｸｭ... ({retryCount}/{3}): {ex2.Message}", ex2.FfmpegErrorCode));
				try
				{
					await Task.Delay(500, token);
				}
				catch (OperationCanceledException)
				{
					goto end_IL_02a0;
				}
				continue;
				end_IL_02a0:;
			}
			catch (Exception ex4) when (retryCount < 3)
			{
				retryCount++;
				RtspErrorKind errorKind = ClassifyException(ex4);
				RaiseStateChanged(ConnectionState.Connecting, new RtspError(errorKind, $"繝・さ繝ｼ繝峨お繝ｩ繝ｼ縺檎匱逕溘＠縺ｾ縺励◆縲ょ・隧ｦ陦御ｸｭ... ({retryCount}/{3}): {ex4.Message}", null));
				try
				{
					await Task.Delay(500, token);
				}
				catch (OperationCanceledException)
				{
					goto end_IL_03ce;
				}
				continue;
				end_IL_03ce:;
			}
			catch (RtspConnectionException ex6)
			{
				RtspConnectionException rtspEx = ex6;
				RaiseStateChanged(ConnectionState.Disconnected, new RtspError(rtspEx.ErrorKind, "繧ｹ繝医Μ繝ｼ繝\uf8f0縺悟・譁ｭ縺輔ｌ縺ｾ縺励◆縲ょ・謗･邯壹〒縺阪∪縺帙ｓ縺ｧ縺励◆: " + rtspEx.Message, rtspEx.FfmpegErrorCode));
				_renderer.Clear();
				return;
			}
			catch (Exception ex7)
			{
				Exception ex8 = ex7;
				RtspErrorKind errorKind2 = ClassifyException(ex8);
				RaiseStateChanged(ConnectionState.Disconnected, new RtspError(errorKind2, "繧ｹ繝医Μ繝ｼ繝\uf8f0縺悟・譁ｭ縺輔ｌ縺ｾ縺励◆縲ょ・謗･邯壹〒縺阪∪縺帙ｓ縺ｧ縺励◆: " + ex8.Message, null));
				_renderer.Clear();
				return;
			}
			break;
		}
		if (!_disposed && _state != ConnectionState.Disconnected)
		{
			_state = ConnectionState.Disconnected;
			RaiseStateChanged(ConnectionState.Disconnected);
			_renderer.Clear();
		}
	}

	private unsafe void RunDecodeLoopSync(RtspConnectionOptions options, CancellationToken token)
	{
		token.ThrowIfCancellationRequested();
		using MediaDictionary mediaDictionary = BuildFormatOptions(options);
		string url = BuildRtspUrl(options);
		FormatContext formatContext = null;
		try
		{
			try
			{
				MediaDictionary options2 = mediaDictionary;
				formatContext = FormatContext.OpenInputUrl(url, null, options2);
			}
			catch (FFmpegException ex)
			{
				RtspErrorKind errorKind = ClassifyFfmpegErrorFromMessage(ex.Message);
				throw new RtspConnectionException(errorKind, ex.Message, null, ex);
			}
			formatContext.LoadStreamInfo();
			MediaStream? mediaStream = formatContext.FindBestStreamOrNull(AVMediaType.Video);
			if (!mediaStream.HasValue)
			{
				throw new RtspConnectionException(RtspErrorKind.UnknownError, "No video stream found.", null);
			}
			MediaStream value = mediaStream.Value;
			using CodecContext codecContext = new CodecContext(Codec.FindDecoderById(value.Codecpar.CodecId));
			codecContext.FillParameters(value.Codecpar);
			codecContext.Open();
			_connectedAt = DateTime.UtcNow;
			Interlocked.Exchange(ref _receivedFrames, 0L);
			_frameTimestamps.Clear();
			RaiseStateChanged(ConnectionState.Connected);
			using (new Timer(OnStatsTimerTick, null, 1000, 1000))
			{
				using VideoFrameConverter videoFrameConverter = new VideoFrameConverter();
				using Frame frame = new Frame();
				Frame frame2 = null;
				int num = 0;
				int num2 = 0;
				try
				{
					foreach (Packet item in formatContext.ReadPackets(value.Index))
					{
						token.ThrowIfCancellationRequested();
						try
						{
							codecContext.SendPacket(item);
						}
						catch (FFmpegException)
						{
							continue;
						}
						while (true)
						{
							CodecResult codecResult;
							try
							{
								codecResult = codecContext.ReceiveFrame(frame);
							}
							catch (FFmpegException ex3)
							{
								throw new RtspConnectionException(RtspErrorKind.DecodeError, "繝輔Ξ繝ｼ繝\uf8f0繝・さ繝ｼ繝峨お繝ｩ繝ｼ: " + ex3.Message, null, ex3);
							}
							int width;
							int height;
							switch (codecResult)
							{
							case CodecResult.EOF:
								return;
							default:
								width = frame.Width;
								height = frame.Height;
								if (frame2 == null || width != num || height != num2)
								{
									frame2?.Dispose();
									frame2 = Frame.CreateVideo(width, height, AVPixelFormat.Bgra);
									num = width;
									num2 = height;
								}
								goto IL_0247;
							case CodecResult.Again:
								break;
							}
							break;
							IL_0247:
							videoFrameConverter.ConvertFrame(frame, frame2);
							int length = width * height * 4;
							ReadOnlySpan<byte> bgraData = new ReadOnlySpan<byte>((void*)frame2.Data[0], length);
							_renderer.RenderFrame(bgraData, width, height);
							Interlocked.Increment(ref _receivedFrames);
							RecordFrameTimestamp();
						}
					}
				}
				finally
				{
					frame2?.Dispose();
				}
			}
		}
		catch (RtspConnectionException)
		{
			throw;
		}
		catch (OperationCanceledException)
		{
			throw;
		}
		catch (FFmpegException ex6)
		{
			RtspErrorKind errorKind2 = ClassifyFfmpegErrorFromMessage(ex6.Message);
			throw new RtspConnectionException(errorKind2, ex6.Message, null, ex6);
		}
		catch (Exception ex7)
		{
			throw new RtspConnectionException(RtspErrorKind.UnknownError, ex7.Message, null, ex7);
		}
		finally
		{
			formatContext?.Dispose();
		}
	}

	private static MediaDictionary BuildFormatOptions(RtspConnectionOptions options)
	{
		MediaDictionary mediaDictionary = new MediaDictionary();
		string value = ((options.Transport == RtspTransport.Tcp) ? "tcp" : "udp");
		mediaDictionary["rtsp_transport"] = value;
		if (options.LowLatencyMode)
		{
			mediaDictionary["fflags"] = "nobuffer";
			mediaDictionary["flags"] = "low_delay";
			mediaDictionary["max_delay"] = "0";
			mediaDictionary["analyzeduration"] = "0";
			mediaDictionary["probesize"] = "32";
		}
		mediaDictionary["rw_timeout"] = "5000000";
		mediaDictionary["stimeout"] = "5000000";
		return mediaDictionary;
	}

	private static string BuildRtspUrl(RtspConnectionOptions options)
	{
		if (string.IsNullOrEmpty(options.Username))
		{
			return options.Url;
		}
		Uri uri = new Uri(options.Url);
		string value = (string.IsNullOrEmpty(options.Password) ? Uri.EscapeDataString(options.Username) : (Uri.EscapeDataString(options.Username) + ":" + Uri.EscapeDataString(options.Password ?? string.Empty)));
		string value2 = (uri.IsDefaultPort ? string.Empty : $":{uri.Port}");
		return $"{uri.Scheme}://{value}@{uri.Host}{value2}{uri.PathAndQuery}";
	}

	private void RecordFrameTimestamp()
	{
		DateTime utcNow = DateTime.UtcNow;
		_frameTimestamps.Enqueue(utcNow);
		DateTime dateTime = utcNow.AddSeconds(-5.0);
		DateTime result;
		while (_frameTimestamps.TryPeek(out result) && result < dateTime)
		{
			_frameTimestamps.TryDequeue(out var _);
		}
	}

	private double CalculateFrameRate()
	{
		int count = _frameTimestamps.Count;
		if (count < 2)
		{
			return 0.0;
		}
		return (double)count / 5.0;
	}

	private void OnStatsTimerTick(object? state)
	{
		if (!_disposed && _state == ConnectionState.Connected)
		{
			ConnectionStats e = new ConnectionStats(CalculateFrameRate(), Interlocked.Read(in _receivedFrames), DateTime.UtcNow - _connectedAt);
			this.StatsUpdated?.Invoke(this, e);
		}
	}

	private static RtspErrorKind ClassifyFfmpegErrorFromMessage(string message)
	{
		if (string.IsNullOrEmpty(message))
		{
			return RtspErrorKind.UnknownError;
		}
		string text = message.ToLowerInvariant();
		if (text.Contains("401") || text.Contains("unauthorized") || text.Contains("forbidden") || text.Contains("access denied") || text.Contains("permission denied") || text.Contains("authentication"))
		{
			return RtspErrorKind.AuthenticationFailed;
		}
		if (text.Contains("timeout") || text.Contains("timed out") || text.Contains("etimedout"))
		{
			return RtspErrorKind.ConnectionTimeout;
		}
		if (text.Contains("connection refused") || text.Contains("network unreachable") || text.Contains("host unreachable") || text.Contains("no route to host") || text.Contains("econnrefused") || text.Contains("enetunreach") || text.Contains("ehostunreach"))
		{
			return RtspErrorKind.NetworkUnreachable;
		}
		return RtspErrorKind.UnknownError;
	}

	private static RtspErrorKind ClassifyException(Exception ex)
	{
		if (1 == 0)
		{
		}
		RtspErrorKind result = ((ex is RtspConnectionException ex2) ? ex2.ErrorKind : ((ex is FFmpegException ex3) ? ClassifyFfmpegErrorFromMessage(ex3.Message) : ((!(ex is OperationCanceledException)) ? RtspErrorKind.UnknownError : RtspErrorKind.ConnectionTimeout)));
		if (1 == 0)
		{
		}
		return result;
	}

	private void RaiseStateChanged(ConnectionState state, RtspError? error = null)
	{
		_state = state;
		this.StateChanged?.Invoke(this, new StreamStateChangedEventArgs(state, error));
	}

	public void Dispose()
	{
		if (!_disposed)
		{
			_disposed = true;
			try
			{
				_decodeCts?.Cancel();
			}
			catch (ObjectDisposedException)
			{
			}
			try
			{
				_decodeCts?.Dispose();
			}
			catch (ObjectDisposedException)
			{
			}
			_decodeCts = null;
			_decodeTask = null;
		}
	}
}
