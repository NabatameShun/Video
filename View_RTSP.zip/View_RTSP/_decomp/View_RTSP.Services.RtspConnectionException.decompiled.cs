using System;
using View_RTSP.Models;

namespace View_RTSP.Services;

internal sealed class RtspConnectionException : Exception
{
	public RtspErrorKind ErrorKind { get; }

	public int? FfmpegErrorCode { get; }

	public RtspConnectionException(RtspErrorKind errorKind, string message, int? ffmpegErrorCode, Exception? innerException = null)
		: base(message, innerException)
	{
		ErrorKind = errorKind;
		FfmpegErrorCode = ffmpegErrorCode;
	}
}
